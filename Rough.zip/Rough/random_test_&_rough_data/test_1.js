var b = function(param1) {
    console.log(param1()); // prints " f() {} "
   }
   b(function(){console.log("test")})