const http = require('http');

// Sample data (replace with your own data source)
let users = [
    { id: 1, name: 'John' },
    { id: 2, name: 'Jane' }
];

// Function to handle incoming HTTP requests
const handleRequest = (req, res) => {
    // Set response headers
    res.setHeader('Content-Type', 'application/json');

    // Handle GET requests to /users endpoint
    if (req.method === 'GET' && req.url === '/users') {
        // Return list of users as JSON
        res.end(JSON.stringify(users));
    } 
    // Handle POST requests to /users endpoint
    else if (req.method === 'POST' && req.url === '/users') {   
        let body = '';

        // Collect data from request body
        req.on('data', chunk => {
            body += chunk.toString();
        });

        // Process data once request body is fully received
        req.on('end', () => {
            const newUser = JSON.parse(body);
            // Add new user to the list
            users.push(newUser);
            // Return the newly added user
            res.end(JSON.stringify(newUser));
        });
    } 
    // Handle other endpoints
    else {
        res.statusCode = 404;
        res.end(JSON.stringify({ message: 'Endpoint not found' }));
    }
};

// Create HTTP server and specify request handler function
const server = http.createServer(handleRequest);

// Specify the port for the server to listen on
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

/******
 * first take the method to test
 * 
 * prepare the mock for the particular method return based on the input
 * 
 * then invoke that method will give some result 
 * 
 * After that will do some expection 
 * 
 * 
 * describe("case 1") {
 *   
 *  const spy(dependentmethod).returnvalue([{}, {}]);
 *   
 * 
 * }
 * 
 * 
 * 
 * 
 */