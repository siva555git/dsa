what is hoisting?
what is the output of settimeout ?
what is the clousre with example ?
how to find the duplication in array with its count ?
what is input and output and its syntax in angular ?
what is clustor in node ?
what is event loop in node ?
what to join collections in mongo db ?
how to create image in docker ?
aws experience 
