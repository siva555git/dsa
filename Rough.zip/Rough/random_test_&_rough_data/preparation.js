// Explain the Event Loop in Node.js:
// Describe how the event loop works in Node.js and how it handles asynchronous operations.
// Follow-up: How does Node.js handle concurrency given its single-threaded nature?


const express = require('express');
const app = express();

const loggerMiddleware = (req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
};

app.use(loggerMiddleware);

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});


// Handling Large Files:
// How would you handle uploading and processing large files in a Node.js application?
// Follow-up: Implement a solution using streams to process a large file line by line.

function debounce(func, wait) {
    let timeout;
    return function(...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(this, args), wait);
    };
  }


  function deepClone(obj) {
    if (obj === null || typeof obj !== 'object') {
      return obj;
    }
    if (Array.isArray(obj)) {
      return obj.map(item => deepClone(item));
    }
    const clonedObj = {};
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        clonedObj[key] = deepClone(obj[key]);
      }
    }
    return clonedObj;
  }

//   Asynchronous Programming:
// Explain the difference between callbacks, promises, and async/await in JavaScript.
// Follow-up: Convert a function using callbacks to use promises and then to use async/await.


// Scenario: You are building a real-time chat application. Users should be able to send and receive messages instantly.

// Design the Architecture:
// Describe the architecture of your chat application, including the technologies and frameworks you would use.
// Implement Real-Time Messaging:
// Write a Node.js server using Socket.io to handle real-time messaging.

const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

io.on('connection', (socket) => {
  console.log('a user connected');
  socket.on('chat message', (msg) => {
    io.emit('chat message', msg);
  });
  socket.on('disconnect', () => {
    console.log('user disconnected');
  });
});

server.listen(3000, () => {
  console.log('listening on *:3000');
});

// middleware 

const express = require("express");

const app1 = express();

app.use((req,res,next) => {
    console.log(req,res);
    next();
});
app.get("/", (req,res) => {
    res.send("hello world");
});

app.listen(3000,() =>{

})

const cluster = require('cluster');
const http = require('http');
const numCPUs = require('os').cpus().length;

if (cluster.isMaster) {
  console.log(`Master ${process.pid} is running`);

  // Fork workers
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }

  cluster.on('exit', (worker, code, signal) => {
    console.log(`Worker ${worker.process.pid} died`);
  });
} else {
  // Workers can share any TCP connection
  http.createServer((req, res) => {
    res.writeHead(200);
    res.end('Hello World\n');
  }).listen(8000);

  console.log(`Worker ${process.pid} started`);
}



const express = require('express');
const app2 = express();

const rateLimit = {};
const RATE_LIMIT_WINDOW = 60000; // 1 minute
const MAX_REQUESTS = 10;

const rateLimiter = (req, res, next) => {
  const userIP = req.ip;
  const currentTime = Date.now();

  if (!rateLimit[userIP]) {
    rateLimit[userIP] = [];
  }

  rateLimit[userIP] = rateLimit[userIP].filter(timestamp => currentTime - timestamp < RATE_LIMIT_WINDOW);

  if (rateLimit[userIP].length >= MAX_REQUESTS) {
    return res.status(429).send('Too many requests, please try again later.');
  }

  rateLimit[userIP].push(currentTime);
  next();
};

app2.use(rateLimiter);

app2.get('/', (req, res) => {
  res.send('Hello World!');
});

app2.listen(3000, () => {
  console.log('Server is running on port 3000');
});

// 
process.on("uncaughtException" ,(err) => {

    process.exit(1);
})

setTimeout(() => {
    throw new error("erorr");
}, 100);

import { ChildProcess } from 'child_process';
// events

import { EventEmitter } from 'events';

const eventEmitter = new EventEmitter();

eventEmitter.on("myevent", (data) => {
    console.log(data);
});

eventEmitter.emit("myevent", "data to emit");

// code to create crud in node

const express = require("express");
const crudApp = express();
crudApp.use(express.json());
const users =[]
crudApp.get("/users",(req,res) => {
    res.status().send(users);
});

crudApp.post("createUser", (req,res) => {
    const user = req.body;
    users.push(user);
    res.status(201).send(user);
});

crudApp.put("updateUser/:id", (req,res) => {
    const userid = req.params.id;
    const userToUpdate = user.filter(user => user.id  === userid);
    users.push(user);
    res.send(user);
});

// how to handle the uncaught error message

process.on("uncaughtException",callback)

// difference between the read file and createReadstream
// read file load all into the memory it will not suitable for large files
// createReadstream will load the chunks of memory it will suitable for large files

// Cluster
// cluster allows you to create ChildProcess under same port which lead to multi core system to handle performance and scalablity

// worker threads
// allow to you run the js code in paralled threads this will useful for worker_threads module



// how to secure the nodejs application
// by using https validating and user input sanitzing and env for sensitive data proper error handling and dependency up to date

//  node js is javascript runtime evn build on chrome v8 engine. it use event driven non blocking I/O making it is lightwight and effient for building scalable application

// npm i <package_name>
// npm -g i <package_name>

// node js is single threaded and async

// how does event loop works
// it will handle the async calls it will check the event queue and excutes the callbacks


// package.json is metadata of project includes dependency and version , config and other scripts

// in node js middlware functions are functiona that have access to req and response they modity it if needed and send it another midleware function using next

// eg : logging, rate limit ing and so on 

// how to hndlie async using 

// process.nexttick() // schedule the callback in the current phase of event loop
// process.setimmediate() // schedule the callback in the next iteration  of event loop

// event delegation is adding event to parent and instead of every children to avoid the memory

// worker threads

// main thread looks into event loop and i/o 
// parallel worker thread into cpu intensive work

const {Worker} = require("worker_threads");
const fs = require("fs");


const worker = new Worker("./worker.js");
const imagebuffer = fs.readFileSync("/path/image.png");
worker.on("message", (processedImag) => {
  if(processedImag?.error){
    console.log("error");
  }else{
    fs.writeFileSync("/path/processedImage.png", processedImag);
  }

});

worker.postMessage(imagebuffer);

// worker.js
const {parentPort} = require("worker_threads");
const sharp = require("sharp");

parentPort.on("message", async(imagebuffer) => {
  try{
    const newiamg = await new sharp(imagebuffer).toRezie(30,30).toBuffer;
    parentPort.postMessage(newiamg);
  }catch(error){
    parentPort.postMessage({error: error.message});
  }
});


const cluster = require("cluster");
const http = require("http");
const numCPUsnew = require("os").cpus().length;

if(cluster.isMaster){
  for(let i=0; i< newCPUsnew; i++){
    const worker = cluster.fork();
  }
  cluster.on("exit", (worker,code,signal) )
}

// create http server

const http = require("http");
let usersnew = [];
const requestHandler = (req, res) => {
  res.setHeader("content-Type", "application/json")

  if(req.method === "GET" && req.url === "/users"){
    res.end(JSON.stringify(usersnew))
  }
  if(req.method === "POST" && req.url === "/users"){
    req.on("data", chuck => {
      req.body += chuck.toString();
    });

    req.on("end", body => {
      
      users.push(JSON.parse(body));
      res.end(JSON.stringify(usersnew));
    });
  }
  else {
    res.statusCode = 404;
    res.end(JSON.stringify({ message: 'Endpoint not found' }));
  }
};

const server1 = http.createServer(requestHandler);

const port = process.env.port || 3000;
server1.listen(port, () =>{

});

// some important middleware
// logging
// authentication
// error handler
// body parser
// cors
// server static files

const authentication = (req, res, next) =>{
  if(req.header.authentication = "token"){
    next();
  }else{
      res.status("401").send("/unathuriozed");
  }
  
}

app.use(express.static(path.join(__dirname, "/public")));

const errorHandler = (err, req, res, next) => {
  console.log(err)
  res.status(500).send("internal server error");
}

/** 
 * fork and spawn 
 * IIFE
 * if million request coming to server means how can we handle in server
 * child process
 * fork and spawn
 * how to load large the response data to the client
 * if 1000 request coming to server how to sequence for particular orgization order 
 * what is livuv
 * 
 */


// Flow of req and resp process in node js 

/** 
 * 
 * Event Loop Initialization
 * ==========================
 * 
 * When a Node.js application starts, it initializes the event loop, which is the core of Node.js’s asynchronous processing
 * 
 * Receving request
 * ================
 * 
 * Node.js uses the http module to create a server. When a request comes in, the server’s callback function is triggered.
 * 
 * const http = require('http');

    const server = http.createServer((req, res) => {
      // Handle request
    });

    server.listen(3000, () => {
      console.log('Server is listening on port 3000');
    });

 * 
 * Event loop and callbacks
 * ========================
 * The event loop continuously checks for new events (like incoming requests) and processes them.
    When a request is received, it is added to the event queue.
 * 
 * Non-blocking I/O Operations
 * ============================
 * 
 * Node.js performs I/O operations (like reading files, querying databases) asynchronously.
Instead of waiting for the operation to complete, Node.js registers a callback and continues processing other events.
const fs = require('fs');

http.createServer((req, res) => {
  fs.readFile('file.txt', (err, data) => {
    if (err) {
      res.writeHead(500);
      res.end('Error reading file');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(data);
  });
}).listen(3000);

 * 
 * Handling Multiple Requests
 * ============================
 * 
 * Node.js can handle multiple requests concurrently because it doesn’t block the event loop.
Each request is processed as an event, and the event loop ensures that all events are handled efficiently.
 * 
 * Processing Requests
 * ===================
 * For each request, Node.js can perform various operations like:
Parsing the request URL and headers.
Performing business logic.
Interacting with databases or other services.
Generating the response.
 * 
 * Delivering Responses
 * =======================
 * 
 * Once the processing is complete, Node.js sends the response back to the client.
http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Hello, World!');
}).listen(3000);

 * 
 * Event Loop Continuation
 * 
 * The event loop continues running, checking for new events and processing them as they come in.
 * 


/*** covalense and L&T
 * how sso works
 * how elastic search is fast
 * how to create nest js application 
 * what are all the way angular store global object in angular
 * where ngrx data will store
 * what is effects in ngrx
 * what are promise, directives
 * what is type and interface
 * static tools like sonarcube eslint
 * what is the command for angular upgrade
 * what is the latest angular changes (standalone)
 * what is difference b/w subject and behavoural subject
 * how to mock http call in unit tests
 * angular life cycles
 * what is inject token
 * what is useclass and usevalue how you used that in angular
 */


// npm install -g @angular/cli@latest
// ng update @angular/core @angular/cli
// ng update @angular/material


/**  
 * import { InjectionToken } from '@angular/core';

export const API_URL = new InjectionToken<string>('apiUrl');



import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { API_URL } from './app.tokens';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule],
  providers: [
    { provide: API_URL, useValue: 'https://api.example.com' }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }



import { Component, Inject } from '@angular/core';
import { API_URL } from './app.tokens';

@Component({
  selector: 'app-root',
  template: `<h1>Welcome to Angular!</h1>`
})
export class AppComponent {
  constructor(@Inject(API_URL) private apiUrl: string) {
    console.log('API URL:', this.apiUrl);
  }
}

 */
