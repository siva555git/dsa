const http  = require("https");

let users = [
    {"name": "siva", "department": "js"}
]

const handleReqeust = (req, res) => {

    req.setheader("Content-Type", "application/json");

    if(res.method === "GET" && res.url === "/users"){
        res.end(JSON.stringify(users));
    }

    if(res.method === "POST" && res.url === "/user"){
        let body;
        req.on("data" , chuck => {
            body += chuck.toString();
        });
        req.on("end", () =>{
            users.push(JSON.parse(body));
            res.end(JSON.stringify(users));    
        });
    }
    else{
        res.statusCode = 404;
        res.end(JSON.stringify({"message": "Endpoint not found"}))
    }

}

const server = http.createServer(handleReqeust);
const port = 3030;
server.listen(port, () => {
    console.log(`Server is running on port ${PORT}`);
});