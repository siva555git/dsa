// 1.what is node js ?
// - it is not language or framework. A frameworks used to reduce the code complexity and having basics inbuild utils 
// - It is run time envirnoment for excuting JS code on server side

// 2.How node is a runtime enviroment on server side? what is V8?
// - Browsers excute the js on cilent side, and similarly, node js excutes javascript on server side
// - V8 is js engine for the js languaage.

// 3. what is difference b/w node.js and express.js
// - Node js is runtime env.
// - Express is used to simplfy the process of building web application providing a set of features like routing, middleware support and etc

// 4. What is difference client side and serverside ?
// - 

// ////
// 1. node.js is asynchronus flow can be acheived by singlethearded, non blocking and event driven architecture    

// Disadvantage of node js
//     - should not use for cpu intensive task

/** 
 * what is body parser
 * what is dif b/w req.params and req.query
 * how to make node app as security // using helmet middleware
 * 
 * 
 * 
 * middleware, routing, jwt, protected route, error handling, multithreading(exec, fork, spawn)
 * security,   
*/


// set up node js project 
// downlaod node js
// download vs code
// create new folder
// open it in vs code
// for create run the command "npm init -y"
// Then to run the app node app.js

// What is npm and node_modules folder

// node modules of dependency 
// Node package manager

// What is package.json // is meta data for the project 

// what are modules in node. what is the difference between function and modules 

// js file treated as js moduels 

// eg:

//  function sayhello = () => {

//  }

// // this for singe function
//  modules.exports = sayhello

//  how many ways to export 

//  function sayhello = () => {

//  }
//  const value = "111";

// // this for multiple function
//  modules.exports = sayhello
//  modules.exports = value

// // import 

// const require("moduele path")

// types of moduels
// - build in modules
// - local modules
// - third party modules

// Top build in modules
// FS modules


