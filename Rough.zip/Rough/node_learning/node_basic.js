// Node is not language or framework 
// IT is runtime environment

// v8 is a javascript engine  for the  js language
// what is runtime env and framework

// one lang can can many runtime eve or many frameworks it depends

// Runtime env. => is primarily focus on providing the necessary infrastructure for code execution, including services like memory management and I/O operation
// framework => primarily focus on simplfiying the development process by offering a structured set of tools, libraries, and best practices.

// Dif b/w node js and express js

// node.js runtime env.

// express.js framework (routing system , middlewares)

// Dif  client side & server side   

// Client side

/****
 *  browser env.
 * 
 *  html csss js
 *  
 *  Document/window/Navigator/Event object
 * 
 *  -
 * 
 *  Handles UI display, interactions and client side logic 
 */



// server side

/****
 *  server env.
 * 
 *  js
 *  
 *  -
 * 
 * 
 *  req/resp/server /database oject
 *
 *  Handles business logic,data storage/ access, authentication, authorization etc
 */

// 7 features of node.js 
/******
 * 1. Single threaded
 * 2. Asynchronus
 * 3. Event driven
 * 4. Non block I/O
 * 5. Cross platform
 * 6. NPM
 * 7. Real time capaclites (chat, game)
 * 
 * 
 */


//  synchronous 
/*****
 * each task will will dependent other
 * 
 * blocking and performance issue
 * 
 * 
 */

// asynchronus
/*****
 * each task will will not dependent other
 * 
 *  non blocking and concurrency 
 * 
 * 
 */


// Event
/*****
 * event    
 * event emitter
 * event queue
 * event handler
 * event loop
 * event driven arch
 *  
 * 
 */

// Disadvanage of node
// Don't use for cpu intense or video processing projects

// how to setup node js project


// npm manage the dependency of node project

// dif/bw modules and function

// imports and exports

// types of modules

// core modules - fs, http, path
// user created modules 
// third party moduels

// Main core moduels 

/****
 * 1. FS 
 * 
 * readfile 
 * writefile
 * appendfile // appends data to the file. If the file is not there then it creates it
 * unlink // delets the specified file
 * readdir  // reads the contents of directory
 * mkdir // create new directory
 * rmdir // removes specfied directory
 */

const fs = require("fs");

fs.readFile("filepath.txt", "utf8", (err, data) =>{
    if(err){
        return;
    }
    console.log(data);
})

const somecontent = "someontent";

fs.writeFile("filepath.txt", somecontext, "utf8", (err) => {
    if(err){
        return;
    }
});



/****
 * 1. path 
 * 
 * join  // joining the segments
 * parse // parsing the path into object with its components
 * resolve // resolving absolute path
 * dirname // getting the directory name of a path
 * extname  // getting the file ext
 */

const path = require("path");

const newpath = path.join("/docs", "file.txt");
console.log(newpath);

const parsedPath = path.parse("/docs/file.txt");
console.log(parsedPath);

/****
 * 1. OS 
 * 
 * type  
 * userInfo     
 * totalmem 
 * freemem 
 * extname 
 */

const os = require("os");

console.log(os.type());

console.log(os.userInfo());

console.log(os.totalmem());

console.log(os.freemem());

/****
 * 1. events 
 * 
 * eventemitter object   
 * on      
 * emit
 * event arguments
 * 
 */

const EventEmitter = require("events");

const event = new EventEmitter();

event.on("eventname", (arg1, arg2)=>{
    console.log(arg1,arg2)
});

event.emit("eventname", "Agr1", "Agr2");

/****
 * 1. http module 
 * 
 * create server
 * 
 */

/****
 * cosnt http = require("http");
 * const server = http.createserver((req, res) => {
 *  res.end();
 * })
 * const port = 5000;
 * server.listen(port =>{
 * })
 */

/*****
 * Advantage of express
 * 
 * web simplicity -express.js provides light weight framework that simplifies the process of building web applications in node.js
 * middleware support - easy integration middleware functions into application request and respons cycles
 * flexible routing - defining routes for handling different http methods (get,post,put,delete etc) and url patterns is easy
 * template engine integration - Express js supports various template engines making it easy to generate dynamic html content on the server side
 */

// install express 
// npm install express

// http server using express js

const http = require("http");

const server = http.createServer((req,res) => {
    res.writeHead(200, {"content-type": "text/plain"});
    res.end("hello world\n");
});

const port = 3000;

server.listen(port, ()=>{
    console.log("server is runing");
});

const express = require("express");

const app = express();

const portexpress = 2000;

app.listen(portexpress, ()=>{
    console.log("server is runing by express");
});

// Middleware 

/****
 * Middleware in express is used to handle the http request, performs operations and passes control to next middleware
 */

// eg

const express = require("express");

const app1 = express();

const middleware = (req,res, next) => {
    res.send("welcome");
    next(); // call the next middle function
}


const middleware2 = (req,res, next) => {
    res.send("welcome");
    next(new Error("something went wrong")); // call the next middle function
}
// router level middleware
app.use("/example", middleware);

// application level middleware
app1.use(middleware2);

// error handler middleware
app1.use(err,req,res,next => {
    console.log(err.stack);
    res.status(500).send("something went wrong");
});

const portNo = 2000;
app1.listen(portNo, ()=>{
    
});

// if you wnat middle ware for specific route globally



// request pipeline in express is series of middle ware functions that handle incoming http request and pass control to next funtions   

// types of middleware 

/****
 * application middleware // middleware applied to all routes. commonly used for logging, authentication etc
 * router level middleware // middleware specific to the certain routes
 * error handler middleware //middle for error handling, will be declared after all other middlewares triggered on errors
 * build in middleware // pre packed middlewares included with express.js like for serving static files
 * third party middleware // midlleware develeoped by others, not part of express core adds various functionalities
 * 
 */

// build in middleware to serve static files

// public is directory
app.use(express.static("public"))

// third party middleware
// npm install helmet body parser compression

const express2 = require("express");

const helmet = require("helmet");
const bodyparser = require("body-parser");
const compression = require("compression");

const app3 = express2();
app.use(helmet());

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:true}));

app.use(compression());

// advantage of express
// modularity //    
// reuseablity
// improved request handling 
// flexible control flow
// third party middlewares 

// Routing in express - routing is the process of directing the http req to appropriate handler fucntions based on the request method (GET, POST) and url path

const expres4 =require("express");

const app4 = express4();

app4.get("/", (req,res) => {
    res.send("welcome")
});

app4.get("/users/:userid", (req,res) => {
    const uid = req.params.userid;
    res.send("welcome")
});

app4.post("/login", (req,res) => {

});

// (req,res) => {

// }); this is route handler

// route method

const express_ = require("express");
const router = express_.Router();

router.get("/", (req, res)=>{

});

module.exports = router;

// app.js

const router = require("router");
app.use("/api", router);

// dif b/w app.get("/") router.get("/")

// router.get("/") is defining where app.get("/") directly mounting

// route chaining // process of assinging multiple middleware for the single route

 app.get("/route", middleware, middleware2 ,(req,res) => {

 });

 // Template engines in express - template engines are libraries that enable devlopers to generate dynamic html content by combining static html templates with data

//  some of the template engnines

//  // EJS
//  // handlbars
//  // pug(formaly jade)
//  // mustache
//  // nunjucks

// step1 npm install ejs

// step2 create a folder views 

// step3 create a below html file as index.html inside the views folder

// <html>
//     <head>
//         <title>EJS</title>
//     </head>
//     <body>
//         <h1><%= title %></h1>
//         <p>static html template</p>
//     </body>
// </html>

// step4 then app.js or server.js

const express__ = require("express")
const app__ = express__();
const path = require("path");
app.set("view-engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.get("/", (req,res) =>{
    res.render("index", {title : "Node ejs template" });
})

// REST  - representational state transfer is an architectural style for designing networked applicatin or rest is a set guidelines for creating APIs
// RESTful API -   is a service which follow REST principle/ guideliens

// Dif b/w rest and soap

// rest is architecural design

// use http vs https 

// use lightweight formats like json and xml

// rest is statelses

// relies on http status code

// generally light weight and fast


// SOAP

// it is portocol

// it http smtp etc

// typically uses xml

// stateful or stateless

// relies on its own fault guildlines

// can be slower due to xml processing


// HTTP verbs

// dif put and patch

// put - complete resource update

// patch - partial resource update


// cors - cross orgin resource sharing is security feature implemented in web browsers that restrict web pages or script from making requests to different domain 
// than the one that served the web page



// different domain eg http://interviewhappy -> http://someotherside
// sub domian eg: http://interviewhappy -> http://api.interviewhappy
// https eg http://interviewhappy -> https://interviewhappy
// for port no alos eg http://interviewhappy -> http://interviewhappy:12
{
    
const express = require("express");

const cors = require("cors");

const app = express();

app.use(cors())

// app.use(cors({
//     origin: "http:example.com"
// }))

}

// serialization vs deserialization 

// using JSON.stringify({}) and JSON.parse(jsonstring)


// Structure of node project

// node_modules
// src
//   - controllers
//     - usercontroller
//     - productcontroller
//   - models
//     - usermodel
//     - productmodel
//   - routes
//     - productroutes
//     - userroutes
//   - utiles
//     - errorhandler.js
//     - validator.js
// app.js
// gitignore
// package.json


 // types of authendication

    //  basic (username and password)
    //  API key Authentication
    //  Token based authentication (JWT)
    //  mulit factor authentication
    //  Certificate based authentication

const crypto = require("crypto");

function createhashsaltpassword(password){
    const salt = crypto.randomBytes(16).toString("hex");

    const hash = crypto.createHash("sha256");

    hash.update(salt+password)
    const hexdec = hash.digest("hex");

    return salt+ "." + hexdec;
}


// API key authentication 

// token based authentication

// step 1 send username and password

// step 2 validate and create jwt token

// step 3 send it to front end browser

// step 4 keep in the local storage

// step 5 send it in the header for every api call

// step 6 server validate it and send the data

// step 7 browers will display the data


JWT consists of three things

// header 

// payload

// signature  

// ERRor handlings

// try catch with sync

// err frist callback

// Promises

// try catch with async 

// debugger techniques in Nodes 

// console.log debugger node.js inspector , visual studio code debugger chrome devtools




