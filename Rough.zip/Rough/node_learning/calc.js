function add (a , b){
    return a + b;
}

module.exports = add;

// we can also use export.add