var fs = require("fs");

fs.readFile("calc.js", "utf8", function(err,data){
    console.log(data);
})

fs.writeFile("calnew.js", 'console.log("hello")', function(err){
    console.log("done")
});

fs.appendFile('calnew.js', 'console.log("world")', function(err){
    console.log(err);
});

fs.unlink("calnew.js", function(err){
    console.log(err);
})