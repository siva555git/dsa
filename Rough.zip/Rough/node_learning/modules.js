/// maintaince ,debugging,sharing
var cal = require("./calc");


let result = cal(2,3);
console.log("the result is " + result);