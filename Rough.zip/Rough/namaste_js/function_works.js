// How function works
var x = 1;
a();
b();
console.log(x);
function a(){
    var x = 10;
    console.log(x);
}

function b(){
    var x = 100;
    console.log(x);
}
//////

// if any varible is not inside the fucntions are called global scope
// eg:

var toplevel = 10;
// we can access the toplevel varible by following types
console.log(window.toplevel);
console.log(this.toplevel);
console.log(toplevel);


//========================

// NOT defined vs Un defined

var newa;
console.log(newa);

console.log(some);
// some is the variable which is not defined


