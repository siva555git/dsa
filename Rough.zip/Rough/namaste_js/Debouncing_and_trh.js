// used for optimization and rate limiting

// eg 1:
// search bar


// eg 2
// resize 
// if type a search word in search bar
// in a time interval calling the api is throttling
// if the key stokes between is delayed by some time means then debouncing
