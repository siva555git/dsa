let ar = [1,2,3,4,5];
const output  =ar.map((a) => 2*a);

const out = ar.filter((a) => a<5);

function findSum(ar){
    let sum = 0;
    for(let i=0;i< ar.length;i++){
            sum = sum+ ar[i];
    }
    return sum;
}

ar.reduce(function(acc, cur){
    acc = acc+ cur;
    return acc;
}, 0);

ar.reduce(function(acc, cur){
    if(cur > acc){
        acc = cur;
    }
    return acc;
}, 0);

const users = [
    {
        firstname: "siva", 
        lastname: " dina",
        age: 30,
    },
    {
        firstname: "siva", 
        lastname: " prakash",
        age: 30,
    },
    {
        firstname: "mark", 
        lastname: " work",
        age: 20,
    },
    {
        firstname: "sachin", 
        lastname: " arjun",
        age: 20,
    }
];

const fullname = users.map(user => user.firstname + user.lastname);

const groupage = users.reduce(function(acc,cur){
    if(acc[cur.age]){
        acc[cur.age] = acc[cur.age] +1;
    }else{
        acc[cur.age] = 1
    }
}, {})

const age = users.filter(user => user.age < 30);

// we can also do the chaining the function

const user = users.filter(user => user.age < 30).map(user => user.firstname);