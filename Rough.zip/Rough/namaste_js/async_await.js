/**          
 * what is async ?
 * what is await ?
 * how async and await works behind the scenes?
 * examples of using async/await
 * error handling
 * interviews
 * async await vs Promise.then/catch
  */


// always return promise / if you dont return promise it will wrap inside the promise
async function getData() {
    return  "promise string"
}



const p = new Promise((resolve, reject) => {
    resolve("promise");
});

async function getData() {
    return  p;  
}

const dataPromise =  getData();

dataPromise.then(response => console.log(response));

// await is a keyword only used inside the async function

// if you use this await in front promise, it will resolve the promise

// async and await are used as combo to handle promise


async function handlePromise(){
    const data = await p;
    console.log(data);
}
handlePromise();

// deep dive 

const pDelay = new Promise((resolve, reject) => {
    setTimeout(() =>{
        resolve("promise");
    }, 10000)
    
});

function getDelayData(){
    pDelay.then(res => console.log(res));
    console.log("Some console");
}
// first print the console.log then after 10 sec print promise data

async function getAsyncDelayData(){
    const data = await p;
    console.log("Some console");
    console.log(data);
}


const promise1 = new Promise((resolve, reject) => {
    setTimeout(() =>{
        resolve("promise");
    }, 10000)
    
});

const promise2 = new Promise((resolve, reject) => {
    setTimeout(() =>{
        resolve("promise");
    }, 500)
    
});

// this case it will wait for promise to resolve then only it start to console the remaining lines

async function handleMutiplePromse(){
    const data1 = await promise1;
    console.log("Some console");
    console.log(data1);

    const data2 = await promise2;
    console.log("Some console");
    console.log(data2);
}

// even if second promise completed also it should wait for 10 sec for 1st promise

// js engine will not wait . But it looks like that 

// Once if the js engine saw the await it will suspend the function and start excuting the other code . Once promise resolved it will back again into call stack


// REal work example
// =================

// error handling 


const API_URL = ""
async function fetchData(){
    try{
        const data = await fetch(API_URL);
    const jsondata = await data.json;

    // fetch() => response.json() => jsonvalue

    // 
    }catch (){

    }
    
}

fetchData().catch(err => console.log(err));






