let name = {
    firstname: "siva",
    lastname: "dina",
    printname: function(){
        console.log(this.firstname + "" + this.lastname)
    }
}

let name2 = {
    firstname : "sachin",
    lastname : "arjun",
}

let fun = printname.bind(name2);
fun();

Function.prototype.mybind = function (...arg){
    let obj = this;
    let newarg = arg.slice(1);
    return function (...innerarg) {
        const finalarg = [...newarg, ...innerarg];
        obj.apply(arg[0], finalarg)
    }
}