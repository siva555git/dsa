// THIS concepts

// this is global scope

console.log(this); // log the window object
// this inside a function

function x(){
    console.log(this); // value depends strict mode or  non strict 
    // if it is strict mode then value is undefined else global object
}
x();

// by using "use strict"

// insdie the function the value of this is undefined
// but if it is called like this then it is global object

window.x();


// this inside  non-strict mode (this substitution)

// => if the value of this is undefined or null then this will be replaced by global object 


// this in strict mode

// this value depends on how this is called (window)
// this inside a objects method
// ===========================




// call apply bind

let obj = {
    x: 10,
    y: function() {
        console.log(this);
    }
}

let obj1 = {
    x: 10,
   
}

obj.y() // print obj

obj.y().call(obj1); 




// arrow function

let arrow = {
    x: 10,
    y: () => {
        console.log(this);
    }
}

arrow.y() // print global object

// let take another example

let arrow2 = {
    x: 10,
    y: function () {
        // enclosing lexical context
        const zvalue = () => {
            console.log(this);
        }
        zvalue();
    },
}

arrow2.y() // print arrow 2 object

// this inside dom element => refer to the dom element


// watch in 47 mins to reviese 







    

