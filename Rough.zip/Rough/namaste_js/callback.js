/** what is callback function in js */
// callback function are first class function
// It makes asyn world in sync manner
// single threaded synchronous act as async using this callback

import { fork } from "child_process";
import { nextTick } from "process";

setTimeout(() => {
    console.log("timer");
}, 1000);

// this settimeout take callback function with timer

function y(z){
    console.log("y");
    z();
}

y(function(){
    console.log("z");
});

// By sending the function as param function y gives the responsiblity to z.
// Z will excute at any time 
// this way async developing

// JS excutes all in the callstack

// Example 

// Create a button
// <input id="clickme" type= "button" value="click">
// Add a event lister to the but by
// document.getElementById("clickme").addEventListor("click", function(){
    //console.log("clicked");
//})

// make the clourse this listen er
// function addEventListorClourse(){
//    var count = 0;
//  document.getElementById("clickme").addEventListor("click", function(){
//     console.log("clicked");
// count++;
//     })
// }

// Basically event listeners are heavy becoz it allocats memory that clourse variables like count
// So If we have manylisteners we should remove it

// strict method in hosting
// closure
// fork
// stub
// authedication in jwt
// crypto
// buffers and streams
// call apply 
// error handling
// nextTick and setImmediate
// recursion
// spreed 
// destrction 
 
// duplicaties in number
// set operator 
// aggreate function in mongo db
// jwt token implementation



// const arr = [1,2,3,4,5,6,7,8,9,10];
// const output = []
// let totalvalue = 0;
// const odd = arr.map(arritem => {
    
//   if(arritem%2 !== 0) {
//       const sq = arritem * arritem;
//       totalvalue = totalvalue+sq;
       
//   }
// });
// console.log(totalvalue);
a= [1,1,1,2,2,2,3,3,3,4,4,4,5,5,5]
const unique = [...new Set(a)];
console.log(unique);
// Output: [1,2,3,4,5]

function recursion(param){
    if(param === 100){
        console.log("end");
    }else{
        console.log(param);
        recursion(param+1)
    }
}

// recursion(1);


// Online Javascript Editor for free
// Write, Edit and Run your Javascript code using JS Online Compiler

// console.log("Try programiz.pro");

// const data = new Promise((resolve,reject) => {
//   try {
//       resolve({data:"data"});
//       reject({data:error});
//   }catch(error){
//       reject({data:error});
//   }
// });

// data.then((result) => {
//     console.log(result);
// });

const newfuncton = function outerfunction() {
    let x= 24;
    return function innerfunction(){
        console.log(x);
    }
}
// const word = "appleisgood";
// const wordArr = word.split("").join();
// const returnData = wordArr.reduce(wordItem, acc => {
//         if(acc[wordItem]) {
//             ++acc[wordItem];
//         }else{
//             acc[wordItem] = 1;
//         }
// }, {});

// {"a": 1, "p": 2 }

// console.log(returnData);

const numberArr = [1,4,5,6,2,1,3,4,5,1,9];
const uniqArr = [];
const duplicateArr = [];
numberArr.forEach(arrItem => {
    console.log(uniqArr.includes(arrItem));
    if(uniqArr.includes(arrItem)){
        if(!duplicateArr.includes(arrItem)){
            duplicateArr.push(arrItem)             
        }
        const index =  uniqArr.indexOf(arrItem);
        delete uniqArr[index];
    }else{
       uniqArr.push(arrItem) 
    }
});

console.log(uniqArr);
console.log(duplicateArr);





// newfuncton()();

// function debounce = (func, wait) => {
//     let timer;
//     return function(...arg) {
//         cleartimer(timer);
//         settime
//     }
// }


// setTimeout(() => {
//         console.info('Execution of Timeout Callback Function'); 
//     }, 10);
//     setImmediate(() => {
//         console.info('Execution of Immediate Callback Function'); 
//     });
//     process.nextTick(() => {
//         console.info('Execution of NextTick Callback Function');
//     })
//     console.info('Execution of Main Module Ends');

// Online Javascript Editor for free
// Write, Edit and Run your Javascript code using JS Online Compiler

// console.log("Try programiz.pro");

// const data = new Promise((resolve,reject) => {
//   try {
//       resolve({data:"data"});
//       reject({data:error});
//   }catch(error){
//       reject({data:error});
//   }
// });

// data.then((result) => {
//     console.log(result);
// });

// const newfuncton = function outerfunction() {
//     let x= 24;
//     return function innerfunction(){
//         console.log(x);
//     }
// }
// // const word = "appleisgood";
// // const wordArr = word.split("").join();
// // const returnData = wordArr.reduce(wordItem, acc => {
// //         if(acc[wordItem]) {
// //             ++acc[wordItem];
// //         }else{
// //             acc[wordItem] = 1;
// //         }
// // }, {});

// // {"a": 1, "p": 2 }

// // console.log(returnData);






