// Some techical terms
// lexical env 
// global excution context
// memory allocatopm and code exc section
// call stack
/////////////////////

// lexical means hierachy
// lexical env is a local memory along with its lexical env of its parent

// scope chain is finding the lexical env of its parent reference to find the variable which is used in parent scope or function
function b(){
    console.log(a);
    c();
    function c(){
        console.log(a);
    }
}

var a = 10;

// In the above code function c check for the variale a to console in its scope. If it is not found then 
// it will check in the parent lexical env which function b, 
// Even if it is not found there. Then it will check in its parent scope like that it will go on. This process is scope chaining
// If variable found it will console the value. Not found means throw err like a is not defined (reference err)