let name = {
    firstname: "siva",
    lastname: "dina",
   
}
let  printname = function(hometown, state){
    console(this.firstname + " " + this.lastname + "" + hometown + "" + state);
}

let name2 = {
    firstname : "shane",
    lastname: "watson",
}

printname.call(name2, "pondy", "PY");

// directly call the method by sending the reference

// only difference between call and apply is passing the arg in apply we send the multiple params in array

printname.apply(name2, ["pondy", "PY"]);

let newfunc = printname.bind(name2, "pondy", "PY");

newfunc();

// bind copy the function and invoke later