let person = {
    firstname: "siva",
    lastname: "dina",
}

let persons = {
    firstname: "rahul",
    lastname: "dina",
}

let printdetails = function(hometown, state, world) {
    console.log(this.firstname + "," + this.lastname+"," + hometown+"," + state+"," + world)
}

let newPrint = printdetails.bind(persons, ["pondy", "indi", "aus"]);
newPrint("india");


Function.prototype.mybind = function(...arg) {
    let obj = this;
    let params = arg.slice(1);
    return function (...newarg){
        obj.apply(arg[0], [...params, ...newarg]);
    }
}

let newmyPrint = printdetails.mybind(persons, "pondy", "indian");
newmyPrint("usa");
