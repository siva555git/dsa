// 

console.log("start");
setTimeout(function(){
    console.log("timer");
}, 5000);
console.log("end");

// 1 million lines to execute

let start  = new Date().getTime();
let end = start;

while (end < start +10000){
    end = new Date().getTime();
}

console.log("while expired");

// In above case call stack will execute the settimeout function after the while expires

// this is concurrency model

// live sever extension used to run the js with callstack
console.log("start");
    let cb =function(){
};
setTimeout(cb, 0);
console.log("end");

// If you have less priority of code then you can use this technique
