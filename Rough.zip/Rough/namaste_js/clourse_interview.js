// clousre is the function inside function combined with its lexical scope

function outer(){
    var x = 1; // even I move this code to line numnber 8 // It points to variable reference
    function inner(){
        console.log(x);
    }
    return inner;
}

var close = outer();
close();

// interview question 
// 1. If i pass a value in the outer function will it work like closure
//   yes it will still form the closure

// like 
function outer(b){
    var x = 1; 
    function inner(){
        console.log(x, b);
    }
    return inner;
}
var close = outer("test");
close();

// 2 . If it is having one more nested function will it work
function outest(){
    var c = 10;
    function outer(b){
        var x = 1; 
        function inner(){
            console.log(x, b, c);
        }
        return inner;
    }
    return outer;
}

var close = outest()("test");
close();

// 3 . suppose if you have a conficting global varibale name means what will happen ?

// 2 . If it is having one more nested function will it work

// It will the inter variable declartion . Suppose if it is not available it will go the global scope
// If suppose in global also it is not there means . It will throw the reference err
function outest(){
    var c = 10;
    function outer(b){
        var x = 1; 
        function inner(){
            console.log(x, b, c);
        }
        return inner;
    }
    return outer;
}

let x = 2;

var close = outest()("test");
close();

// 4 . Advantage of clousre 
// module pattern , function currying, memozie once , data hiding and encapsulation

// 5 . More about data hiding and encapsulation

function counter() {
    var count = 0; // this variable is encapsulated, // this can not access by out side other function
    return function increment(){
        count++;
    }
}
counter()();
// console.log(count); this will throw reference error

// 6. What happen will call the counter method again ?

// It will form a new closure scope function for new function call
function counter() {
    var count = 0; // this variable is encapsulated, // this can not access by out side other function
    return function increment(){
        count++;
    }
}
var counter1 = counter();
counter1();

var counter2 = counter();
counter2();

// 7. How to do the optimze the one for decrement fucntionality

function counter() {
    var count = 0; // this variable is encapsulated, // this can not access by out side other function
    this.increment = function(){
        count++;
    }
    this.decrement = function(){
        count--;
    }
}

var counterfn = new counter();
counterfn.increment();
counterfn.decrement();

// 8. Disadvanage of clousre
// Over memory consumption
// It will not do the garbage collection
// It will leads to brower freeze

// 9. What is garbage collector
// JS is high level language here js engine will take the used variable memory

// 10 .eg for garbage collection

function a(){
    var x = 0;
    return function b(){
        console.log(x);
    }
}
var y = a();

// this y is called later in the code, until that x variable is not free up 
// this is called garbage collection

y();

// 11. Some of the browser will do the garbage collection smartly

// here in the below code z is not used so brower is remove the memory smartly

// if you put break point in that place try to print x and z. x will show value but  z in not defined err will come

function a(){
    var x = 0; z = 7;
    return function b(){
        console.log(x);
    }
}
var y = a();