// block is defined by { }
// block is also compound/multiple statement

{
    let a = 10;
    console.log(a);
}

// if(true) // this syntax err
if(true) return true; // this is single statement

{
    let a =1; // let and const are block scoped
    const b =2;
    var a = 2; // global scope
}

// shadowing

var n = 10;
{
    var n = 23; // this is shadowing and overwrite that variable
}

let x  =2;

{
    let x =12; // this is also shadowing but it will not overwrite 
}

let y = 4;
{
    var y = 5; 
}
// this illegal shadowing

let v = 4;
function c(){
    var v = 5; 
}

// this is fine
var z = 1;
{
    let z = 2 // this is legal
}


const a =1 ;
{
    const a = 2;
    {
        const b = 3;
    }
}