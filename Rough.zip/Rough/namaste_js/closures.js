function x(){
    var a = 7;
    function y(){
        console.log(a); // it is try to find the a it is not found then it check in lexical scope
    }
    y();
}

x();
// output is 7 

// Closure
// closure is a function which is bundled together with sorrounding state (lexical scope)


// we can also do function as return or pass or assign to variable
function x(){
    var a = 7;
    function y(){
        console.log(a); // it is try to find the a it is not found then it check in lexical scope
    }
    return y;
}

// or 

function x(){
    var a = 7;
    return function y(){
        console.log(a); // a is pointing to the reference
    }
    var a = 100;
}
var z = x();
// console will print 100
// Now the function y is called outside of the scope

function s(){
    var b = 8;
    function x(){
        var a = 7;
        return function y(){
            console.log(a); // a is pointing to the reference
            console.log(b); 
        }
        var a = 100;
    }
    x();
}

s();


/// Uses of closures
//1.module design pattern.
//2.currying
//3.functions like once
//4.memoize
//5.maintaining state in async world
//6.settimeouts
//7.iterators
