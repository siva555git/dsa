// javascript runtime env has
// js engine
// apis to access the power 
// event loop
// callback queue

// chrome, node  using v8
// firebox using spider monkey

// js engine will take the high level language and convert into machine readable code

code

// (chunck token generated )
parsing  
// (Syntax parser)
// AST

// JIT compilaier
// optimize on the runtime

// AOT 
// take the piece of code which excute later optimize that and generates token


compliation

// Memory heap  with call stack
execution

// Garbage collection use the mark and sweep alg

// inlining
// copy
// inline caching