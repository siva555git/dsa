// promise.all

Promise.all([p1,p2,p3]);


// P! - 1 sec
// p2 - 2 sec
// p3 - 3 sec

// all success -> it wait for all to complete success

//  all success -> as soon as any one is rejected then immedialely promise all also get rejected. not wait for other prmises

promise.allSeteled ([p1,p2,p3])

// case 1: if  all success the it will give response as promise all
// case 2: if any one get failed then it wait for other to complete the give response as [success, error , success] P2 is failed in this case


Promise.race([P1,P2,P3])

// Which is gets first resolved or setteled then it will get that promise either it success or failed

Promise.any([p1,p2,p3])

// seeking for first success

// Wait for first success

// case1

// P! - 1 sec (success)
// p2 - 2 sec
// p3 - 3 sec

// case 2

// P! - 1 sec (failed)
// p2 - 2 sec (success)
// p3 - 3 sec

// case 3

// P! - 1 sec (failed)
// p2 - 2 sec (failed)
// p3 - 3 sec (failed)

// give it as aggrecated error


// eg for promise all 
const p1 = new Promise((resolve,reject) => {
    setTimeout(() => {
            resolve("P1 success");
    }, 1000);
});

const p2 = new Promise((resolve,reject) => {
    setTimeout(() => {
            // resolve("P2 success");
            reject("P2 fail");
    }, 2000);
});

const p3 = new Promise((resolve,reject) => {
    setTimeout(() => {
            resolve("P3 success");
    }, 3000);
});

Promise.all([p1,p2,p3]).then(res => {
    console.log(res);
}).catch((err) => {
    console.error(err);
});


// eg for promise all 
const pr1 = new Promise((resolve,reject) => {
    setTimeout(() => {
            resolve("P1 success");
    }, 1000);
});

const pr2 = new Promise((resolve,reject) => {
    setTimeout(() => {
            // resolve("P2 success");
            reject("P2 fail");
    }, 2000);
});

const pr3 = new Promise((resolve,reject) => {
    setTimeout(() => {
            resolve("P3 success");
    }, 3000);
});

Promise.allSettled([pr1,pr2,pr3]).then(res => {
    console.log(res);
}).catch((err) => {
    console.error(err);
});


// eg for promise all 
const pra1 = new Promise((resolve,reject) => {
    setTimeout(() => {
            resolve("P1 success");
    }, 1000);
});

const pra2 = new Promise((resolve,reject) => {
    setTimeout(() => {
            // resolve("P2 success");
            reject("P2 fail");
    }, 2000);
});

const pra3 = new Promise((resolve,reject) => {
    setTimeout(() => {
            resolve("P3 success");
    }, 3000);
});

Promise.race([pra1,pra2,pra3]).then(res => {
    console.log(res);
}).catch((err) => {
    console.error(err);
});


// setteled promise -> resolve or reject / fullfilled or reject / success or failure


// eg for promise all 
const pany1 = new Promise((resolve,reject) => {
    setTimeout(() => {
            resolve("P1 success");
    }, 1000);
});

const pany2 = new Promise((resolve,reject) => {
    setTimeout(() => {
            // resolve("P2 success");
            reject("P2 fail");
    }, 2000);
});

const pany3 = new Promise((resolve,reject) => {
    setTimeout(() => {
            resolve("P3 success");
    }, 3000);
});

Promise.race([pany1,pany2,pany3]).then(res => {
    console.log(res);
}).catch((err) => {
    console.error(err);
// for aggreate error 
    console.log(err.errors);
});


