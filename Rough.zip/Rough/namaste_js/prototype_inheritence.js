// js inheritance is different from other language

let  arr = ["siva", "dina"];

// if we use arr.length we can use that properties . we didn't define that

let object = {
    name : "siva",
    city : "pondy",
    getIntro : () => {
        console.log(`${this.name}${this.city}`);
    }
}
function fun(){

}

// by excuting our code js will attach some hidden properties is called prototype

// __proto__ is a object which attached to all the varaibales

// when we arr.__proto__ is Array.prototype
// arr.__proto__.__proto__ is object.prototype
// arr.__proto__.__proto__.__proto__ is null

// when we object.__proto__ is object.prototype
// object.__proto__.__proto__ is null

// when we fun.__proto__ is functiion.prototype
// object.__proto__.__proto__ is object.prototype
// object.__proto__.__proto__.__proto is null

// prototype chain

// js all are prototype

// Dont modify the __proto__ directly

let object2 = {
    name: "adithiya"
}

object2.__proto__ = object;

// 

Function.prototype.mybind = function (){
    console.log("check");
}


fun.mybind();