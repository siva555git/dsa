// creating new promise

// error handing

// promise chaining

const cart = ["pant","dress","shoe"];

const promise  = createOrder(cart);

createOrder.then(function(data){
    console.log(data);
    return data
}).then(function(data){
    return proceedToPayment(data);

}).then(function(){
    return "done";
}).catch(function(err){
    console.log(err);
}).then(function(){
    console.log("no matter what happens, I will be definietely be called.")
})


// return will is used to flow the data to the next level

// if suppose it is long chain then we can use catch inbetween

// any

function proceedToPayment(data){
    return new Promise(function(resolve, reject){
        resolve("payment is successfull");
    });
}

function createOrder(){
    const promise = new Promise(function(resolve,reject){
        if(!validatePayload()){
            const err = new Error("invalid cart");
            reject(err);
        }
        const orderid = "1234";
        if(orderid){
            resolve(orderid);
        }

    });

    return promise;
}



validatePayload(cart) {
    return true;
}