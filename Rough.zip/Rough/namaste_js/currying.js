
// We can do function currying using method 
// one is by binding the funtions
// another one is by closure
let mutlply = function(x,y) {
    return x*y;
}

let multipleBytwo = mutlply.bind(this,2);
multipleBytwo(5);
// 10

let multipleBythree = mutlply.bind(this,5);
multipleBytwo(5);
// 15


let multiplyNew =  function(x)  {
    return function(y) {
        return x*y;
    }
}

let multiplyNewThree = multiplyNew(3);
multiplyNewThree(5);
// 15
