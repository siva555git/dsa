// - let and const also in the hoisting
// - But it is in the temporal deadszone

console.log(b); // undefined
console.log(a); // ReferenceError cannot access a after initialization bcoz it is in temporal dead zone and also in the script/separate scope not in the global scope
let a = 10;
var b = 100;

// if you inspect let variable in the script and var in the global space

// But both are allocated memory before execution

// Temporal dead zone is time between the let hoisted and value assinged for it

// var b is in window object or global scope

// let a = 100;

// we cannot redeclare the let variable it will through syntax error

var b = 1000;
// but we can redeclare var 

// const 
//=========

// const is more strict that this too

const b = 500;
b = 200;
// this will throw the type error


// Types of error
// reference err - when try to access the variable which is not in the scope or in the temporal dead zone or not in the code
// syntax err - when we redeclare the let variable
// type err - when we reassign some values for the const 

// push all the declaration and init to the top of our code so only we can strink the time of temporal dead zone
