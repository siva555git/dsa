// functional programing
function x(){
    console.log("heelow");
}

// x is the callback function

function y(x){
    x();
}

// y is the higher order function

const radius = [4,3,2,1];

let calculateArea = function(radius){
    let output = [];
    for(let i=0; i <radius.length; i++){
        output.push(Math.PI * radius[i] * radius[i]);
    }
    return output;
}

console.log(calculateArea(radius));

let calculateCircumference = function(radius){
    let output = [];
    for(let i=0; i <radius.length; i++){
        output.push( 2 * Math.PI * radius[i] );
    }
    return output;
}

console.log(calculateCircumference(radius));


let calculateDiameter = function(radius){
    let output = [];
    for(let i=0; i <radius.length; i++){
        output.push(2 * radius[i]);
    }
    return output;
}

console.log(calculateDiameter(radius));

// we can rewrite this as below

const radius1 = [4,3,2,1];
const area = function (radius){
    return Math.PI * radius[i] * radius[i]
}
const circumference = function (radius){
    return 2 * Math.PI * radius[i];
}
const diameter = function (radius){
    return 2 * radius[i] ;
}
console.log(calculate(radius, area));
console.log(calculate(radius, circumference));
console.log(calculate(radius, diameter));
let calculate = function(radius1, logic){
    let output = [];
    for(let i=0; i < radius1.length; i++){
        output.push(logic(radius1[i]));
    }
    return output;
}


radius.map(area);
// this simillar to this 
radius.calculate(area);

// we can also change the calculate like map

Array.prototype.calculate = function(logic){
    let output = [];
    for(let i=0; i < this.length; i++){
        output.push(logic(this[i]));
    }
    return output;
}