function x() {
    var a = 3;
    setTimeout(function(){
        console.log(a);
    }, 1000);
    console.log("hello");
}

x();


// i points to the value 6 so the output will be 666666
function x() {
    
    for(var i = 0; i <= 6;i++ ){
        setTimeout(function(){
        console.log(i);
        }, i* 1000);
    }
    
    console.log("hello");
}



// But let is block scope so we get new variable for each iteration
function x() {
    
    for(let i = 0; i <= 5;i++ ){
        setTimeout(function(){
        console.log(i);
        }, i * 1000);
    }
    
    console.log("hello");
}

// we can achieve by creating function and forming a closure again
function x() {
    
    for(var i = 0; i <= 5;i++ ){
        function close(i){
            setTimeout(function(){
            console.log(i);
            }, i * 1000);
        }
        close(i);
    }
    
    console.log("hello");
}