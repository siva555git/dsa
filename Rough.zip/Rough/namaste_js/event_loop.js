// GEC created and into the callstack
// callstack inside the js engine which inside the browser
// browser also have timer, localstorage and fetch
// To access this browser sub powers we need web apis
// settimeout
// Dom API
// fetch()
// localstorage
// console
// location

// We can access in global object or window

// we can use all this with out window keyboard since it is global scope    


// eg of EVENT loop
// first GEC created in callstack
// If any cb function is there
// keep it away from call stack
// When the time to execute the cb , at that time it will come to callback queue
// from this callback queue event loop will help to take the cb function into call stack



 console.log("start");
 settimeout(function(){
 console.log("timer");
 }, 1000);
 console.log("end");

 console.log("start");
 document.getElementById("clickme").addEventListor("click", function(){
    console.log("clicked");
})
console.log("end");
 

// For the case of fetch it is different

// there is micro task que which wil priortize the CB function

// callback queue is also called task queue

console.log("start");
 settimeout(function(){
 console.log("timer");
 }, 5000);

 fetch("https://api/netflix.com").then(function cbf(){
 console.log("fetch");
 });
 console.log("end");

 // promises
 // mutation absoror

 // If micro task queue has three item
 // callback queue has one item

 // even that time also event loop first clear the micro task queue then its come to callback queue


 // when micro task queue is nested priory then it is starvation