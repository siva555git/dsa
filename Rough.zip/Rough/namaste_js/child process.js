// child process

// two way to create the process
// 1. exec()

// this will execute the shell commands directly 

// eg

const { exec } = require("child_process");

    exec("ls -lh", (err, stoerr, stdout) => {

});


// 2. execFile()

// this will execute the files 

