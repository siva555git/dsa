// callback hell
// inversion of control

 const cart = ["shoes","pants", "kurte"];


 api.createOrder(cart, function(){
    api.proceedToPayment(function(){
        api.showOrderSummary(function(){
            api.updateWallet();
         });
     });
 });
 // what is callback hell

 // one cb inside another callback

 // inversion of control

 // when we are giving the cb function to another function means we are giving the control to another function