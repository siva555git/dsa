<!-- real time use case of event propagation-->
<!DOCTYPE html>
<head>
    <title>Event delagation</title>
</head>
<body>
    <!-- Eg 1-->
    <ul id="category">
        <li id="laptop">
        </li>
        <li id="mobiles">
        </li>
        <li id="systems">
        </li>
    </ul>

    <!-- Eg 2-->
    <div id ="form">
        <input type="text" id="name" data-uppercase>
        <input type="text" id="pan">
        <input type="text" id="mobile">
    </div>


</body>
</html>

<script>
    // eg 1
    document.querySelector("#category").addEventListener("click", (e) =>{
        if(e.target.id) {
            window.location.href =  "/"+e.target.id
        }
    });
    // eg 2
    document.querySelector("#form").addEventListener("keyup", (e) =>{
        if(e.target.dataset.uppercase !== undefined) {
            e.target.value = e.target.value.toUppercase();
        }
    });
</script>
