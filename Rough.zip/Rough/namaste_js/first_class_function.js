/** function statement */
function a (){
 console.log("a called");
}

a();

/** function experssion */ 
var b = function (){
    console.log("b called");
}

b(); 

// assigning function to variable is beauitful thing in JS

// difference b/w this two is hoisting

// If i move the a() and b() to top of the code . One will throw error. which is b()


/** Function Declartion */

// Function statement ar function declaration both or same

/** Anonymous function */
// function (){

// }

// Function without name is anonymous function and if we write like this means it will throw sytax err
// Synatax err : Err is function statement require name 

/** Named function expression */

// this is similar to  function expression but it looks like below

var z = function abc (){
    console.log(abc);
}

// But if i called abc() then i will get err 
// like reference err xyz is not defined
 //  but we can call that abc inside that abc 

/** Dif b/w params and args */

// eg
var f = function(params1, params2) {
    console.log("f");
}

// f(arg1,arg2);
f(1,2);

/** First class function */

// ablity pass the function as arg to another function 


var fc = function(params1) {
    console.log(params1);
    return params1;
}
fc(function(){

})();

// arrow functions