const cart = ["pant", "shoe", "kurta"];
createOrder(cart); // create order will give you the order id

createOrder(cart, function(orderID){
    proceedToPayment(orderID);
});

// now if we use promise means

const promise = createOrder(cart);

// { data: undefined};

promise.then(function(orderID){
    proceedToPayment(orderID);
});

// real promise object

const GIT_URL = "https://api.github.com/users/akashisani";

const user = fetch(GIT_URL);

console.log(user);

// promise is object it is has two states
// one is pending, rejected and another one is fulfilled

// Once the fulfilled state is come . we get the data.

// promise is a place holder filled later with value

// promise is a container for future async operation values

// promise is a object representing eventual completion or failure of an asyn operation.

createOrder(cart, function(orderID){
    proceedToPayment(orderID, function(paymentSlip){
        showOrderSummary(paymentSlip, function(){
            updateWalletBalance(paymentSlip);
        });
    });
});

//while chaining we have to return it

createOrder(cart).then(function(orderID){
    return proceedToPayment(orderID);
}).then(function(paymentSlip){
    return showOrderSummary(paymentSlip);
}).then(function(){
    return updateWalletBalance();
})

