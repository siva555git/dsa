<div id="grandparent" onclick = onGrandParentclick() >
    <div id="parent" onclick = onParentclick()>
        <div id="child" onclick = onChildclick()>

        </div>
    </div>
</div>

<!--
    Bubbling

    when clicking the child its Bubbling to top which means the child, parent and grandparent click will be called

    Capturating

    when clicking the child its capturing from top which means the grand parent ,parent and child click will be called

-->


<script>
    // By send true or false will decide it as capturing or bubbling if it is false then it is bubbling if true  then it is capturing
    // Also by calling the stop progration in child it will stop the bubbling to top level
    document.querySelector("#grandparent").addEventListener("click", ()=>{
        console.log("grandparent clicked");
    }, false);
    document.querySelector("#parent").addEventListener("click", ()=>{
        console.log("parent clicked");
    }, false);
    document.querySelector("#child").addEventListener("click", (e)=>{
        console.log("child clicked");
        e.stopPropagation();
    }, false);
</script>

