import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

@Component({
  selector: 'app-dashboard',
  template: `<div *ngFor="let post of posts">{{ post.title }}</div>`
})
export class DashboardComponent implements OnInit {
  posts: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('/api/users').pipe(
      mergeMap((users: any) => {
        // Assuming users is an array and we take the first user's ID
        const userId = users[0].id;
        return this.http.get(`/api/posts?userId=${userId}`);
      })
    ).subscribe((posts: any) => {
      this.posts = posts;
    });
  }
}


import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { concatMap } from 'rxjs/operators';

@Component({
  selector: 'app-form',
  template: `<button (click)="saveForm()">Save Form</button>`
})
export class FormComponent {
  constructor(private http: HttpClient) {}

  saveForm() {
    const formSections = [
      { section: 'personalInfo', data: { name: 'John' } },
      { section: 'address', data: { city: 'New York' } },
      { section: 'preferences', data: { likes: 'Pizza' } }
    ];

    of(...formSections).pipe(
      concatMap(section => this.http.post(`/api/save/${section.section}`, section.data))
    ).subscribe(response => {
      console.log('Section saved:', response);
    });
  }
}