function flattenArray(arr) {
    return arr.reduce((acc, val) => Array.isArray(val) ? acc.concat(flattenArray(val)) : acc.concat(val), []);
  }
  
  const nestedArray = [1, [2, [3, 4], 5], 6];
  console.log(flattenArray(nestedArray));


  // polyfill for debounce
function debounce(fun ,wait) {
    let timeout
    return function (...arg) {
        clearTimeout(timeout);
        timeout = setTimeout(() => { fun.apply(...arg);}, wait)
    };
}

function deepclone(obj){
    if(obj === NULL || typeof obj != "object"){
        return obj;
    }
    if(Array.array(obj)){
        obj.map(oj => deepclone(oj))
    };

    let clonedObj = {}
    for( const key  in obj){    
        if(obj.hasOwnProperty(key)){
            clonedObj[key] = deepclone(obj[key]);
        }
    }
}


// what is directive 
// what is pipe
// what is angular life cycle
// what is dif b/w obserbable and pips
// what is dif b/w padding and margin
// what is b/w service, directive and components
// what is dependency injection
// what is 