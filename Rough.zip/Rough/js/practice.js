let arr = [1,2,[12,3, [3,5]], 6];

function flatarray(arrr){
    return arrr.reduce((acc, item) => Array.isArray(item) ? acc.concat(flatarray(item)) : acc.concat(item), []);
}

console.log(flatarray(arr));

let duplicateArr = [1,2,3,5,6,2];
let uniqueArr = []
for(let i=0;  i< duplicateArr.length; i++){
    const item = duplicateArr[i];
    if(item){
        if(uniqueArr.indexOf(item) === -1){
            uniqueArr.push(item);
        }
    }
    
}
console.log(uniqueArr);


function deepClone(obj){
    if(obj === null || typeof obj !== "object"){
        return obj;
    }
    if(Array.isArray(obj)){
        obj.map(oj => deepClone(oj));
    }

    let newobject = {}
   for(const key in obj){
    if(obj.hasOwnProperty(key)){
        newobject[key] = deepClone(obj[key]);
    }
   }
   return newobject;
}

const oldobj = {first: "df", second: [{a: "a", b: "b"}], third: {c:"c", d: "d"}};
const newobj = deepClone(oldobj);
oldobj["five"] = "test";
console.log(newobj);
console.log(oldobj);


function debounce(func, wait){
    let timer;
    return function(...arg){
        const context = this;
        clearTimeout(timer);
        timer = setTimeout(() => func.apply(context, arg), wait);
    }
}