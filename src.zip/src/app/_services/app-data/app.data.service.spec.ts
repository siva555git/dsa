/* eslint-disable   no-console, sonarjs/no-duplicate-string
    , @typescript-eslint/no-explicit-any */

import { TestBed, inject } from "@angular/core/testing";

import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { OAuthService } from "angular-oauth2-oidc";
import { AppDataService } from "./app.data.service";
import { AppStateService } from "../app-state/app.state.service";
import { EMPTY, ANONYMOUS_USER } from "../../app.constant";
import { AppSettings } from "../../app.settings";
import { MockOAuthService } from "../../testing/mock-oauth.service";
import { AppBroadCastService } from "../app-broadcast/app.broadcast.service";

/* eslint-disable-next-line max-lines-per-function */
describe("AppDataService", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                AppDataService,
                AppBroadCastService,
                AppStateService,
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
            ],
        }),
    );

    it("should be created", () => {
        const service: AppDataService = TestBed.inject(AppDataService);
        expect(service).toBeTruthy();
    });

    it("Should make http GET call", inject([HttpTestingController], (httpMock: HttpTestingController) => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        appData.get("api/data", []).subscribe((response) => {
            expect(response).toBeTruthy();
        });

        const request = httpMock.expectOne("api/data");

        console.log(request.request);
        expect(request.request.method).toEqual("GET");
        // expect(request.request.headers.has("Authorization")).toEqual(false);

        request.flush({});
        httpMock.verify();
    }));

    it("Should receive error on http GET call", inject([HttpTestingController], (httpMock: HttpTestingController) => {
        let errorResponse: any;
        const appData: AppDataService = TestBed.inject(AppDataService);

        appData.get("api/data", []).subscribe({
            next: (response) => {
                console.log(response);
            },
            error: (error) => {
                errorResponse = error;
            },
        });

        const data = "Invalid request parameters";
        const mockError = { status: 400, statusText: "bad Request" };

        httpMock.expectOne("api/data").flush(data, mockError);

        expect(errorResponse.error).toBe(data);
        httpMock.verify();
    }));

    it("Should make actual http GET call and set cached", inject([HttpTestingController], (httpMock: HttpTestingController) => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        const appState: AppStateService = TestBed.inject(AppStateService);

        spyOn(appState, "set");

        appData.getCached("api/data", []).subscribe((response) => {
            expect(response).toBeTruthy();
        });

        const request = httpMock.expectOne("api/data");

        console.log(request.request);
        expect(request.request.method).toEqual("GET");
        request.flush([{ name: "test_user_1" }, { name: "test_user_2" }]);
        expect(appState.set).toHaveBeenCalledWith("api/data", [{ name: "test_user_1" }, { name: "test_user_2" }]);

        httpMock.verify();
    }));

    it("Should make http GET call and get cached response", inject([HttpTestingController], (httpMock: HttpTestingController) => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        const appState: AppStateService = TestBed.inject(AppStateService);

        spyOn(appState, "get");
        appState.set("api/data", [{ name: "test_user_1" }, { name: "test_user_2" }]);

        appData.getCached("api/data", []).subscribe((response) => {
            expect(response).toBeTruthy();
        });

        const request = httpMock.expectOne("api/data");
        expect(request.request.method).toEqual("GET");
        request.flush([{ name: "test_user_1" }, { name: "test_user_2" }]);

        expect(appState.get).toHaveBeenCalledWith("api/data");
        httpMock.verify();
    }));

    it("Should make http POST call", inject([HttpTestingController], (httpMock: HttpTestingController) => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        appData.post("api/data", [], { userId: "axb1234" }).subscribe((response) => {
            expect(response).toBeTruthy();
        });

        const request = httpMock.expectOne("api/data");

        console.log(request.request);
        expect(request.request.method).toEqual("POST");
        expect(request.request.body).toEqual({ userId: "axb1234" });

        request.flush({});
        httpMock.verify();
    }));

    it("Should receive error on http POST call", inject([HttpTestingController], (httpMock: HttpTestingController) => {
        let errorResponse: any;
        const appData: AppDataService = TestBed.inject(AppDataService);

        appData.post("api/data", [], { userId: "axb1234" }).subscribe({
            next: (response) => {
                console.log(response);
            },
            error: (error) => {
                errorResponse = error;
            },
        });

        const data = "Invalid request parameters";
        const mockError = { status: 400, statusText: "bad Request" };

        httpMock.expectOne("api/data").flush(data, mockError);

        expect(errorResponse.error).toBe(data);
        httpMock.verify();
    }));

    it("Should make http PUT call", inject([HttpTestingController], (httpMock: HttpTestingController) => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        appData.put("api/data", [], { userId: "axb1234" }).subscribe((response) => {
            expect(response).toBeTruthy();
        });

        const request = httpMock.expectOne("api/data");

        expect(request.request.method).toEqual("PUT");
        expect(request.request.body).toEqual({ userId: "axb1234" });

        request.flush({});
        httpMock.verify();
    }));

    it("Should receive error on http PUT call", inject([HttpTestingController], (httpMock: HttpTestingController) => {
        let errorResponse: any;
        const appData: AppDataService = TestBed.inject(AppDataService);

        appData.put("api/data", [], { userId: "axb1234" }).subscribe({
            next: (response) => {
                console.log(response);
            },
            error: (error) => {
                errorResponse = error;
            },
        });

        const data = "Invalid request parameters";
        const mockError = { status: 400, statusText: "bad Request" };

        httpMock.expectOne("api/data").flush(data, mockError);

        expect(errorResponse.error).toBe(data);
        httpMock.verify();
    }));

    it("should return formatted image url", () => {
        const service: AppDataService = TestBed.inject(AppDataService);
        const imageUrl = service.getImageUrl("assets/images/{0}/photo.png", ["axb1234"]);
        expect(imageUrl).toEqual("assets/images/axb1234/photo.png");
    });

    it("should return url with token as a query param", () => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        spyOn(appData, "getToken").and.returnValue("test_token");

        const imageUrl = appData.getUrl("api/data/{0}", ["axb1234"]);
        expect(imageUrl).toEqual("api/data/axb1234?token=test_token");
    });

    it("should return url with token as one of query param along with other params", () => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        spyOn(appData, "getToken").and.returnValue("test_token");

        const imageUrl = appData.getUrl("api/data/{0}?is_active=true", ["axb1234"]);
        expect(imageUrl).toEqual("api/data/axb1234?is_active=true&token=test_token");
    });

    it("should return auth token on OKTA enabled", () => {
        AppSettings.isOktaRequired = true;
        const appData: AppDataService = TestBed.inject(AppDataService);

        const authToken = appData.getToken();

        expect(authToken).toEqual("test_auth_token");
    });

    it("should return empty on OKTA disabled", () => {
        AppSettings.isOktaRequired = false;
        const appData: AppDataService = TestBed.inject(AppDataService);

        const authToken = appData.getToken();

        expect(authToken).toEqual(EMPTY);
    });

    it("should return an actual userid", () => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        const appState: AppStateService = TestBed.inject(AppStateService);

        appState.set(appState.stateId.userInfo, { globaluserid: "axb1234" });

        const userId = appData.getUserId();

        expect(userId).toEqual("axb1234");
    });

    it("should return an anonymous userid", () => {
        const appData: AppDataService = TestBed.inject(AppDataService);
        const appState: AppStateService = TestBed.inject(AppStateService);

        appState.set(appState.stateId.userInfo, {});

        const userId = appData.getUserId();

        expect(userId).toEqual(ANONYMOUS_USER);
    });
});
