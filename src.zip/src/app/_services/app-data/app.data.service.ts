/* eslint-disable @typescript-eslint/no-explicit-any, class-methods-use-this
    , @typescript-eslint/explicit-module-boundary-types */

/** Angular Modules */
import { HttpClient, HttpParams } from "@angular/common/http";
import { ElementRef, Injectable } from "@angular/core";
import { UntypedFormControl } from "@angular/forms";

/** Services */
import { OAuthService } from "angular-oauth2-oidc";
import { Observable, of, throwError } from "rxjs";
import { catchError, map } from "rxjs/operators";
import { AppSettings } from "../../app.settings";
import { AppStateService } from "../app-state/app.state.service";
import { EMPTY, ANONYMOUS_USER, apiGatewayHeaderName } from "../../app.constant";

const CONTENT_TYPE_HEADER = "application/json";
const ACCEPT_HEADER = "application/json";

/**
 *Class AppDataService
 *
 * @export
 * @class AppDataService
 */
@Injectable()
export class AppDataService {
    /** public members */
    public url = {
        ADPeoplePicker: `${AppSettings.AppUrl.api}userservice?displayname={0}`,
        getProfile: `${AppSettings.AppUrl.api}profile/{0}`,
        login: `${AppSettings.AppUrl.api}users/login`,
        userByEmail: `${AppSettings.AppUrl.api}users/?emailids={0}`,
        userPhoto: `${AppSettings.AppUrl.api}users/{0}/photo`,
        userSecurityGroups: `${AppSettings.AppUrl.api}users/getUserSecurityGroups`,
        getApplicationPermissions: `${AppSettings.AppUrl.api}securitymanagement/permissions/{0}`,

        /* Application Settings */
        getApplicationSettings: `${AppSettings.AppUrl.settings}`,
        getExperimentAccessPermissions: `${AppSettings.AppUrl.settings}/permissionCategory`,

        /* UserTabs */
        getUserTabs: `${AppSettings.AppUrl.usertabs}get`,
        getRecentTabs: `${AppSettings.AppUrl.usertabs}recentTabs`,
        getUserTabDetails: `${AppSettings.AppUrl.usertabs}details/{0}`,
        createUserTabs: `${AppSettings.AppUrl.usertabs}`,
        updateUserTabs: `${AppSettings.AppUrl.usertabs}update`,
        updateUserTabExpSequence: `${AppSettings.AppUrl.usertabs}updateExpColumnSequence`,
        deleteUserTab: `${AppSettings.AppUrl.usertabs}delete`,
        updateUserTabIsOpenById: `${AppSettings.AppUrl.usertabs}`,
        updateUserTabSequence: `${AppSettings.AppUrl.usertabs}update/sequence`,

        /* Experiments */
        getExperiments: `${AppSettings.AppUrl.experiments}getAllMyExperiments`,
        getSharedExperiments: `${AppSettings.AppUrl.experiments}getSharedExperiments`,
        getExperimentById: `${AppSettings.AppUrl.experiments}{0}`,
        getExperimentByCode: `${AppSettings.AppUrl.experiments}getExpByCode/{0}`,
        getExperimentByIds: `${AppSettings.AppUrl.experiments}getExperimentsByIds`,
        updateExperimentById: `${AppSettings.AppUrl.experiments}{0}`,
        createExperiment: `${AppSettings.AppUrl.experiments}`,
        searchExperiment: `${AppSettings.AppUrl.experiments}search`,
        globalExperimentSearch: `${AppSettings.AppUrl.experiments}getGlobalExperiments`,
        allothersearchExperiment: `${AppSettings.AppUrl.experiments}getOthersExperiment`,
        getTrusteeExperiment: `${AppSettings.AppUrl.experiments}getAllMyTrusteeExperiments`,
        updateExperimentsPrivacy: `${AppSettings.AppUrl.experiments}update-privacy`,
        lockExperiment: `${AppSettings.AppUrl.experiments}experiment/lock`,
        createExperimentFromExperiment: `${AppSettings.AppUrl.experiments}copy`,
        getCircularRefAudit: `${AppSettings.AppUrl.experiments}audit/circularreference/{0}`,
        viewLineage: `${AppSettings.AppUrl.experiments}view/lineage`,
        getExplodeCombineFormula: `${AppSettings.AppUrl.experiments}explode-combine/`,
        updateExperimentName: `${AppSettings.AppUrl.experiments}experiment/expName`,
        copyExperimentToUser: `${AppSettings.AppUrl.experiments}copy/multiple`,
        clearCostForExperiment: `${AppSettings.AppUrl.experiments}clear-cost/{0}`,

        /* Experiment Analysis */
        createExpBomRestriction: `${AppSettings.AppUrl.experimentAnalysis}`,
        getProductTechnologyById: `${AppSettings.AppUrl.experimentAnalysis}{0}`,
        getAllExperimentAnalysis: `${AppSettings.AppUrl.experimentAnalysis}getall`,
        deleteExperimentAnalysis: `${AppSettings.AppUrl.experimentAnalysis}delete`,
        updateExpBomRestrictionById: `${AppSettings.AppUrl.experimentAnalysis}{0}`,
        getExperimentAnalysisAudit: `${AppSettings.AppUrl.experimentAnalysis}audit`,
        allowCosting: `${AppSettings.AppUrl.experimentAnalysis}allowCosting`,

        /* Experiment Notes */
        getExperimentNotes: `${AppSettings.AppUrl.experimentNotes}notes`,
        updateExperimentNotes: `${AppSettings.AppUrl.experimentNotes}{0}`,
        deleteExperimentNotes: `${AppSettings.AppUrl.experimentNotes}deleteNotes`,
        addNotes: `${AppSettings.AppUrl.experimentNotes}`,
        getExperimentNotesById: `${AppSettings.AppUrl.experimentNotes}{0}`,
        getProductDataNotes: `${AppSettings.AppUrl.experimentNotes}productnotes/{0}`,

        /* Working cost */
        addWorkingCost: `${AppSettings.AppUrl.experiments}workingCost`,
        clearWorkingCost: `${AppSettings.AppUrl.experiments}clearWorkingCost/{0}`,

        /* Experiment Formula */
        getExperimentFormula: `${AppSettings.AppUrl.experiments}bomdetails`,
        saveExperimentFormula: `${AppSettings.AppUrl.experimentformulas}addbom`,
        updateExperimentFormula: `${AppSettings.AppUrl.experimentformulas}updatebom/{0}`,
        getIPCProductData: `${AppSettings.AppUrl.experimentformulas}corp/bom`,
        experimentCreativeReview: `${AppSettings.AppUrl.experimentformulas}creativeReview/expbom`,
        getIngredientSearch: `${AppSettings.AppUrl.experimentformulas}search/`,
        getIngredientRequestStatus: `${AppSettings.AppUrl.experimentformulas}/replace/checkPendingRequest`,
        replaceIngredientByIpc: `${AppSettings.AppUrl.experimentformulas}replace`,
        getFlexPalletInfo: `${AppSettings.AppUrl.experiments}flexPallet`,

        /* Bom View Report */
        getBomViewReportData: `${AppSettings.AppUrl.experimentformulas}bomview/report`,
        getRegions: `${AppSettings.AppUrl.settings}/getRegionsFromSettings`,

        /* Experiment Folders */
        experimentFolder: `${AppSettings.AppUrl.experimentFolders}`,
        getExperimentByFolderId: `${AppSettings.AppUrl.experimentFolders}getExpByFolderId`,
        getExperimentFolderById: `${AppSettings.AppUrl.experimentFolders}getExpFolderById/{0}`,
        updateParentFolder: `${AppSettings.AppUrl.experimentFolders}updateParent`,
        createFolder: `${AppSettings.AppUrl.experimentFolders}`,
        updateFolder: `${AppSettings.AppUrl.experimentFolders}{0}`,
        deleteFolder: `${AppSettings.AppUrl.experimentFolders}delete`,
        getRecentlyUsedExp: `${AppSettings.AppUrl.experimentFolders}getRecentlyUsedExperiments`,
        getSearchExpFolderView: `${AppSettings.AppUrl.experimentFolders}getExpFolderTreeList`,
        getChildFoldersByParentId: `${AppSettings.AppUrl.experimentFolders}getExpFolderTreeList/{0}`,

        /* FMP Review */
        // {0} -> dosage {1} -> expcode
        getFMPMaxDosage: `${AppSettings.AppUrl.fmp}{0}/{1}`,
        getFMPPrediction: `${AppSettings.AppUrl.fmp}getFMPPrediction`,
        getFlashPointPrediction: `${AppSettings.AppUrl.flashPoint}`,

        /* MDR */
        getFlavorTypes: `${AppSettings.AppUrl.mdr}flavorTypes`,
        getProductTypes: `${AppSettings.AppUrl.mdr}productTypes/{0}`,
        getProductTypesByCode: `${AppSettings.AppUrl.mdr}productTypesByCode/{0}/{1}`,
        getFacilities: `${AppSettings.AppUrl.mdr}facilities`,
        getMdrBatchSize: `${AppSettings.AppUrl.mdr}batchSize`,
        getWorkingCost: `${AppSettings.AppUrl.mdr}workingCost`,
        getProductLists: `${AppSettings.AppUrl.mdr}productLists`,
        getAttributesData: `${AppSettings.AppUrl.mdr}attributesdata`,
        getCostBooks: `${AppSettings.AppUrl.mdr}costbooks`,
        getFlags: `${AppSettings.AppUrl.mdr}flags`,
        getSpecs: `${AppSettings.AppUrl.mdr}specs`,
        validateIPC: `${AppSettings.AppUrl.mdr}validate`,
        getFlavorClass: `${AppSettings.AppUrl.mdr}flavorClass`,
        getProductsByIpc: `${AppSettings.AppUrl.mdr}getProductsByIpc/{0}`,
        getCurrencies: `${AppSettings.AppUrl.mdr}currencies`,
        getMDRCurrencyRate: `${AppSettings.AppUrl.mdr}currencyrates`,
        getUOMDetails: `${AppSettings.AppUrl.mdr}uomDetails`,
        getSapTechnology: `${AppSettings.AppUrl.mdr}sapTechnology`,
        getBomRightsForIpcs: `${AppSettings.AppUrl.mdr}bomRightsForIpcs`,
        getProductCostStock: `${AppSettings.AppUrl.mdr}stock`,
        getProductBySalesNumber: `${AppSettings.AppUrl.mdr}materials/{0}`,
        getSecurityGroupsUsers: `${AppSettings.AppUrl.mdr}getRestrictedUsageAccessList`,
        getIFFMaterialData: `${AppSettings.AppUrl.mdr}masource`,
        getIPCData: `${AppSettings.AppUrl.mdr}getIPCData`,

        /* Recently Used */
        getProductByIpc: `${AppSettings.AppUrl.recentlyUsed}getProductsByIpc/{0}`,
        recentlyUsedExp: `${AppSettings.AppUrl.recentlyUsed}recentExperiment`,
        recentlyUsedProduct: `${AppSettings.AppUrl.recentlyUsed}recentProduct`,
        getKeywordByIpc: `${AppSettings.AppUrl.sfdc}product`,
        recentlyUsedProductType: `${AppSettings.AppUrl.recentlyUsed}recentlyUsedProductType`,

        /* Plants and Source */
        getPlantsAndSources: `${AppSettings.AppUrl.userAllocation}plantSource`,

        /* References */
        getInstructionSearchCriteria: `${AppSettings.AppUrl.references}categories`,
        getInstructionList: `${AppSettings.AppUrl.references}searchInstructions`,
        Favourites: `${AppSettings.AppUrl.api}favourites`,

        /* User Column Layout */
        getColumnLayoutList: `${AppSettings.AppUrl.userColumnLayouts}layouttypes`,
        createColumnLayoutList: `${AppSettings.AppUrl.userColumnLayouts}`,
        updateColumnLayoutList: `${AppSettings.AppUrl.userColumnLayouts}{0}`,
        deleteColumnLayoutList: `${AppSettings.AppUrl.userColumnLayouts}delete`,
        columnLayoutLastUsed: `${AppSettings.AppUrl.userColumnLayouts}userpreference`,
        customLastUsedLayout: `${AppSettings.AppUrl.userColumnLayouts}customcolumnlayout`,

        /* User Preferences */
        defaultuserpreference: `${AppSettings.AppUrl.userColumnLayouts}defaultuserpreference`,
        privacyEmailSend: `${AppSettings.AppUrl.userColumnLayouts}privacyEmailSend/{0}`,
        alluserpreferencetype: `${AppSettings.AppUrl.userColumnLayouts}alluserpreferencetype`,
        notificationPreferences: `${AppSettings.AppUrl.notificationPreferences}`,
        updateNotifypreference: `${AppSettings.AppUrl.notificationPreferences}updateNotifypreference`,
        getDefaultNotificationSettings: `${AppSettings.AppUrl.settings}/notificationsettings`,

        /* Creative Review */
        getReviewResults: `${AppSettings.AppUrl.creativereviews}result/{0}/{1}`,
        postCreativeReview: `${AppSettings.AppUrl.creativereviews}review`,
        getMultipleReviewLists: `${AppSettings.AppUrl.creativereviews}history/multiple`,
        getCommericalReviewEndUse: `${AppSettings.AppUrl.gra}enduse`,
        getFavByUserId: `${AppSettings.AppUrl.gra}favorites`,
        reviewForProjectNumber: `${AppSettings.AppUrl.gra}project`,
        getRegulatoryEndUse: `${AppSettings.AppUrl.creativereviews}regulatoryEndUse/{0}`,
        getReviewsByFullSearch: `${AppSettings.AppUrl.creativereviews}searchReview`,
        getReviewComparison: `${AppSettings.AppUrl.creativereviews}review/comparison/{0}/{1}`,
        getBosDetailsByIpcOrExp: `${AppSettings.AppUrl.creativereviews}review/getBosDetails`,
        postBatchCreativeReview: `${AppSettings.AppUrl.creativereviews}review/batch`,

        /*  IPC Selection */
        getProductSearchCriteria: `${AppSettings.AppUrl.ipcselections}productSearchCriteria`,
        getIpcCriteria: `${AppSettings.AppUrl.ipcselections}`,
        getIpcSelection: `${AppSettings.AppUrl.ipcselections}ipcSelectionList`,
        createIpcSelection: `${AppSettings.AppUrl.ipcselections}`,
        updateIpcSelection: `${AppSettings.AppUrl.ipcselections}{0}`,
        deleteIpcSelection: `${AppSettings.AppUrl.ipcselections}delete`,

        /* Access-cooperators-list */
        getUsersListSearch: `${AppSettings.AppUrl.api}users/search`,
        staffLists: `${AppSettings.AppUrl.experiments}staff`,
        removeStaffList: `${AppSettings.AppUrl.experiments}staff/remove`,

        /* Notifications */
        notificationsList: `${AppSettings.AppUrl.notifications}/`,
        addNotifications: `${AppSettings.AppUrl.notifications}/add`,
        updateNotifications: `${AppSettings.AppUrl.notifications}/update`,
        deleteNotifications: `${AppSettings.AppUrl.notifications}/delete`,

        /* variant */
        getChangeCondition: `${AppSettings.AppUrl.experiments}changeconditions`,
        createVariant: `${AppSettings.AppUrl.experiments}variant`,
        deleteVariant: `${AppSettings.AppUrl.experiments}variant/`,

        /* Socket */
        socketServer: `${AppSettings.AppUrl.socket}`,

        /* Unapproved */
        getUnapprovedCategories: `${AppSettings.AppUrl.unapproved}categories`,
        getUnapprovedList: `${AppSettings.AppUrl.unapproved}search`,
        updateUnapproved: `${AppSettings.AppUrl.unapproved}/update/{0}`,
        createUnapproved: `${AppSettings.AppUrl.unapproved}/create`,
        getMarketCodes: `${AppSettings.AppUrl.unapproved}/marketCodes`,

        /* Experiment from product IPC ,BOM validation and getting product details */
        getExperimentFromProductDetails: `${AppSettings.AppUrl.experimentformulas}productdetail`,

        /* Create experiment from product */
        createExpFromProduct: `${AppSettings.AppUrl.experiments}expfromproduct`,

        /* Send experiment to IFFMAN */
        sendExpToIffman: `${AppSettings.AppUrl.iffman}upload`,
        sendExpFormulaToIffman: `${AppSettings.AppUrl.iffman}resendExpFormula`,
        recostMDR: `${AppSettings.AppUrl.iffman}recost`,

        /* User Collaboration Group */
        getCollaborationGroupList: `${AppSettings.AppUrl.userCollaborationGroup}`,
        getCollaborationGroupListExperiments: `${AppSettings.AppUrl.userCollaborationGroup}collaborationlist`,
        getSearchedCollaborationGroupListExperiments: `${AppSettings.AppUrl.userCollaborationGroup}collaborationlist/search/{0}`,
        checkCollaborationGroupExp: `${AppSettings.AppUrl.userCollaborationGroup}checkExp`,
        addExperimentToUserCollaborationGroup: `${AppSettings.AppUrl.userCollaborationGroup}addExp`,
        removeExpFromCollaborationGroup: `${AppSettings.AppUrl.userCollaborationGroup}removeExpFromGroup`,
        updateCollaborationGroup: `${AppSettings.AppUrl.userCollaborationGroup}{0}`,
        getCollaborationUserList: `${AppSettings.AppUrl.userCollaborationGroup}collaborationUserList/{0}`,
        deleteCollaborationGroup: `${AppSettings.AppUrl.userCollaborationGroup}delete`,
        getCollaborationAndFolderInfoByExpID: `${AppSettings.AppUrl.userCollaborationGroup}collaborationlist/get/{0}`,
        leaveCollaborationGroup: `${AppSettings.AppUrl.userCollaborationGroup}leave`,

        /* batchSheet */
        createBatchSheet: `${AppSettings.AppUrl.batchSheet}`,
        validateExpCode: `${AppSettings.AppUrl.batchSheet}validateExp`,
        getSampleSheet: `${AppSettings.AppUrl.batchSheet}samples`,
        getLabelTemplate: `${AppSettings.AppUrl.batchSheet}label`,
        generateLabelTemplate: `${AppSettings.AppUrl.batchSheet}generateLabel`,
        getDetailsBySampleID: `${AppSettings.AppUrl.batchSheet}sample/{0}`,
        generateSapPo: `${AppSettings.AppUrl.batchSheet}sapPO`,

        /* Instruction */
        getUserInstructionList: `${AppSettings.AppUrl.instruction}instruction`,
        createInstruction: `${AppSettings.AppUrl.instruction}`,
        updateInstruction: `${AppSettings.AppUrl.instruction}{0}`,
        getSearchInstruction: `${AppSettings.AppUrl.instruction}search/{0}`,
        deleteInstruction: `${AppSettings.AppUrl.instruction}delete/{0}`,

        /* BOSON */
        getExplodedBomDetails: `${AppSettings.AppUrl.api}boson/bom`,
        trackExplodedBomDetails: `${AppSettings.AppUrl.api}boson/bom/track`,
        getMyTaskNames: `${AppSettings.AppUrl.creativetask}`,
        getTaskDetailsByTaskId: `${AppSettings.AppUrl.creativetask}{0}`,
        getTaskByTaskId: `${AppSettings.AppUrl.creativetask}getTaskByTaskId/{0}`,
        getWorkingCostInfo: `${AppSettings.AppUrl.api}costing`,
        getCurrencyRate: `${AppSettings.AppUrl.api}costing/currencyrates`,
        getBatchSize: `${AppSettings.AppUrl.api}costing/batchsize`,
        recostBoson: `${AppSettings.AppUrl.api}costing/batchmnc`,
    };

    /**
     *Creates an instance of AppDataService.
     * @param {HttpClient} http
     * @param {AppStateService} appState
     * @param {OAuthService} oAuthSvc
     * @memberof AppDataService
     */
    constructor(private http: HttpClient, private appState: AppStateService, private oAuthSvc: OAuthService) {}

    /**
     *Gets constructed Http GET
     *
     * @param {string} qry
     * @param {string[]} prm
     * @returns {Observable<any>}
     * @memberof AppDataService
     */
    public get(qry: string, prm: string[], queryParameters?: HttpParams, sendEncoded?: boolean): Observable<any> {
        const heads = {
            "Cache-control": "no-cache,no-store",
            Expires: "0",
            Pragma: "no-cache",
        };
        const options = { headers: heads, withCredentials: true };
        if (queryParameters) {
            // eslint-disable-next-line dot-notation
            options["params"] = queryParameters;
        }
        const aQry = this.formatQuery(qry, prm, sendEncoded);
        return this.http.get(aQry, options).pipe(catchError((error) => throwError(() => error)));
    }

    /**
     *Gets cached Http GET
     *
     * @param {string} qry
     * @param {string[]} prm
     * @returns {Observable<any>}
     * @memberof AppDataService
     */
    public getCached(qry: string, prm: string[]): Observable<any> {
        const heads = {};
        const options = { headers: heads, withCredentials: true };
        const aQry = this.formatQuery(qry, prm);
        if (this.appState.get(aQry)) {
            return of(this.appState.get(aQry));
        }
        return this.http.get(aQry, options).pipe(
            map((response) => {
                this.appState.set(aQry, response);
                return response;
            }),
        );
    }

    /**
     *Gets constructed Http POST
     *
     * @param {string} qry
     * @param {any[]} prm
     * @param {*} data
     * @returns {Observable<any>}
     * @memberof AppDataService
     */
    public post(qry: string, prm: any[], data: any): Observable<any> {
        const hdr = {
            "Content-Type": CONTENT_TYPE_HEADER,
        };
        const options = { headers: hdr };
        const aQry = this.formatQuery(qry, prm);
        return this.http.post(aQry, data, options).pipe(catchError((error) => throwError(() => error)));
    }

    /**
     *Gets constructed http PUT
     *
     * @param {string} qry
     * @param {any[]} prm
     * @param {*} data
     * @returns {Observable<any>}
     * @memberof AppDataService
     */
    public put(qry: string, prm: any[], data: any): Observable<any> {
        const hdr = {
            "Content-Type": CONTENT_TYPE_HEADER,
            accept: ACCEPT_HEADER,
        };
        const options = { headers: hdr };
        const aQry = this.formatQuery(qry, prm);
        return this.http.put(aQry, data, options).pipe(catchError((error) => throwError(() => error)));
    }

    /**
     *Delete constructed http delete
     *
     * @param {string} qry
     * @param {any[]} prm
     * @returns {Observable<any>}
     * @memberof AppDataService
     */
    public delete(qry: string, prm: any[]): Observable<any> {
        const hdr = {
            "Content-Type": CONTENT_TYPE_HEADER,
            accept: ACCEPT_HEADER,
        };
        const options = { headers: hdr };
        const aQry = this.formatQuery(qry, prm);
        return this.http.delete(aQry, options).pipe(catchError((error) => throwError(() => error)));
    }

    /**
     *Gets formatted URL
     *
     * @param {string} qry
     * @param {any[]} prm
     * @returns {string}
     * @memberof AppDataService
     */
    public getUrl(qry: string, prm: any[]): string {
        const index = qry.indexOf("?");
        // eslint-disable-next-line no-param-reassign
        qry += index === -1 ? `?token=${this.getToken()}` : `&token=${this.getToken()}`;
        return this.formatQuery(qry, prm);
    }

    /**
     *Gets auth token
     *
     * @returns {string}
     * @memberof AppDataService
     */
    public getToken(): string {
        return AppSettings.isOktaRequired ? this.oAuthSvc.getIdToken() : EMPTY;
    }

    /**
     *Gets current user id
     *
     * @returns {string}
     * @memberof AppDataService
     */
    public getUserId(): string {
        return this.appState.get(this.appState.stateId.userInfo) && this.appState.get(this.appState.stateId.userInfo).globaluserid
            ? this.appState.get(this.appState.stateId.userInfo).globaluserid
            : ANONYMOUS_USER;
    }

    /**
     *Gets formatted images URL
     *
     * @param {string} qry
     * @param {any[]} prm
     * @returns {string}
     * @memberof AppDataService
     */
    public getImageUrl(qry: string, prm: any[]): string {
        return this.formatQuery(qry, prm);
    }

    /**
     *Formats query
     *
     * @private
     * @param {string} query
     * @param {string[]} parameters
     * @returns {string}
     * @memberof AppDataService
     */
    private formatQuery(query: string, parameters: string[], sendEncoded = false): string {
        let theString = query;
        if (parameters.length === 0) {
            return theString;
        }

        const theParameters = parameters;
        // eslint-disable-next-line no-restricted-syntax
        for (const [index, element] of theParameters.entries()) {
            if (element !== undefined && element !== null) {
                const regEx = new RegExp(`\\{${index}\\}`, "gm");
                theString = sendEncoded ? encodeURI(theString.replace(regEx, element)) : theString.replace(regEx, element);
            }
        }
        return theString;
    }

    /**
     *Reset Form control and user search value
     *
     * @param {FormControl} searchControl
     * @param {ElementRef} searchInput
     * @returns {void}
     * @memberof AppDataService
     */
    public resetSearchValues(searchControl: UntypedFormControl, searchInput: ElementRef): void {
        searchControl.setValue("");
        const input = searchInput;
        input.nativeElement.value = "";
    }

    /**
     *Gets constructed Http POST
     *
     * @param {string} qry
     * @param {any[]} prm
     * @param {*} data
     * * @param {*} authHeader
     * @returns {Observable<any>}
     * @memberof AppDataService
     */
    public postWithAuthHeader(qry: string, prm: any[], data: any, authHeader: any): Observable<any> {
        const hdr = {
            "Content-Type": CONTENT_TYPE_HEADER,
            Authorization: `Bearer ${authHeader}`,
            // eslint-disable-next-line max-lines
            [apiGatewayHeaderName]: AppSettings.config().agwKey,
        };

        const options = { headers: hdr };
        const aQry = this.formatQuery(qry, prm);
        return this.http.post(aQry, data, options).pipe(catchError((error) => throwError(() => error)));
    }
}
