/* eslint-disable max-lines-per-function */
/* eslint-disable   no-console, sonarjs/no-duplicate-string, no-new-object
    , @typescript-eslint/no-explicit-any, prefer-promise-reject-errors */

import { TestBed, tick, fakeAsync } from "@angular/core/testing";

import { OAuthService, OAuthSuccessEvent } from "angular-oauth2-oidc";
import { NGXLogger, CustomNGXLoggerService, NGXLoggerConfigEngine } from "ngx-logger";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { of, throwError } from "rxjs";
import { MSAL_GUARD_CONFIG, MsalBroadcastService, MsalService } from "@azure/msal-angular";
import { AppResolver } from "./app.resolver.service";
import { AppSettings } from "../../app.settings";
import { AppDataService } from "../app-data/app.data.service";
import { AppStateService } from "../app-state/app.state.service";
import { ErrorFormatService, WindowReferenceService } from "../app-common";
import { MockOAuthService } from "../../testing/mock-oauth.service";
import { MockLoggerService, MockNGXLoggerHttpService, MockLoggerConfig } from "../../testing/mock-logger.service";
import { MockErrorFormatService } from "../../testing/mock-error-format.service";
import { AppBroadCastService } from "../app-broadcast/app.broadcast.service";

/* eslint-disable-next-line     max-lines-per-function */
describe("AppResolver", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                AppResolver,
                AppDataService,
                AppStateService,
                AppBroadCastService,
                {
                    provide: MsalService,
                    useValue: {
                        loginRedirect: () => {
                            return false;
                        },
                        handleRedirectObservable: () => {
                            return of(true);
                        },
                        instance: {
                            getActiveAccount: () => {
                                return true;
                            },
                        },
                    },
                },
                {
                    provide: MsalBroadcastService,
                    useValue: {
                        msalSubject$: of(true),
                    },
                },
                {
                    provide: MSAL_GUARD_CONFIG,
                    useValue: {},
                },
                {
                    provide: ErrorFormatService,
                    useClass: MockErrorFormatService,
                },
                WindowReferenceService,
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: CustomNGXLoggerService,
                    useClass: MockNGXLoggerHttpService,
                },
                {
                    provide: NGXLoggerConfigEngine,
                    useClass: MockLoggerConfig,
                },
            ],
        }),
    );

    it("should create", () => {
        const service: AppResolver = TestBed.inject(AppResolver);
        expect(service).toBeTruthy();
    });

    it("should configure OAuth JWT validator", () => {
        const appResolver: AppResolver = TestBed.inject(AppResolver);
        const oAuthService: OAuthService = TestBed.inject(OAuthService);
        spyOn(oAuthService, "configure");

        appResolver.configureJWT();

        expect(oAuthService.configure).toHaveBeenCalled();
    });

    it("should log authentication failure on login for an invalid claim [OKTA Disabled]", () => {
        const failureMessage = "Login Failed";
        const appResolver: AppResolver = TestBed.inject(AppResolver);
        const appData: AppDataService = TestBed.inject(AppDataService);
        const formatService: ErrorFormatService = TestBed.inject(ErrorFormatService);
        const logger: NGXLogger = TestBed.inject(NGXLogger);

        AppSettings.isOktaRequired = false;

        spyOn(appResolver, "configureJWT");
        spyOn(appData, "post").and.returnValue(throwError(() => failureMessage));
        spyOn(formatService, "getFormattedError").and.returnValue({ message: failureMessage });
        spyOn(logger, "error");

        appResolver
            .validateUser()
            .then(
                (result): any => {
                    expect(result).toBeTruthy();
                    return true;
                },
                (): any => {
                    return false;
                },
            )
            .catch(() => false);

        expect(appResolver.configureJWT).toHaveBeenCalled();
        expect(appData.post).toHaveBeenCalled();
        expect(formatService.getFormattedError).toHaveBeenCalled();
        expect(logger.error).toHaveBeenCalledWith("Authentication Failed", new Object({ message: failureMessage }));
    });

    it("should log failure on login for non-existing user [OKTA Disabled]", () => {
        const appResolver: AppResolver = TestBed.inject(AppResolver);
        const appData: AppDataService = TestBed.inject(AppDataService);
        const formatService: ErrorFormatService = TestBed.inject(ErrorFormatService);
        const logger: NGXLogger = TestBed.inject(NGXLogger);

        AppSettings.isOktaRequired = false;

        spyOn(appResolver, "configureJWT");
        spyOn(appData, "post").and.returnValue(of(null)); // eslint-disable-line unicorn/no-null
        spyOn(formatService, "getFormattedError").and.returnValue("User Profile Not Found");
        spyOn(logger, "error");

        appResolver
            .validateUser()
            .then(
                (result): any => {
                    expect(result).toBeTruthy();
                    return true;
                },
                (): any => {
                    return false;
                },
            )
            .catch(() => false);

        expect(appResolver.configureJWT).toHaveBeenCalled();
        expect(appData.post).toHaveBeenCalled();
        expect(formatService.getFormattedError).toHaveBeenCalled();
        expect(logger.error).toHaveBeenCalledWith("Authentication Failed- User Not Found", "User Profile Not Found");
    });

    it("should log success on login for valid user [OKTA Disabled]", () => {
        const appResolver: AppResolver = TestBed.inject(AppResolver);
        const appData: AppDataService = TestBed.inject(AppDataService);
        const logger: NGXLogger = TestBed.inject(NGXLogger);
        const appState: AppStateService = TestBed.inject(AppStateService);

        AppSettings.isOktaRequired = false;

        spyOn(appResolver, "configureJWT");
        spyOn(appData, "post").and.returnValue(of({ globaluserid: "axb1234" }));
        spyOn(logger, "debug");

        appResolver
            .validateUser()
            .then(
                (result): any => {
                    expect(result).toBeTruthy();
                    return true;
                },
                (): any => {
                    return false;
                },
            )
            .catch(() => false);

        expect(appResolver.configureJWT).toHaveBeenCalled();
        expect(appData.post).toHaveBeenCalled();
        expect(logger.debug).toHaveBeenCalledWith("Authentication Success");
        expect(appState.get(appState.stateId.userInfo)).not.toEqual(new Object({ globaluserid: "axb1234" }));
    });

    it("should not initialize app on login for an invalid claim [OKTA Enabled]", fakeAsync(() => {
        const appResolver: AppResolver = TestBed.inject(AppResolver);
        const formatService: ErrorFormatService = TestBed.inject(ErrorFormatService);
        const logger: NGXLogger = TestBed.inject(NGXLogger);
        const oAuth: OAuthService = TestBed.inject(OAuthService);

        AppSettings.isOktaRequired = true;

        spyOn(appResolver, "configureJWT");
        spyOn(formatService, "getFormattedError").and.returnValue("Discovery document error");
        spyOn(logger, "error");

        spyOn(oAuth, "loadDiscoveryDocument").and.returnValue(Promise.reject({ message: "Load discovery document error" }));

        appResolver
            .validateUser()
            .then(
                (response): any => {
                    console.log(response);
                    return true;
                },
                (error): any => {
                    expect(error).toBeTruthy();
                    return false;
                },
            )
            .catch(() => false);

        tick();

        expect(appResolver.configureJWT).toHaveBeenCalled();
        expect(oAuth.loadDiscoveryDocument).toHaveBeenCalled();
        expect(formatService.getFormattedError).toHaveBeenCalledWith(new Object({ message: "Load discovery document error" }));
        expect(logger.error).toHaveBeenCalledWith("Unable to initialize the application", "Discovery document error");
    }));

    it("should get user information for valid claims on token received [OKTA Enabled]", fakeAsync(() => {
        const appResolver: AppResolver = TestBed.inject(AppResolver);
        const oAuth: OAuthService = TestBed.inject(OAuthService);

        AppSettings.isOktaRequired = true;

        spyOn(appResolver, "configureJWT");
        spyOn(oAuth, "loadDiscoveryDocument").and.returnValue(Promise.resolve({} as OAuthSuccessEvent));
        spyOn(oAuth, "tryLogin").and.returnValue(Promise.resolve(true));
        spyOn(oAuth, "getIdentityClaims");

        appResolver
            .validateUser()
            .then(
                (result): any => {
                    expect(result).toBeTruthy();
                    return true;
                },
                (): any => {
                    return false;
                },
            )
            .catch(() => false);

        tick();

        expect(appResolver.configureJWT).toHaveBeenCalled();
        expect(oAuth.tryLogin).toHaveBeenCalled();
        expect(oAuth.getIdentityClaims).toHaveBeenCalled();
    }));

    it("should log failure on login for an invalid claims [OKTA Enabled]", fakeAsync(() => {
        const appResolver: AppResolver = TestBed.inject(AppResolver);
        const formatService: ErrorFormatService = TestBed.inject(ErrorFormatService);
        const logger: NGXLogger = TestBed.inject(NGXLogger);
        const oAuth: OAuthService = TestBed.inject(OAuthService);

        AppSettings.isOktaRequired = true;

        spyOn(appResolver, "configureJWT");
        spyOn(oAuth, "loadDiscoveryDocument").and.returnValue(Promise.resolve({} as OAuthSuccessEvent));
        spyOn(oAuth, "tryLogin").and.returnValue(Promise.reject("Invalid Login Attempt"));
        spyOn(formatService, "getFormattedError").and.returnValue("Invalid User");
        spyOn(logger, "error");

        appResolver
            .validateUser()
            .then(
                (result): any => {
                    expect(result).toBeTruthy();
                    return true;
                },
                (): any => {
                    return false;
                },
            )
            .catch(() => false);

        tick();

        expect(oAuth.loadDiscoveryDocument).toHaveBeenCalled();
        expect(formatService.getFormattedError).toHaveBeenCalledWith("Invalid Login Attempt");
        expect(logger.error).toHaveBeenCalledWith("Unauthorized okta user", "Invalid User");
    }));

    it("should log success on login for valid claims [OKTA Enabled]", fakeAsync(() => {
        const appResolver: AppResolver = TestBed.inject(AppResolver);
        const formatService: ErrorFormatService = TestBed.inject(ErrorFormatService);
        const logger: NGXLogger = TestBed.inject(NGXLogger);
        const oAuth: OAuthService = TestBed.inject(OAuthService);

        AppSettings.isOktaRequired = true;

        spyOn(appResolver, "configureJWT");
        spyOn(oAuth, "loadDiscoveryDocument").and.returnValue(Promise.resolve({} as OAuthSuccessEvent));
        spyOn(oAuth, "tryLogin").and.returnValue(Promise.reject("Invalid Login Attempt"));
        spyOn(oAuth, "hasValidIdToken").and.returnValue(false);
        spyOn(oAuth, "hasValidAccessToken").and.returnValue(false);
        spyOn(oAuth, "initImplicitFlow");

        spyOn(formatService, "getFormattedError").and.returnValue("Invalid User");
        spyOn(logger, "error");

        appResolver
            .validateUser()
            .then(
                (result): any => {
                    expect(result).toBeTruthy();
                    return true;
                },
                (): any => {
                    return false;
                },
            )
            .catch(() => false);

        tick();

        expect(oAuth.loadDiscoveryDocument).toHaveBeenCalled();
        expect(oAuth.initImplicitFlow).toHaveBeenCalled();
        expect(oAuth.hasValidAccessToken).toHaveBeenCalled();
    }));
});
