/* eslint-disable   @typescript-eslint/no-explicit-any, angular/window-service
, promise/no-nesting, promise/always-return */

/** Angular Modules */
import { Injectable } from "@angular/core";
import { filter, forkJoin } from "rxjs";

/** Dependencies */
import { NGXLogger } from "ngx-logger";
import { OAuthService } from "angular-oauth2-oidc";
import { JwksValidationHandler } from "angular-oauth2-oidc-jwks";
/** Enums & Constants */
import { MsalBroadcastService, MsalService } from "@azure/msal-angular";
import { AuthenticationResult, EventMessage, EventType } from "@azure/msal-browser";
import { HttpClient } from "@angular/common/http";
import { UserStatus } from "../../_shared/enums/user-status.enum";
import { AUTHENTICATION_FAILED, AUTHENTICATION_SUCCESS, AUTHORIZATION_FAILED } from "../../_shared/constants/notification.constant";

/** Services */
import { AppDataService } from "../app-data/app.data.service";
import { AppStateService } from "../app-state/app.state.service";
import { AppSettings } from "../../app.settings";
import { ErrorFormatService } from "../app-common";
import { AuthService } from "../app-auth/app.auth.service";

/**
 *Class AppResolver
 *
 * @export
 * @class AppResolver
 */
@Injectable()
export class AppResolver {
    /**
     *Creates an instance of AppResolver.
     * @param {AppDataService} appData
     * @param {AppStateService} appState
     * @param {OAuthService} oAuthSvc
     * @param {NGXLogger} logger
     * @param {ErrorFormatService} errorFormatter
     * @memberof AppResolver
     */
    constructor(
        private appData: AppDataService,
        private appState: AppStateService,
        private oAuthSvc: OAuthService,
        private logger: NGXLogger,
        private errorFormatter: ErrorFormatService,
        private msalService: MsalService,
        private authService: AuthService,
        private msalBroadcastService: MsalBroadcastService,
        private http: HttpClient,
    ) {
        this.msalBroadcastService.msalSubject$
            .pipe(
                filter((message: EventMessage) => {
                    const payload = message.payload as AuthenticationResult;
                    if (payload?.account?.idToken) {
                        this.msalService.instance.setActiveAccount(payload.account);
                        sessionStorage.setItem(this.appState.stateId.token, payload?.idToken);
                    }
                    return message.eventType === EventType.LOGIN_SUCCESS;
                }),
            )
            .subscribe((result: EventMessage) => {
                const payload = result.payload as AuthenticationResult;
                this.msalService.instance.setActiveAccount(payload.account);
                // console.log(this.msalService.instance.getActiveAccount()?.idToken);
                sessionStorage.setItem(this.appState.stateId.token, payload?.idToken);
                // this.authService.handleRedirect();
            });
    }

    /**
     *Configures OAuth and JWT validator
     *
     * @memberof AppResolver
     */
    public configureJWT(): void {
        const config = AppSettings.config();
        this.oAuthSvc.configure(config.okta);
        this.oAuthSvc.tokenValidationHandler = new JwksValidationHandler();
    }

    /**
     *Validates user based on OKTA flag
     *
     * @returns {Promise<any>}
     * @memberof AppResolver
     */
    public validateUser(): Promise<any> {
        this.configureJWT();
        let isInvalidLogin;
        return new Promise((resolve, reject) => {
            // eslint-disable-next-line no-negated-condition
            if (AppSettings.isOktaRequired) {
                this.oAuthSvc
                    .loadDiscoveryDocument()
                    .then(() => {
                        this.oAuthSvc
                            .tryLogin({
                                onLoginError: () => {
                                    isInvalidLogin = true;
                                    this.appState.set(this.appState.stateId.isAccessDenied, true);
                                    resolve(true);
                                },
                                onTokenReceived: (context) => {
                                    this.appState.set(this.appState.stateId.RedirectUri, context.state);
                                    const claims: any = this.oAuthSvc.getIdentityClaims();
                                    this.updateUserInfo(claims, resolve);
                                },
                            })
                            .catch((error) => {
                                this.logger.error("Unauthorized okta user", this.errorFormatter.getFormattedError(error));
                            });

                        if (!this.oAuthSvc.hasValidIdToken() && !this.oAuthSvc.hasValidAccessToken()) {
                            if (!isInvalidLogin) {
                                this.oAuthSvc.initImplicitFlow(window.location.pathname);
                            }
                        } else {
                            const claims: any = this.oAuthSvc.getIdentityClaims();
                            this.updateUserInfo(claims, resolve);
                        }
                    })
                    .catch((error) => {
                        this.logger.error("Unable to initialize the application", this.errorFormatter.getFormattedError(error));
                        reject(error);
                    });
            } else {
                this.updateUserInfo(true, resolve);
            }
        });
    }

    /**
     *Updates application user profile information
     *
     * @private
     * @param {*} claims
     * @param {*} resolve
     * @memberof AppResolver
     */
    // eslint-disable-next-line max-lines-per-function
    private updateUserInfo(claims: any, resolve: any): void {
        if (claims) {
            if (typeof claims !== "boolean") {
                this.appState.set(this.appState.stateId.token, this.oAuthSvc.getAccessToken());
            }
            this.appData.post(this.appData.url.login, [], {}).subscribe({
                next: (result) => {
                    if (result) {
                        result.sapempid = Number(result.sapempid);
                        this.appState.set(this.appState.stateId.isAccessDenied, false);
                        this.appState.set(this.appState.stateId.userAppStatus, UserStatus.ACTIVE); // Set user status here
                        this.appState.set(this.appState.stateId.userInfo, result);
                        this.logger.debug(AUTHENTICATION_SUCCESS);
                        this.oAuthSvc.setupAutomaticSilentRefresh();
                        this.onCheckApplicationPermission(result?.globaluserid, claims, resolve);
                    } else {
                        this.appState.set(this.appState.stateId.userAppStatus, UserStatus.NOT_FOUND);
                        this.appState.set(this.appState.stateId.isAccessDenied, true);
                        this.logger.error(
                            `${AUTHENTICATION_FAILED}- User Not Found`,
                            this.errorFormatter.getFormattedError(`${AUTHENTICATION_FAILED}- User Not Found`),
                        );
                        resolve(claims);
                    }
                },
                error: (error) => {
                    this.appState.set(this.appState.stateId.isAccessDenied, true);
                    this.logger.error(AUTHENTICATION_FAILED, this.errorFormatter.getFormattedError(error));
                    resolve(claims);
                },
            });
        } else if (!this.oAuthSvc.hasValidIdToken() && !this.oAuthSvc.hasValidAccessToken()) {
            this.appState.set(this.appState.stateId.userAppStatus, UserStatus.NOT_FOUND);
            this.appState.set(this.appState.stateId.isAccessDenied, true);
            this.logger.error(
                `${AUTHENTICATION_FAILED}- Invalid Claims`,
                this.errorFormatter.getFormattedError(`${AUTHENTICATION_FAILED}- Invalid Claims`),
            );
            resolve(claims);
        }
    }

    /**
     * @description Method to check the application permission
     * @memberof AppResolver
     */
    public onCheckApplicationPermission(globaluserid: string, claims: any, resolve: any): void {
        forkJoin({
            systemSettings: this.appData.get(this.appData.url.getApplicationSettings, []),
            permissions: this.appData.get(this.appData.url.getApplicationPermissions, [globaluserid]),
            experimentAccessPermission: this.appData.get(this.appData.url.getExperimentAccessPermissions, []),
            securityGroupMembers: this.appData.get(this.appData.url.userSecurityGroups, []),
            alluserpreferencetype: this.appData.get(this.appData.url.alluserpreferencetype, []),
        }).subscribe({
            next: (response) => {
                this.appState.set(this.appState.stateId.applicationSettings, response.systemSettings);
                this.appState.set(this.appState.stateId.permissions, response.permissions);
                this.appState.set(this.appState.stateId.experimentAccessPermission, response.experimentAccessPermission);
                this.appState.set(this.appState.stateId.securityGroupMembers, response.securityGroupMembers);
                AppStateService.userDefaultPreference = response.alluserpreferencetype;
                resolve(claims);
            },
            error: (error) => {
                console.log(error);
                if (error) {
                    this.appState.set(this.appState.stateId.permissions, []);
                    this.appState.set(this.appState.stateId.userAppStatus, UserStatus.UN_AUTHORIZED);
                    this.appState.set(this.appState.stateId.isAccessDenied, true);
                    this.logger.error(
                        `${AUTHORIZATION_FAILED}- User Has No Permission`,
                        this.errorFormatter.getFormattedError(`${AUTHORIZATION_FAILED}- User Has No Permission`),
                    );
                }
                resolve(claims);
            },
        });
    }

    /**
     * @description Method to validate user via entra
     * @memberof AppResolver
     */
    public validateUserADEntra() {
        return new Promise((resolve, reject) => {
            // Get logged in user info from entra server
            this.http.get("https://graph.microsoft.com/v1.0/me").subscribe({
                next: async (_profile) => {
                    // eslint-disable-next-line no-console
                    // console.log("Profile", profile);
                    this.appState.set("IsLoadedMicroFrontSide", false);
                    const response = await this.authService.getLoginInfo(this.msalService.instance.getActiveAccount()?.idToken);
                    // console.log("Wait Response------>", response);
                    this.onCheckApplicationPermission(response?.globaluserid, true, resolve);
                    this.authService.updateUserInfo(response);
                },
                error: (error) => {
                    this.logger.error("Unable to initialize the application", this.errorFormatter.getFormattedError(error));
                    reject(error);
                },
            });
        });
    }
}
