import { Inject, Injectable } from "@angular/core";
import { MSAL_GUARD_CONFIG, MsalGuardConfiguration, MsalService } from "@azure/msal-angular";
import { CacheLookupPolicy, InteractionRequiredAuthError, RedirectRequest } from "@azure/msal-browser";
import { BehaviorSubject, Observable, catchError, from, of, switchMap, throwError } from "rxjs";
import { NGXLogger } from "ngx-logger";

import { AUTHENTICATION_FAILED, AUTHENTICATION_SUCCESS } from "@te-shared/constants";
import { UserStatus } from "@te-shared/enums";
import { AppStateService } from "../app-state/app.state.service";
import { AppDataService } from "../app-data/app.data.service";
import { ErrorFormatService } from "../app-common";

@Injectable({
    providedIn: "root",
})
export class AuthService {
    // eslint-disable-next-line unicorn/no-null
    idToken$: BehaviorSubject<string | null> = new BehaviorSubject<string | null>(null);

    redirectCompleted$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

    constructor(
        private msalService: MsalService,
        private appState: AppStateService,
        private logger: NGXLogger,
        private appData: AppDataService,
        private errorFormatter: ErrorFormatService,
        @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    ) {
        this.refreshToken();
    }

    /**
     * @description Method to get the id token
     * @return {*}  {(string | null)}
     * @memberof AuthService
     */
    public getIdToken(): string | null {
        return this.idToken$.value;
    }

    /**
     * @description Method to trigger the login
     * @memberof AuthService
     */
    public login() {
        if (this.msalGuardConfig.authRequest) {
            this.msalService.loginRedirect({ ...this.msalGuardConfig.authRequest } as RedirectRequest);
        } else {
            this.msalService.loginRedirect();
        }
    }

    /**
     * @description Method to refresh the token
     * @return {*}  {(Observable<string | null>)}
     * @memberof AuthService
     */
    public refreshToken(): Observable<string | null> {
        // eslint-disable-next-line unicorn/no-null
        this.idToken$.next(null);
        return this.msalService.handleRedirectObservable().pipe(
            switchMap(() => {
                return from(
                    this.msalService.acquireTokenSilent({
                        scopes: ["openid", "profile", "user.read"],
                        cacheLookupPolicy: CacheLookupPolicy.RefreshTokenAndNetwork,
                        forceRefresh: true,
                    }),
                ).pipe(
                    switchMap((tokenResponse) => {
                        const { idToken } = tokenResponse;
                        this.appState.set(this.appState.stateId.token, idToken);
                        this.idToken$.next(idToken);
                        return idToken;
                    }),
                    catchError((error) => {
                        if (error instanceof InteractionRequiredAuthError) {
                            // Handles the issue where the app is left idle for more than a day and user try to resumes the session after that
                            this.msalService.acquireTokenRedirect({
                                scopes: ["openid", "profile", "user.read", "offline_access"],
                            });
                            // if above doesn't work then call the login method of  Auth Service to initiate the login again
                            // remove below line if it gives an error. This is optional and used for making sure that the subscription is complete
                            // eslint-disable-next-line unicorn/no-null
                            return of(null);
                        }
                        return throwError(() => {
                            return error;
                        });
                    }),
                );
            }),
        );
    }

    /**
     * @description Method to logout
     * @memberof AuthService
     */
    public logout() {
        this.msalService.logout();
    }

    /**
     * @description Method to get the login info
     * @param {*} authHeader
     * @return {*}  {Promise<void>}
     * @memberof AuthService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getLoginInfo(authHeader): Promise<any> {
        return this.appData.postWithAuthHeader(this.appData.url.login, [], {}, authHeader).toPromise();
    }

    /**
     * @description Method to update the user info
     * @param {*} result
     * @memberof AuthService
     */
    public updateUserInfo(result): void {
        if (result) {
            this.appState.set(this.appState.stateId.isAccessDenied, false);
            this.appState.set(this.appState.stateId.userAppStatus, UserStatus.ACTIVE); // Set user status here
            this.appState.set(this.appState.stateId.userInfo, result);
            sessionStorage.setItem(this.appState.stateId.isAccessDenied, "false");
            sessionStorage.setItem(this.appState.stateId.userAppStatus, UserStatus.ACTIVE);
            sessionStorage.setItem(this.appState.stateId.userInfo, JSON.stringify(result));
            this.logger.debug(AUTHENTICATION_SUCCESS);
        } else {
            this.appState.set(this.appState.stateId.userAppStatus, UserStatus.NOT_FOUND);
            this.appState.set(this.appState.stateId.isAccessDenied, true);
            this.logger.error(
                `${AUTHENTICATION_FAILED}- User Not Found`,
                this.errorFormatter.getFormattedError(`${AUTHENTICATION_FAILED}- User Not Found`),
            );
        }
    }

    /**
     * @description Method to handle the redirect
     * @memberof AuthService
     */
    public handleRedirect() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias, unicorn/no-this-assignment
        const self = this;
        this.msalService.handleRedirectObservable().subscribe({
            next: (result) => {
                if (result) {
                    // eslint-disable-next-line no-console
                    console.log("Token received initially", result?.idToken);
                    self.appState.set(self.appState.stateId.token, result?.idToken);
                    sessionStorage.setItem(self.appState.stateId.token, result?.idToken);
                    const idToken = result?.idToken;
                    // const response = this.getLoginInfo(result?.idToken);
                    // this.updateUserInfo(response);
                    this.idToken$.next(idToken);
                    // this.appState.set(this.appState.stateId.token, idToken);
                    // sessionStorage.setItem(this.appState.stateId.token, idToken);
                }
                this.redirectCompleted$.next(true);
            },
            error: (error) => {
                // eslint-disable-next-line no-console
                console.log("Error during redirect callback", error);
                this.redirectCompleted$.next(true);
            },
        });
    }
}
