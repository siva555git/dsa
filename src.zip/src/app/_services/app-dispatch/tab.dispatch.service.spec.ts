/* eslint-disable unicorn/no-abusive-eslint-disable */
/* eslint-disable */

import { Injectable } from "@angular/core";
import { Store } from "@ngrx/store";
import { TabDataModel } from "../../models/tab-data-model";
import { TasteEditorAppState } from "../../_shared/taste-editor-app-state";
import * as fromTabActions from "../../_shared/actions/tab-add-update";

@Injectable()
export class TabDispatchService {
    constructor(private store: Store<TasteEditorAppState>) {}

    doAddTabs(tabId) {
        const tabDataModel: TabDataModel = {
            tabId,
            isDataFromCache: false,
        };
        this.store.dispatch(new fromTabActions.AddTab(tabDataModel));
    }
}
