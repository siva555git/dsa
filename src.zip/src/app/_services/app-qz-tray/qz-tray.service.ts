/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from "@angular/core";
import { from as fromPromise, Observable } from "rxjs";
import { sha256 } from "js-sha256";
// eslint-disable-next-line import/no-named-default
import { default as qz } from "qz-tray";
import { KJUR, KEYUTIL, stob64, hextorstr } from "jsrsasign";

@Injectable({
    providedIn: "root",
})
export class QzTrayService {
    constructor() {
        qz.security.setCertificatePromise((resolve, reject) => {
            return fetch("assets/qz/digital-certificate.txt", {
                cache: "no-store",
                headers: { "Content-Type": "text/plain" },
            })
                .then((data) => {
                    return resolve(data.text());
                })
                .catch((error) => {
                    reject(error);
                });
        });

        qz.security.setSignatureAlgorithm("SHA512"); // Since 2.1
        qz.security.setSignaturePromise((hash) => {
            return (resolve, reject) => {
                fetch("assets/qz/private-key.pem", { cache: "no-store", headers: { "Content-Type": "text/plain" } })
                    .then((wrapped) => wrapped.text())
                    .then((data) => {
                        const primaryKey = KEYUTIL.getKey(data);
                        const signature = new KJUR.crypto.Signature({ alg: "SHA512withRSA" }); // Use "SHA1withRSA" for QZ Tray 2.0 and older
                        signature.init(primaryKey);
                        signature.updateString(hash);
                        const hex = signature.sign();
                        return resolve(stob64(hextorstr(hex)));
                    })
                    .catch((error) => {
                        reject(error);
                    });
            };
        });

        qz.api.setSha256Type((data) => sha256(data));
        qz.api.setPromiseType((resolver) => new Promise(resolver));
    }

    /**
     * Method to initiate qz websocket connection with licence
     * @memberof QzTrayService
     */
    public connect(): Observable<any> {
        return fromPromise(qz.websocket.connect({ host: "tasteeditor-print.iff.com", usingSecure: true }));
    }

    // Get the list of printers connected
    public getPrinters = (): Observable<string[] | any> => {
        return fromPromise(
            qz.printers.details().then((printers) => {
                const labelPrinter = [];
                const paperPrinter = [];
                printers.forEach((printer) => {
                    labelPrinter.push(printer);
                    paperPrinter.push(printer);
                });
                return { labelPrinter, paperPrinter };
            }),
        );
    };

    public disconnect = (): void => {
        qz.websocket.disconnect();
    };

    // Get the SPECIFIC connected printer
    public getPrinter = (printerName: string): Observable<string | any> => {
        // eslint-disable-next-line unicorn/no-fn-reference-in-iterator, unicorn/no-array-callback-reference
        return fromPromise(qz.printers.find(printerName));
    };

    // Print data to chosen printer
    public printData = (printer: string, data: any, size: any): Observable<any> => {
        const config = qz.configs.create(printer, size);

        return fromPromise(qz.print(config, data));
    };
}
