import { TestBed } from "@angular/core/testing";

import { QzTrayService } from "./qz-tray.service";
import { isArray } from "lodash";

xdescribe("QzTrayService", () => {
    let service: QzTrayService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(QzTrayService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });
    
    xit("should call on connect", () => {
        const spy = spyOn(service, "connect").and.callThrough();
        service.connect();
        expect(spy).toHaveBeenCalled();
    });
    xit("should call on disconnect", () => {
        const spy = spyOn(service, "disconnect").and.callThrough();
        service.disconnect();
        expect(spy).toHaveBeenCalled();
    }); 
    xit("should call on getPrinters", () => {
        const MockData = []
        const spy = spyOn(service, "getPrinters").and.callThrough();
        spy.and.returnValue(MockData as unknown as any) 
        const result = service.getPrinters();
        expect(spy).toHaveBeenCalled();
    });
    it("should call on getPrinter", () => {
        const spy = spyOn(service, "getPrinter").and.callThrough();
         service.getPrinter("TASTE_PRINTER");
        expect(spy).toHaveBeenCalled();
    });
});
