import { TestBed } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorFormatService } from "./error-format.service";
import { AppDataService } from "../../app-data/app.data.service";
import { WindowReferenceService } from "../window/window.service";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { MockLoggerService } from "../../../testing/mock-logger.service";

describe("ErrorFormatService", () => {
    let service: ErrorFormatService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: AppDataService, useClass: MockAppDataService },
                { provide: NGXLogger, useClass: MockLoggerService },
                WindowReferenceService,
            ],
        });
        service = TestBed.inject(ErrorFormatService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });

    it("should return formatted error for non-http response error", () => {
        const error = new Error("Testing Error");

        const formattedError = service.getFormattedError(error);

        expect(formattedError.userId).toEqual("anonymous");
        expect(formattedError.applicationURL).toBeDefined();
        expect(formattedError.severity).toBeDefined();
        expect(formattedError.errorMessage).toEqual("Testing Error");
    });

    it("should return formatted error for http response error", () => {
        const error = new HttpErrorResponse({
            error: "Invalid API",
            status: 404,
            statusText: "Not Found",
            url: "https://test.iff.com/api/user",
        });

        const formattedError = service.getFormattedError(error);

        expect(formattedError.userId).toEqual("anonymous");
        expect(formattedError.applicationURL).toBeDefined();
        expect(formattedError.severity).toBeDefined();
        expect(formattedError.errorMessage).toEqual("Http failure response for https://test.iff.com/api/user: 404 Not Found");
        expect(formattedError.statusCode).toEqual(404);
        expect(formattedError.statusCodeDescription).toEqual("Not Found");
    });
});
