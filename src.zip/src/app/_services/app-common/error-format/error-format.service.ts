/* eslint-disable @typescript-eslint/no-explicit-any, class-methods-use-this
    , @typescript-eslint/explicit-module-boundary-types */

import { Injectable } from "@angular/core";

import { NGXLogger, NgxLoggerLevel } from "ngx-logger";

import { WindowReferenceService } from "../window/window.service";
import { AppDataService } from "../../app-data/app.data.service";

/**
 *Class ErrorFormatService
 *
 * @export
 * @class ErrorFormatService
 */
@Injectable({
    providedIn: "root",
})
export class ErrorFormatService {
    /**
     *Creates an instance of ErrorFormatService.
     * @param {AppDataService} appData
     * @param {WindowReferenceService} windowService
     * @memberof ErrorFormatService
     */
    constructor(private appData: AppDataService, private windowService: WindowReferenceService, private readonly logger: NGXLogger) {}

    /**
     *Parses error object
     *
     * @private
     * @param {*} error
     * @returns {*}
     * @memberof ErrorFormatService
     */
    private parseError(error: any): any {
        if (!error) return;
        const additional: any = {
            errorMessage: error.message ?? error.toString(),
        };

        if (error.stack) {
            additional.stackTrace = error.stack;
        }

        if (error.status) {
            additional.statusCode = error.status;
            additional.statusCodeDescription = error.statusText;
            additional.url = error.url;
        }

        if (error.error && Object.keys(error.error).length > 0) {
            additional.internalError = error.error;
        }

        // eslint-disable-next-line consistent-return
        return additional;
    }

    /**
     *Gets formatted error information with an additional error attributes
     *
     * @param {*} error
     * @param {NgxLoggerLevel} [severity=NgxLoggerLevel.ERROR]
     * @returns {*}
     * @memberof ErrorFormatService
     */
    public getFormattedError(error: any, severity: NgxLoggerLevel = NgxLoggerLevel.ERROR): any {
        return {
            applicationURL: this.windowService.nativeWindow.location.href,
            userId: this.appData.getUserId(),
            severity: NgxLoggerLevel[severity],
            ...this.parseError(error),
        };
    }

    /**
     * Method to log error in formatted manner
     *
     * @param {string} message
     * @param {*} error
     * @param {NgxLoggerLevel} [severity=NgxLoggerLevel.ERROR]
     * @memberof ErrorFormatService
     */
    public logFormattedError(message: string, error: any, severity: NgxLoggerLevel = NgxLoggerLevel.ERROR): void {
        this.logger.error(message, this.getFormattedError(error, severity));
    }
}
