/* eslint-disable   @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types */

import { Injectable } from "@angular/core";

import { Angulartics2 } from "angulartics2";

import { environment } from "../../../../environments/environment";
import { MatomoEvent, MatomoProperties } from "../../../_shared/models";

/**
 * Class Matomo Service
 *
 * @export
 * @class MatomoService
 */
@Injectable()
export class MatomoService {
    /**
     *Creates an instance of MatomoService.
     * @param {Angulartics2} angulartics2
     * @memberof MatomoService
     */
    constructor(private angulartics2: Angulartics2) {}

    /**
     * logMatomoEventHandling
     *
     * @param {*} category
     * @param {*} action
     * @param {*} label
     * @memberof MatomoService
     */
    /*  eslint-disable-next-line    unicorn/no-useless-undefined */
    public trackEvent(category: any, action: any, label: any, value = undefined): void {
        if (environment.enableMatomoEventTracking) {
            const matomoEvent = {} as MatomoEvent;
            const matomoProperties = {} as MatomoProperties;
            matomoEvent.action = action;
            matomoProperties.label = label;
            matomoProperties.category = category;
            if (value) {
                matomoProperties.value = value;
            }
            matomoEvent.properties = matomoProperties;
            this.angulartics2.eventTrack.next(matomoEvent);
        }
    }
}
