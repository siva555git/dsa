import { TestBed } from "@angular/core/testing";

import { Angulartics2 } from "angulartics2";
import { MatomoService } from "./matomo.service";
import { environment } from "../../../../environments/environment";
import { MatomoCategory, MatomoAction, MatomoLabel } from "../../../_shared/enums";
import { MockAngularics2Service } from "../../../testing/mock-angulartics2.service";

describe("MatomoService", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            providers: [
                MatomoService,
                {
                    provide: Angulartics2,
                    useClass: MockAngularics2Service,
                },
            ],
        }),
    );

    it("should create", () => {
        const service: MatomoService = TestBed.inject(MatomoService);
        expect(service).toBeTruthy();
    });

    it("should call eventTrack method on enableMatomoEventTracking enabled", () => {
        environment.enableMatomoEventTracking = true;
        const matomo: MatomoService = TestBed.inject(MatomoService);
        const angulartics2: Angulartics2 = TestBed.inject(Angulartics2);
        spyOn(angulartics2.eventTrack, "next");

        matomo.trackEvent(MatomoCategory.APP_THEME, MatomoAction.THEME_CHANGE, MatomoLabel.DARK_THEME, 123);

        expect(angulartics2.eventTrack.next).toHaveBeenCalled();
    });

    it("should not call eventTrack method on enableMatomoEventTracking disabled", () => {
        environment.enableMatomoEventTracking = false;
        const matomo: MatomoService = TestBed.inject(MatomoService);
        const angulartics2: Angulartics2 = TestBed.inject(Angulartics2);
        spyOn(angulartics2.eventTrack, "next");

        matomo.trackEvent(MatomoCategory.APP_THEME, MatomoAction.THEME_CHANGE, MatomoLabel.DARK_THEME);

        expect(angulartics2.eventTrack.next).not.toHaveBeenCalled();
    });

    it("should call eventTrack method on enableMatomoEventTracking enabled and value is undefined ", () => {
        environment.enableMatomoEventTracking = true;
        const matomo: MatomoService = TestBed.inject(MatomoService);
        const angulartics2: Angulartics2 = TestBed.inject(Angulartics2);
        spyOn(angulartics2.eventTrack, "next");

        // eslint-disable-next-line unicorn/no-useless-undefined
        matomo.trackEvent(MatomoCategory.APP_THEME, MatomoAction.THEME_CHANGE, undefined);

        expect(angulartics2.eventTrack.next).toHaveBeenCalled();
    });
});
