import { TestBed } from "@angular/core/testing";

import { WindowReferenceService } from "./window.service";

describe("WindowReferenceService", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            providers: [WindowReferenceService],
        }),
    );

    it("should create", () => {
        const service: WindowReferenceService = TestBed.inject(WindowReferenceService);
        expect(service).toBeTruthy();
    });
});
