import { Injectable } from "@angular/core";

/**
 * CustomWindow
 *
 * @export
 * @interface CustomWindow
 * @extends {Window}
 */
export interface CustomWindow extends Window {
    /**
     * custom global stuff
     *
     * @type {string}
     * @memberof CustomWindow
     */
    customGlobalStuff: string;
}

/**
 * getWindow
 *
 * @returns {*}
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getWindow(): any {
    return window;
}
/**
 * Class WindowReferenceService
 *
 * @export
 * @class WindowReferenceService
 */
@Injectable()
export class WindowReferenceService {
    /**
     * nativeWindow
     *
     * @readonly
     * @type {CustomWindow}
     * @memberof WindowReferenceService
     */
    // eslint-disable-next-line class-methods-use-this
    get nativeWindow(): CustomWindow {
        return getWindow();
    }
}
