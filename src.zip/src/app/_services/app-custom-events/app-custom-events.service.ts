/* eslint-disable angular/window-service */
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: "root",
})
export class AppCustomEventsService {
    /**
     * @description Method to publish the events
     * @param {string} eventType
     * @param {*} data
     * @memberof AppCustomEventsService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public publishCustomEvent(eventType: string, data: any): void {
        const createEvents = new CustomEvent(eventType, { detail: data });
        window.dispatchEvent(createEvents);
    }

    /**
     * @description Method to subscribe the event
     * @param {string} eventType
     * @param {*} callback
     * @return {*}  {*}
     * @memberof AppCustomEventsService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public subscribeCustomEvent(eventType: string, callback: any): any {
        return window.addEventListener(eventType, callback);
    }
}
