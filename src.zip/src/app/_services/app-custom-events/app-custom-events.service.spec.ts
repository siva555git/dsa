import { TestBed } from "@angular/core/testing";

import { AppCustomEventsService } from "./app-custom-events.service";

describe("AppCustomEventsService", () => {
    let service: AppCustomEventsService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(AppCustomEventsService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });

    it("should call on publishCustomEvent()", () => {
        const spy = spyOn(service, "publishCustomEvent").and.callThrough();
        service.publishCustomEvent("Test", []);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on subscribeCustomEvent()", () => {
        const spy = spyOn(service, "subscribeCustomEvent").and.callThrough();
        service.subscribeCustomEvent("Test", []);
        expect(spy).toHaveBeenCalled();
    });
});
