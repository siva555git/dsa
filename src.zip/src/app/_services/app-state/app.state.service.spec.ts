/* eslint-disable max-lines-per-function */
/* eslint-disable   no-return-assign */

import { TestBed } from "@angular/core/testing";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { AppBroadCastService } from "../app-broadcast/app.broadcast.service";
import { AppStateService } from "./app.state.service";

describe("AppStateService", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            providers: [AppStateService, AppBroadCastService, SecurityHelper],
        }),
    );

    it("should create", () => {
        const service: AppStateService = TestBed.inject(AppStateService);
        expect(service).toBeTruthy();
    });

    it("should return empty state on initial load", () => {
        const service: AppStateService = TestBed.inject(AppStateService);
        const stateInfo = service.state;
        expect(stateInfo).toBeDefined();
    });

    it("should throw an error on setting state value directly", () => {
        const service: AppStateService = TestBed.inject(AppStateService);
        expect(() => (service.state = {})).toThrow(new Error("do not mutate the `.state` directly"));
    });

    it("should return current user info", () => {
        const service: AppStateService = TestBed.inject(AppStateService);
        service.set(service.stateId.userInfo, "Test User");

        const stateInfo = service.state;
        const user = service.getCurrentUser();

        expect(user).toEqual("Test User");
        expect(Object.keys(stateInfo).length).toBeLessThanOrEqual(5);
    });

    it("should return current application user", () => {
        const service: AppStateService = TestBed.inject(AppStateService);
        service.set(service.stateId.currentApplicationUser, "Test User");

        const stateInfo = service.state;
        const user = service.getApplicationCurrentUser();

        expect(user).toEqual("Test User");
        expect(Object.keys(stateInfo).length).toBeLessThanOrEqual(5);
    });

    it("should return current application settings", () => {
        const service: AppStateService = TestBed.inject(AppStateService);
        service.set(service.stateId.applicationSettings, "Test User Settings");

        const stateInfo = service.state;
        const settings = service.getApplicationSettings();

        expect(settings).toEqual("Test User Settings");
        expect(Object.keys(stateInfo).length).toBeLessThanOrEqual(5);
    });
});
