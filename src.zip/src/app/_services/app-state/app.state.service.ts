/* eslint-disable @typescript-eslint/no-explicit-any, unicorn/no-null
    , no-underscore-dangle, class-methods-use-this, @typescript-eslint/explicit-module-boundary-types */

/** Angular Modules */
import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { filter } from "lodash";
import { GeneralPreference } from "@te-shared/models/notification-preferences.model";
import { ExperimentAccessPermissionModel, SecurityGroupMembersResposeModel } from "../../_shared/models/experiment-access-model";
import { WorkSpaces } from "../../_shared/models/create-tab.model";
import { CurrencyRateModel } from "../../_shared/models/currencies-rate-model";
import { CurrenciesModel } from "../../experiment-editor/models/currencies-model";
import { SharedExperimentUtil } from "../../_shared/helpers/shared-experiment.util";
import { ColumnLayoutResponse } from "../../master-data/models/column-layout.model";
import { APP_PRIVACY } from "../../_shared/constants/common.constant";
import { CreateSampleRememberData, ExperimentDetails, TreeViewModel } from "../../_shared/models/experiment-list.model";
import { WorkSpaceModel } from "../../experiment-editor/models/experiment-editor.model";
import { BomDetailsCount } from "../../creative-review/models/creative-review.model";
import { AppSettings } from "../../app.settings";

export type InternalStateType = {
    [key: string]: any;
};

@Injectable()
export class AppStateService {
    public stateId = {
        // State Id
        RedirectUri: "/home",
        isAccessDenied: "isAccessDenied",
        token: "TOKEN",
        userClaims: "USER_CLAIMS",
        userInfo: "USER_INFO",
        userNotFound: "userNotFound",
        userAppStatus: "UNKNOWN",
        currentApplicationUser: "CURRENT_APPLICATION_USER",
        applicationSettings: "APPLICATION_SETTINGS",
        permissions: "permissions",
        experimentAccessPermission: "expeirmentAccessPermission",
        securityGroupMembers: "securityGroupMembers",
    };

    public _state: InternalStateType = {};

    public static currency: CurrenciesModel;

    public currencyValue$ = new Subject<number>();

    public static conversionRate: number;

    public static savedColumnLayoutLists: ColumnLayoutResponse[];

    public static redirectedExperimentDetails: ExperimentDetails;

    public static lastUsedColumnLayout: ColumnLayoutResponse[];

    public static expFolderList: TreeViewModel[];

    public static userDefaultPreference: GeneralPreference[];

    public static workspaces: WorkSpaces[];

    public static expToBeActiveInWorkSpace: string;

    public static userTabDetails: WorkSpaceModel;

    public experimentReview$ = new Subject<any>();

    public static experimentBomCount: BomDetailsCount[];

    public static requestSampleRememberData: CreateSampleRememberData;

    constructor() {
        if (AppSettings.isEntraRequired) {
            this.set(this.stateId.token, sessionStorage.getItem(this.stateId.token));
            // eslint-disable-next-line no-unneeded-ternary
            this.set(this.stateId.isAccessDenied, sessionStorage.getItem(this.stateId.isAccessDenied) !== "false");
            this.set(this.stateId.userAppStatus, sessionStorage.getItem(this.stateId.userAppStatus));
            this.set(this.stateId.userInfo, JSON.parse(sessionStorage.getItem(this.stateId.userInfo) as string));
        }
    }

    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    public get state() {
        this._state = this._clone(this._state);
        return this._state;
    }

    public set state(value) {
        throw new Error("do not mutate the `.state` directly");
    }

    public get(property): any {
        const { state } = this;
        return state.hasOwnProperty(property) ? state[property] : null; // eslint-disable-line no-prototype-builtins
    }

    public set(property, value: any): any {
        this._state[property] = value;
        return value;
    }

    private _clone(object: InternalStateType): any {
        return JSON.parse(JSON.stringify(object));
    }

    public getCurrentUser(): any {
        return this.get(this.stateId.userInfo);
    }

    public getApplicationCurrentUser(): any {
        return this.get(this.stateId.currentApplicationUser);
    }

    public getApplicationSettings(): any {
        return this.get(this.stateId.applicationSettings);
    }

    public getCurrentUserSapEmpId(): any {
        return this.get(this.stateId.userInfo).sapempid;
    }

    public static getCurrencyValue(): any {
        return AppStateService.currency?.currencycode;
    }

    public setCurrencyValue(currency: CurrenciesModel, currenciesRate: CurrencyRateModel[] | number): any {
        const conversionRate =
            typeof currenciesRate === "number"
                ? currenciesRate
                : SharedExperimentUtil.getcurrencyRate(currency.currencycode, currenciesRate);
        AppStateService.currency = currency;
        AppStateService.conversionRate = conversionRate;
        this.currencyValue$.next(conversionRate);
    }

    public static getConversionRate(): any {
        return AppStateService.conversionRate;
    }

    /**
     * Method to set saved column layout lists
     * @param {ColumnLayoutResponse} savedColumnLayouts
     * @returns {*}
     * @memberof AppStateService
     */
    public setSavedColumnLayoutList(savedColumnLayouts: ColumnLayoutResponse[]): void {
        AppStateService.savedColumnLayoutLists = savedColumnLayouts;
    }

    /**
     * Method to get saved column layout lists
     * @returns {ColumnLayoutResponse}
     * @memberof AppStateService
     */
    public static getSavedColumnLayoutList(): ColumnLayoutResponse[] {
        return AppStateService.savedColumnLayoutLists;
    }

    /**
     * Method to get redirectedExperimentdetails
     * @returns {ExperimentDetails}
     * @memberof AppStateService
     */
    public static getRedirectedExperimentDetails(): ExperimentDetails {
        return AppStateService.redirectedExperimentDetails;
    }

    /**
     * Method to set redirect Experiment details
     * @param {ExperimentDetails} experimentDetails
     * @returns {*}
     * @memberof AppStateService
     */
    public static setRedirectedExperimentDetails(experimentDetails?: ExperimentDetails): void {
        AppStateService.redirectedExperimentDetails = experimentDetails;
    }

    /**
     * Method to last used column layout for prod search screen
     * @param {ColumnLayoutResponse} lastUsedLayout
     * @returns {*}
     * @memberof AppStateService
     */
    public setLastUsedColumnLayout(lastUsedLayout: ColumnLayoutResponse[]): void {
        AppStateService.lastUsedColumnLayout = lastUsedLayout;
    }

    /**
     * Method to get last used column layout for prod search screen
     * @returns {ColumnLayoutResponse}
     * @memberof AppStateService
     */
    public static getLastUsedLColumnLayout(): ColumnLayoutResponse[] {
        return AppStateService.lastUsedColumnLayout;
    }

    /**
     * Method to get application permission
     * @returns {any}
     * @memberof AppStateService
     */
    public getApplicationPermissions(): any {
        return this.get(this.stateId.permissions);
    }

    /**
     * Method to set userTabDetails
     * @param {WorkSpaceModel} userTabDetails
     * @returns {void}
     * @memberof AppStateService
     */
    public setUserTabDetails(userTabDetails: WorkSpaceModel): void {
        AppStateService.userTabDetails = userTabDetails;
    }

    /**
     * Method to get userTabDetails
     * @returns {WorkSpaceModel}
     * @memberof AppStateService
     */
    public static getUserTabDetails(): WorkSpaceModel {
        return AppStateService.userTabDetails;
    }

    /**
     * Method to get Experiment Access permission
     * @returns {ExperimentAccessPermissionModel}
     * @memberof AppStateService
     */
    public getExperimentAccessPermission(): ExperimentAccessPermissionModel {
        return this.get(this.stateId.experimentAccessPermission);
    }

    /**
     * function to get privacy model detail
     * @memberof ExperimentHelper
     */
    public getPrivacyModelInfo(): boolean {
        const applicationSettings = this.getApplicationSettings();
        const value = filter(
            applicationSettings.ApplicationSettings,
            (detail) => detail.ParameterCode === APP_PRIVACY.APP_STATE_PRIVACY_CODE,
        );
        return value.length > 0 && value[0].ParameterInString === APP_PRIVACY.CLOSED_MODEL;
    }

    /**
     * Method to get saved exp folders list
     * @returns {TreeViewModel}
     * @memberof AppStateService
     */
    public static getExpFolderList(): TreeViewModel[] {
        return AppStateService.expFolderList;
    }

    /**
     * Method to save exp folders list
     * @param {TreeViewModel} folderList
     * @returns {*}
     * @memberof AppStateService
     */
    public static setExpFolderList(folderList: TreeViewModel[]): void {
        AppStateService.expFolderList = folderList;
    }

    /**
     * Method to get the user default preference
     * @returns {GeneralPreference[]}
     * @memberof AppStateService
     */
    public static getUserDefaultPreferenceType(): GeneralPreference[] {
        return AppStateService.userDefaultPreference;
    }

    /**
     * Method to save the user default preference
     * @param {GeneralPreference} userDefaultPreferenceList
     * @returns {*}
     * @memberof AppStateService
     */
    public static setUserDefaultPreferenceType(userDefaultPreferenceList: GeneralPreference[]): void {
        AppStateService.userDefaultPreference = userDefaultPreferenceList;
    }

    /**
     * Method to set updated workSpace
     * @param {WorkSpaces[]} workSpaces
     * @returns {void}
     * @memberof AppStateService
     */
    public static setWorkSpace(workSpace: WorkSpaces[]): void {
        AppStateService.workspaces = workSpace;
    }

    /**
     * Method to get updated workSpace
     * @returns {WorkSpaces[]}
     * @memberof AppStateService
     */
    public static getUpdatedWorkSpace(): WorkSpaces[] {
        return AppStateService.workspaces;
    }

    /**
     * Method to set bom count
     *
     * @param {BomDetailsCount[]} expBom
     * @returns {WorkSpaces[]}
     * @memberof AppStateService
     */
    public static setBomCount(expBom: BomDetailsCount[]): void {
        AppStateService.experimentBomCount = expBom;
    }

    /**
     * Method to get set bom count
     *
     * @memberof AppStateService
     */
    public static getBomCount(): any {
        return AppStateService.experimentBomCount;
    }

    /**
     * Method to get Request Sample Remember Data
     * @returns {CreateSampleRememberData}
     * @memberof AppStateService
     */
    public static getRequestSampleRememberData(): CreateSampleRememberData {
        return AppStateService.requestSampleRememberData;
    }

    /**
     * Method to set redirect Experiment details
     * @param {CreateSampleRememberData} requestSampleData
     * @returns {*}
     * @memberof AppStateService
     */
    public static setRequestSampleRememberData(requestSampleData?: CreateSampleRememberData): void {
        AppStateService.requestSampleRememberData = requestSampleData;
    }

    /**
     * Method to get security group members
     *
     * @memberof AppStateService
     */
    public getSecurityGroupMembers(): SecurityGroupMembersResposeModel {
        return this.get(this.stateId.securityGroupMembers);
    }

    /**
     * Method to set Experiment to set active in workSpace
     * @returns {void}
     * @memberof AppStateService
     */
    public static setExpToBeActiveInWorkSpace(expCode: string): void {
        AppStateService.expToBeActiveInWorkSpace = expCode;
    }

    /**
     * Method to get Experiment to set active in workSpace
     * @returns {string}
     * @memberof AppStateService
     */
    public static getExpToBeActiveInWorkSpace(): string {
        return AppStateService.expToBeActiveInWorkSpace;
    }
}
