import { TestBed } from "@angular/core/testing";

import { ThemeService } from "./app.theme.service";
import { AppEventManager } from "../app-event-manager/app.event-manager.service";
import { THEME_CHANGE } from "../../_shared/constants/event.constant";

describe("ThemeService", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            providers: [AppEventManager],
        }),
    );

    it("should create", () => {
        const service: ThemeService = TestBed.inject(ThemeService);
        expect(service).toBeTruthy();
    });

    it("should call an event broadcast on setting theme", () => {
        const service: ThemeService = TestBed.inject(ThemeService);
        const eventManager: AppEventManager = TestBed.inject(AppEventManager);
        spyOn(eventManager, "broadcast");

        service.setDarkTheme(true);

        expect(eventManager.broadcast).toHaveBeenCalledWith({
            name: THEME_CHANGE,
            isThemeDark: true,
        });
    });
});
