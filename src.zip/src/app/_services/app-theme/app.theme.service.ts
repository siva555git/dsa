/** Angular Modules */
import { Injectable } from "@angular/core";

/** Enums and Contants */
import { THEME_CHANGE } from "../../_shared/constants/event.constant";

/** Services */
import { AppEventManager } from "../app-event-manager/app.event-manager.service";

@Injectable({
    providedIn: "root",
})
export class ThemeService {
    /** public members */
    public isThemeDark = false;

    constructor(private eventManager: AppEventManager) {}

    public setDarkTheme(isThemeDark: boolean): void {
        this.eventManager.broadcast({
            name: THEME_CHANGE,
            isThemeDark,
        });
    }
}
