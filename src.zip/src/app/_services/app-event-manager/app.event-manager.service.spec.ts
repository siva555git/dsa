import { TestBed } from "@angular/core/testing";
import { Subscription } from "rxjs";

import { AppEventManager } from "./app.event-manager.service";
import { SpyService, callback } from "../../testing/spy.service";

describe("AppEventManager", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            providers: [AppEventManager, SpyService],
        }),
    );

    it("should create", () => {
        const eventService = TestBed.inject(AppEventManager);
        expect(eventService).toBeTruthy();
    });

    it("should create an event and receive on subscribe", () => {
        const eventService = TestBed.inject(AppEventManager);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        eventService.subscribe("TEST_EVENT", () => callback(spyService));
        eventService.broadcast({ name: "TEST_EVENT", content: "Test Content" });
        expect(spyService.called).toBeTruthy();
    });

    it("should unsubscribe when destroy method called", () => {
        const eventService = TestBed.inject(AppEventManager);
        const subscription = new Subscription();
        spyOn(subscription, "unsubscribe");
        eventService.destroy(subscription);
        expect(subscription.unsubscribe).toHaveBeenCalled();
    });
});
