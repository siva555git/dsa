/* eslint-disable max-lines-per-function */
import { TestBed } from "@angular/core/testing";
import { Server } from "mock-socket";
import { ToastrService } from "ngx-toastr";
import { AppBroadCastService } from "../app-broadcast/app.broadcast.service";
import { NotificationService } from "./notification.service";
import { MockToastrService } from "../../testing/mock-toastr.service";
import { NotificationSubscriptionService } from "./notification-subscription.service";
import { AppDataService } from "../app-data/app.data.service";
import { MockAppDataService } from "../../testing/mock-app.data.service";
import { NotificationHelper } from "../../_shared/components/notification-drawer/helper/notification-helper";
import { MockNotificationHelper } from "../../testing/mock-notification.helper";

describe("NotificationService", () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                NotificationService,
                AppBroadCastService,
                NotificationSubscriptionService,
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                { provide: NotificationHelper, useClass: MockNotificationHelper },
            ],
        });
    });

    it("should create mock socket server", () => {
        // eslint-disable-next-line angular/window-service
        const SERVER_URL = window.location.host;
        const mockServer = new Server(SERVER_URL);
        mockServer.on("connection", (socket) => {
            socket.on("message", () => {
                socket.send("test message from mock server");
            });
        });
        const service: NotificationService = TestBed.inject(NotificationService);
        service.initiateSocketConnection("33323");
    });

    it("should create NotificationService", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        expect(service).toBeTruthy();
    });

    const notificationMock = {
        Subject: "Mock Subject for experiment access",
        Body: "Mock Body",
        NotificationTypeID: 1,
        NotificationEventID: 1,
        CreatedTo: 33_323,
        IsPushMessage: "false",
        UserName: "Aravinth",
        alertAppearance: "None",
    };

    it("should invoke add user to experiment access handler", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        service.handleAddUserToExpAccess(notificationMock);
    });

    it("should invoke remove user from experiment access handler", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        service.handleRemoveUserToExpAccess(notificationMock);
    });

    it("should invoke add cooperator handler", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        service.handleAddCooperator(notificationMock);
    });

    it("should invoke remove cooperator handler", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        service.handleRemoveCooperator(notificationMock);
    });

    it("should invoke copy others experiment handler", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        service.handleCopyOthersExperiment(notificationMock);
    });

    it("should create NotificationSubscriptionService", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        expect(service).toBeTruthy();
    });

    it("should invoke subscription notification handler", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.subscribeNotificationBroadCastService();
    });

    it("should invoke notification popup handler with warning type", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.showNotificationPopUp(notificationMock);
    });

    const notificationMockDefaultEventType = {
        Subject: "Mock Subject for default event type",
        Body: "Mock Body",
        NotificationTypeID: 3,
        NotificationEventID: 1,
        CreatedTo: 33_323,
        IsPushMessage: "false",
        UserName: "Aravinth",
        alertAppearance: "None",
    };
    it("should invoke notification popup handler with default type", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.showNotificationPopUp(notificationMockDefaultEventType);
    });

    const validNotificationMockDefaultEventType = {
        Subject: "Mock Subject for valid push",
        Body: "Mock Body",
        NotificationTypeID: 2,
        NotificationEventID: 1,
        CreatedTo: 33_323,
        IsPushMessage: "false",
        UserName: "Aravinth",
        alertAppearance: "None",
        isValidPush: true,
    };
    it("should invoke notification popup handler with valid push", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.showNotificationPopUp(validNotificationMockDefaultEventType);
    });

    const playSoundNotification = {
        Subject: "Mock Subject for notification tone",
        Body: "Mock Body",
        NotificationTypeID: 2,
        NotificationEventID: 2,
        CreatedTo: 33_323,
        IsPushMessage: "false",
        UserName: "Aravinth",
        alertAppearance: "None",
        isValidPush: true,
        shouldPlaySound: true,
    };
    it("should invoke notification popup with notification tone", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.showNotificationPopUp(playSoundNotification);
    });

    xit("should invoke information popup", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.infoPopUp(notificationMock);
    });

    it("should invoke information popup", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.triggerNotificationTone();
    });

    const notificationPayloadWithLink = {
        Subject: "Mock Subject with link",
        Body: "Mock Body",
        NotificationTypeID: 2,
        NotificationEventID: 2,
        CreatedTo: 33_323,
        IsPushMessage: "false",
        UserName: "Aravinth",
        alertAppearance: "None",
        isValidPush: true,
        shouldPlaySound: true,
        ExpCode: "AXB00117AB",
    };
    it("should invoke information popup with link", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.openTabOnExpCodeClick(notificationPayloadWithLink);
    });

    it("should invoke error popup", () => {
        const service: NotificationSubscriptionService = TestBed.inject(NotificationSubscriptionService);
        service.errorPopUp(notificationMock);
    });

    it("should invoke leave user from collaboration group handler", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        service.handleAddUserToExpAccess(notificationMock);
    });

    it("should invoke remove user from collaboration group handler", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        service.handleAddUserToExpAccess(notificationMock);
    });

    it("should invoke creative review batch process notification", () => {
        const service: NotificationService = TestBed.inject(NotificationService);
        service.handleBatchProcessNotification(notificationMock);
        expect(notificationMock.IsPushMessage).toBe("false");
    });
});
