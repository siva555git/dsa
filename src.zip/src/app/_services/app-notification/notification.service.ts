import { Injectable } from "@angular/core";
import { io } from "socket.io-client";
import { POPUP_NOTIFICATION_EVENTS } from "../../_shared/constants/notification.constant";
import { SocketNotificationModel } from "../../_shared/models/socket-notification.model";
import { AppBroadCastService } from "../app-broadcast/app.broadcast.service";
import { AppDataService } from "../app-data/app.data.service";

/**
 * Service to listen user events
 *
 * @export
 * @class NotificationService
 */
@Injectable()
export class NotificationService {
    constructor(public appBroadCastService: AppBroadCastService, private readonly appDataService: AppDataService) {}

    public socket;

    /**
     * Method to initiate socket connection to server
     *
     * @param {string} sapempid
     * @memberof NotificationService
     * @return {void}
     */
    public initiateSocketConnection(sapempid: string): void {
        this.socket = io(this.appDataService.url.socketServer, { transports: ["websocket"] });
        this.socket.emit(POPUP_NOTIFICATION_EVENTS.USER_JOIN, { userId: sapempid });
        this.listenToNotifEvents();
    }

    /**
     * Method to listen socket events and trigger respective handlers
     *
     * @memberof NotificationService
     * @return {void}
     */
    public listenToNotifEvents(): void {
        this.socket.on(POPUP_NOTIFICATION_EVENTS.ADD_EXPERIMENT_ACCESS, this.handleAddUserToExpAccess);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.REMOVE_EXPERIMENT_ACCESS, this.handleRemoveUserToExpAccess);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.ADD_COOPERATOR, this.handleAddCooperator);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.REMOVE_COOPERATOR, this.handleRemoveCooperator);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.COPY_OTHERS_EXP, this.handleCopyOthersExperiment);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.CREATIVE_REVIEW_RESULT, this.handleCreativeReviewResult);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.ADD_USER_TO_COLLABORATION_GROUP, this.handleCollaborationNotification);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.LOCK_EXPERIMENT, this.handleLockExperimentNotification);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.DELETE_COLLABORATION_GROUP, this.handleDeleteCollaborationNotification);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.ASSIGN_TRUSTEE, this.handleAssignTrusteeNotification);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.LEAVE_COLLABORATION_GROUP, this.handleLeaveCollaborationNotification);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.REMOVE_MEMBER_FROM_COLLABORATION_GROUP, this.handleRemovedMemberFromCollaboration);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.CREATIVE_REVIEW_BATCH_PROCESS, this.handleBatchProcessNotification);
        this.socket.on(POPUP_NOTIFICATION_EVENTS.VIEWED_MY_EXP, this.handleViewedMyExperimentNotification);
    }

    /**
     * Method to emit event on add user to experiment access
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleAddUserToExpAccess = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onAddExpAccessNotify(notificationDetails);
    };

    /**
     * Method to emit event on remove user from experiment access
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleRemoveUserToExpAccess = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onRemoveExpAccessNotify(notificationDetails);
    };

    /**
     * Method to emit event on add user to co-operator
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleAddCooperator = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onAddCooperatorNotify(notificationDetails);
    };

    /**
     * Method to emit event on remove user from co-operator
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleRemoveCooperator = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onRemoveCooperatorNotify(notificationDetails);
    };

    /**
     * Method to emit event on copy other users experiment
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleCopyOthersExperiment = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onOtherUserExpCopyNotify(notificationDetails);
    };

    /**
     * Method to emit event on receiving creative review result
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleCreativeReviewResult = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onCreativeReviewResultNotify(notificationDetails);
    };

    /**
     * Method to emit event on add user to collaboration group
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleCollaborationNotification = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onCollaborationAddUsersNotify(notificationDetails);
    };

    /**
     * Method to emit event on delete user from collaboration group
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleDeleteCollaborationNotification = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onCollaborationDeleteUsersNotify(notificationDetails);
    };

    /**
     * Method to emit event on lock experiment
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleLockExperimentNotification = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onLockExperimentNotify(notificationDetails);
    };

    /**
     * Method to emit event on add user as a trustee user
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleAssignTrusteeNotification = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onAddTrusteeNotify(notificationDetails);
    };

    /**
     * Method to emit event on leave user from collaboration group
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleLeaveCollaborationNotification = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onCollaborationLeaveUsersNotify(notificationDetails);
    };

    /**
     * Method to emit event on leave user from collaboration group
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleRemovedMemberFromCollaboration = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onRemovedMemberFromCollaborationGroupUsersNotify(notificationDetails);
    };

    /**
     * Method to emit event on batch process
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
    public handleBatchProcessNotification = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onUpdateBatchProcessNotify(notificationDetails);
    };
     /**
     * Method to emit event on batch process
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationService
     * @return {void}
     */
     public handleViewedMyExperimentNotification = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onViewedMyExperimentNotify(notificationDetails);
    };
}
