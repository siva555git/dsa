import { Injectable } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { delay } from "lodash";
import { NotificationHelper } from "@te-shared/components/notification-drawer/helper/notification-helper";
import { DATE_RANGE_DROPDOWN } from "@te-shared/constants";
import { ALERT_APPEARANCE, DEFAULT_TOASTER_OPTIONS, NOTIF_EVENT_TYPE } from "../../_shared/constants/notification.constant";
import { SocketNotificationModel } from "../../_shared/models/socket-notification.model";
import { AppBroadCastService } from "../app-broadcast/app.broadcast.service";

/**
 * Service to subscribe notification events
 *
 * @export
 * @class NotificationSubscriptionService
 */
@Injectable()
export class NotificationSubscriptionService {
    constructor(
        public appBroadCastService: AppBroadCastService,
        private readonly toastrService: ToastrService,
        private readonly notificationHelper: NotificationHelper,
    ) {}

    /**
     * Method to subscribe to notification events and call the respective handlers
     *
     * @memberof NotificationSubscriptionService
     * @returns {void}
     */
    public subscribeNotificationBroadCastService = (): void => {
        this.appBroadCastService.addExpAccessNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.removeExpAccessNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.addCooperatorNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.removeCooperatorNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.otherUserExpCopyNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.creativeReviewResultSubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.collaborationDeleteNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.collaborationNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.lockExperimentNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.addTrusteeNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.collaborationLeaveNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.collaborationRemoveMemberNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.batchProcessNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
        this.appBroadCastService.viewedMyExperimentNotifySubject.subscribe((data: SocketNotificationModel) => {
            this.showNotificationPopUp(data);
        });
    };

    /**
     * Method to trigger popup based on type of event
     *
     * @memberof NotificationSubscriptionService
     * @param {SocketNotificationModel} notificationDetails
     * @returns {void}
     */
    public showNotificationPopUp = (notificationDetails: SocketNotificationModel): void => {
        // Method to update bell icon count and notification list view
        this.updateBellIconAndNotificationListDrawer();
        // Check user denied the push notifications
        if (!notificationDetails.isValidPush) {
            return;
        }
        // Method to trigger sound on receiving notifications
        if (notificationDetails.shouldPlaySound) {
            this.triggerNotificationTone();
        }

        // Show popup based on notificationtype
        if (notificationDetails.NotificationTypeID === NOTIF_EVENT_TYPE.ERROR) {
            this.errorPopUp(notificationDetails);
        } else {
            this.infoPopUp(notificationDetails);
        }

        delay(() => {
            this.notificationHelper.viewAllNotifications(DATE_RANGE_DROPDOWN[2].OneWeek);
        }, 500);
    };

    /**
     * Method to send event to trigger sound on receiving notifications
     *
     * @memberof NotificationSubscriptionService
     */
    public triggerNotificationTone = (): void => {
        this.appBroadCastService.onPushNotificationNotifyWithSound();
    };

    /**
     * Method to update bell icon count and notification list view
     *
     * @memberof NotificationSubscriptionService
     */
    public updateBellIconAndNotificationListDrawer = (): void => {
        this.appBroadCastService.onPushNotificationNotify();
    };

    /**
     * Method to trigger toaster for information
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationSubscriptionService
     * @returns {void}
     */
    public infoPopUp(notificationDetails: SocketNotificationModel): void {
        DEFAULT_TOASTER_OPTIONS.positionClass = ALERT_APPEARANCE[notificationDetails.alertAppearance];
        this.toastrService
            .info(`${notificationDetails.Body}`, `${notificationDetails.Subject}`, DEFAULT_TOASTER_OPTIONS)
            .onTap.pipe()
            .subscribe(() => {
                // Open experiment in new tab when experiment code is clicked
                this.openTabOnExpCodeClick(notificationDetails);
            });
    }

    /**
     * Method to open experiment in a tab when experiment code is clicked
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationSubscriptionService
     * @returns {void}
     */
    public openTabOnExpCodeClick = (notificationDetails: SocketNotificationModel): void => {
        this.appBroadCastService.onSharedExperimentNotify({
            experimentCode: notificationDetails.ExpCode,
        });
    };

    /**
     * Method to trigger toaster for error
     *
     * @param {SocketNotificationModel} notificationDetails
     * @memberof NotificationSubscriptionService
     * @returns {void}
     */
    public errorPopUp(notificationDetails: SocketNotificationModel): void {
        DEFAULT_TOASTER_OPTIONS.positionClass = ALERT_APPEARANCE[notificationDetails.alertAppearance];
        this.toastrService.error(`${notificationDetails.Body}`, `${notificationDetails.Subject}`, DEFAULT_TOASTER_OPTIONS);
    }
}
