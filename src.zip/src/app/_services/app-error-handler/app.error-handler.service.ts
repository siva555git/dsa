/* eslint-disable  @typescript-eslint/explicit-module-boundary-types */

/** Angular Modules */
import { ErrorHandler, Injectable } from "@angular/core";

/** Dependencies */
import { NGXLogger } from "ngx-logger";

/** Services */
import { ErrorFormatService } from "../app-common/error-format/error-format.service";

/**
 *Class AppErrorHandlerService
 *
 * @export
 * @class AppErrorHandlerService
 * @implements {ErrorHandler}
 */
@Injectable({
    providedIn: "root",
})
export class AppErrorHandlerService implements ErrorHandler {
    /**
     *Creates an instance of AppErrorHandlerService.
     * @param {ErrorFormatService} formatService
     * @param {NGXLogger} logger
     * @memberof AppErrorHandlerService
     */
    constructor(private formatService: ErrorFormatService, private logger: NGXLogger) {}

    /**
     *Handles application level errors
     *
     * @param {*} error
     * @memberof AppErrorHandlerService
     */
    handleError(error): void {
        const message = error.message ?? error.toString();
        // eslint-disable-next-line no-console
        console.log(error);
        this.logger.error(message, this.formatService.getFormattedError(error));
    }
}
