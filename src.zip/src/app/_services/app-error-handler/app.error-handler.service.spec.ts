import { TestBed } from "@angular/core/testing";
import { NGXLogger, CustomNGXLoggerService, NGXLoggerConfigEngine } from "ngx-logger";
import { AppErrorHandlerService } from "./app.error-handler.service";
import { ErrorFormatService } from "../app-common/error-format/error-format.service";
import { MockErrorFormatService } from "../../testing/mock-error-format.service";
import { MockNGXLoggerHttpService, MockLoggerService, MockLoggerConfig } from "../../testing/mock-logger.service";

describe("AppErrorHandlerService", () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                AppErrorHandlerService,
                {
                    provide: ErrorFormatService,
                    useClass: MockErrorFormatService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: CustomNGXLoggerService,
                    useClass: MockNGXLoggerHttpService,
                },
                {
                    provide: NGXLoggerConfigEngine,
                    useClass: MockLoggerConfig,
                },
            ],
        });
    });

    it("should create", () => {
        const errorHandler = TestBed.inject(AppErrorHandlerService);
        expect(errorHandler).toBeTruthy();
    });

    it("should be able to handle global errors", () => {
        const errorHandler = TestBed.inject(AppErrorHandlerService);
        const formatService: ErrorFormatService = TestBed.inject(ErrorFormatService);
        const logger: NGXLogger = TestBed.inject(NGXLogger);

        spyOn(formatService, "getFormattedError").and.returnValue({ message: "Unhandled global error" });
        spyOn(logger, "error");

        const error = "Unhandled App Error";
        errorHandler.handleError(error);

        expect(formatService.getFormattedError).toHaveBeenCalledWith(error);
        /* eslint-disable-next-line no-new-object */
        expect(logger.error).toHaveBeenCalledWith("Unhandled App Error", new Object({ message: "Unhandled global error" }));
    });
});
