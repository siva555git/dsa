/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types */

/** Angular Modules */
import { Injectable } from "@angular/core";

/** rxjs */
import { BehaviorSubject, Subject } from "rxjs";
// eslint-disable-next-line import/no-unresolved
import { ColumnLayouTypePayload } from "src/app/master-data/models/column-layout.model";
import { IpcBasicAttributeInfo } from "@te-shared/components/add-ipc-list/models/add-ipc-list.model";
import { BomDetailsModel } from "@te-shared/models/experiment-bom.model";
import { SocketNotificationModel } from "../../_shared/models/socket-notification.model";
import { UpdatedVariantData } from "../../_shared/models/variant.model";
import { FooterRefreshModel } from "../../experiment-editor/models/experiment-editor.model";
import { RefreshGridModel } from "../../experiment-editor/models/grid-refresh.model";
import { AllOtherExperiment, CreateExperiment, WorkSpaceUpdateModel } from "../../_shared/models/create-experiment.model";
import { CacheSortModel, TabsCrudDataModel, WorkSpaces } from "../../_shared/models/create-tab.model";
import { RefreshExperimentHeaderModel } from "../../_shared/models/experiments.model";
import { CollaborationGroupListModel } from "../../_shared/models/user-collaboration-group.model";
import { ExperimentDetails, ExperimentList, WorkSpaceDialogResponse } from "../../_shared/models";
import { ReviewSelectedRowDataModel } from "../../creative-review/models/creative-review.model";

@Injectable()
export class AppBroadCastService {
    /** private members */
    private currentUserSubject = new Subject<any>();

    private showHeaderSubject = new Subject<any>();

    private findTextLineageSub = new Subject<any>();

    /** public members */

    public appSpinnerPrompt = new Subject<string>();

    // For socket notifications

    public pushNotificationSubject = new Subject<SocketNotificationModel | void>();

    public pushNotificationToneSubject = new Subject<SocketNotificationModel | void>();

    public addCooperatorNotifySubject = new Subject<SocketNotificationModel | void>();

    public removeCooperatorNotifySubject = new Subject<SocketNotificationModel | void>();

    public addExpAccessNotifySubject = new Subject<SocketNotificationModel | void>();

    public removeExpAccessNotifySubject = new Subject<SocketNotificationModel | void>();

    public otherUserExpCopyNotifySubject = new Subject<SocketNotificationModel | void>();

    public sharedExperimentNotificationClickSubject = new Subject<{ experimentCode: string }>();

    public creativeReviewResultSubject = new Subject<SocketNotificationModel | void>();

    public collaborationNotifySubject = new Subject<SocketNotificationModel | void>();

    public collaborationDeleteNotifySubject = new Subject<SocketNotificationModel | void>();

    public lockExperimentNotifySubject = new Subject<SocketNotificationModel | void>();

    public experimentUpdateSubject = new Subject<ExperimentList>();

    public isHomeUrlIdentifySubject = new Subject<boolean>();

    public experimentDetailsSubject = new Subject<ExperimentDetails>();

    public experimentRemoveSubject = new Subject<boolean>();

    public showLoader = new Subject<AllOtherExperiment>();

    // For socket notifications

    public activeSideBarMenu = new Subject<any>();

    public openFolderTreeView = new Subject<void>();

    public createUserTabSubject = new Subject<any>();

    public tabsCrudOperationSubject = new Subject<any>();

    public createExperimentsSubject = new Subject<CreateExperiment>();

    public editLayoutSubject = new Subject<any>();

    public experimentListSubject: string[] = [];

    public selectedTabName = "";

    public refreshGrid = new Subject<RefreshGridModel>();

    public lastColumnLayoutUsedSubject = new Subject<any>();

    public updatedColumnLayoutSubject = new Subject<any>();

    public workspaceDialogResponseSubject = new Subject<any>();

    public refreshExperimentHeader = new Subject<RefreshExperimentHeaderModel>();

    // AG GRID
    public refreshFooter = new Subject<FooterRefreshModel>();
    // AG GRID

    public notificationsSubject = new Subject<any>();

    public matomoDetect = new Subject<string>();

    public editSuggestSubject = new Subject<any>();

    public getSuggestGridDataSubject = new Subject<any>();

    public variantSubject = new Subject<UpdatedVariantData>();

    public userPrefCurrency = new Subject<string>();

    public openNewExperiment = new Subject<any>();

    public creativeReviewLoaderSubject = new Subject<boolean>();

    public createCollaborationGroupSubject = new Subject<void>();

    public deleteCollaborationGroupSubject = new Subject<CollaborationGroupListModel>();

    public experimentRemovedFromList = new Subject<any>();

    public createGroupFromNoRowOverlay = new Subject<CollaborationGroupListModel>();

    public payLoadForEditionSubject = new Subject<any>();

    public navigateToWorkspaceSub = new Subject<any>();

    public selectedExpSubject = new Subject<any>();

    public creativeReviewSubject = new Subject<any>();

    public productVariantSubject = new Subject<any>();

    public productTab = this.productVariantSubject.asObservable();

    public updateCollaborationGroupSubject = new Subject<void>();

    public selectedExp = this.selectedExpSubject.asObservable();

    public creativeReview = this.creativeReviewSubject.asObservable();

    public payLoadForEdition = this.payLoadForEditionSubject.asObservable();

    public showHeader = this.showHeaderSubject.asObservable();

    public subCurrentUser = this.currentUserSubject.asObservable();

    public updateAppSpinnerPrompt = this.appSpinnerPrompt.asObservable();

    public updateActiveSideMenu = this.activeSideBarMenu.asObservable();

    public updateOpenFolderTreeView = this.openFolderTreeView.asObservable();

    public createUserTabs = this.createUserTabSubject.asObservable();

    public tabsCrudOperation = this.tabsCrudOperationSubject.asObservable();

    public createExperiments = this.createExperimentsSubject.asObservable();

    public editLayouts = this.editLayoutSubject.asObservable();

    public editSuggestActions = this.editSuggestSubject.asObservable();

    public getSuggestGridData = this.getSuggestGridDataSubject.asObservable();

    // public updateReviewTabName = this.selectedTabName.asObservable();

    public updateWorkspace = this.refreshGrid.asObservable();

    public lastColumnLayoutUsed = this.lastColumnLayoutUsedSubject.asObservable();

    public updatedColumnLayout = this.updatedColumnLayoutSubject.asObservable();

    public workspaceDialogResponse = this.workspaceDialogResponseSubject.asObservable();

    public refreshExperimentHeaderSubject = this.refreshExperimentHeader.asObservable();

    // AG GRID
    public refreshFooterValues = this.refreshFooter.asObservable();
    // AG GRID

    public allNotifications = this.notificationsSubject.asObservable();

    public getFindTextValueFromLineage = this.findTextLineageSub.asObservable();

    public getUserPrefCurrency = this.userPrefCurrency.asObservable();

    public createCollaborationGroup = this.createCollaborationGroupSubject.asObservable();

    public deleteCollaborationGroup = this.deleteCollaborationGroupSubject.asObservable();

    public columnLayoutSavedData = new Subject<ColumnLayouTypePayload[]>();

    public workSpaceSub = new Subject<any>();

    public updatedWorkSpace = new Subject<WorkSpaceUpdateModel>();

    public workSpaceBomSearch = new Subject<any>();

    public workSpaceFromCache = this.workSpaceBomSearch.asObservable();

    public addTrusteeNotifySubject = new Subject<SocketNotificationModel | void>();

    public folderLocation = new Subject<ExperimentDetails>();

    public selectedFolderLocation = this.folderLocation.asObservable();

    public collaborationLeaveNotifySubject = new Subject<SocketNotificationModel | void>();

    public accessList = new Subject<any>();

    public sortOrderSubject = new Subject<CacheSortModel>();

    private findTextRestrictedView = new Subject<any>();

    public onPublishFindTextFromRestrictedViewList = this.findTextRestrictedView.asObservable();

    public collaborationRemoveMemberNotifySubject = new Subject<SocketNotificationModel | void>();

    public updateCollaborationGroup = this.updateCollaborationGroupSubject.asObservable();

    public selectExpIngrediantSearchSubject = new BehaviorSubject<boolean>(false);

    public selectExpIngrediantSearch = this.selectExpIngrediantSearchSubject.asObservable();

    public selectedIngrediantSearchSubject = new Subject<number>();

    public selectedIngrediantSearch = this.selectedIngrediantSearchSubject.asObservable();

    public batchProcessNotifySubject = new Subject<SocketNotificationModel | void>();
    
    public viewedMyExperimentNotifySubject = new Subject<SocketNotificationModel | void>();
    
    public viewedMyExperimentNotificationClickSubject = new Subject<{ experimentCode: string }>();
    
    public clearSelectedExperimentRowsSubject = new Subject<any>();

    public onAddedSelectedExperimentRowsToCG = this.clearSelectedExperimentRowsSubject.asObservable();

    public clearHoveredCGSubject = new Subject<any>();

    public onClearHoveredCG = this.clearHoveredCGSubject.asObservable();

    public reviewSelectedExpSubject = new Subject<ReviewSelectedRowDataModel[]>();

    public onReviewSelectedExp = this.reviewSelectedExpSubject.asObservable();

    public creativeReviewComparisonSubject = new Subject<boolean>();

    public reviewComparison = this.creativeReviewComparisonSubject.asObservable();

    public addedIpcListSubject = new Subject<{ attributes: IpcBasicAttributeInfo[]; addType: string }>();

    public addedIpcListInfo = this.addedIpcListSubject.asObservable();

    public excelFileData = new Subject<any>();

    public uploadedExcelFileData = this.excelFileData.asObservable();

    public textFileData = new Subject<any>();

    public uploadedTextFileData = this.textFileData.asObservable();

    public refreshBomDetails = new Subject<BomDetailsModel>();

    public updatedBomDetails = this.refreshBomDetails.asObservable();

    /**
     * Method called on update app spinner prompt
     * @param {string} value
     * @memberof AppBroadCastService
     */
    public onUpdateAppSpinnerPrompt(value: string): void {
        this.appSpinnerPrompt.next(value);
    }

    /**
     * Method to broad cast payload for edition
     * @param response
     * @memberof AppBroadCastService
     */
    public broadcastingPayLoadForEdition(response): void {
        this.payLoadForEditionSubject.next(response);
    }

    /**
     * Method called on pub current user
     * @param value
     * @memberof AppBroadCastService
     */
    public pubCurrentUser(value: any): void {
        this.currentUserSubject.next(value);
    }

    /**
     * Method called on pub show header
     * @param {any} value
     * @memberof AppBroadCastService
     */
    public pubShowHeader(value: any): void {
        this.showHeaderSubject.next(value);
    }

    /**
     * Method called on updating active class sidebar
     * @param {any} value
     * @memberof AppBroadCastService
     */
    public onUpdateActiveClassSideBar(value: any): void {
        this.activeSideBarMenu.next(value);
    }

    /**
     * Method called on opening folder tree view
     * @memberof AppBroadCastService
     */
    public onOpenFolderTreeView(): void {
        this.openFolderTreeView.next();
    }

    /**
     * Method called on new user tab creation
     * @param {any} value
     * @memberof AppBroadCastService
     */
    public onCreateUserTabs(value: any): void {
        this.createUserTabSubject.next(value);
    }

    /**
     * Method called on tab action change
     * @param {TabsCrudDataModel} value
     * @memberof AppBroadCastService
     */
    public onTabsActionChange(value: TabsCrudDataModel): void {
        this.tabsCrudOperationSubject.next(value);
    }

    /**
     * Method called on creating experiment
     * @param {CreateExperiment} value
     * @memberof AppBroadCastService
     */
    public onExperimentCreated(value: CreateExperiment): void {
        this.createExperimentsSubject.next(value);
    }

    /**
     * Method called on changing layout
     * @param {any} value
     * @memberof AppBroadCastService
     */
    public onLayoutChange(value: any): void {
        this.editLayoutSubject.next(value);
    }

    /**
     * Method called on changing experiment
     * @param {any[]} value
     * @memberof AppBroadCastService
     */
    public onExperimentChange(value: any[]): void {
        this.experimentListSubject = value;
    }

    /**
     * Method to get selected Experiments
     * @returns {string[]}
     * @memberof AppBroadCastService
     */
    public getSelectedExperiments(): string[] {
        return this.experimentListSubject;
    }

    /**
     * Method to get side bar experiment
     * @param {any} value
     * @memberof AppBroadCastService
     */
    public getSideBarExperiment(value: any): void {
        this.selectedExpSubject.next(value);
    }

    /**
     * Method to open creative review popup
     * @param {boolean} value
     * @memberof AppBroadCastService
     */
    public creativeReviewPopup(value: boolean): void {
        this.creativeReviewSubject.next(value);
    }

    public produtVatiantTab(value: any): void {
        this.productVariantSubject.next(value);
    }

    /**
     * Method to send event to udpate about the tab changes
     * @param {string} value
     * @memberof AppBroadCastService
     */
    public onReviewTabChange(value: string): void {
        this.selectedTabName = value;
    }

    public getReviewTab(): string {
        return this.selectedTabName;
    }

    /**
     * Method to update the bomdetails for the experiment header
     *
     * @param {*} bomdetails
     * @memberof AppBroadCastService
     */
    public onRefreshBomdetailsForExpHeader(bomdetails: BomDetailsModel): void {
        this.refreshBomDetails.next(bomdetails);
    }

    /**
     * Method to send event to refresh the grid based on  grid actions
     * @param {RefreshGridModel} refreshGrid
     * @memberof AppBroadCastService
     */
    public onRefreshGrid(refreshGrid: RefreshGridModel): void {
        this.refreshGrid.next({
            refreshType: refreshGrid?.refreshType,
            refreshData: refreshGrid?.refreshData,
            openNewExpInWorkspace: refreshGrid?.openNewExpInWorkspace,
            isAddVariant: refreshGrid?.isAddVariant,
            IsInstructionFromQuickInsert: refreshGrid?.IsInstructionFromQuickInsert,
        });
    }

    /**
     * Method to send event to get last used column layout
     * @memberof AppBroadCastService
     */
    public onLastColumnLayoutUsed(value: any): void {
        this.lastColumnLayoutUsedSubject.next(value);
    }

    /**
     * Method called on updating column layout
     * @param response
     * @memberof AppBroadCastService
     */
    public onUpdatedColumnLayout(response): void {
        this.updatedColumnLayoutSubject.next(response);
    }

    /**
     * Method to update the workspace dialog response for product index
     *
     * @param {WorkSpaceDialogResponse} response
     * @memberof AppBroadCastService
     */
    public onWorkspaceDialogResponse(response: WorkSpaceDialogResponse): void {
        this.workspaceDialogResponseSubject.next(response);
    }

    /**
     * Method to send event to refresh the experiment based on header actions
     * @param {RefreshExperimentHeaderModel} refreshExperimentHeader
     * @memberof AppBroadCastService
     */
    public onRefreshExperimentHeader(refreshExperimentHeader: RefreshExperimentHeaderModel): void {
        this.refreshExperimentHeader.next({
            refreshType: refreshExperimentHeader.refreshType,
            refreshData: refreshExperimentHeader.refreshData,
        });
    }

    /**
     * Method to send event to refresh the experiment based on header actions
     * @param {RefreshExperimentHeaderModel} refreshExperimentHeader
     * @memberof AppBroadCastService
     */
    public onRefreshFooter(refreshFooter: FooterRefreshModel): void {
        this.refreshFooter.next({
            footerType: refreshFooter.footerType,
            footerValues: refreshFooter.footerValues,
        });
    }

    /**
     * Method to send event to get notification details
     * @memberof AppBroadCastService
     */
    public getAllNotifications(value: any): void {
        this.notificationsSubject.next(value);
    }

    /**
     * Method to send event to get variant details
     * @memberof AppBroadCastService
     */
    public onUpdateVariant(value: UpdatedVariantData): void {
        this.variantSubject.next(value);
    }

    /**
     * Method to send event to trigger notification on add user to co-operator
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onAddCooperatorNotify(value: SocketNotificationModel): void {
        this.addCooperatorNotifySubject.next(value);
    }

    /**
     * Method to send event to trigger notification on remove user to co-operator
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onRemoveCooperatorNotify(value: SocketNotificationModel): void {
        this.removeCooperatorNotifySubject.next(value);
    }

    /**
     * Method to send event to trigger notification on add user to experiment access
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onAddExpAccessNotify(value: SocketNotificationModel): void {
        this.addExpAccessNotifySubject.next(value);
    }

    /**
     * Method to send event to trigger notification on remove user from experiment access
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onRemoveExpAccessNotify(value: SocketNotificationModel): void {
        this.removeExpAccessNotifySubject.next(value);
    }

    /**
     * Method to send event to trigger notification on copy other users experiment
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onOtherUserExpCopyNotify(value: SocketNotificationModel): void {
        this.otherUserExpCopyNotifySubject.next(value);
    }

    /**
     * Method to send when experiment is shared and trying to open in tab
     *
     * @param {*} value
     * @memberof AppBroadCastService
     */
    public onSharedExperimentNotify(value): void {
        this.sharedExperimentNotificationClickSubject.next(value);
    }

    /*
     * Method to send event to trigger notification on receiving creative review result
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onCreativeReviewResultNotify(value: SocketNotificationModel): void {
        this.creativeReviewResultSubject.next(value);
    }

    /**
     * Method to send event to trigger sound on receiving notifications
     *
     * @memberof AppBroadCastService
     * @returns {void}
     */
    public onPushNotificationNotifyWithSound(): void {
        this.pushNotificationToneSubject.next();
    }

    /**
     * Method to send event to update notification list
     *
     * @memberof AppBroadCastService
     * @returns {void}
     */
    public onPushNotificationNotify(): void {
        this.pushNotificationSubject.next();
    }

    /**
     * Method to send event to trigger find text value
     *  @returns {void}
     *  @param {string} findText
     * @memberof AppBroadCastService
     */
    public onPublishFindTextFromLineage(findText: string): void {
        this.findTextLineageSub.next(findText);
    }

    /**
     * Method to publish currency value
     *  @returns {void}
     *  @param {string} currencyName
     * @memberof AppBroadCastService
     */
    public onPublishUserPrefCurrency(currencyName: string): void {
        this.userPrefCurrency.next(currencyName);
    }

    /**
     * Method to handle Edition Suggestion Actions
     *
     * @param {*} response
     * @memberof AppBroadCastService
     */
    public onEditSuggestAction(response): void {
        this.editSuggestSubject.next(response);
    }

    /**
     * Method to handle Edition Suggestion Actions
     *
     * @param {*} response
     * @memberof AppBroadCastService
     */
    public onGettingSuggestGridData(response): void {
        this.getSuggestGridDataSubject.next(response);
    }

    /**
     * Method to handle Edition Suggestion Actions
     *
     * @param {*} response
     * @memberof AppBroadCastService
     */
    public onOpenNewExperiment(response): void {
        this.openNewExperiment.next(response);
    }

    /**
     * Method to send event to get notification details
     * @memberof AppBroadCastService
     */
    public onCreateCollaborationGroup(): void {
        this.createCollaborationGroupSubject.next();
    }

    /**
     * Method to send event to switch to previous group or parent folder
     *
     * @param {CollaborationGroupListModel} collaborationGroup
     * @memberof AppBroadCastService
     */
    public onDeleteCollaborationGroup(collaborationGroup: CollaborationGroupListModel): void {
        this.deleteCollaborationGroupSubject.next(collaborationGroup);
    }

    /**
     * Method to send event to trigger notification on add user to collaboration group
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onCollaborationAddUsersNotify(value: SocketNotificationModel): void {
        this.collaborationNotifySubject.next(value);
    }

    /**
     * Method to send event to trigger notification on delete user from collaboration group
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onCollaborationDeleteUsersNotify(value: SocketNotificationModel): void {
        this.collaborationDeleteNotifySubject.next(value);
    }

    /**
     * Method to send event to trigger notification on lock experiment
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onLockExperimentNotify(value: SocketNotificationModel): void {
        this.lockExperimentNotifySubject.next(value);
    }

    /**
     * Method to see the update related changes in the home screen
     *
     * @param {ExperimentList} value
     * @memberof AppBroadCastService
     */

    public experimentUpdate(value: ExperimentList): void {
        this.experimentUpdateSubject.next(value);
    }

    /**
     * Method to see the remove related changes in the home screen
     *
     * @param {boolean} value
     * @memberof AppBroadCastService
     */

    public experimentRemove(value: boolean): void {
        this.experimentRemoveSubject.next(value);
    }

    /**
     * Method to pass the loader and the other parameters to the experiment-header component
     *
     * @param {*} value
     * @memberof AppBroadCastService
     */

    public showLoaderProperty(value: AllOtherExperiment): void {
        this.showLoader.next(value);
    }

    /**
     * Method to send event to udpate which workspacename is being clicked and to navigate to corresponding workspace.
     *
     * @param {WorkSpaces} workSpaceDetail
     * @memberof AppBroadCastService
     * @returns {void}
     */
    public getWorkSpaceDetails(workSpaceDetail: WorkSpaces): void {
        this.navigateToWorkspaceSub.next(workSpaceDetail);
    }

    /**
     * Method to send event to get the workspace details from cache
     *
     * @param {WorkSpaces} workSpaceDetail
     * @memberof AppBroadCastService
     * @returns {void}
     */
    public getWorkSpaceBomSearchFromCache(value?: number): void {
        this.workSpaceBomSearch.next(value);
    }

    /**
     * Method to send event to trigger notification on add user as a trustee user
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onAddTrusteeNotify(value: SocketNotificationModel): void {
        this.addTrusteeNotifySubject.next(value);
    }

    /**
     * Method to send event to trigger notification on leave user from collaboration group
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onCollaborationLeaveUsersNotify(value: SocketNotificationModel): void {
        this.collaborationLeaveNotifySubject.next(value);
    }

    /*
     * Method to pass the selected Experiment related details from editBom screen.
     *
     * @param {ExperimentDetails} experiment
     * @memberof AppBroadCastService
     */

    public onExperimentRedirectionInfo(experiment: ExperimentDetails): void {
        this.experimentDetailsSubject.next(experiment);
    }

    /**
     * Method to see if the current Url is Home or Not
     *
     * @param {isHome} boolean
     * @memberof AppBroadCastService
     */

    public checkHomeUrl(isHome: boolean): void {
        this.isHomeUrlIdentifySubject.next(isHome);
    }

    /**
     * Method to send event to get the selected exp details
     *
     * @param {ExperimentDetails} expDetail
     * @memberof AppBroadCastService
     * @returns {void}
     */
    public getSelectedExpFolderDetails(expDetail: ExperimentDetails): void {
        this.folderLocation.next(expDetail);
    }

    public onPublishFindRestrictedViewList(findText: string): void {
        this.findTextRestrictedView.next(findText);
    }

    /**
     * Method to send event to trigger notification on removed member/user from collaboration group
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onRemovedMemberFromCollaborationGroupUsersNotify(value: SocketNotificationModel): void {
        this.collaborationRemoveMemberNotifySubject.next(value);
    }

    /**
     * Method to triger event on update CG
     * @memberof AppBroadCastService
     */
    public onUpdateCollaborationGroup() {
        this.updateCollaborationGroupSubject.next();
    }

    /**
     * Method to triger event on update CG
     *
     * @param {boolean} selectAllCheckBox
     * @memberof AppBroadCastService
     */
    public onSelectExpIngrediantSearch(selectAllCheckBox: boolean): void {
        this.selectExpIngrediantSearchSubject.next(selectAllCheckBox);
    }

    /**
     * Method to triger event on update CG
     * @memberof AppBroadCastService
     */
    public seletectedExpInIngrediantSearch(selectedExps: number): void {
        this.selectedIngrediantSearchSubject.next(selectedExps);
    }

    /*
     * Method to send event to trigger notification on batch process
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onUpdateBatchProcessNotify(value: SocketNotificationModel): void {
        this.batchProcessNotifySubject.next(value);
    }
    
    /*
     * Method to send event to trigger notification on batch process
     *
     * @param {SocketNotificationModel} value
     * @memberof AppBroadCastService
     */
    public onViewedMyExperimentNotify(value): void {
        this.viewedMyExperimentNotifySubject.next(value);
    }

    /*
     * Method to trigger clear selection while dragged experiments to CG
     * @param value
     */
    public onAddedToCollaborationGroupClearSelectedRows(value: boolean): void {
        this.clearSelectedExperimentRowsSubject.next(value);
        this.onClearCGClass(value);
    }

    /**
     * Method to clear hover class from CG
     * @param value
     */
    public onClearCGClass(value: boolean): void {
        this.clearHoveredCGSubject.next(value);
    }

    /**
     * Method to trigger creative review when select the experiment
     * @param value
     */
    public onCreativeReviewSelectedExp(value): void {
        this.reviewSelectedExpSubject.next(value);
    }

    /*
     * Method to open BOM/BOS review comparison popup
     * @param {boolean} value
     * @memberof AppBroadCastService
     */
    public reviewComparisonPopup(value: boolean): void {
        this.creativeReviewComparisonSubject.next(value);
    }

    /*
     * Method to add ipc list in ipc selection criteria
     * @param {any} value
     * @memberof AppBroadCastService
     */
    public addedIpcListValue(value: { attributes: IpcBasicAttributeInfo[]; addType: string }): void {
        this.addedIpcListSubject.next(value);
    }

    /*
     * Method to pass excel file data
     * @param {any} value
     * @memberof AppBroadCastService
     */
    public uploadedExcelFileInfo(value): void {
        this.excelFileData.next(value);
    }

    /*
     * Method to pass text file data
     * @param {any} value
     * @memberof AppBroadCastService
     */
    public uploadedTextFileInfo(value): void {
        this.textFileData.next(value);
    }
}
