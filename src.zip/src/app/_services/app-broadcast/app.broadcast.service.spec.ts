/* eslint-disable unicorn/no-null */
/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
import { TestBed } from "@angular/core/testing";
import { AppBroadCastService } from "./app.broadcast.service";
import { SpyService, callback } from "../../testing/spy.service";
import { FooterRefreshModel } from "../../experiment-editor/models/experiment-editor.model";
import { ExperimentList, WorkSpaceDialogResponse } from "../../_shared/models/experiment-list.model";

describe("AppBroadCastService", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            providers: [AppBroadCastService],
        }),
    );

    const socketNotificationModel = {
        Subject: "test",
        Body: "test",
        NotificationTypeID: 1,
        NotificationEventID: 1,
        CreatedTo: 1,
        IsPushMessage: "test",
        UserName: "kxs8282",
        alertAppearance: "test",
        isValidPush: true,
        ExpCode: "aaa000123",
        shouldPlaySound: true,
    };
    const experimentDetails = {
        ExperimentCode: "test",
        FolderName: "test",
        FolderID: 1234,
    };

    const workSpaces = {
        SavedLayoutTypeID: 1,
        CustomLayoutTypeID: 1,
        IsSavedSelected: true,
        class: "test",
        CreatedBy: 1,
        CreatedOn: "2020-08-19T09:46:01.000Z",
        IsCurrent: "test",
        Sequence: 1,
        TabName: "one",
        UpdatedBy: 1,
        UpdatedOn: "2020-08-19T09:46:01.000Z",
        UserTabID: 1,
        IsHideDeletedSetting: true,
        ProductSearchID: 1,
    };
    const experimentList = {
        IPC: null,
        Task: null,
        ExpID: 1,
        UOMID: 1,
        Yield: 99,
        Comment: "test",
        ExpCode: "zaaa0000",
        isESResponseFlag: true,
        ExpName: "aaa",
        PlantID: "test",
        Trustee: 1,
        IsLocked: true,
        IsPublic: true,
        LockedBy: 1,
        LockedOn: 1,
        UseLevel: 1,
        BatchSize: 1,
        CreatedBy: 1,
        CreatedOn: new Date(),
        ExpSource: "test",
        IsDeleted: true,
        UpdatedBy: 1,
        UpdatedOn: new Date(),
        ArchivedOn: 1,
        FolderName: "test",
        IsArchived: true,
        CountryCode: "test",
        IsFavourite: true,
        ProductTypeID: "test",
        ExperimentLineage: {
            ExpLineageID: 1,
            CreatedBy: 1,
            UpdatedBy: 1,
            ExpID: 1,
        },
        SourceFlagCodeID: "test",
        ExperimentVariant: "test",
        UserCollaborationGroupMapped: "test",
    } as unknown as ExperimentList;

    it("should create", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        expect(service).toBeTruthy();
    });

    it("should receive spinner content on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();

        service.appSpinnerPrompt.subscribe(() => callback(spyService));
        service.onUpdateAppSpinnerPrompt("Test Value");

        expect(spyService.called).toBeTruthy();
    });

    it("should receive current user info on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.subCurrentUser.subscribe(() => callback(spyService));
        service.pubCurrentUser("Current User Info");

        expect(spyService.called).toBeTruthy();
    });

    it("should receive header info on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.showHeader.subscribe(() => callback(spyService));
        service.pubShowHeader("Test Header");

        expect(spyService.called).toBeTruthy();
    });

    it("should receive sidebar active info on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.updateActiveSideMenu.subscribe(() => callback(spyService));
        service.onUpdateActiveClassSideBar("Test Sidebar");

        expect(spyService.called).toBeTruthy();
    });

    it("should receive to open folderview info on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.updateOpenFolderTreeView.subscribe(() => callback(spyService));
        service.onOpenFolderTreeView();

        expect(spyService.called).toBeTruthy();
    });

    it("should receive review tab change info on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        service.onReviewTabChange("Test review tab change");
        expect(spyService.called).toBeFalsy();
    });

    it("should receive create user tab info on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.createUserTabs.subscribe(() => callback(spyService));
        service.onCreateUserTabs("Test create user tabs");

        expect(spyService.called).toBeTruthy();
    });

    it("should receive layout change info on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.editLayouts.subscribe(() => callback(spyService));
        service.onLayoutChange("Test layout change");

        expect(spyService.called).toBeTruthy();
    });

    it("should receive experiment change info on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.onExperimentChange(["Test experiment change"]);

        expect(spyService.called).toBeFalsy();
    });

    it("should receive tabs action change info on subscribe3", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.tabsCrudOperation.subscribe(() => callback(spyService));
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const data: any = "Test tabs action change";
        service.onTabsActionChange(data);

        expect(spyService.called).toBeTruthy();
    });

    it("should receive experiment create info on subscribe3", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.createExperiments.subscribe(() => callback(spyService));
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const data: any = "Test experiment create";
        service.onExperimentCreated(data);

        expect(spyService.called).toBeTruthy();
    });

    it("should receive home url validation on subscribe ", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        service.isHomeUrlIdentifySubject.subscribe(() => callback(spyService));
        const isHomeUrl = true;
        service.checkHomeUrl(isHomeUrl);

        expect(spyService.called).toBeTruthy();
    });

    it("should receive broadcastingPayLoadForEdition on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.payLoadForEdition.subscribe(() => callback(spyService));
        service.broadcastingPayLoadForEdition("Test");
        expect(spyService.called).toBeTruthy();
    });

    it("should receive triger event on update CG on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.updateCollaborationGroupSubject.subscribe(() => callback(spyService));
        service.onUpdateCollaborationGroup();
        expect(spyService.called).toBeTruthy();
    });

    it("should receive event to trigger notification on removed member/user from collaboration group on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.collaborationRemoveMemberNotifySubject.subscribe(() => callback(spyService));
        service.onRemovedMemberFromCollaborationGroupUsersNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should receive send event to get the selected exp details on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.folderLocation.subscribe(() => callback(spyService));
        service.getSelectedExpFolderDetails(experimentDetails);
        expect(spyService.called).toBeTruthy();
    });

    it("should receive see if the current Url is Home or Not on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.isHomeUrlIdentifySubject.subscribe(() => callback(spyService));
        service.checkHomeUrl(false);
        expect(spyService.called).toBeTruthy();
    });

    it("should rpass the selected Experiment related details from editBom screen on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.experimentDetailsSubject.subscribe(() => callback(spyService));
        service.onExperimentRedirectionInfo(experimentDetails);
        expect(spyService.called).toBeTruthy();
    });

    it("should event to trigger notification on leave user from collaboration group on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.collaborationLeaveNotifySubject.subscribe(() => callback(spyService));
        service.onCollaborationLeaveUsersNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should event to event to trigger notification on add user as a trustee user on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.addTrusteeNotifySubject.subscribe(() => callback(spyService));
        service.onAddTrusteeNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to udpate which workspacename is being clicked and to navigate to corresponding workspace on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.navigateToWorkspaceSub.subscribe(() => callback(spyService));
        service.getWorkSpaceDetails(workSpaces);
        expect(spyService.called).toBeTruthy();
    });

    it("should pass the loader and the other parameters to the experiment-header component subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.showLoader.subscribe(() => callback(spyService));
        const allOtherExperiment = {
            experiments: true,
            isLoading: true,
        };
        service.showLoaderProperty(allOtherExperiment);
        expect(spyService.called).toBeTruthy();
    });

    it("should see the remove related changes in the home screen on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.experimentRemoveSubject.subscribe(() => callback(spyService));
        service.experimentRemove(false);
        expect(spyService.called).toBeTruthy();
    });

    it("should see the remove related changes in the home screen on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.experimentUpdateSubject.subscribe(() => callback(spyService));
        service.experimentUpdate(experimentList);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on lock experiment on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.lockExperimentNotifySubject.subscribe(() => callback(spyService));
        service.onLockExperimentNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on delete user from collaboration group on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.collaborationDeleteNotifySubject.subscribe(() => callback(spyService));
        service.onCollaborationDeleteUsersNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should  send event to switch to previous group or parent folder on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.deleteCollaborationGroupSubject.subscribe(() => callback(spyService));
        const selectedGroup = {
            CollaborationGroupID: 6,
            CreatedByUser: {
                FirstName: "BALA",
                Surname: "MURUGAN",
                UserID: 983_453,
            },
            GroupDescription: "testing",
            GroupName: "GroupName",
            UserCollaborationGroupMapped: [
                {
                    IsOwnedGroup: 0,
                },
            ],
            isActive: true,
        };
        service.onDeleteCollaborationGroup(selectedGroup);
        expect(spyService.called).toBeTruthy();
    });

    it("should send  event to get notification details on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.createCollaborationGroupSubject.subscribe(() => callback(spyService));
        service.onCreateCollaborationGroup();
        expect(spyService.called).toBeTruthy();
    });

    it("should handle Edition Suggestion Actions on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.openNewExperiment.subscribe(() => callback(spyService));
        service.onOpenNewExperiment("test");
        expect(spyService.called).toBeTruthy();
    });

    it("should handle Edition Suggestion Actions by edit on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.editSuggestSubject.subscribe(() => callback(spyService));
        service.onEditSuggestAction("test");
        expect(spyService.called).toBeTruthy();
    });

    it("should publish currency value on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.userPrefCurrency.subscribe(() => callback(spyService));
        service.onPublishUserPrefCurrency("dollar");
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger find text value on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.getFindTextValueFromLineage.subscribe(() => callback(spyService));
        service.onPublishFindTextFromLineage("text");
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to update notification list on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.pushNotificationSubject.subscribe(() => callback(spyService));
        service.onPushNotificationNotify();
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on receiving creative review result on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.creativeReviewResultSubject.subscribe(() => callback(spyService));
        service.onCreativeReviewResultNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should send when experiment is shared and trying to open in tab on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.sharedExperimentNotificationClickSubject.subscribe(() => callback(spyService));
        service.onSharedExperimentNotify("test");
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on copy other users experiment on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.otherUserExpCopyNotifySubject.subscribe(() => callback(spyService));
        service.onOtherUserExpCopyNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on remove user from experiment access on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.removeExpAccessNotifySubject.subscribe(() => callback(spyService));
        service.onRemoveExpAccessNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on add user to experiment access on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.addExpAccessNotifySubject.subscribe(() => callback(spyService));
        service.onAddExpAccessNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on remove user to co-operator on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.removeCooperatorNotifySubject.subscribe(() => callback(spyService));
        service.onRemoveCooperatorNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on add user to co-operator on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.addCooperatorNotifySubject.subscribe(() => callback(spyService));
        service.onAddCooperatorNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to get variant details on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.variantSubject.subscribe(() => callback(spyService));
        const updatedVariantData = {
            variantSource: "text",
            isVariantUpdateCancelled: true,
        };
        service.onUpdateVariant(updatedVariantData);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to get notification details on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.notificationsSubject.subscribe(() => callback(spyService));
        service.getAllNotifications("test");
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to refresh the experiment based on header actions on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.refreshExperimentHeaderSubject.subscribe(() => callback(spyService));
        const updatedVariantData = {
            refreshType: "text",
            refreshData: "text",
        };
        service.onRefreshExperimentHeader(updatedVariantData);
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to refresh the experiment based on header actions on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.refreshFooter.subscribe(() => callback(spyService));
        const refreshFooter = {
            footerType: "text",
            footerValues: "text",
        } as unknown as FooterRefreshModel;
        service.onRefreshFooter(refreshFooter);
        expect(spyService.called).toBeTruthy();
    });

    it("should update the workspace dialog response for product index subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.workspaceDialogResponse.subscribe(() => callback(spyService));
        const workspace = {
            type: "text",
            workSpaceDetail: "text",
        } as unknown as WorkSpaceDialogResponse;
        service.onWorkspaceDialogResponse(workspace);
        expect(spyService.called).toBeTruthy();
    });

    it("should called on updating column layout on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.updatedColumnLayout.subscribe(() => callback(spyService));
        service.onUpdatedColumnLayout("test");
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to refresh the grid based on  grid actions on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.updateWorkspace.subscribe(() => callback(spyService));
        const workspace = {
            refreshType: "text",
            refreshData: "text",
            openNewExpInWorkspace: true,
            isAddVariant: true,
        };
        service.onRefreshGrid(workspace);
        expect(spyService.called).toBeTruthy();
    });

    it("should send send event to get the workspace details from cache subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.workSpaceFromCache.subscribe(() => callback(spyService));
        service.getWorkSpaceBomSearchFromCache();
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger notification on add user to collaboration group on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.collaborationNotifySubject.subscribe(() => callback(spyService));
        service.onCollaborationAddUsersNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });

    it("should handle Edition Suggestion Actions on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.getSuggestGridDataSubject.subscribe(() => callback(spyService));
        service.onGettingSuggestGridData("value");
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to trigger sound on receiving notifications on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.pushNotificationToneSubject.subscribe(() => callback(spyService));
        service.onPushNotificationNotifyWithSound();
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to get last used column layout on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.lastColumnLayoutUsed.subscribe(() => callback(spyService));
        service.onLastColumnLayoutUsed("layout");
        expect(spyService.called).toBeTruthy();
    });

    it("should send event to udpate about the tab changes", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.getReviewTab();
    });

    it("should open creative review popup on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.creativeReview.subscribe(() => callback(spyService));
        service.creativeReviewPopup(true);
        expect(spyService.called).toBeTruthy();
    });

    it("should  get side bar experiment on subscribe", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.selectedExp.subscribe(() => callback(spyService));
        service.getSideBarExperiment("sideBar");
        expect(spyService.called).toBeTruthy();
    });

    it("should get selected Experiments", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.getSelectedExperiments();
    });

    it("should receive event to trigger notification on creative review batch process", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();
        service.batchProcessNotifySubject.subscribe(() => callback(spyService));
        service.onUpdateBatchProcessNotify(socketNotificationModel);
        expect(spyService.called).toBeTruthy();
    });
});
