import { Directive, HostListener, EventEmitter, Output } from "@angular/core";

@Directive({ selector: "[keyCatcher]" })
export class KeyCatcherDirective {
    @Output()
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    keydown: EventEmitter<any> = new EventEmitter();

    @HostListener("document:keydown", ["$event"])
    public onKeydownHandler(event: KeyboardEvent): void {
        if (event) {
            this.keydown = new EventEmitter();
            this.keydown.emit(event);
        }
    }
}
