export { KeyCatcherDirective } from "./key-catcher.directive";
