import { Component, DebugElement } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { KeyCatcherDirective } from "./key-catcher.directive";

@Component({
    template: `<input type="number" keyCatcher />`,
})
class TestKeyCatcherDirective {}

describe("KeyCatcherDirective", () => {
    let fixture: ComponentFixture<TestKeyCatcherDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [TestKeyCatcherDirective, KeyCatcherDirective],
        });
        fixture = TestBed.createComponent(TestKeyCatcherDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new KeyCatcherDirective();
        expect(directive).toBeTruthy();
    });

    it("test for numerical value in input", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("document:keydown", { key: "1" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for numerical value in input when event has value", () => {
        const directive = new KeyCatcherDirective();
        directive.onKeydownHandler(new KeyboardEvent("document:keydown", { key: "1" }));
    });

    it("test for numerical value in input  when event has empty", () => {
        const directive = new KeyCatcherDirective();
        directive.onKeydownHandler({} as KeyboardEvent);
    });
});
