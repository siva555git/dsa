import { Component, DebugElement, ElementRef } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
// eslint-disable-next-line import/no-unresolved
import { MockElementRef as MockElementReference } from "../../../testing/mock-elementRef.service";
import { NumericOnlyDirective } from "./numeric-only.directive";

@Component({
    template: `<input type="number" appNumericOnly />`,
})
class NumberOnlyDirective {}

describe("NumericOnlyDirective", () => {
    let fixture: ComponentFixture<NumberOnlyDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [NumberOnlyDirective, NumericOnlyDirective],
            providers: [{ provide: ElementRef, useClass: MockElementReference }],
        });
        fixture = TestBed.createComponent(NumberOnlyDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new NumberOnlyDirective();
        expect(directive).toBeTruthy();
    });

    it("test for numerical value in input", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("input", { key: "1" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });
});
