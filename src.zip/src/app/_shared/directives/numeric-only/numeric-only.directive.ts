/* eslint-disable unicorn/better-regex */
import { Directive, HostListener, ElementRef } from "@angular/core";

@Directive({
    selector: "[appNumericOnly]",
})
export class NumericOnlyDirective {
    constructor(private readonly element: ElementRef) {}

    @HostListener("input", ["$event"]) onInputChange(event: KeyboardEvent): void {
        const initalValue = this.element.nativeElement.value;
        this.element.nativeElement.value = initalValue.replace(/[^0-9]*/g, "");
        if (initalValue !== this.element.nativeElement.value) {
            event.stopPropagation();
        }
    }
}
