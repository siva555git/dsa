import { Directive, ElementRef, HostListener } from "@angular/core";
import { VALUE } from "@te-shared/components/base-ipc-layout/base-ipc-layout-constant";

@Directive({
    selector: "[appUppercaseInput]",
    host: {
        "(input)": "$event",
    },
})
export class UppercaseInputDirective {
    constructor(public reference: ElementRef) {}

    @HostListener("input", ["$event"]) onKeyUp(event: Event) {
        const inputEvent = event;
        this.reference.nativeElement.value = inputEvent.target[VALUE].toUpperCase();
    }
}
