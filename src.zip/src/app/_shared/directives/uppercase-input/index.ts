export { UppercaseInputDirective } from "./uppercaseinput.directive";
