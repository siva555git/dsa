import { Component, DebugElement } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { UppercaseInputDirective } from "./uppercaseinput.directive";

@Component({
    template: `<input appUppercaseInput />`,
})
class TestUppercaseInputDirective {}

describe("UppercaseInputDirective", () => {
    let fixture: ComponentFixture<TestUppercaseInputDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [TestUppercaseInputDirective, UppercaseInputDirective],
        });
        fixture = TestBed.createComponent(TestUppercaseInputDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new TestUppercaseInputDirective();
        expect(directive).toBeTruthy();
    });

    it("test for numerical value in input", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("input", { key: "abc" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });
});
