import { Component, DebugElement, ElementRef } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { DigitDecimaNumberDirective } from ".";
// eslint-disable-next-line import/no-unresolved
import { MockElementRef as MockElementReference } from "../../../testing/mock-elementRef.service";

@Component({
    template: `<input appDigitDecimaNumber [limitOptions]="LIMIT" />`,
})
class DecimalLimitDirective {}

describe("AlphaNumericDirective", () => {
    let fixture: ComponentFixture<DecimalLimitDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [DecimalLimitDirective, DigitDecimaNumberDirective],
            providers: [{ provide: ElementRef, useClass: MockElementReference }],
        });
        fixture = TestBed.createComponent(DecimalLimitDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new DecimalLimitDirective();
        expect(directive).toBeTruthy();
    });

    it("test for alphanumeric value in input when key is a", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "a" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for alphanumeric value in input when key is Backspace", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "Backspace" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for alphanumeric value in input when key is -", () => {
        inputElement.nativeElement.value = "-5";
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "-" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("-5");
    });

    it("test for numerical value in input2 when key is Decimal", () => {
        inputElement.nativeElement.selectionStart = "5";
        inputElement.nativeElement.selectionEnd = "5";
        inputElement.nativeElement.value = "-5";
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "-" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("-5");
    });

    it("test for alphanumeric value in input when key is Decimal", () => {
        inputElement.nativeElement.value = "-5";
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "Decimal" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("-5");
    });
});
