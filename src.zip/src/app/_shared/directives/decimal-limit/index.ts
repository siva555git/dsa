export { DigitDecimaNumberDirective } from "./decimal-limit";
