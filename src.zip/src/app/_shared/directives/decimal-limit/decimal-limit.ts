/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import { Directive, ElementRef, HostListener, Input } from "@angular/core";
import { UA_NUMERIC_LIMITS } from "../../../master-data/constants/unapproved.constant";

@Directive({
    selector: "[appDigitDecimaNumber]",
})
export class DigitDecimaNumberDirective {
    // Allow decimal numbers and negative values
    // decimalDigi =4;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Input() limitOptions: any = {};

    // eslint-disable-next-line unicorn/better-regex, prefer-regex-literals
    private regex = new RegExp(/^((\+|-)?(?:\d{1,11}(?:\.\d{0,4})|(-)?\d{1,11}))$/g);

    // Allow key codes for special events. Reflect :
    // Backspace, tab, end, home
    private specialKeys: Array<string> = [
        "Backspace",
        "Tab",
        "End",
        "Home",
        "-",
        "ArrowLeft",
        "ArrowUp",
        "ArrowDown",
        "ArrowRight",
        "Del",
        "Delete",
        "Enter",
        "PageUp",
        "PageDown",
    ];

    private minusKey = "-";

    constructor(private element: ElementRef) {}

    @HostListener("keydown", ["$event"])
    onKeyDown(event: KeyboardEvent) {
        if (this.limitOptions?.PAGE_FROM) {
            if (this.limitOptions?.PAGE_FROM !== UA_NUMERIC_LIMITS.PAGE_FROM)
                // eslint-disable-next-line curly, prefer-regex-literals
                this.regex = new RegExp(/^((?:\d{1,5}\.\d{0,2}|(-)?\d{1,5}))$/g);
            if (event.key === this.minusKey) {
                event.preventDefault();
            }
        }
        if (event.key === this.minusKey && String(this.element.nativeElement.value).includes(this.minusKey)) {
            event.preventDefault();
        }
        // Allow Backspace, tab, end, and home keys
        if (this.specialKeys.includes(event.key)) {
            return;
        }
        const current: string = this.element.nativeElement.value;
        const position = this.element.nativeElement.selectionStart;
        const next: string = [current.slice(0, position), event.key === "Decimal" ? "." : event.key, current.slice(position)].join("");
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let value: any = next.split(".", 1);
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        value = value[0].replace(/-/g, "");
        // eslint-disable-next-line unicorn/prefer-regexp-test
        if (next && !String(next).match(this.regex)) {
            event.preventDefault();
        }
    }
}
