/* eslint-disable no-underscore-dangle */
import { Directive, Output, EventEmitter, Self } from "@angular/core";
import { MatSelect } from "@angular/material/select";
import { KEYBOARD_KEYS } from "@te-shared/constants";

@Directive({
    selector: "[no-tab]",
})
export class NoTabDirective {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Output("tabkeydown") tabkeydown: EventEmitter<any> = new EventEmitter<any>();

    constructor(@Self() private select: MatSelect) {
        this.select._handleKeydown = (event: KeyboardEvent) => {
            if (event.key === KEYBOARD_KEYS.TAB) {
                const active = this.select.panelOpen
                    ? // eslint-disable-next-line unicorn/prefer-array-find
                      this.select.options.filter((matOption) => matOption.active)[0] || undefined
                    : undefined;
                this.select.close();
                this.tabkeydown.emit(active ? active.value : undefined);
            } else if (!this.select.disabled) {
                // eslint-disable-next-line no-unused-expressions, @typescript-eslint/no-explicit-any
                this.select.panelOpen ? (this.select as any)._handleOpenKeydown(event) : (this.select as any)._handleClosedKeydown(event);
            }
        };
    }
}
