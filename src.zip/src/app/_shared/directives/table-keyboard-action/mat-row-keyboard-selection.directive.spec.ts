/* eslint-disable max-lines-per-function */
import { Component, DebugElement, ElementRef, SimpleChanges } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { MockElementRef } from "@te-testing/mock-elementRef.service";
import { MatRowKeyboardActionDirective } from "./table-keyboard-action.directive";

@Component({
    template: `<table mat-table [dataSource]="[{ index: 1 }]">
        <tr mat-row matRowKeyboardSelection></tr>
    </table>`,
})
class MatRowKeyboardSelectionDirective {}

describe("MatRowKeyboardActionDirective", () => {
    let fixture: ComponentFixture<MatRowKeyboardSelectionDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [MatRowKeyboardActionDirective, MatRowKeyboardSelectionDirective],
            providers: [{ provide: ElementRef, useClass: MockElementRef }],
        });
        fixture = TestBed.createComponent(MatRowKeyboardSelectionDirective);
    });

    it("should call ngOnChanges and Throw Error", () => {
        inputElement = fixture.debugElement.query(By.css("table"));
        const directive = new MatRowKeyboardActionDirective(inputElement);
        const changes = {
            data: {
                currentValue: [],
            },
        } as unknown as SimpleChanges;
        // eslint-disable-next-line func-names
        expect(function () {
            directive.ngOnChanges(changes);
        }).toThrow(new Error("[rowModel] is required"));
    });

    xit("should call ngOnChanges", () => {
        inputElement = fixture.debugElement.query(By.css("table"));
        const directive = new MatRowKeyboardActionDirective(inputElement);
        const spy = spyOn(directive, "ngOnChanges").and.callThrough();
        const changes = {
            data: {
                currentValue: [],
            },
        } as unknown as SimpleChanges;
        directive.rowModel = [];
        directive.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });
});
