import { SelectionModel } from "@angular/cdk/collections";
import { AfterViewInit, Directive, ElementRef, HostListener, Input, OnDestroy, SimpleChanges } from "@angular/core";
import { MatRow, MatTableDataSource } from "@angular/material/table";
import { KEYBOARD_KEYS } from "@te-shared/constants";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";

@Directive({
    selector: "[matRowKeyboardSelection]",
})
export class MatRowKeyboardActionDirective implements OnDestroy, AfterViewInit {
    private dataSource: MatTableDataSource<unknown>;

    private rows: NodeListOf<HTMLElement>;

    private renderedData: unknown[];

    @Input("matRowKeyboardSelection") set MatRowKeyboardSelection(selection) {
        this.selection = selection;
    }

    @Input() selection: SelectionModel<unknown>;

    @Input() rowModel;

    @Input() toggleOnEnter = true;

    @Input() selectOnFocus = true;

    @Input() deselectOnBlur = false;

    @Input() preventNewSelectionOnTab = false;

    @Input() data: Array<unknown> = [];

    @Input() row: MatRow;

    private unsubscriber$ = new Subject<void>();

    constructor(private element: ElementRef) {}

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.data?.currentValue) this.ngAfterViewInit();
    }

    ngAfterViewInit(): void {
        if (!this.rowModel) {
            throw new Error("[rowModel] is required");
        }
        if (this.element.nativeElement.tabIndex < 0) {
            this.element.nativeElement.tabIndex = 0;
        }

        this.dataSource = new MatTableDataSource(this.data);
        if (this.dataSource) {
            this.dataSource
                .connect()
                .pipe(takeUntil(this.unsubscriber$))
                .subscribe((data) => {
                    this.renderedData = data;
                    this.rows = this.getTableRows();
                });
        }
    }

    ngOnDestroy(): void {
        this.unsubscriber$.next();
        this.unsubscriber$.complete();
    }

    @HostListener("focus", ["$event"]) onFocus(): void {
        if (this.selectOnFocus && !this.selection.isMultipleSelection()) {
            this.selection.select(this.rowModel);
        }

        if (this.selectOnFocus && this.preventNewSelectionOnTab) {
            this.rows.forEach((row) => {
                if (row !== this.element.nativeElement) {
                    const dataRow = row;
                    dataRow.tabIndex = -1;
                }
            });
        }
    }

    @HostListener("blur", ["$event"]) onBlur(): void {
        if (this.deselectOnBlur && !this.selection.isMultipleSelection()) {
            this.selection.deselect(this.rowModel);
        }
        if (this.selectOnFocus) {
            this.element.nativeElement.tabIndex = 0;
        }
    }

    @HostListener("keydown", ["$event"]) onKeydown(event: KeyboardEvent): void {
        if (
            event.altKey ||
            event.shiftKey ||
            event.ctrlKey ||
            event.metaKey ||
            (event.key !== KEYBOARD_KEYS.UP_ARROW && event.key !== KEYBOARD_KEYS.DOWN_ARROW)
        ) {
            return;
        }

        let newRow;
        const currentIndex = this.renderedData.indexOf(this.rowModel);
        if (event.key === KEYBOARD_KEYS.DOWN_ARROW) {
            newRow = this.rows[currentIndex + 1];
        } else if (event.key === KEYBOARD_KEYS.UP_ARROW) {
            newRow = this.rows[currentIndex - 1];
        }

        if (newRow) {
            newRow.focus();
            newRow.scrollIntoViewIfNeeded(true);
        }
    }

    private getTableRows(): NodeListOf<HTMLElement> {
        let { nativeElement } = this.element;
        while (nativeElement?.parentNode) {
            nativeElement = nativeElement.parentNode;
            if (nativeElement.tagName?.toLowerCase() === "mat-table" || nativeElement?.hasAttribute("mat-table")) {
                return nativeElement.querySelectorAll("mat-row, tr[mat-row]");
            }
        }
        // eslint-disable-next-line unicorn/no-null
        return null;
    }
}
