import { Component } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { MatAutocomplete, MAT_AUTOCOMPLETE_SCROLL_STRATEGY } from "@angular/material/autocomplete";
import { MAT_SELECT_SCROLL_STRATEGY_PROVIDER } from "@angular/material/select";
import { OptionsScrollDirective } from "./option-scroll.directive";

@Component({
    template: `<mat-autocomplete optionsScroll></mat-autocomplete>`,
})
class TestOptionScrollDirective {}

describe("OptionsScrollDirective", () => {
    let fixture: ComponentFixture<TestOptionScrollDirective>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [TestOptionScrollDirective, OptionsScrollDirective],
            providers: [
                MatAutocomplete,
                {
                    provide: MAT_AUTOCOMPLETE_SCROLL_STRATEGY,
                    useValue: MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
                },
            ],
        });
        fixture = TestBed.createComponent(TestOptionScrollDirective);
        fixture.detectChanges();
    });

    it("should create an instance", () => {
        const directive = new TestOptionScrollDirective();
        expect(directive).toBeTruthy();
    });
});
