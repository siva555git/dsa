/* eslint-disable unicorn/better-regex */
import { Directive, HostListener, ElementRef } from "@angular/core";

@Directive({
    selector: "[appAlphaNumericOnly]",
})
export class AlphaNumericOnlyDirective {
    constructor(private readonly element: ElementRef) {}

    @HostListener("input", ["$event"]) onInputChange(event: KeyboardEvent): void {
        const initalValue = this.element.nativeElement.value;
        const expectspecialcharater = initalValue.replace(/[^a-zA-z0-9\s]*/g, "");
        // eslint-disable-next-line no-useless-escape
        this.element.nativeElement.value = expectspecialcharater.replace(/[\\^_`\[\]\*]/g, "");
        if (initalValue !== this.element.nativeElement.value) {
            event.stopPropagation();
        }
    }
}
