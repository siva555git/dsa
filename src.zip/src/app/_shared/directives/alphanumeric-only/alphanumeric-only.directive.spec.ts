import { Component, DebugElement, ElementRef } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
// eslint-disable-next-line import/no-unresolved
import { MockElementRef as MockElementReference } from "../../../testing/mock-elementRef.service";
import { AlphaNumericOnlyDirective } from "./alphanumeric-only.directive";

@Component({
    template: `<input type="number" appAlphaNumericOnly />`,
})
class LetterNumberOnlyDirective {}

describe("AlphaNumericOnlyDirective", () => {
    let fixture: ComponentFixture<LetterNumberOnlyDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [LetterNumberOnlyDirective, AlphaNumericOnlyDirective],
            providers: [{ provide: ElementRef, useClass: MockElementReference }],
        });
        fixture = TestBed.createComponent(LetterNumberOnlyDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new LetterNumberOnlyDirective();
        expect(directive).toBeTruthy();
    });

    it("test for alphanumeric value in input", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("input", { key: "a" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for alphanumeric value in input", () => {
        inputElement.nativeElement.value = "5";
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("input", { key: "a" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("5");
    });
});
