/* eslint-disable max-lines-per-function */
import { Component, DebugElement, ElementRef, Renderer2, Type } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { MockElementRef as MockElementReference } from "../../../testing/mock-elementRef.service";
import { ResizeColumnDirective } from "./resize-column.directive";

@Component({
    template: `<input resizeColumn [resizeColumn]="true" [pressed]="true" />`,
})
class ResizeColumnHeaderDirective {}

describe("ResizeColumnDirective", () => {
    let fixture: ComponentFixture<ResizeColumnHeaderDirective>;
    let inputElement: DebugElement;
    let renderer2: Renderer2;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ResizeColumnHeaderDirective, ResizeColumnDirective],
            providers: [{ provide: ElementRef, useClass: MockElementReference }],
        });
        fixture = TestBed.createComponent(ResizeColumnHeaderDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
        renderer2 = fixture.componentRef.injector.get<Renderer2>(Renderer2 as Type<Renderer2>);
    });

    it("should create an instance", () => {
        const directive = new ResizeColumnDirective(renderer2, inputElement);
        expect(directive).toBeTruthy();
    });

    it("should call ngOnInit when resizable is true", () => {
        inputElement = fixture.debugElement.query(By.css("input"));
        const directive = new ResizeColumnDirective(renderer2, inputElement);
        directive.resizable = true;
        directive.ngOnInit();
        expect(directive).toBeTruthy();
    });

    it("should call ngOnInit when resizable is false", () => {
        inputElement = fixture.debugElement.query(By.css("input"));
        const directive = new ResizeColumnDirective(renderer2, inputElement);
        directive.resizable = false;
        directive.ngOnInit();
        expect(directive).toBeTruthy();
    });

    it("should call onMouseDown", () => {
        const mouseEvent = {
            pageX: 0,
        } as MouseEvent;
        inputElement = fixture.debugElement.query(By.css("input"));
        const directive = new ResizeColumnDirective(renderer2, inputElement);
        directive.onMouseDown(mouseEvent);
        expect(directive).toBeTruthy();
    });

    it("should call onMouseDown when resizable is false", () => {
        const mouseEvent = {
            pageX: 0,
            buttons: 0,
        } as MouseEvent;
        inputElement = fixture.debugElement.query(By.css("input"));
        const directive = new ResizeColumnDirective(renderer2, inputElement);
        // eslint-disable-next-line dot-notation
        directive["pressed"] = true;
        directive.onMouseMove(mouseEvent);
        expect(directive).toBeTruthy();
    });

    it("should call onMouseUp ", () => {
        inputElement = fixture.debugElement.query(By.css("input"));
        const directive = new ResizeColumnDirective(renderer2, inputElement);
        directive.onMouseUp();
        expect(directive).toBeTruthy();
    });
});
