import { Directive, OnInit, Renderer2, Input, ElementRef } from "@angular/core";
import { DEFAULT_COLUMN_WIDTH, RESIZING_WIDTH } from "../../constants/common.constant";

@Directive({
    selector: "[resizeColumn]",
})
export class ResizeColumnDirective implements OnInit {
    @Input("resizeColumn") resizable: boolean;

    private startX: number;

    private startWidth: number;

    private column: HTMLElement;

    private table: HTMLElement;

    private pressed: boolean;

    constructor(private renderer: Renderer2, private element: ElementRef) {
        this.column = this.element.nativeElement;
    }

    ngOnInit(): void {
        if (this.resizable) {
            const row = this.renderer.parentNode(this.column);
            const thead = this.renderer.parentNode(row);
            this.table = this.renderer.parentNode(thead);

            const resizer = this.renderer.createElement("span");
            this.renderer.addClass(resizer, "resize-holder");
            this.renderer.appendChild(this.column, resizer);
            this.renderer.listen(resizer, "mousedown", this.onMouseDown);
            this.renderer.listen(this.table, "mousemove", this.onMouseMove);
            this.renderer.listen("document", "mouseup", this.onMouseUp);
            this.renderer.setStyle(this.column, "width", `${DEFAULT_COLUMN_WIDTH}px`);
        }
    }

    onMouseDown = (event: MouseEvent): void => {
        this.pressed = true;
        this.startX = event.pageX;
        this.startWidth = this.column.offsetWidth;
        this.resizable = false;
    };

    onMouseMove = (event: MouseEvent): void => {
        const offset = 35;
        if (this.pressed && event.buttons) {
            this.renderer.addClass(this.table, "resizing");

            // Calculate width of column
            const width = this.startWidth + (event.pageX - this.startX - offset);

            // eslint-disable-next-line unicorn/prefer-spread
            const tableCells = Array.from(this.table.querySelectorAll(".mat-row")).map((row) =>
                // eslint-disable-next-line dot-notation
                row.querySelectorAll(".mat-cell").item(this.column["cellIndex"]),
            );
            if (width <= RESIZING_WIDTH) return;
            // Set table header width
            this.renderer.setStyle(this.column, "min-width", `${width}px`);
            this.renderer.setStyle(this.column, "max-width", `${width}px`);

            // Set table cells width
            // eslint-disable-next-line no-restricted-syntax
            for (const cell of tableCells) {
                this.renderer.setStyle(cell, "min-width", `${width}px`);
                this.renderer.setStyle(cell, "max-width", `${width}px`);
            }
        }
    };

    onMouseUp = (): void => {
        if (this.pressed) {
            this.pressed = false;
            this.renderer.removeClass(this.table, "resizing");
            this.resizable = false;
        }
    };
}
