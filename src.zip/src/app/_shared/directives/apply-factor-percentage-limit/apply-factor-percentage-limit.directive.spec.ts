import { Component, DebugElement, ElementRef } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { MockElementRef as MockElementReference } from "../../../testing/mock-elementRef.service";
import { ApplyFactorPercentageLimitDirective } from "./apply-factor-percentage-limit.directive";

@Component({
    template: `<input type="number" appApplyFactorPercentageLimit />`,
})
class ApplyFactorPercentageDirective {}

describe("ApplyFactorPercentageLimitDirective", () => {
    let fixture: ComponentFixture<ApplyFactorPercentageDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ApplyFactorPercentageDirective, ApplyFactorPercentageLimitDirective],
            providers: [{ provide: ElementRef, useClass: MockElementReference }],
        });
        fixture = TestBed.createComponent(ApplyFactorPercentageDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new ApplyFactorPercentageDirective();
        expect(directive).toBeTruthy();
    });

    it("test for numerical value in input2", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "1" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for numerical value in input2 when key is Backspace", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "Backspace" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for numerical value in input2 when key is minus", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "-" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for numerical value in input2 when key is Decimal", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "Decimal" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });
});
