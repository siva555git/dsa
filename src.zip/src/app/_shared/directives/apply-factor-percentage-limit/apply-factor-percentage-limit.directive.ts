import { Directive, ElementRef, HostListener, Input } from "@angular/core";
import { DECIMAL_LIMIT } from "../../constants/common.constant";

@Directive({
    selector: "[appApplyFactorPercentageLimit]",
})
export class ApplyFactorPercentageLimitDirective {
    constructor(private element: ElementRef) {}

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Input() limitOptions: any = {};

    private minusKey = DECIMAL_LIMIT.MINUS_KEY;

    private MAX_LIMIT_VALUE = this.limitOptions.MAX ?? DECIMAL_LIMIT.MAX;

    private DECIMAL_POINT = DECIMAL_LIMIT.DECIMAL_POINT;

    // eslint-disable-next-line prefer-regex-literals
    private regex = new RegExp(/^((\+|-)?(?:\d{1,11}\.\d{0,2}|(-)?\d{1,11}))$/g);

    // Backspace, tab, end, home
    private specialKeys: Array<string> = DECIMAL_LIMIT.SPECIAL_KEYS;

    @HostListener("keydown", ["$event"])
    onKeyDown(event: KeyboardEvent): void {
        const current: string = this.element.nativeElement.value;
        const position = this.element.nativeElement.selectionStart;
        const next: string = [
            current.slice(0, position),
            event.key === DECIMAL_LIMIT.DECIMAL_KEY ? this.DECIMAL_POINT : event.key,
            current.slice(position),
        ].join("");
        // Allow Backspace, tab, end, home keys, etc
        if (this.specialKeys.includes(event.key)) {
            return;
        }
        if (
            event.key === this.minusKey ||
            Number(next) > this.MAX_LIMIT_VALUE ||
            String(this.element.nativeElement.value).includes(this.minusKey) ||
            // eslint-disable-next-line unicorn/prefer-regexp-test
            !String(next).match(this.regex)
        ) {
            event.preventDefault();
        }
    }
}
