import { Component, DebugElement, ElementRef } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { AlphaNumericDirective } from ".";
// eslint-disable-next-line import/no-unresolved
import { MockElementRef as MockElementReference } from "../../../testing/mock-elementRef.service";

@Component({
    template: `<input type="number" appAlphaNumeric />`,
})
class LetterNumberOnlyDirective {}

describe("AlphaNumericDirective", () => {
    let fixture: ComponentFixture<LetterNumberOnlyDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [LetterNumberOnlyDirective, AlphaNumericDirective],
            providers: [{ provide: ElementRef, useClass: MockElementReference }],
        });
        fixture = TestBed.createComponent(LetterNumberOnlyDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new LetterNumberOnlyDirective();
        expect(directive).toBeTruthy();
    });

    it("test for alphanumeric value in input", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keypress", { key: "a" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for alphanumeric value in keypress when key is empty", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keypress", { key: "" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for alphanumeric value in input when event is paste", () => {
        const pasteData = new DataTransfer();
        pasteData.setData("text", "test");
        const pasteEvent = new ClipboardEvent("paste", {
            clipboardData: pasteData,
        } as ClipboardEvent);
        inputElement.nativeElement.dispatchEvent(new ClipboardEvent("paste", pasteEvent));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for alphanumeric value in input when key is empty", () => {
        const pasteData = new DataTransfer();
        pasteData.setData("text", "");
        const pasteEvent = new ClipboardEvent("paste", {
            clipboardData: pasteData,
        } as ClipboardEvent);
        inputElement.nativeElement.dispatchEvent(new ClipboardEvent("paste", pasteEvent));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });
});
