/* eslint-disable class-methods-use-this */
import { Directive, HostListener, ElementRef } from "@angular/core";

@Directive({
    selector: "[appAlphaNumeric]",
})
export class AlphaNumericDirective {
    constructor(private readonly element: ElementRef) {}

    /**
     * Keypress event validate the special char
     *
     * @param {KeyboardEvent} event
     * @return {*}  {boolean}
     * @memberof AlphaNumericDirective
     */
    @HostListener("keypress", ["$event"]) onKeyPress(event: KeyboardEvent): boolean {
        if (/[\dA-Za-z]/.test(event.key)) {
            return true;
        }
        event.preventDefault();
        return false;
    }

    /**
     * Paste event validate the special char
     *
     * @param {ClipboardEvent} event
     * @return {*}  {boolean}
     * @memberof AlphaNumericDirective
     */
    @HostListener("paste", ["$event"]) blockpaste(event: ClipboardEvent): boolean {
        return this.validatePaste(event);
    }

    /**
     * Method to validate the text with special char
     *
     * @param {ClipboardEvent} event
     * @memberof AlphaNumericDirective
     */
    public validatePaste(event: ClipboardEvent): boolean {
        // eslint-disable-next-line prefer-regex-literals
        const regex = new RegExp("^[ 0-9a-zA-Z\\b]+$");
        const key = event.clipboardData.getData("text");
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
        return true;
    }
}
