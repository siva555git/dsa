export { AlphabetOnlyDirective } from "./alphabet-only.directive";
