import { Component, DebugElement } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { AlphabetOnlyDirective } from "./alphabet-only.directive";

@Component({
    template: `<input type="text" appAlphabetOnly />`,
})
class TestAlphabetOnlyComponent {}

describe("AlphabetOnlyDirective", () => {
    let fixture: ComponentFixture<TestAlphabetOnlyComponent>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [TestAlphabetOnlyComponent, AlphabetOnlyDirective],
        });
        fixture = TestBed.createComponent(TestAlphabetOnlyComponent);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new AlphabetOnlyDirective();
        expect(directive).toBeTruthy();
    });

    it("test for numerical value in input", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "1" ,keyCode :49}));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });
});
