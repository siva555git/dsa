/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import { AfterViewInit, Directive, ElementRef, HostListener, Input } from "@angular/core";
import { delay } from "lodash";
import { VALUE } from "@te-shared/components/base-ipc-layout/base-ipc-layout-constant";
import { EMPTY } from "../../../app.constant";
import { ExperimentUtil } from "../../../experiment-editor/helpers/experiment.util";
import { DISPLAY_DECIMALS, NUMRIC_LIMITS } from "../../constants/common.constant";

@Directive({
    selector: "[appDecimalNumber]",
})
export class GridDecimaNumberDirective implements AfterViewInit {
    @Input() limitOptions = {};

    // eslint-disable-next-line prefer-regex-literals, unicorn/better-regex
    private regex = new RegExp(/^([-]?(?=.*[0-9]|\.)?\d{0,11}(?:\.\d{0,4})?$)/g);

    // Allow key codes for special events. Reflect :
    // Backspace, tab, end, home
    private specialKeys: Array<string> = [
        "Backspace",
        "Tab",
        "End",
        "Home",
        "ArrowLeft",
        "ArrowUp",
        "ArrowDown",
        "ArrowRight",
        "Del",
        "Delete",
        "Enter",
    ];

    private minusKey = "-";

    public previousValue;

    constructor(private element: ElementRef) {}

    @HostListener("keydown", ["$event"])
    onKeyDown(event: KeyboardEvent) {
        const position = this.element.nativeElement.selectionStart;
        if (this.specialKeys.includes(event.key)) {
            return;
        }
        const currentValue: string = this.element.nativeElement.value;
        const processedValue: string = [
            currentValue.slice(0, position),
            event.key === "Decimal" ? "." : event.key,
            currentValue.slice(position),
        ].join("");

        if (
            this.element.nativeElement.selectionStart === this.element.nativeElement.selectionEnd &&
            event.key === this.minusKey &&
            currentValue.includes(this.minusKey)
        ) {
            event.preventDefault();
        }

        if (
            currentValue.length === this.element.nativeElement.selectionEnd &&
            this.element.nativeElement.selectionStart === 0 &&
            event.key.match(this.regex)
        ) {
            return;
        }
        if (processedValue && !processedValue.match(this.regex)) {
            event.preventDefault();
        }
    }

    @HostListener("focus", ["$event"])
    onFocus(event: KeyboardEvent) {
        if (!event || !event.target || !event.target[VALUE]) {
            return false;
        }
        if (event.target[VALUE] === this.minusKey) {
            return event;
        }

        if (!this.previousValue) {
            this.previousValue = event.target[VALUE];
        }
        const onFocusEvent = event;
        onFocusEvent.target[VALUE] = ExperimentUtil.parseFloatWithGivenDecimals(onFocusEvent.target[VALUE], NUMRIC_LIMITS.DECIMAL_LIMIT);
        return onFocusEvent;
    }

    @HostListener("focusout", ["$event"])
    onFocusOut(event: KeyboardEvent) {
        const focousOutEvent = event;
        if (!event || !event.target || !event.target[VALUE] || Number.isNaN(+event.target[VALUE])) {
            focousOutEvent.target[VALUE] = this.previousValue ?? EMPTY;
            return focousOutEvent;
        }
        if (focousOutEvent.target[VALUE].endsWith(".")) {
            focousOutEvent.target[VALUE] = this.previousValue;
        } else if (focousOutEvent.target[VALUE] !== this.minusKey && focousOutEvent.target[VALUE].trim() !== EMPTY) {
            this.previousValue = +focousOutEvent.target[VALUE];
        }
        focousOutEvent.target[VALUE] = ExperimentUtil.parseFloatWithGivenDecimals(focousOutEvent.target[VALUE], DISPLAY_DECIMALS);
        return focousOutEvent;
    }

    ngAfterViewInit(): void {
        delay(() => {
            this.element.nativeElement.selectionStart = 0;
        }, 0);
    }
}
