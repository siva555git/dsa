/* eslint-disable max-lines-per-function */
import { CUSTOM_ELEMENTS_SCHEMA, Component, DebugElement, ElementRef } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { DISPLAY_DECIMALS, NUMRIC_LIMITS } from "@te-shared/constants";
import { MockElementRef as MockElementReference } from "@te-testing/mock-elementRef.service";
import { GridDecimaNumberDirective } from "./grid-decimal-limit.directive";

@Component({
    template: `<input appDecimalNumber [limitOptions]="limit" />`,
})
class DecimalNumberDirective {}

describe("GridDecimaNumberDirective", () => {
    let fixture: ComponentFixture<DecimalNumberDirective>;
    let inputElement: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [DecimalNumberDirective, GridDecimaNumberDirective],
            providers: [{ provide: ElementRef, useClass: MockElementReference }],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        });
        fixture = TestBed.createComponent(DecimalNumberDirective);
        inputElement = fixture.debugElement.query(By.css("input"));
    });

    it("should create an instance", () => {
        const directive = new DecimalNumberDirective();
        expect(directive).toBeTruthy();
    });

    it("test for numerical value in input", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("input", { key: "1" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for keydown event when key has value", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "1" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for focus out", () => {
        inputElement.nativeElement.value = "5";
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("focusout", { key: "1" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toEqual(Number.parseFloat("5").toFixed(DISPLAY_DECIMALS));
    });

    it("test for onfocus", () => {
        inputElement.nativeElement.value = "5";
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("focus", { key: "1" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toEqual(Number.parseFloat("5").toFixed(NUMRIC_LIMITS.DECIMAL_LIMIT));
    });

    it("test for keydown event when key is backspace", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "Backspace" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for keydown event  key is deciaml", () => {
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "Decimal" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for keydown event", () => {
        inputElement.nativeElement.selectionStart = "5";
        inputElement.nativeElement.selectionEnd = "5";
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "-" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("");
    });

    it("test for keydown event", () => {
        inputElement.nativeElement.value = "-5";
        inputElement.nativeElement.selectionStart = "5";
        inputElement.nativeElement.selectionEnd = "5";
        inputElement.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { key: "-" }));
        fixture.detectChanges();
        expect(inputElement.nativeElement.value).toBe("-5");
    });
});
