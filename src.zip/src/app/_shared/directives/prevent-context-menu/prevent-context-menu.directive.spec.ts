import { TestBed } from '@angular/core/testing';
import { PreventContextMenuDirective } from './prevent-context-menu.directive';
import { SecurityHelper } from '@te-shared/security/helpers/security.helper';

describe('PreventContextMenuDirective', () => {
  let directive: PreventContextMenuDirective;
  let securityHelper: SecurityHelper;
  let event: MouseEvent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PreventContextMenuDirective,
        { provide: SecurityHelper, useValue: { hasPermission: () => true } } // Mock SecurityHelper implementation
      ]
    });
    directive = TestBed.inject(PreventContextMenuDirective);
    securityHelper = TestBed.inject(SecurityHelper);
    event = new MouseEvent('contextmenu');
  });

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });

  it('should prevent default behavior on right click if permission is granted', () => {
    directive.permission = 'somePermission';
    spyOn(securityHelper, 'hasPermission').and.returnValue(true);
    spyOn(event, 'preventDefault');

    directive.onRightClick(event);

    expect(securityHelper.hasPermission).toHaveBeenCalledWith('somePermission');
    expect(event.preventDefault).toHaveBeenCalled();
  });

  it('should not prevent default behavior on right click if permission is denied', () => {
    directive.permission = 'somePermission';
    spyOn(securityHelper, 'hasPermission').and.returnValue(false);
    spyOn(event, 'preventDefault');

    directive.onRightClick(event);

    expect(securityHelper.hasPermission).toHaveBeenCalledWith('somePermission');
    expect(event.preventDefault).not.toHaveBeenCalled();
  });
});
