import { Directive, HostListener, Input } from "@angular/core";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";

@Directive({
    selector: "[appPreventContextMenuDirective]",
})
export class PreventContextMenuDirective {
    @Input() permission: string;

    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor(private readonly securityHelper: SecurityHelper) {}

    @HostListener("contextmenu", ["$event"])
    onRightClick(event) {
        if (this.permission && this.securityHelper.hasPermission(this.permission)) {
            event.preventDefault();
        }
    }
}
