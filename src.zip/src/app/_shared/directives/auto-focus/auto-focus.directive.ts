import { Directive, AfterViewInit, ElementRef } from "@angular/core";
import { delay } from "lodash";

@Directive({
    selector: "[appAutoFocus]",
})
export class AutoFocusDirective implements AfterViewInit {
    constructor(private element: ElementRef) {}

    public ngAfterViewInit(): void {
        delay(() => {
            this.element.nativeElement.focus();
        }, 500);
    }
}
