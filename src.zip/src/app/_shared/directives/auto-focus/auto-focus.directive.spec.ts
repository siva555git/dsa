/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, DebugElement } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { AutoFocusDirective } from "./auto-focus.directive";

@Component({
    template: `<input type="text" appAlphabetOnly />`,
})
class TestAutoFocusComponent {}

describe("AutoFocusDirective", () => {
    let component: TestAutoFocusComponent;
    let fixture: ComponentFixture<TestAutoFocusComponent>;
    let inputElement: DebugElement;
    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [TestAutoFocusComponent, AutoFocusDirective],
        });

        fixture = TestBed.createComponent(TestAutoFocusComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create an instance", () => {
        expect(component).toBeTruthy();
    });

    it("should create an instance", () => {
        inputElement = fixture.debugElement.query(By.css("input"));
        const directive = new AutoFocusDirective(inputElement);
        directive.ngAfterViewInit();
        expect(directive).toBeTruthy();
    });
});
