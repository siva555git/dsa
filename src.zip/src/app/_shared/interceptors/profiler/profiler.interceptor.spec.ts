/* eslint-disable    no-console, @typescript-eslint/explicit-module-boundary-types
    , @typescript-eslint/no-explicit-any */

import { TestBed, inject, waitForAsync } from "@angular/core/testing";
import { HTTP_INTERCEPTORS, HttpClient } from "@angular/common/http";
import { NGXLogger, CustomNGXLoggerService, NGXLoggerConfigEngine } from "ngx-logger";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { ProfilerInterceptor } from "./profiler.interceptor";
import { MockLoggerService, MockNGXLoggerHttpService, MockLoggerConfig } from "../../../testing/mock-logger.service";

/* eslint-disable-next-line     max-lines-per-function */
describe("ProfilerInterceptor", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: ProfilerInterceptor,
                    multi: true,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: CustomNGXLoggerService,
                    useClass: MockNGXLoggerHttpService,
                },
                {
                    provide: NGXLoggerConfigEngine,
                    useClass: MockLoggerConfig,
                },
            ],
        }),
    );

    it("should create", () => {
        const interceptor: ProfilerInterceptor = TestBed.inject(ProfilerInterceptor);
        expect(interceptor).toBeTruthy();
    });

    it("should calculate response time for http request success", waitForAsync(
        inject([HttpClient, HttpTestingController], (http: HttpClient, httpMock: HttpTestingController) => {
            const logger: NGXLogger = TestBed.inject(NGXLogger);
            spyOn(logger, "info");

            http.get("/data").subscribe((response) => {
                expect(response).toBeTruthy();
            });

            const request = httpMock.expectOne(`/data`);

            expect(request.request.method).toEqual("GET");
            expect(request.request.headers.has("Authorization")).toEqual(false);
            request.flush({
                type: "SUCCESS",
                status: 200,
                body: { test: "result" },
            });
            expect(logger.info).toHaveBeenCalled();
            httpMock.verify();
        }),
    ));

    it("should calculate response time for http request failure", waitForAsync(
        inject([HttpClient, HttpTestingController], (http: HttpClient, httpMock: HttpTestingController) => {
            const logger: NGXLogger = TestBed.inject(NGXLogger);
            spyOn(logger, "info");

            let errorResponse: any;
            http.get("api/data").subscribe({
                next: (response) => {
                    console.log(response);
                },
                error: (error) => {
                    errorResponse = error;
                },
            });

            const data = "Invalid request parameters";
            const mockError = { status: 400, statusText: "Bad Request" };

            httpMock.expectOne("api/data").flush(data, mockError);

            expect(logger.info).toHaveBeenCalled();
            expect(errorResponse.error).toBe(data);

            httpMock.verify();
        }),
    ));
});
