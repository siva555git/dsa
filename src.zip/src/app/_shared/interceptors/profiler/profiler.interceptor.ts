/* eslint-disable @typescript-eslint/no-explicit-any, id-length
    , @typescript-eslint/no-unused-vars, no-return-assign */

/** Angular Modules */
import { Injectable } from "@angular/core";
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse, HttpResponse } from "@angular/common/http";

/** Dependencies */
import { NGXLogger } from "ngx-logger";

/** Constants */

/** Rxjs */
import { Observable } from "rxjs";
import { tap, finalize } from "rxjs/operators";
import { EMPTY } from "../../../app.constant";

/**
 *Class ProfilerInterceptor
 *
 * @export
 * @class ProfilerInterceptor
 * @implements {HttpInterceptor}
 */
@Injectable({
    providedIn: "root",
})
export class ProfilerInterceptor implements HttpInterceptor {
    /**
     *Creates an instance of ProfilerInterceptor.
     * @param {NGXLogger} logger
     * @memberof ProfilerInterceptor
     */
    constructor(private logger: NGXLogger) {}

    /**
     *Intercepts on http calls for time duration
     *
     * @param {HttpRequest<unknown>} request
     * @param {HttpHandler} next
     * @returns {Observable<HttpEvent<unknown>>}
     * @memberof ProfilerInterceptor
     */
    intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
        const started = Date.now();
        let ok: string;
        return next.handle(request).pipe(
            tap({
                next: (event: HttpEvent<any>) => (ok = event instanceof HttpResponse ? "succeeded" : EMPTY),
                error: (error: HttpErrorResponse) => (ok = "failed"),
            }),
            // Log when response observable either completes or errors
            finalize(() => {
                const elapsed = Date.now() - started;
                const url = request.urlWithParams ?? "/";
                const message = `${request.method} "${url}" ${ok} in ${elapsed} ms.`;
                this.logger.info(message);
            }),
        );
    }
}
