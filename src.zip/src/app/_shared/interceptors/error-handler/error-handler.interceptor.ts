/* eslint-disable @typescript-eslint/no-explicit-any, class-methods-use-this */

/** Angular Modules */
import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpErrorResponse, HttpHandler, HttpEvent } from "@angular/common/http";

/** rxjs */
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";

/**
 *Class ErrorHandlerInterceptor
 *
 * @export
 * @class ErrorHandlerInterceptor
 * @implements {HttpInterceptor}
 */
@Injectable({
    providedIn: "root",
})
export class ErrorHandlerInterceptor implements HttpInterceptor {
    /**
     *Intercepts on application level http errors
     *
     * @param {HttpRequest<any>} request
     * @param {HttpHandler} next
     * @returns {Observable<HttpEvent<any>>}
     * @memberof ErrorHandlerInterceptor
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(this.handleError.bind(this)));
    }

    /**
     *Handles application level http errors
     *
     * @param {HttpErrorResponse} error
     * @returns {*}
     * @memberof ErrorHandlerInterceptor
     */
    handleError(error: HttpErrorResponse): any {
        return throwError(() => error);
    }
}
