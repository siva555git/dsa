/* eslint-disable   @typescript-eslint/no-explicit-any, no-console */

import { TestBed, inject, waitForAsync } from "@angular/core/testing";
import { HTTP_INTERCEPTORS, HttpClient } from "@angular/common/http";
import { HttpTestingController, HttpClientTestingModule } from "@angular/common/http/testing";
import { ErrorHandlerInterceptor } from "./error-handler.interceptor";

describe("ErrorHandlerInterceptor", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: ErrorHandlerInterceptor,
                    multi: true,
                },
            ],
        }),
    );

    it("should create", () => {
        const interceptor: ErrorHandlerInterceptor = TestBed.inject(ErrorHandlerInterceptor);
        expect(interceptor).toBeTruthy();
    });

    it("should handle error response for http request failure", waitForAsync(
        inject([HttpClient, HttpTestingController], (http: HttpClient, httpMock: HttpTestingController) => {
            let errorResponse: any;
            http.get("api/data").subscribe({
                next: (response) => {
                    console.log(response);
                },
                error: (error) => {
                    errorResponse = error;
                },
            });

            const data = "Invalid request parameters";
            const mockError = { status: 400, statusText: "Bad Request" };

            httpMock.expectOne("api/data").flush(data, mockError);

            expect(errorResponse.error).toBe(data);

            httpMock.verify();
        }),
    ));
});
