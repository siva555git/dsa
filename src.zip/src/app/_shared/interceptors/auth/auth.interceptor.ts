/* eslint-disable @typescript-eslint/no-explicit-any */

/** Angular Modules */
import { Injectable } from "@angular/core";
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";

/** Dependencies */
import { OAuthService } from "angular-oauth2-oidc";

/** Services */
import { Observable, catchError, filter, finalize, from, lastValueFrom, switchMap, take, throwError } from "rxjs";
import { jwtDecode } from "jwt-decode";
import { MsalService } from "@azure/msal-angular";
import { AppSettings } from "../../../app.settings";
// eslint-disable-next-line import/no-cycle
import { AppDataService, AppStateService } from "../../../_services";
// eslint-disable-next-line import/no-cycle
import { AuthService } from "../../../_services/app-auth/app.auth.service";

/** Constants */
import { EMPTY, apiGatewayHeaderName } from "../../../app.constant";

/** rxjs */

@Injectable({
    providedIn: "root",
})
export class AuthInterceptor implements HttpInterceptor {
    private isRefreshing = false;

    constructor(
        private oAuthSvc: OAuthService,
        private msalService: MsalService,
        private authService: AuthService,
        private appData: AppDataService,
        private appStateService: AppStateService,
    ) {}

    /**
     *Intercepts http request for auth token
     *
     * @param {HttpRequest<any>} request
     * @param {HttpHandler} next
     * @returns {Observable<HttpEvent<any>>}
     * @memberof AuthInterceptor
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (AppSettings.isOktaRequired) {
            return from(this.handleAccess(request, next));
        }
        if (AppSettings.isEntraRequired) {
            return this.handleRequestEntra(request, next);
        }
        return next.handle(request);
    }

    private async handleAccess(request: HttpRequest<any>, next: HttpHandler): Promise<HttpEvent<any>> {
        // if (request.urlWithParams.includes(AppSettings.AppUrl.api)) {
        if (AppSettings.isOktaRequired && request.urlWithParams.includes(AppSettings.AppUrl.api)) {
            const accessToken = AppSettings.isOktaRequired ? this.oAuthSvc.getIdToken() : EMPTY;
            // Http requests are immutable the cloned new request object with updated header is passed here
            const authRequest = request.clone({
                setHeaders: {
                    Authorization: `Bearer ${accessToken}`,
                    [apiGatewayHeaderName]: AppSettings.config().agwKey,
                },
            });
            return lastValueFrom(next.handle(authRequest));
        }
        return lastValueFrom(next.handle(request));
    }

    /**
     * @description Method to handle the entra request
     * @param {HttpRequest<any>} request
     * @param {HttpHandler} next
     * @return {*}  {Observable<HttpEvent<any>>}
     * @memberof AuthInterceptor
     */
    public handleRequestEntra(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (
            AppSettings.isEntraRequired &&
            request.urlWithParams.includes(AppSettings.AppUrl.api) &&
            !request.urlWithParams.includes(this.appData.url.login)
        ) {
            const idToken =
                this.appStateService.get(this.appStateService.stateId.token) ?? sessionStorage.getItem(this.appStateService.stateId.token);
            const accountIdToken = this.msalService.instance.getActiveAccount()?.idToken;

            // check if the token is available and not expired
            if (idToken && !this.isTokenExpired(idToken)) {
                // eslint-disable-next-line no-param-reassign
                request = this.addTokenToRequest(request, idToken);
                return next.handle(request);
            }

            // check if the token is available and not expired
            if (accountIdToken && !this.isTokenExpired(accountIdToken)) {
                // eslint-disable-next-line no-param-reassign
                request = this.addTokenToRequest(request, accountIdToken);
                return next.handle(request);
            }

            // id token either not available or expired, attempt to refresh it.
            return this.refreshToken().pipe(
                switchMap((refreshedToken) => {
                    // eslint-disable-next-line no-param-reassign
                    refreshedToken =
                        this.msalService.instance.getActiveAccount()?.idToken ?? sessionStorage.getItem(this.appStateService.stateId.token);
                    // eslint-disable-next-line no-param-reassign
                    request = this.addTokenToRequest(request, refreshedToken);
                    return next.handle(request);
                }),
                catchError((error) => {
                    return throwError(error);
                }),
                finalize(() => {
                    this.isRefreshing = false;
                }),
            );
        }

        return next.handle(request);
    }

    /**
     * @description Method to add token to the request
     * @private
     * @param {HttpRequest<any>} request
     * @param {(string | null)} token
     * @return {*}  {HttpRequest<any>}
     * @memberof AuthInterceptor
     */
    private addTokenToRequest(request: HttpRequest<any>, token: string | null): HttpRequest<any> {
        return request.clone({
            setHeaders: {
                Authorization: `Bearer ${token}`,
                [apiGatewayHeaderName]: AppSettings.config().agwKey,
            },
        });
    }

    /**
     * @description Method to refresh the token
     * @private
     * @return {*}  {(Observable<string | null>)}
     * @memberof AuthInterceptor
     */
    private refreshToken(): Observable<string | null> {
        if (!this.isRefreshing) {
            this.isRefreshing = true;
            return this.authService.refreshToken().pipe(
                filter((token) => !!token),
                take(1),
            );
        }

        return this.authService.idToken$.pipe(
            filter((token) => !!token),
            take(1),
        );
    }

    /**
     * @description Method to check the token expire
     * @param {string} token
     * @return {*}  {boolean}
     * @memberof AuthInterceptor
     */
    public isTokenExpired(token: string): boolean {
        const decodedToken = jwtDecode(token);
        const currentTime = Date.now();
        return currentTime > Number(decodedToken.exp) * 1000;
    }
}
