import { TestBed, inject } from "@angular/core/testing";
import { HTTP_INTERCEPTORS, HttpClient } from "@angular/common/http";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";

import { OAuthService } from "angular-oauth2-oidc";

import { MSAL_GUARD_CONFIG, MsalService } from "@azure/msal-angular";
import { AppDataService, AppStateService, WindowReferenceService } from "@te-services/index";
import { NGXLogger } from "ngx-logger";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { of } from "rxjs";
import { AuthInterceptor } from "./auth.interceptor";
import { AppSettings } from "../../../app.settings";
import { MockOAuthService } from "../../../testing/mock-oauth.service";

/* eslint-disable-next-line     max-lines-per-function */
describe("AuthInterceptor", () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                AppStateService,
                AppDataService,
                WindowReferenceService,
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: AuthInterceptor,
                    multi: true,
                },
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
                {
                    provide: MsalService,
                    useValue: {
                        handleRedirectObservable: () => {
                            return of(true);
                        },
                        acquireTokenSilent: (response) => {
                            return response;
                        },
                        instance: {
                            getActiveAccount: () => {
                                return true;
                            },
                        },
                    },
                },
                {
                    provide: MSAL_GUARD_CONFIG,
                    useValue: {},
                },
                { provide: NGXLogger, useClass: MockLoggerService },
            ],
        });
    });

    it("should create", () => {
        const interceptor: AuthInterceptor = TestBed.inject(AuthInterceptor);
        expect(interceptor).toBeTruthy();
    });

    it("Should not add Authorization header for non-api requests", inject(
        [HttpClient, HttpTestingController],
        (http: HttpClient, httpMock: HttpTestingController) => {
            http.get("/data").subscribe((response) => {
                expect(response).toBeTruthy();
            });

            const request = httpMock.expectOne(`/data`);
            expect(request.request.method).toEqual("GET");
            expect(request.request.headers.has("Authorization")).toEqual(false);

            request.flush({});
            httpMock.verify();
        },
    ));

    it("Should add an EMPTY Authorization header [OKTA Disabled]", inject(
        [HttpClient, HttpTestingController],
        (http: HttpClient, httpMock: HttpTestingController) => {
            AppSettings.isOktaRequired = false;

            http.get("/data").subscribe((response) => {
                expect(response).toBeTruthy();
            });

            const request = httpMock.expectOne(`/data`);

            expect(request.request.method).toEqual("GET");
            // eslint-disable-next-line unicorn/no-null
            expect(request.request.headers.get("Authorization")).toEqual(null);

            request.flush({});
            httpMock.verify();
        },
    ));
});
