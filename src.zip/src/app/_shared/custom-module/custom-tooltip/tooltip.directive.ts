/* eslint-disable max-lines */
/* eslint-disable id-length */
/* eslint-disable class-methods-use-this */
/* eslint-disable angular/timeout-service */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable sonarjs/no-identical-functions */
/* eslint-disable no-underscore-dangle */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
    Directive,
    ElementRef,
    HostListener,
    Input,
    ComponentFactoryResolver,
    EmbeddedViewRef,
    ApplicationRef,
    Injector,
    Output,
    EventEmitter,
    Inject,
    Optional,
    SimpleChanges,
} from "@angular/core";
import { TooltipComponent } from "./tooltip.component";
import { TooltipOptionsService } from "./options.service";
import { defaultOptions, backwardCompatibilityOptions } from "./options";
import { TooltipOptions } from "./options.interface";

export interface AdComponent {
    data: any;
    show: boolean;
    close: boolean;
    events: any;
}

@Directive({
    selector: "[tooltip]",
    exportAs: "tooltip",
})
export class TooltipDirective {
    private hideTimeoutId!: number;

    private destroyTimeoutId!: number;

    public hideAfterClickTimeoutId!: number;

    private createTimeoutId!: number;

    private showTimeoutId!: number;

    private componentRef: any;

    private elementPosition: any;

    public _id: any;

    private _options: any = {};

    public _defaultOptions: any;

    private _destroyDelay!: number;

    private componentSubscribe: any;

    private _contentType: "string" | "html" | "template" = "string";

    private _showDelay!: number;

    private _hideDelay!: number;

    private _zIndex!: number;

    private _tooltipClass!: string;

    private _animationDuration!: number;

    private _maxWidth!: string;

    @Input("options") set options(value: TooltipOptions) {
        if (value && defaultOptions) {
            this._options = value;
        }
    }

    public get options() {
        return this._options;
    }

    @Input("tooltip") public tooltipValue!: string;

    @Input("placement") public placement!: string;

    @Input("autoPlacement") public autoPlacement!: boolean;

    // Content type
    @Input("content-type") set contentTypeBackwardCompatibility(value: "string" | "html" | "template") {
        if (value) {
            this._contentType = value;
        }
    }

    @Input("contentType") set contentType(value: "string" | "html" | "template") {
        if (value) {
            this._contentType = value;
        }
    }

    public get contentType() {
        return this._contentType;
    }

    @Input("hide-delay-mobile") public hideDelayMobile!: number;

    @Input("hideDelayTouchscreen") public hideDelayTouchscreen!: number;

    // z-index
    @Input("z-index") set zIndexBackwardCompatibility(value: number) {
        if (value) {
            this._zIndex = value;
        }
    }

    @Input("zIndex") set zIndex(value: number) {
        if (value) {
            this._zIndex = value;
        }
    }

    public get zIndex() {
        return this._zIndex;
    }

    // Animation duration
    @Input("animation-duration") set animationDurationBackwardCompatibility(value: number) {
        if (value) {
            this._animationDuration = value;
        }
    }

    @Input("animationDuration") set animationDuration(value: number) {
        if (value) {
            this._animationDuration = value;
        }
    }

    public get animationDuration() {
        return this._animationDuration;
    }

    @Input("trigger") trigger!: string;

    // Tooltip class
    @Input("tooltip-class") set tooltipClassBackwardCompatibility(value: string) {
        if (value) {
            this._tooltipClass = value;
        }
    }

    @Input("tooltipClass") set tooltipClass(value: string) {
        if (value) {
            this._tooltipClass = value;
        }
    }

    public get tooltipClass() {
        return this._tooltipClass;
    }

    @Input("display") public display!: boolean;

    @Input("display-mobile") public displayMobile!: boolean;

    @Input("displayTouchscreen") public displayTouchscreen!: boolean;

    @Input("shadow") public shadow!: boolean;

    @Input("theme") public theme!: "dark" | "light";

    @Input("offset") public offset!: number;

    @Input("width") public width!: string;

    // Max width
    @Input("max-width") set maxWidthBackwardCompatibility(value: string) {
        if (value) {
            this._maxWidth = value;
        }
    }

    @Input("maxWidth") set maxWidth(value: string) {
        if (value) {
            this._maxWidth = value;
        }
    }

    public get maxWidth() {
        return this._maxWidth;
    }

    @Input("id") public id: any;

    // Show delay
    @Input("show-delay") set showDelayBackwardCompatibility(value: number) {
        if (value) {
            this._showDelay = value;
        }
    }

    @Input("showDelay") set showDelay(value: number) {
        if (value) {
            this._showDelay = value;
        }
    }

    public get showDelay() {
        return this._showDelay;
    }

    // Hide delay
    @Input("hide-delay") set hideDelayBackwardCompatibility(value: number) {
        if (value) {
            this._hideDelay = value;
        }
    }

    @Input("hideDelay") set hideDelay(value: number) {
        if (value) {
            this._hideDelay = value;
        }
    }

    public get hideDelay() {
        return this._hideDelay;
    }

    @Input("hideDelayAfterClick") public hideDelayAfterClick!: number;

    @Input("pointerEvents") public pointerEvents!: "auto" | "none";

    @Input("position") public position!: { top: number; left: number };

    private get isTooltipDestroyed() {
        return this.componentRef && this.componentRef.hostView.destroyed;
    }

    private get destroyDelay() {
        if (this._destroyDelay) {
            return this._destroyDelay;
        }
        return Number(this.getHideDelay()) + Number(this.options.animationDuration);
    }

    private set destroyDelay(value: number) {
        this._destroyDelay = value;
    }

    private get tooltipPosition() {
        if (this.options.position) {
            return this.options.position;
        }
        return this.elementPosition;
    }

    @Output() public events: EventEmitter<any> = new EventEmitter<any>();

    constructor(
        @Optional() @Inject(TooltipOptionsService) private initOptions: any,
        private elementReference: ElementRef,
        private componentFactoryResolver: ComponentFactoryResolver,
        private appReference: ApplicationRef,
        private injector: Injector,
    ) {}

    @HostListener("focusin")
    @HostListener("mouseenter")
    onMouseEnter() {
        if (this.isDisplayOnHover === false) {
            return;
        }
        this.show();
    }

    @HostListener("focusout")
    @HostListener("mouseleave")
    onMouseLeave() {
        if (this.options.trigger === "hover") {
            this.destroyTooltip();
        }
    }

    @HostListener("click")
    onClick() {
        if (this.isDisplayOnClick === false) {
            return;
        }

        this.show();
        this.hideAfterClickTimeoutId = window.setTimeout(() => {
            this.destroyTooltip();
        }, this.options.hideDelayAfterClick);
    }

    public ngOnChanges(changes: SimpleChanges) {
        this.initOptions = this.renameProperties(this.initOptions);
        let changedOptions = this.getProperties(changes);
        changedOptions = this.renameProperties(changedOptions);

        this.applyOptionsDefault(defaultOptions, changedOptions);
    }

    public ngOnDestroy(): void {
        this.destroyTooltip({
            fast: true,
        });

        if (this.componentSubscribe) {
            this.componentSubscribe.unsubscribe();
        }
    }

    private getShowDelay() {
        return this.options.showDelay;
    }

    private getHideDelay() {
        const { hideDelay } = this.options;
        const { hideDelayTouchscreen } = this.options;

        return this.isTouchScreen ? hideDelayTouchscreen : hideDelay;
    }

    private getProperties(changes: SimpleChanges) {
        const directiveProperties: any = {};
        let customProperties: any = {};
        let allProperties: any = {};

        // eslint-disable-next-line no-restricted-syntax, guard-for-in
        for (const property in changes) {
            if (property !== "options" && property !== "tooltipValue") {
                directiveProperties[property] = changes[property].currentValue;
            }
            if (property === "options") {
                customProperties = changes[property].currentValue;
            }
        }

        allProperties = { ...customProperties, ...directiveProperties };
        return allProperties;
    }

    private renameProperties(options: any) {
        // eslint-disable-next-line no-restricted-syntax
        for (const property in options) {
            if (backwardCompatibilityOptions[property]) {
                // eslint-disable-next-line no-param-reassign
                options[backwardCompatibilityOptions[property]] = options[property];
                // eslint-disable-next-line no-param-reassign
                delete options[property];
            }
        }

        return options;
    }

    private getElementPosition(): void {
        this.elementPosition = this.elementReference.nativeElement.getBoundingClientRect();
    }

    private createTooltip(): void {
        this.clearTimeouts();
        this.getElementPosition();

        this.createTimeoutId = window.setTimeout(() => {
            this.appendComponentToBody(TooltipComponent);
        }, this.getShowDelay());

        this.showTimeoutId = window.setTimeout(() => {
            this.showTooltipElem();
        }, this.getShowDelay());
    }

    private destroyTooltip(
        // eslint-disable-next-line unicorn/no-object-as-default-parameter
        options = {
            fast: false,
        },
    ): void {
        this.clearTimeouts();

        if (this.isTooltipDestroyed === false) {
            this.hideTimeoutId = window.setTimeout(
                () => {
                    this.hideTooltip();
                },
                options.fast ? 0 : this.getHideDelay(),
            );

            this.destroyTimeoutId = window.setTimeout(
                () => {
                    if (!this.componentRef || this.isTooltipDestroyed) {
                        return;
                    }

                    this.appReference.detachView(this.componentRef.hostView);
                    this.componentRef.destroy();
                    this.events.emit({
                        type: "hidden",
                        position: this.tooltipPosition,
                    });
                },
                options.fast ? 0 : this.destroyDelay,
            );
        }
    }

    private showTooltipElem(): void {
        this.clearTimeouts();
        (<AdComponent>this.componentRef.instance).show = true;
        this.events.emit({
            type: "show",
            position: this.tooltipPosition,
        });
    }

    private hideTooltip(): void {
        if (!this.componentRef || this.isTooltipDestroyed) {
            return;
        }
        (<AdComponent>this.componentRef.instance).show = false;
        this.events.emit({
            type: "hide",
            position: this.tooltipPosition,
        });
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    private appendComponentToBody(component: any): void {
        this.componentRef = this.componentFactoryResolver.resolveComponentFactory(component).create(this.injector);

        (<AdComponent>this.componentRef.instance).data = {
            value: this.tooltipValue,
            element: this.elementReference.nativeElement,
            elementPosition: this.tooltipPosition,
            options: this.options,
        };
        this.appReference.attachView(this.componentRef.hostView);
        const domElement = (this.componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;
        // eslint-disable-next-line unicorn/prefer-node-append, angular/document-service, unicorn/prefer-dom-node-append
        document.body.appendChild(domElement);

        this.componentSubscribe = (<AdComponent>this.componentRef.instance).events.subscribe((event: any) => {
            this.handleEvents(event);
        });
    }

    private clearTimeouts(): void {
        if (this.createTimeoutId) {
            clearTimeout(this.createTimeoutId);
        }

        if (this.showTimeoutId) {
            clearTimeout(this.showTimeoutId);
        }

        if (this.hideTimeoutId) {
            clearTimeout(this.hideTimeoutId);
        }

        if (this.destroyTimeoutId) {
            clearTimeout(this.destroyTimeoutId);
        }
    }

    private get isDisplayOnHover(): boolean {
        if (this.options.display === false) {
            return false;
        }

        if (this.options.displayTouchscreen === false && this.isTouchScreen) {
            return false;
        }

        return !(this.options.trigger !== "hover");
    }

    private get isDisplayOnClick(): boolean {
        if (this.options.display === false) {
            return false;
        }

        if (this.options.displayTouchscreen === false && this.isTouchScreen) {
            return false;
        }

        return !(this.options.trigger !== "click");
    }

    private get isTouchScreen() {
        const prefixes = " -webkit- -moz- -o- -ms- ".split(" ");
        // eslint-disable-next-line func-names
        const mq = function (query: any) {
            // eslint-disable-next-line angular/window-service
            return window.matchMedia(query).matches;
        };

        if ("ontouchstart" in window) {
            return true;
        }

        const query = ["(", prefixes.join("touch-enabled),("), "heartz", ")"].join("");
        return mq(query);
    }

    private applyOptionsDefault(defaultNewOptions: any, options: any): void {
        // eslint-disable-next-line unicorn/no-useless-fallback-in-spread
        this.options = { ...defaultNewOptions, ...(this.initOptions || {}), ...this.options, ...options };
    }

    private handleEvents(event: any) {
        if (event.type === "shown") {
            this.events.emit({
                type: "shown",
                position: this.tooltipPosition,
            });
        }
    }

    public show() {
        if (!this.tooltipValue) {
            return;
        }

        if (!this.componentRef || this.isTooltipDestroyed) {
            this.createTooltip();
        } else if (!this.isTooltipDestroyed) {
            this.showTooltipElem();
        }
    }

    public hide() {
        this.destroyTooltip();
    }
}
