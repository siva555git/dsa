import { DisableSortPipe } from "./disable-sort.pipe";

describe("DisableSortPipe", () => {
    const pipe = new DisableSortPipe();
    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });

    it("transforms if value is empty", () => {
        expect(pipe.transform([])).toBeTruthy();
    });

    it("transforms => if array has values", () => {
        const mockArray = [1, 2, 3];
        expect(pipe.transform(mockArray)).toBeFalsy();
    });

    it("transforms => selectedColumn is costperkg", () => {
        const selectedColumn = {
            isCost: true,
            value: "BAFL",
            columns: "CostPerKg",
            gridHeaderType: "attribute",
        };
        const mockArray = [1, 2, 3];
        expect(pipe.transform(mockArray, selectedColumn)).toBeFalsy();
    });

    it("transforms => selectedColumn is other than costperkg", () => {
        const selectedColumn = {
            isCost: true,
            value: "BAFL",
            columns: "CostPerParts",
            gridHeaderType: "attribute",
        };
        const mockArray = [1, 2, 3];
        expect(pipe.transform(mockArray, selectedColumn)).toBeTruthy();
    });
});
