import { SEARCH_AUDIT_STATUS } from "@te-shared/constants";
import { AuditValidationPipe } from "./audit-validation.pipe";

describe("AuditValidationPipe", () => {
    let pipe: AuditValidationPipe;
    beforeEach(() => {
        pipe = new AuditValidationPipe();
    });

    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });

    it("should return true for 'pass' when inverse is false", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_PASS,false);
        expect(result).toBe(true);
    });
    it("should return false for 'fail' when inverse is false", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_FAIL,false);
        expect(result).toBe(false);
    });  it("should return false for 'pass' when inverse is true", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_PASS,true);
        expect(result).toBe(false);
    });
});
