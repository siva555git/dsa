import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: "nameWidth",
})
export class NameWidthPipe implements PipeTransform {
    transform = (name: string): string => {
        return name.slice(0, 40);
    };
}
