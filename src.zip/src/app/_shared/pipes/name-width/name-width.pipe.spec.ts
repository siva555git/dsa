import { NameWidthPipe } from "./name-width.pipe";

describe("NameWidthPipe", () => {
    let pipe : NameWidthPipe;
    beforeAll(()=>{
        pipe = new NameWidthPipe();
    })
    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });
    it("should return pass icon  for 'pass'", () => {
        const name = "TASTE EDITOR NAME TEST FOR LENGTH GREATER THAN FORTY SHOULD BE SLICED AND LENGTH SHOULD BE ALWAYS LESS THAN FORTY"
        const result = pipe.transform(name);
        expect(result.length <= 40).toBe(true);
    });
});
