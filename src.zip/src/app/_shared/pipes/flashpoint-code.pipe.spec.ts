import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { FlashpointCodePipe } from "./flashpoint-code.pipe";

describe("FlashpointCodePipe", () => {
    let pipe: FlashpointCodePipe;

    beforeEach(() => {
        pipe = new FlashpointCodePipe();
    });

    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });

    it("test with bind the value into flashpoint column header", () => {
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("F");
        const result = pipe.transform("FLASHPOINT");
        expect(result).toEqual(`FLASHPOINT <span class="unitInfo flashpoint"> (&deg;F) </span>`);
    });
});
