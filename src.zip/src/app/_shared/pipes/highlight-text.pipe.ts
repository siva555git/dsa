import { Pipe, PipeTransform } from "@angular/core";
import { HIGHLIGHTED_CLASS, HIGHLIGHT_TYPE } from "../constants/common.constant";
import { EMPTY } from "../../app.constant";

@Pipe({
    name: "highlight",
})
export class HighlightTextPipe implements PipeTransform {
    // eslint-disable-next-line class-methods-use-this
    transform(items: string, findTextValue: string, type?: string): string {
        const highlighed = type === HIGHLIGHT_TYPE ? HIGHLIGHTED_CLASS : EMPTY;

        const replaceBy = type === HIGHLIGHT_TYPE ? `<mark>$1</mark>` : `<span class="highlight-text ${highlighed}">$1</span>`;
        const replacedTextWithClass = findTextValue ? items.replace(new RegExp(`(${findTextValue.trim()})`, "ig"), replaceBy) : items;
        return replacedTextWithClass;
    }
}
