/* eslint-disable class-methods-use-this */
import { Pipe, PipeTransform } from "@angular/core";
import * as moment from "moment";

@Pipe({
    name: "notesDate",
})
export class NotesDatePipe implements PipeTransform {
    transform(dateValue: string): string {
        return moment(new Date(dateValue)).format("DD-MMM-yyyy").toUpperCase();
    }
}
