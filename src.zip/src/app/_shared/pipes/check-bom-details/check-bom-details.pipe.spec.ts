import { mockAttributesArray } from "@te-testing/mock-ag-grid-data";
import { CheckBomDetailsPipe } from "./check-bom-details.pipe";
import { bomDetails } from "@te-testing/mock-data-audit";
import { mockBomDetailExperiments } from "@te-testing/mock-context-menu.helper";
import { BomDetailExperimentsModel } from "@te-shared/models/experiment-bom.model";

describe("CheckBomDetailsPipe", () => {
    let pipe: CheckBomDetailsPipe;

    beforeEach(() => {
        pipe = new CheckBomDetailsPipe();
    });

    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });
    it("should resolve for when row data sub type is I", () => {
        const parameters = {
            columnType: "Flag",
            value: "NO",
            context: {
                componentParent: {
                    attributes: mockAttributesArray,
                },
            },
            data: {
                SUBCode: "00010000",
                SUBType : "I",
                ipc:"00010000"
            },
        };
        const params = parameters;
        const bomDetails = {['Test']: mockBomDetailExperiments as unknown as BomDetailExperimentsModel[]}
        expect(pipe.transform(false,params.data,bomDetails, params.context.componentParent.attributes)).toEqual({ isBom: true, isFlag: false });
    });
    it("should resolve for when row data sub type is E", () => {
        const parameters = {
            columnType: "Flag",
            value: "NO",
            context: {
                componentParent: {
                    attributes: mockAttributesArray,
                },
            },
            data: {
                SUBCode: "00010000",
                SUBType : "E",
            },
        };
        const params = parameters;
        const bomDetails = {['Test']: mockBomDetailExperiments as unknown as BomDetailExperimentsModel[]}
        expect(pipe.transform(false,params.data,bomDetails, params.context.componentParent.attributes)).toEqual({ isBom: false, isFlag: false });
    });
    it("should resolve for when row data sub type is E", () => {
        const parameters = {
            columnType: "Flag",
            value: "NO",
            context: {
                componentParent: {
                    attributes: mockAttributesArray,
                },
            },
            data: {
                SUBCode: "00010000",
                SUBType : "E",
            },
        };
        const params = parameters;
        const bomDetails = {['Test']: mockBomDetailExperiments as unknown as BomDetailExperimentsModel[]}
        expect(pipe.transform(false,params.data,bomDetails, params.context.componentParent.attributes)).toEqual({ isBom: false, isFlag: false });
    });
});
