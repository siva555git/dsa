import { Pipe, PipeTransform } from "@angular/core";
import { BOM_TYPE, DO_NOT_EXPLODE } from "@te-shared/constants";
import { BomDetailsModel } from "@te-shared/models/experiment-bom.model";
import { find, includes } from "lodash";

@Pipe({
    name: "checkBomDetails",
})
export class CheckBomDetailsPipe implements PipeTransform {
    transform = (
        isBomDetailExist: boolean,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        rowData: any,
        bomDetails: BomDetailsModel,
        attributesInfo,
    ): { isBom: boolean; isFlag: boolean } => {
        if (rowData.SUBType === BOM_TYPE.EXPERIMENT) {
            const expFormula = find(bomDetails.Experiments, (bomInfo) => bomInfo.ExpCode === rowData.ipc)?.ExperimentFormula;
            if (expFormula?.length > 0) {
                return { isBom: true, isFlag: false };
            }
        } else if (rowData.SUBType === BOM_TYPE.PRODUCT) {
            const isProductFormulaExist = find(attributesInfo, (ipcData) => ipcData.ipc === rowData.ipc)?.isbom;
            const isProductFormula = find(attributesInfo, (ipcData) => ipcData.ipc === rowData.ipc)?.flags?.map(
                (flagInfo) => flagInfo?.flagcode,
            );
            // eslint-disable-next-line @typescript-eslint/naming-convention
            const flagData = includes(isProductFormula, DO_NOT_EXPLODE);
            if (flagData && isProductFormulaExist) {
                return { isBom: true, isFlag: true };
            }
            if (isProductFormulaExist) {
                return { isBom: true, isFlag: false };
            }
        }
        return { isBom: false, isFlag: false };
    };
}
