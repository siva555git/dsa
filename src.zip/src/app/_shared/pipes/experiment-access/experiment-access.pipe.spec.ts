import { inject, TestBed } from "@angular/core/testing";
import { EXPERIMENT_ACCESS } from "../../constants/experiment-access.constant";
import { ExperimentAccessHelper } from "../../helpers/experiment-access.helper";
import { MockExperimentAccessHelper } from "../../../testing/mock-experiment-access.helper";
import { ExperimentAccessPipe } from "./experiment-access.pipe";

describe("ExperimentAccessPipe", () => {
    const mockExpList = [
        {
            CreatedBy: 65_820,
            ExpAccessStatus: false,
            ExpCode: "VXV00435AC",
            ExpID: 63_388_299,
            ExpName: "menu check",
            ExperimentStaff: [],
            ExperimentVariant: undefined,
            IPC: undefined,
            IsLocked: "0",
            IsOtherExp: undefined,
            IsPublic: true,
            SharedFrom: undefined,
            SharedTo: undefined,
            checked: true,
            productType: "",
        },
    ];
    beforeEach(() =>
        TestBed.configureTestingModule({ providers: [{ provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper }] }),
    );

    it("create an instance", inject([ExperimentAccessHelper], (experimentAccessHelper: ExperimentAccessHelper) => {
        const pipe = new ExperimentAccessPipe(experimentAccessHelper);
        expect(pipe).toBeTruthy();
    }));

    it("Experiment access check method called on pipe", inject(
        [ExperimentAccessHelper],
        (experimentAccessHelper: ExperimentAccessHelper) => {
            const pipe = new ExperimentAccessPipe(experimentAccessHelper);
            expect(pipe.transform(undefined, mockExpList, 65_820, EXPERIMENT_ACCESS.VIEW_BOM)).toBeFalsy();
        },
    ));

    it("test with empty experiment List", inject([ExperimentAccessHelper], (experimentAccessHelper: ExperimentAccessHelper) => {
        const pipe = new ExperimentAccessPipe(experimentAccessHelper);
        expect(pipe.transform(undefined, [], 65_820, EXPERIMENT_ACCESS.VIEW_BOM)).toBeTruthy();
    }));
});
