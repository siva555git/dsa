import { Pipe, PipeTransform } from "@angular/core";
import { ExperimentAccessHelper } from "../../helpers/experiment-access.helper";

@Pipe({
    name: "experimentAccess",
})
export class ExperimentAccessPipe implements PipeTransform {
    constructor(private readonly experimentAccessHelper: ExperimentAccessHelper) {}

    transform(isDisabled: boolean, experimentList, userID: number, accessFunction: string): boolean {
        if (experimentList?.length > 0) {
            const accessInfo = this.experimentAccessHelper.getExperimentAccessCheck(experimentList, userID, accessFunction);
            return !accessInfo.isPermitted;
        }
        return true;
    }
}
