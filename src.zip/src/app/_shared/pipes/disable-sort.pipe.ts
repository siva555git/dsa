import { Pipe, PipeTransform } from "@angular/core";
import { CAN_SORT_DYNAMIC_COLUMNS } from "../constants/common.constant";
import { DisplayValueModel } from "../../experiment-editor/models/experiment-editor.model";

@Pipe({
    name: "disableSort",
})
export class DisableSortPipe implements PipeTransform {
    transform = (value: Array<unknown>, selectedColumn?: DisplayValueModel): boolean => {
        if (value?.length === 0) return true;
        return !!(selectedColumn && !CAN_SORT_DYNAMIC_COLUMNS[selectedColumn.columns]);
    };
}
