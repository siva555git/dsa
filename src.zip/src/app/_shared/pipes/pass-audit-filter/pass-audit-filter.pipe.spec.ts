import { SEARCH_AUDIT_STATUS } from "@te-shared/constants";
import { PassAuditFilterPipe } from "./pass-audit-filter.pipe";

describe("PassAuditFilterPipe", () => {
    let pipe: PassAuditFilterPipe;

    beforeEach(() => {
        pipe = new PassAuditFilterPipe();
    });

    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });
    
    it("should resolve when there is no items", () => {
        const items = undefined;
        const toggle = true;
        const result = pipe.transform(items,toggle);
        expect(result.length).toEqual(0);
    });
    it("should resolve when toggle as false", () => {
        const items = [{ 'audit' : {'status' : SEARCH_AUDIT_STATUS.STATUS_INFO }}];
        const toggle = false;
        const result = pipe.transform(items,toggle);
        expect(result).toEqual(items);
    });
    it("should resolve when toggle as true", () => {
        const items = [
            { 'audit' : {'status' : SEARCH_AUDIT_STATUS.STATUS_INFO }},
            { 'audit' : {'status' : SEARCH_AUDIT_STATUS.STATUS_WARNING }},
            { 'audit' : {'status' : SEARCH_AUDIT_STATUS.STATUS_PASS }},
        ];
        const toggle = true;
        const result = pipe.transform(items,toggle);
        expect(result.length).toEqual(2);
    });
});
