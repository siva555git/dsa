import { Pipe, PipeTransform } from "@angular/core";
import { SEARCH_AUDIT_STATUS } from "@te-shared/constants/common.constant";

@Pipe({
    name: "passAuditFilter",
})
export class PassAuditFilterPipe implements PipeTransform {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    transform = (items: any[], toggle: boolean): any[] => {
        if (!items) return [];
        if (!toggle) return items;
        return items?.filter(
            (product) =>
                product?.audit.status === SEARCH_AUDIT_STATUS.STATUS_INFO || product?.audit.status === SEARCH_AUDIT_STATUS.STATUS_PASS,
        );
    };
}
