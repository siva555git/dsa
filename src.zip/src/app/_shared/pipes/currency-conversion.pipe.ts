/* eslint-disable class-methods-use-this */
import { Pipe, PipeTransform } from "@angular/core";
import { AppStateService } from "../../_services/app-state/app.state.service";
import { AgGridUtil } from "../helpers/ag-grid-util";

@Pipe({
    name: "currencyConversionPipe",
})
export class CurrencyConversionPipe implements PipeTransform {
    transform(costValue: string | number): string {
        let cost = "";
        if (costValue) {
            const rate = AppStateService.getConversionRate() ?? 1;
            cost = AgGridUtil.roundOffCost(Number(costValue) / Number(rate));
        }
        return cost;
    }
}
