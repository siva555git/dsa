import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: "checboxChecked",
})
export class ChecboxCheckedPipe implements PipeTransform {
    // eslint-disable-next-line class-methods-use-this
    transform(value: number, ..._arguments: number[]): boolean {
        return value === _arguments[0];
    }
}
