/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable class-methods-use-this */
import { Pipe, PipeTransform } from "@angular/core";
import { AppStateService } from "../../_services/app-state/app.state.service";

@Pipe({
    name: "currencycodepipe",
    pure: false,
})
export class CurrencyCodePipe implements PipeTransform {
    transform(displayHeaderName: string): string {
        const currencyCode = `<span class="unitInfo"> ${"("}${AppStateService.getCurrencyValue()}${")"} </span>`;
        return `${displayHeaderName} ${currencyCode}`;
    }
}
