import { Pipe, PipeTransform } from "@angular/core";
import { SEARCH_AUDIT_STATUS, SEARCH_AUDIT_STATUS_ICON } from "../constants";

@Pipe({
    name: "auditiconpipe",
})
export class AuditIconPipe implements PipeTransform {
    transform = (auditValue: string): string => {
        let styleName = "";
        if (auditValue) {
            // eslint-disable-next-line unicorn/prefer-switch
            if (auditValue === SEARCH_AUDIT_STATUS.STATUS_PASS) {
                styleName = SEARCH_AUDIT_STATUS_ICON.ICON_PASS;
            } else if (auditValue === SEARCH_AUDIT_STATUS.STATUS_FAIL) {
                styleName = SEARCH_AUDIT_STATUS_ICON.ICON_FAIL;
            } else if (auditValue === SEARCH_AUDIT_STATUS.STATUS_WARNING) {
                styleName = SEARCH_AUDIT_STATUS_ICON.ICON_WARNING;
            } else if (auditValue === SEARCH_AUDIT_STATUS.STATUS_CRITICAL) {
                styleName = SEARCH_AUDIT_STATUS_ICON.ICON_CRITICAL;
            } else if (auditValue === SEARCH_AUDIT_STATUS.STATUS_INFO) {
                styleName = SEARCH_AUDIT_STATUS_ICON.ICON_INFO;
            } else if (auditValue === SEARCH_AUDIT_STATUS.STATUS_SEVERE) {
                styleName = SEARCH_AUDIT_STATUS_ICON.ICON_SEVERE;
            }
        }
        return styleName;
    };
}
