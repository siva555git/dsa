/* eslint-disable class-methods-use-this */
import { Pipe, PipeTransform } from "@angular/core";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";

@Pipe({
    name: "attributeColumnHeader",
})
export class AttributeColumnHeaderPipe implements PipeTransform {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    transform(displayHeaderName: any): string {
        if (displayHeaderName.isCost) {
            const currencyCode = `<span class="unitInfo d-block"> ${"("}${AppStateService.getCurrencyValue()}${")"} </span>`;
            return `<span class="matThAttribute"> ${displayHeaderName.value} ${currencyCode} </span>`;
        }
        if (displayHeaderName.value === "FLASHPOINT") {
            const flashpointValue = `<span class="unitInfo d-block"> ${"("}&deg;${TasteEditorUtilClass.getUserDefaultFlashpoint()}${")"} </span>`;
            return `<span class="matThAttribute"> ${displayHeaderName.value} ${flashpointValue} </span>`;
        }
        return `<span class="matThAttribute" title="${displayHeaderName.value}"> ${displayHeaderName.value} </span>`;
    }
}
