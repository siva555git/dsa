import { Pipe, PipeTransform } from "@angular/core";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { forEach } from "lodash";

@Pipe({
    name: "flashpointConversion",
})
export class FlashpointConversionPipe implements PipeTransform {
    transform = (gridData, isEditionSuggestion = false) => {
        const defaultValues = TasteEditorUtilClass.getUserDefaultFlashpoint();
        const filterProductData = gridData.filter((item) => item.FLASHPOINT !== null);
        forEach(filterProductData, (productData) => {
            const product = productData;
            if (isEditionSuggestion && !product?.isFlashPointConversionDone) {
                product.FLASHPOINT =
                    product.FLASHPOINT?.slice(-1) === defaultValues
                        ? product.FLASHPOINT?.slice(0, -1).trim()
                        : TasteEditorUtilClass.flashPointConversion(product);
                product["isFlashPointConversionDone"] = true;
            } else if (!isEditionSuggestion) {
                product.FLASHPOINT =
                    product.FLASHPOINT?.slice(-1) === defaultValues
                        ? product.FLASHPOINT?.slice(0, -1).trim()
                        : TasteEditorUtilClass.flashPointConversion(product);
            }
        });
        return gridData;
    };
}
