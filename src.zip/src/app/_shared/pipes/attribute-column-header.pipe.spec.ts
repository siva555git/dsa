import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { AttributeColumnHeaderPipe } from "./attribute-column-header.pipe";
import { AppStateService } from "@te-services/app-state/app.state.service";

describe("AttributeColumnHeaderPipe", () => {
    let pipe : AttributeColumnHeaderPipe
    beforeEach(() => {
        pipe = new AttributeColumnHeaderPipe();
    });
    it("create an instance", () => {
        const pipe = new AttributeColumnHeaderPipe();
        expect(pipe).toBeTruthy();
    });
    
    it("test with bind the value into attribute column header when isCost is false and it's not FLASHPOINT", () => {
        const displayHeaderName = {value : 'FLASHPOINT1'}
        const result = pipe.transform(displayHeaderName);
        expect(result).toContain(`<span class="matThAttribute" title="FLASHPOINT1"> FLASHPOINT1 </span>`);
    });
    
    it("test with bind the value into attribute column header when isCost is true and it's not FLASHPOINT", () => {
        const displayHeaderName = {value : 'cost',isCost:true}
        // spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("F");
        
        spyOn(AppStateService, "getCurrencyValue").and.returnValue("USD");
        const result = pipe.transform(displayHeaderName);
        expect(result).toContain(`<span class="matThAttribute"> cost <span class="unitInfo d-block"> (USD) </span> </span>`);
    });
    it("test with bind the value into attribute column header", () => {
        const displayHeaderName = {value : 'FLASHPOINT'}
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("F");
        const result = pipe.transform(displayHeaderName);
        expect(result).toContain(`<span class="matThAttribute"> FLASHPOINT <span class="unitInfo d-block"> (&deg;F) </span> </span>`);
    });

});
