import { NotesFilterPipe } from "./notes-filter.pipe";

describe("FilterPipe", () => {
    let pipe: NotesFilterPipe;
    const searchArray = [
        {
            name: "mint",
            Description: "mint",
        },
        {
            name: "sweet",
            Description: "sweet",
        },
    ];

    beforeEach(() => {
        pipe = new NotesFilterPipe();
    });

    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });

    it("test with empty array and empty search value", () => {
        expect(pipe.transform([], "", "all")).toEqual([]);
    });

    it("test with array value and search value", () => {
        expect(pipe.transform(searchArray, "swee", "all")).toEqual([{ name: "sweet", Description: "sweet" }]);
    });

    it("test with array value and search value", () => {
        expect(pipe.transform(searchArray, "swee", "last7Days")).toEqual([{ name: "sweet", Description: "sweet" }]);
    });
});
