/* eslint-disable no-param-reassign */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable class-methods-use-this */
import { Pipe, PipeTransform } from "@angular/core";
import { toLower } from "lodash";
import * as moment from "moment";
import { DATE_RANGE_DROPDOWN_NOTES } from "../../constants/common.constant";

@Pipe({
    name: "notesFilter",
})
export class NotesFilterPipe implements PipeTransform {
    transform(items: any[], searchText: string, dateAgo: string): any[] {
        if (!items) return [];
        if (!searchText && dateAgo === DATE_RANGE_DROPDOWN_NOTES[2].allTime) return items;
        if (DATE_RANGE_DROPDOWN_NOTES[2].allTime === dateAgo) {
            return items.filter((value) => toLower(value?.Description).includes(toLower(searchText)));
        }
        // eslint-disable-next-line no-else-return
        else {
            const filteredData = [];
            items.forEach((note: any) => {
                const todayDate = moment();
                const daysCount = todayDate.diff(moment(note.CreatedOn).startOf("day"), "day");
                const retrunData = this.filteredNotesData(dateAgo, note, daysCount);
                if (retrunData) {
                    filteredData.push(retrunData);
                }
            });
            if (searchText) {
                return filteredData.filter((value) => toLower(value?.Description).includes(toLower(searchText)));
            }
            return filteredData;
        }
    }

    public filteredNotesData(dateValue: string, element: any, daysCount: number): any {
        let note: any;
        if (daysCount >= 0 && daysCount <= 7 && dateValue === DATE_RANGE_DROPDOWN_NOTES[0].OneWeek) {
            note = element;
            // eslint-disable-next-line sonarjs/no-duplicated-branches
        } else if (daysCount >= 0 && daysCount <= 31 && dateValue === DATE_RANGE_DROPDOWN_NOTES[1].OneMonth) {
            note = element;
        }
        return note;
    }
}
