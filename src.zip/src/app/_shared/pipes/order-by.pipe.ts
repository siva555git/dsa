/* eslint-disable @typescript-eslint/no-explicit-any */
import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: "orderBy",
})
export class OrderByPipe implements PipeTransform {
    transform = (array: Array<any>, field: string): any[] => {
        array?.sort((aRecord: any, bRecord: any) => {
            if (aRecord[field] < bRecord[field]) {
                return -1;
            }
            if (aRecord[field] > bRecord[field]) {
                return 1;
            }
            return 0;
        });
        return array;
    };
}
