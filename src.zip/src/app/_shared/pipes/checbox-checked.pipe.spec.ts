import { ChecboxCheckedPipe } from "./checbox-checked.pipe";

describe("ChecboxCheckedPipe", () => {
    let pipe: ChecboxCheckedPipe;

    beforeEach(() => {
        pipe = new ChecboxCheckedPipe();
    });

    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });

    it("test with empty array and empty search value", () => {
        expect(pipe.transform(1, 1)).toBeTruthy();
    });
});
