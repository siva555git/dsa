import { ReplaceStringPipe } from "./replace-string.pipe";

describe("ReplaceStringPipe", () => {
    let pipe: ReplaceStringPipe;

    beforeEach(() => {
        pipe = new ReplaceStringPipe();
    });

    it("Should create", () => {
        expect(pipe).toBeTruthy();
    });

    it("Should test dataString, regex and replace Value", () => {
        const mockString = "4219(5%); 2665(10%)";
        const regexValue = ";";
        const replaceValue = ",";
        expect(pipe.transform(mockString, regexValue, replaceValue)).toBeTruthy();
    });
});
