import { Pipe, PipeTransform } from "@angular/core";
import { INVALID_USER } from "@te-shared/constants/common.constant";
import { NotesResponse } from "@te-shared/models/notes.model";

@Pipe({
    name: "noteUsername",
})
export class NoteUsernamePipe implements PipeTransform {
    transform = (userFullName: string, experimentNote: NotesResponse): string => {
        const userName = INVALID_USER;
        let name;
        if (experimentNote?.User?.FirstName && experimentNote?.User?.FirstName === userName.name) {
            name = userName.value;
        } else if (experimentNote?.User?.firstname && experimentNote?.User?.firstname === userName.name) {
            name = userName.value;
        } else {
            name = experimentNote?.User?.fullname;
        }
        return name;
    };
}
