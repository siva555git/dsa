/* eslint-disable class-methods-use-this */
import { Pipe, PipeTransform } from "@angular/core";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";

@Pipe({
    name: "flashpointCode",
})
export class FlashpointCodePipe implements PipeTransform {
    transform(displayHeaderName: string): string {
        const flashpointValue = `<span class="unitInfo flashpoint"> ${"("}&deg;${TasteEditorUtilClass.getUserDefaultFlashpoint()}${")"} </span>`;
        return `${displayHeaderName} ${flashpointValue}`;
    }
}
