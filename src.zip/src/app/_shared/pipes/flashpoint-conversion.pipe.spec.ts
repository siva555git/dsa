import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { FlashpointConversionPipe } from "./flashpoint-conversion.pipe";

describe("FlashpointConversionPipe", () => {
    let pipe: FlashpointConversionPipe;

    beforeEach(() => {
        pipe = new FlashpointConversionPipe();
    });
    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });

    it("test with gridData converting celsius to Fahrenheit", () => {
        const gridData = [{ ipc: "00100010", FLASHPOINT: "0 C" }];
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("F");
        const result = pipe.transform(gridData);
        expect(result[0].FLASHPOINT).toEqual("32");
    });

    it("test with gridData converting celsius to Fahrenheit", () => {
        const gridData = [{ ipc: "00100010", FLASHPOINT: "32 F" }];
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("C");
        const result = pipe.transform(gridData);
        expect(result[0].FLASHPOINT).toEqual("0");
    });
});
