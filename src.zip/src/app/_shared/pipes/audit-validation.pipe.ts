import { Pipe, PipeTransform } from "@angular/core";
import { SEARCH_AUDIT_STATUS } from "../constants";

@Pipe({
    name: "auditValidationPipe",
})
export class AuditValidationPipe implements PipeTransform {
    transform = (auditValue: string, inverse = false): boolean => {
        let isVaidAudit = false;
        if (auditValue) {
            isVaidAudit =
                auditValue === SEARCH_AUDIT_STATUS.STATUS_PASS ||
                auditValue === SEARCH_AUDIT_STATUS.STATUS_WARNING ||
                auditValue === SEARCH_AUDIT_STATUS.STATUS_INFO;
        }
        return inverse ? !isVaidAudit : isVaidAudit;
    };
}
