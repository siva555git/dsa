import { Pipe, PipeTransform } from "@angular/core";
import { ExplodeBomItemModel } from "../../experiment-editor/models/experiment-editor.model";

@Pipe({
    name: "emptyArray",
})
export class EmptyArrayPipe implements PipeTransform {
    // eslint-disable-next-line class-methods-use-this
    transform(value: ExplodeBomItemModel[]): boolean {
        return value?.length === 0;
    }
}
