/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable class-methods-use-this */
import { Pipe, PipeTransform } from "@angular/core";
import * as moment from "moment";

@Pipe({
    name: "dateAgo",
    pure: true,
})
export class DateAgoPipe implements PipeTransform {
    transform(value: any): any {
        const timeAgo = moment(new Date(value)).fromNow(true);
        return timeAgo;
    }
}
