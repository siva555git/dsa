import { SEARCH_AUDIT_STATUS, SEARCH_AUDIT_STATUS_ICON } from "@te-shared/constants";
import { AuditIconPipe } from "./audit-icon.pipe";

describe("auditiconpipe", () => {
    let pipe: AuditIconPipe;
    beforeEach(() => {
        pipe = new AuditIconPipe();
    });

    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });

    it("should return pass icon  for 'pass'", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_PASS);
        expect(result).toBe(SEARCH_AUDIT_STATUS_ICON.ICON_PASS);
    });
    it("should return fail icon  for 'fail'", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_FAIL);
        expect(result).toBe(SEARCH_AUDIT_STATUS_ICON.ICON_FAIL);
    });
    it("should return critical icon  for 'critical'", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_CRITICAL);
        expect(result).toBe(SEARCH_AUDIT_STATUS_ICON.ICON_CRITICAL);
    });
    it("should return warning icon  for 'warning'", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_WARNING);
        expect(result).toBe(SEARCH_AUDIT_STATUS_ICON.ICON_WARNING);
    });
    it("should return info icon  for 'info'", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_INFO);
        expect(result).toBe(SEARCH_AUDIT_STATUS_ICON.ICON_INFO);
    });
    it("should return pass icon  for 'severe'", () => {
        const result = pipe.transform(SEARCH_AUDIT_STATUS.STATUS_SEVERE);
        expect(result).toBe(SEARCH_AUDIT_STATUS_ICON.ICON_SEVERE);
    });
});
