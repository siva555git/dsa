import { EmptyArrayPipe } from "./empty-array.pipe";

describe("FilterPipe", () => {
    let pipe: EmptyArrayPipe;

    beforeEach(() => {
        pipe = new EmptyArrayPipe();
    });

    it("create an instance", () => {
        expect(pipe).toBeTruthy();
    });

    it("test with empty array and empty search value", () => {
        const searchArray = [];
        expect(pipe.transform(searchArray)).toBeTruthy();
    });
});
