export interface IpcOperatorsResponse {
    IPC: string[];
    "IPC Description": string[];
    "Product Type": string[];
    Cost: string[];
    Flags: string[];
    Spec: string[];
    Plant: string[];
    "Flavor Class": string[];
    "Flavor Type": string[];
    "Product Allocation": string[];
}

export interface AuxillarCriteriaResponse {
    Flags: string[];
}
export interface IpcCriteriaResponse {
    criteriaList: string[];
    operators: IpcOperatorsResponse;
    logicalOperators: string[];
    auxilaryCriteria: AuxillarCriteriaResponse;
}
