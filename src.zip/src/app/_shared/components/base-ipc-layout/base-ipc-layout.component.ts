/* eslint-disable max-lines */
import { Component, OnInit, Output, EventEmitter, Input, SimpleChanges, OnChanges, ViewChild, ElementRef } from "@angular/core";
import {
    UntypedFormGroup,
    UntypedFormControl,
    UntypedFormBuilder,
    UntypedFormArray,
    Validators,
    ValidationErrors,
    FormControl,
    AbstractControlOptions,
} from "@angular/forms";
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { NGXLogger } from "ngx-logger";
import { delay, each, filter, forEach, includes, isEmpty, pull } from "lodash";
import { startWith, map } from "rxjs/operators";
import { Observable } from "rxjs";
import { ProductSearchResponse } from "src/app/master-data/models/ipc-selection-model";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { IPC_COLUMN_LAYOUT_VALIDATION_MSG } from "@te-shared/constants/common.constant";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { FlagsOperator } from "@te-shared/enums/ipc-selection.enum";
import { COMMA, ENTER } from "@angular/cdk/keycodes";
import { MatSidenav } from "@angular/material/sidenav";
import { BaseIPCSelectionHelper } from "./helper/base-ipc-layout-helper";
import { IpcCriteriaResponse } from "./models/ipc-selection.model";
import {
    CRITERIA_LIST,
    DEFAULT_OPERATOR,
    DEFAULT_LOGICAL_OPERATOR,
    ROW_DELETE_ERROR_TIME,
    MANDATORY_ATTRIBUTES_CRITERIA,
    BETWEEN_OPERATOR,
    DEFAULT_CRITERIA,
    DEFAULT_FLAGS_LIST,
    IPC_NUMRIC_LIMITS,
    FORM_CONTROL_NAME,
    DEFAULT_AUXILLARY_CRITERIA,
    CRITERIA,
    BOM_CRITERIA_ATTRIBUTES,
    DEFAULT_BOM_CRITERIA_ATTRIBUTE,
    IPC_SELECTION_NOT_DISABLE,
    DIVISION_CRITERIA_ATTRIBUTES,
    IPC_SELECTION_WITH_IN_CLAUSE,
    IPC_SELECTION,
} from "./base-ipc-layout-constant";
import { AppStateService } from "../../../_services/app-state/app.state.service";
import { CONTROLS, COPY_TOOLTIP, DRAG_AND_DROP_TOOLTIP, EMPTY } from "../../../app.constant";
import { DIVISION_LIST } from "../product-data/product-data-constant";

const DEFAULT_FORM_ROWS_COUNT = 6;
@Component({
    selector: "app-base-ipc-layout",
    templateUrl: "./base-ipc-layout.component.html",
})
export class BaseIpcLayoutComponent implements OnInit, OnChanges {
    public ipcSelectionForm: UntypedFormGroup;

    public ipcSelectionCriteriaList: IpcCriteriaResponse;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public defaultData: any;

    public CriteriaList = CRITERIA_LIST;

    public errorRowDelete = false;

    public drapAndDropTooltip = DRAG_AND_DROP_TOOLTIP;

    public copyTooltip = COPY_TOOLTIP;

    public betweenOperator = BETWEEN_OPERATOR;

    public numericLimits = IPC_NUMRIC_LIMITS;

    public logicalAnd = DEFAULT_LOGICAL_OPERATOR;

    public formControlName = FORM_CONTROL_NAME;

    public isAdminAccess: boolean;

    public validationMsg = IPC_COLUMN_LAYOUT_VALIDATION_MSG;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public filteredAttributes: Observable<any>[] = [];

    public criteria = CRITERIA;

    public loggedUserId: number;

    public savedIpcListData: Array<string>;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Input() public userIpcSelectionFormData: any;

    @Output()
    public onEmitFormValues = new EventEmitter();

    @Output()
    public onEmitRowOrder = new EventEmitter();

    @Input() public currentSelectedIpc: ProductSearchResponse;

    @Input() public disableAllFields: boolean;

    @ViewChild("inputInOperator")
    inputTrigger: ElementRef<HTMLInputElement>;

    public rowOrderChanged = false;

    public readonly separatorKeysCodes: number[] = [ENTER, COMMA];

    public selectable = true;

    public removable = true;

    public selectedAttributes: Array<{ criteria: string; attributes: string[] }> = IPC_SELECTION_WITH_IN_CLAUSE;

    public openAddIpcDrawer = false;

    @ViewChild("viewAddIpcList") viewAddIpcList: MatSidenav;

    ipcSelectionFormArray(): UntypedFormArray {
        return this.ipcSelectionForm.get("IpcSelection") as UntypedFormArray;
    }

    get getIpcSelectionFormArray(): UntypedFormArray {
        return this.ipcSelectionForm.controls.IpcSelection as UntypedFormArray;
    }

    ipcSelectionFormGroup(): UntypedFormGroup {
        return this.formBuilder.group({
            Criteria: new UntypedFormControl(""),
            AuxiliaryCriteria: new UntypedFormControl(),
            Operator: new UntypedFormControl(DEFAULT_OPERATOR),
            Attributes: new UntypedFormControl(),
            AttributesIN: new UntypedFormControl(),
            AttributesTo: new UntypedFormControl(),
            Condition: new UntypedFormControl(DEFAULT_LOGICAL_OPERATOR),
        });
    }

    constructor(
        private readonly formBuilder: UntypedFormBuilder,
        private readonly baseIpcSelectionHelper: BaseIPCSelectionHelper,
        private readonly logger: NGXLogger,
        private readonly appState: AppStateService,
        public readonly securityHelper: SecurityHelper,
        private readonly spaceTrim: SpaceTrimPipe,
    ) {
        this.getDefaultData();
    }

    public ngOnInit(): void {
        this.getIpcCriteriaList();
        this.loggedUserId = Number(this.appState.getCurrentUserSapEmpId());
        this.isAdminAccess = this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.IPC_SELECTION_ADMIN);
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.userIpcSelectionFormData?.currentValue?.length > 0) {
            this.bindIpcSelectionFormData(changes.userIpcSelectionFormData.currentValue);
            return;
        }

        if (this.ipcSelectionForm?.get("Criteria") && this.ipcSelectionForm?.get("Criteria")[CONTROLS].length === 0) {
            this.defaultSetRows(DEFAULT_FORM_ROWS_COUNT);
        }
    }

    /**
     * Method to get the criteria and opertors list for ipc
     *
     * @memberof BaseIpcLayoutComponent
     */
    public getIpcCriteriaList(): void {
        this.baseIpcSelectionHelper.getIpcCriteriaList().subscribe({
            next: (result) => {
                if (result) {
                    this.ipcSelectionCriteriaList = result;
                }
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to get the default data
     *
     * @memberof BaseIpcLayoutComponent
     */
    public getDefaultData(): void {
        this.baseIpcSelectionHelper.getDefaultData().subscribe({
            next: (result) => {
                if (result) {
                    this.defaultData = result;
                    this.ipcSelectionForm = this.createipcSelectionForm();
                }
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to intiate the form group
     *
     * @private
     * @memberof BaseColumnLayoutComponent
     */
    private createipcSelectionForm = (): UntypedFormGroup => {
        return this.formBuilder.group({
            IpcSelection: new UntypedFormArray([], [this.layoutForm]),
        });
    };

    /**
     * Method to load the default row of the form
     *
     * @memberof BaseColumnLayoutComponent
     */
    public defaultSetRows(defaultRowCount: number): void {
        for (let row = 0; row < defaultRowCount; row += 1) {
            const columnData = this.ipcSelectionFormGroup();
            this.ipcSelectionFormArray().push(columnData);
            if (row < DEFAULT_FLAGS_LIST.length) {
                this.onSelectionCriteria(row);
                this.ipcSelectionFormArray().at(row).get("Attributes").setValidators([Validators.required]);
                this.ipcSelectionFormArray().at(row).patchValue({
                    Criteria: DEFAULT_CRITERIA,
                    Attributes: DEFAULT_FLAGS_LIST[row],
                    Operator: FlagsOperator.DEFAULT_HAS_OPERATOR,
                    AuxiliaryCriteria: DEFAULT_AUXILLARY_CRITERIA,
                });
            }
        }
    }

    /**
     * Method to add the new criteria
     *
     * @memberof BaseIpcLayoutComponent
     */
    public addNewCriteria(): void {
        const selectionData = this.ipcSelectionFormGroup();
        this.ipcSelectionFormArray().push(selectionData);
    }

    /**
     * Method to Clone the criteria
     *
     * @param {number} index
     * @memberof BaseIpcLayoutComponent
     */
    public onCloneCriteria(index: number): void {
        const clonedForm = this.ipcSelectionFormGroup();
        const originalFormControl: FormControl = this.ipcSelectionFormArray().at(index) as FormControl;
        const clonedFormControl: FormControl = new FormControl(originalFormControl.value);
        clonedForm.patchValue(clonedFormControl.value);
        this.ipcSelectionFormArray().insert(index, clonedForm);
        this.onEmitFormValues.emit(this.ipcSelectionForm);
    }

    /**
     * Method to delete the row from the form
     *
     * @param {number} index
     * @returns {void}
     * @memberof BaseIpcLayoutComponent
     */
    public deleteCriteria(index: number): void {
        if (this.ipcSelectionForm.get("IpcSelection").value.length > 1) {
            this.ipcSelectionFormArray().removeAt(index);
            this.onEmitFormValues.emit(this.ipcSelectionForm);
            return;
        }
        this.errorRowDelete = true;
        delay(() => {
            this.errorRowDelete = false;
        }, ROW_DELETE_ERROR_TIME);
    }

    /**
     * Method to call when selecting the criteriatype
     * @param {number} index
     * @param {string} criteria
     * @memberof BaseIpcLayoutComponent
     */
    public onSelectionCriteria(index: number, criteria?: string): void {
        this.ipcSelectionFormArray()
            .at(index)
            .patchValue({
                Operator: this.getCriteriaBasedOperatorInfo(index),
                AuxiliaryCriteria:
                    this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.FLAGS ||
                    this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.CBW_FLAGS
                        ? DEFAULT_AUXILLARY_CRITERIA
                        : "",
                Attributes: this.getCriteriaBasedAttributeInfo(index),
                AttributesTo: EMPTY,
            });
        if (MANDATORY_ATTRIBUTES_CRITERIA.includes(this.ipcSelectionFormArray().at(index).get("Criteria").value)) {
            this.ipcSelectionFormArray().at(index).get("Attributes").setValidators([Validators.required]);
        } else {
            this.ipcSelectionFormArray().at(index).get("Attributes").clearValidators();
            this.ipcSelectionFormArray().at(index).get("Attributes").updateValueAndValidity();
        }

        if (
            this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.COST ||
            this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.SPEC
        ) {
            const defaultValue = this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.COST ? "0" : "";
            this.ipcSelectionFormArray().at(index).get("Attributes").patchValue(defaultValue);
            this.ipcSelectionFormArray().at(index).get("AuxiliaryCriteria").setValidators([Validators.required]);
        } else {
            this.ipcSelectionFormArray().at(index).get("AuxiliaryCriteria").clearValidators();
            this.ipcSelectionFormArray().at(index).get("AuxiliaryCriteria").updateValueAndValidity();
        }
        this.bindAttributesControl(index);
        this.onEmitFormValues.emit(this.ipcSelectionForm);
        this.disableNoColumn(criteria);
    }

    /**
     * Method to get Criteria Based Operator Info
     * @param {number} index
     * @returns {string}
     * @memberof BaseIpcLayoutComponent
     */
    public getCriteriaBasedOperatorInfo(index: number): string {
        if (
            this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.FLAGS ||
            this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.CBW_FLAGS
        ) {
            return FlagsOperator.DEFAULT_HAS_OPERATOR;
        }
        return this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.IPC_LIST
            ? FlagsOperator.DEFAULT_IN_OPERATOR
            : DEFAULT_OPERATOR;
    }

    /**
     * Method to get Criteria Based Attribute Info
     * @param {number} index
     * @returns {string | Array<string>}
     * @memberof BaseIpcLayoutComponent
     */
    public getCriteriaBasedAttributeInfo(index: number): string | Array<string> {
        if (
            this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.BOM ||
            this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.BOM_LOCKED ||
            this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.SOLUTION
        ) {
            return DEFAULT_BOM_CRITERIA_ATTRIBUTE;
        }
        return this.ipcSelectionFormArray().at(index).get("Criteria").value === CRITERIA_LIST.IPC_LIST ? [] : EMPTY;
    }

    /**
     * Method to change the attributes
     *
     * @param {void} index
     * @memberof BaseIpcLayoutComponent
     */
    public onChangeAttributes(): void {
        this.onEmitFormValues.emit(this.ipcSelectionForm);
    }

    /**
     * Method when autocomplete multiselection option is clicked
     *
     * @param {Event} event
     * @param {string} item
     * @param {string} criteria
     * @param {number} index
     * @memberof BaseIpcLayoutComponent
     */
    public attributeINClicked(event: Event, item: string, criteria: string, index: number) {
        event.stopPropagation();
        this.toggleSelection(item, criteria, index);
    }

    /**
     * Method when autocomplete multiselection option check box is clicked
     *
     * @param {string} item
     * @param {string} criteria
     * @param {number} index
     * @memberof BaseIpcLayoutComponent
     */
    public toggleSelection(item: string, criteria: string, index: number): void {
        if (this.selectedINAttribute(item, criteria, index)) {
            this.onRemoveAttributeChip(item, criteria, index);
        } else {
            const attributeInControl = this.ipcSelectionForm.get(IPC_SELECTION)[CONTROLS].at(index);
            const attributeArray = attributeInControl.value.Attributes;
            attributeArray.push(item);
            attributeInControl.patchValue({ Attributes: attributeArray });
            this.inputTrigger.nativeElement.value = EMPTY;
            attributeInControl.get("AttributesIN").reset();
        }
        this.onChangeAttributes();
    }

    /**
     * Method to select the attributes check box
     *
     * @param {string} item
     * @param {string} criteria
     * @param {number} index
     * @returns {boolean} boolean
     * @memberof BaseIpcLayoutComponent
     */
    public selectedINAttribute(item: string, criteria: string, index: number): boolean {
        const attributeInControl = this.ipcSelectionForm.get(IPC_SELECTION)[CONTROLS].at(index);
        return attributeInControl.value.Attributes.includes(item);
    }

    /**
     * Method to remove chip from multiselect auto complete
     *
     * @param {string} attribute
     * @param {string} criteria
     * @param {number} index
     * @memberof BaseIpcLayoutComponent
     */
    public onRemoveAttributeChip(attribute: string, criteria: string, index: number): void {
        const attributeInControl = this.ipcSelectionForm.get(IPC_SELECTION)[CONTROLS].at(index);
        const attributeArray = attributeInControl.value.Attributes;
        pull(attributeArray, attribute);
        attributeInControl.patchValue(attributeArray);
    }

    /**
     * Method to load the attributes
     *
     * @param {void} index
     * @memberof BaseIpcLayoutComponent
     */
    public loadAttributes(index: number): void {
        this.bindAttributesControl(index);
    }

    /**
     * Method to bind the auxiliary and attributes in the control
     *
     * @private
     * @param {number} index
     * @memberof BaseIpcLayoutComponent
     */
    // eslint-disable-next-line sonarjs/cognitive-complexity, max-lines-per-function
    private bindAttributesControl(index: number): void {
        const arrayControl = this.ipcSelectionFormArray();
        let formControl;
        if (
            arrayControl.at(index).get("Criteria").value === CRITERIA_LIST.SPEC ||
            arrayControl.at(index).get("Criteria").value === CRITERIA_LIST.COST
        ) {
            formControl = "AuxiliaryCriteria";
        } else {
            formControl = arrayControl.at(index).get("Operator").value === "IN" ? "AttributesIN" : "Attributes";
        }
        this.filteredAttributes[index] = arrayControl
            .at(index)
            .get(formControl)
            .valueChanges.pipe(
                startWith(""),
                // eslint-disable-next-line consistent-return
                map((search) => {
                    return this.filterDataFetching(arrayControl.at(index).get("Criteria").value, search);
                }),
            );
    }

    /**
     * Method to return filtered data of each crietreia
     *
     * @param {string} criteria
     * @param {string} search
     * @returns {any[]} any[]
     */
    // eslint-disable-next-line consistent-return, @typescript-eslint/no-explicit-any
    private filterDataFetching(criteria: string, search: string): any[] {
        if (!this.defaultData) return [];

        if (criteria === CRITERIA_LIST.SPEC) {
            return this.filterDropDownData(this.defaultData?.specs, "speccode", search);
        }
        if (criteria === CRITERIA_LIST.COST || criteria === CRITERIA_LIST.PRODUCT_ALLOC || criteria === CRITERIA_LIST.PLANT) {
            const costBookData =
                this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION) === false
                    ? filter(this.defaultData?.costs, (cost) => includes(cost.costbookcode, DIVISION_LIST.FLAV))
                    : this.defaultData?.costs;
            return this.filterDropDownData(costBookData, "costbookcode", search);
        }
        if (criteria === CRITERIA_LIST.FLAGS) {
            return this.filterDropDownData(this.defaultData?.flags, "flagcode", search);
        }
        if (criteria === CRITERIA_LIST.CBW_FLAGS) {
            return this.filterDropDownData(this.defaultData?.cbwflags, "flagcode", search);
        }
        if (criteria === CRITERIA_LIST.FLAVOR_CLASS) {
            return this.filterDropDownData(this.defaultData?.flavorClasses, "name", search);
        }
        if (criteria === CRITERIA_LIST.FLAVOR_TYPE) {
            return this.filterDropDownData(this.defaultData?.flavorTypes, "name", search);
        }
        if (criteria === CRITERIA_LIST.PRODUCT_TYPE) {
            return this.filterDropDownData(this.defaultData?.productTypes, "prodtypecode", search);
        }
        if (criteria === CRITERIA_LIST.BOM || criteria === CRITERIA_LIST.BOM_LOCKED || criteria === CRITERIA_LIST.SOLUTION) {
            return this.filterDropDownData(BOM_CRITERIA_ATTRIBUTES, EMPTY, search);
        }
        if (criteria === CRITERIA_LIST.DIVISION) {
            return this.filterDropDownData(DIVISION_CRITERIA_ATTRIBUTES, EMPTY, search);
        }
    }

    /**
     * Method to filter data that matches search
     *
     * @param {*} list
     * @param {*} keyToCheck
     * @param {*} search
     * @returns
     * @memberof BaseIpcLayoutComponent
     */
    // eslint-disable-next-line class-methods-use-this
    private filterDropDownData(list, keyToCheck, search) {
        const response =
            search && typeof search === "string"
                ? list.filter((column) => {
                      return keyToCheck
                          ? column[keyToCheck].toLowerCase().includes(search.toLowerCase())
                          : column.toLowerCase().includes(search.toLowerCase());
                  })
                : list?.slice();
        return response;
    }

    /**
     * Method to bind the data when click on edit/view
     *
     * @param {*} formData
     * @memberof BaseColumnLayoutComponent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
    public bindIpcSelectionFormData(formData: any): void {
        this.ipcSelectionForm = this.createipcSelectionForm();
        const formattedFormData = this.baseIpcSelectionHelper.formatInOperatorFormData(formData);
        each(formattedFormData, (criteria, key) => {
            this.ipcSelectionFormArray().push(
                this.formBuilder.group(
                    {
                        Criteria: new UntypedFormControl(criteria.Criteria),
                        AuxiliaryCriteria: new UntypedFormControl(criteria.AuxiliaryCriteria),
                        Operator: new UntypedFormControl(criteria.Operator),
                        Attributes: new UntypedFormControl(criteria.Attributes),
                        AttributesIN: new UntypedFormControl(),
                        AttributesTo: new UntypedFormControl(criteria.AttributesTo),
                        Condition: new UntypedFormControl(criteria.Condition),
                    },
                    {
                        validator: this.auxillaryCriteriaValidation,
                    } as AbstractControlOptions,
                ),
            );
            this.ipcSelectionForm.setControl("Columns", this.ipcSelectionFormArray());
            if (criteria.Attributes || criteria.AuxiliaryCriteria) {
                this.bindAttributesControl(Number(key));
            }
        });
        this.onEmitFormValues.emit(this.ipcSelectionForm);
    }

    /**
     * Method to handle the drag and drop
     *
     * @param {CdkDragDrop<string[]>} event
     * @memberof BaseIpcLayoutComponent
     */
    public drop(event: CdkDragDrop<string[]>): void {
        moveItemInArray(this.ipcSelectionForm.get("IpcSelection")[CONTROLS], event.previousIndex, event.currentIndex);
        moveItemInArray(this.ipcSelectionForm.get("IpcSelection").value, event.previousIndex, event.currentIndex);
        this.rowOrderChanged = true;
        this.onEmitRowOrder.emit();
    }

    /**
     * Method to reset the defalt ipc selection
     *
     * @memberof BaseIpcLayoutComponent
     */
    public resetIpcSelectionCriteria(): void {
        this.ipcSelectionForm = this.createipcSelectionForm();
        this.defaultSetRows(DEFAULT_FORM_ROWS_COUNT);
        this.onEmitFormValues.emit(this.ipcSelectionForm);
    }

    public onChangeOperator(operator: string, criteria: string, index: number): void {
        const formArrayControl = this.ipcSelectionForm.get(IPC_SELECTION)[CONTROLS].at(index);
        if (operator === "IN") {
            formArrayControl.patchValue({ Attributes: [] });
        }
        if (operator !== "IN" && Array.isArray(formArrayControl.value[FORM_CONTROL_NAME.ATTRIBUTES])) {
            formArrayControl.patchValue({ Attributes: EMPTY });
        }
    }

    /**
     * Method to check form is valid or invalid based on input values
     * @param {FormControl} control
     * @returns {ValidationErrors | null}
     * @memberof BaseColumnLayoutComponent
     */
    public layoutForm = (control: UntypedFormControl): ValidationErrors | null => {
        forEach(control.value, (values, index) => {
            const result = this.operatorAttributeValidation(values);
            if (!result && MANDATORY_ATTRIBUTES_CRITERIA.includes(values.Criteria)) {
                control[CONTROLS][index].controls.Attributes.setErrors({ isInvalid: true });
            }
        });
        // eslint-disable-next-line unicorn/no-null
        return null;
    };

    /**
     * Method to check the values
     * @param {any} values
     * @returns {*}
     */
    // eslint-disable-next-line max-lines-per-function, sonarjs/cognitive-complexity, consistent-return
    public operatorAttributeValidation(values) {
        // eslint-disable-next-line default-case
        switch (values.Criteria) {
            case CRITERIA_LIST.PRODUCT_TYPE: {
                return values.Operator !== "IN" && typeof values.Attributes === "string"
                    ? this.defaultData?.productTypes.find(
                          (product) => product?.prodtypecode.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                      )
                    : values?.Attributes;
            }
            case CRITERIA_LIST.FLAGS: {
                return values.Operator !== "IN" && typeof values.Attributes === "string"
                    ? this.defaultData?.flags?.find(
                          (flag) => flag?.flagcode.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                      )
                    : values?.Attributes;
            }
            case CRITERIA_LIST.CBW_FLAGS: {
                return values.Operator !== "IN" && typeof values.Attributes === "string"
                    ? this.defaultData?.cbwflags.find(
                          (flag) => flag?.flagcode.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                      )
                    : values?.Attributes;
            }
            case CRITERIA_LIST.PLANT:
            case CRITERIA_LIST.PRODUCT_ALLOC: {
                return values.Operator !== "IN" && typeof values.Attributes === "string"
                    ? this.defaultData?.costs.find(
                          (cost) => cost?.costbookcode.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                      )
                    : values?.Attributes;
            }
            case CRITERIA_LIST.FLAVOR_CLASS: {
                return values.Operator !== "IN" && typeof values.Attributes === "string"
                    ? this.defaultData?.flavorClasses.find(
                          (flavorClass) => flavorClass?.name.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                      )
                    : values?.Attributes;
            }
            case CRITERIA_LIST.FLAVOR_TYPE: {
                return values.Operator !== "IN" && typeof values.Attributes === "string"
                    ? this.defaultData?.flavorTypes.find(
                          (flavorType) => flavorType?.name.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                      )
                    : values?.Attributes;
            }
            case CRITERIA_LIST.BOM: {
                return BOM_CRITERIA_ATTRIBUTES.includes(this.spaceTrim.transform(values?.Attributes));
            }
            case CRITERIA_LIST.BOM_LOCKED: {
                return BOM_CRITERIA_ATTRIBUTES.includes(this.spaceTrim.transform(values?.Attributes));
            }
            case CRITERIA_LIST.SOLUTION: {
                return BOM_CRITERIA_ATTRIBUTES.includes(this.spaceTrim.transform(values?.Attributes));
            }
            case CRITERIA_LIST.DIVISION: {
                return values.Operator !== "IN" && typeof values.Attributes === "string"
                    ? DIVISION_CRITERIA_ATTRIBUTES.includes(this.spaceTrim.transform(values?.Attributes))
                    : values?.Attributes;
            }
            case CRITERIA_LIST.IPC_LIST: {
                return values?.Attributes?.length > 0;
            }
        }
    }

    /**
     * Method to validate form
     *
     * @param {FormGroup} form
     * @returns {ValidationErrors}
     * @memberof BaseIpcLayoutComponent
     */
    public auxillaryCriteriaValidation = (form: UntypedFormGroup): ValidationErrors => {
        const error = {};
        if (form.get(CRITERIA)?.value === this.CriteriaList.FLAGS || form.get(CRITERIA)?.value === this.CriteriaList.CBW_FLAGS) {
            if (!form.get(FORM_CONTROL_NAME.AUXILLARY_CRITERIA)?.value) {
                error[FORM_CONTROL_NAME.AUXILLARY_CRITERIA] = true;
            }
            if (!includes(FlagsOperator, form.get(FORM_CONTROL_NAME.OPERATOR)?.value)) {
                error[FORM_CONTROL_NAME.OPERATOR] = true;
            }
        }
        return isEmpty(error) ? undefined : error;
    };

    /**
     * Method to validate duplicate for BOM criteria
     * @param {string} value
     * @returns {boolean}
     * @memberof BaseIpcLayoutComponent
     */
    public disableNoColumn(value: string): boolean {
        const selectedInOperatorCriteria = this.ipcSelectionFormArray()
            .value.map((layout) => ({ Criteria: layout.Criteria, Operator: layout.Operator }))
            .find((column) => column.Criteria === value && column.Operator === "IN");
        if (selectedInOperatorCriteria) return true;
        const notDisableField = new Set(IPC_SELECTION_NOT_DISABLE);
        const selectedColumns = this.ipcSelectionFormArray()
            .value.map((layout) => layout.Criteria)
            .filter((column) => !notDisableField.has(column));
        return selectedColumns.includes(value);
    }

    /**
     * Method called on add ipc list
     * @param {boolean} event
     * @param {Array<string>} ipcListData
     * @returns {void}
     * @memberof BaseIpcLayoutComponent
     */
    public onAddIpcListClicked(event: boolean, ipcListData?: Array<string>): void {
        if (event) {
            this.savedIpcListData = ipcListData?.length > 0 ? ipcListData : [];
            this.openAddIpcDrawer = true;
            this.viewAddIpcList.toggle();
        } else {
            this.openAddIpcDrawer = false;
            this.viewAddIpcList.close();
        }
    }

    /**
     * Method called to handle IpcList Changes
     * @param {Array<string>} event
     * @returns {void}
     * @memberof BaseIpcLayoutComponent
     */
    public handleIpcListChanges(event): void {
        const ipcListFormIndex = this.ipcSelectionForm
            ?.get(IPC_SELECTION)
            .value.findIndex((controlData) => controlData.Criteria === this.CriteriaList.IPC_LIST);
        this.onIpcListSelection(event, this.CriteriaList.IPC_LIST, ipcListFormIndex);
    }

    /**
     * Method when autocomplete multiselection option check box is clicked
     *
     * @param {string} item
     * @param {string} criteria
     * @param {number} index
     * @memberof BaseIpcLayoutComponent
     */
    public onIpcListSelection(item: Array<string>, criteria: string, index: number): void {
        const attributeInControl = this.ipcSelectionForm.get(IPC_SELECTION)[CONTROLS].at(index);
        let attributeArray = attributeInControl.value.Attributes;
        attributeArray = item;
        attributeInControl.patchValue({ Attributes: attributeArray });
        attributeInControl.get("AttributesIN").reset();
        this.onChangeAttributes();
    }
}
