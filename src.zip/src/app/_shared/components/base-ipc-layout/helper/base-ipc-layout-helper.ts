/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable class-methods-use-this */
/** Angular Modules */
import { Injectable } from "@angular/core";

/* External Modules */
import { Observable } from "rxjs";
import { each, orderBy, partition } from "lodash";
import { FlagsOperator } from "@te-shared/enums";
import { SEQUENCE } from "@te-experiment/experiment.constant";
import { ProductSearchLayoutPayload } from "src/app/master-data/models/ipc-selection-model";
import { MasterDataHelper } from "../../../master-data/helpers/master-data.helper";
import { AppDataService } from "../../../../_services";
import { IpcCriteriaResponse } from "../models/ipc-selection.model";
import { MASTER_DATAS } from "../../../constants/common.constant";

@Injectable()
export class BaseIPCSelectionHelper {
    constructor(private readonly appDataService: AppDataService, private readonly masterDataHelper: MasterDataHelper) {}

    /**
     * Method to format the form data
     *
     * @param {*} formData
     * @returns {*}
     * @memberof BaseColumnHelper
     */
    public formatCriteriaFormData(formData: any): any {
        const ipcCriteria = [];
        each(formData, (criteria) => {
            const criteriaData = {
                Criteria: criteria.Criteria,
                AuxiliaryCriteria: criteria.Auxillary,
                Operator: criteria.Operator,
                Attributes: criteria.Value1,
                AttributesTo: criteria.Value2,
                Condition: criteria.Condition,
            };
            ipcCriteria.push(criteriaData);
        });
        return ipcCriteria;
    }

    /**
     * Method to get the all saved column layouts
     *
     * @returns {Observable<ColumnLayoutResponse>}
     * @memberof BaseColumnHelper
     */
    public getIpcCriteriaList(): Observable<IpcCriteriaResponse> {
        return this.appDataService.get(this.appDataService.url.getIpcCriteria, []);
    }

    /**
     * Method to get the default value
     *
     * @memberof IPCSelectitonHelper
     */
    public getDefaultData(): Observable<any> {
        return this.masterDataHelper.checkAndFetchDefaultData(MASTER_DATAS);
    }

    /**
     * Method to format form data to patch
     *
     * @param {any[]} formData
     * @returns any
     */
    public formatInOperatorFormData(formData: ProductSearchLayoutPayload[]): any {
        const ipcSelections = partition(
            formData.map((selection, index) => {
                selection.Sequence = index + 1;
                return selection;
            }),
            (criteria) => criteria.Operator === FlagsOperator.DEFAULT_IN_OPERATOR,
        );
        const groupINOperatorData = [
            ...ipcSelections[0]
                // eslint-disable-next-line unicorn/no-array-reduce
                .reduce((previousCriteria, nextCriteria) => {
                    // eslint-disable-next-line one-var
                    const key = nextCriteria.Criteria,
                        match = previousCriteria.get(key);
                    // eslint-disable-next-line no-unused-expressions
                    match
                        ? match.Attributes.push(nextCriteria.Attributes)
                        : previousCriteria.set(key, { ...nextCriteria, Attributes: [nextCriteria.Attributes] });
                    return previousCriteria;
                }, new Map())
                .values(),
        ];
        const result = orderBy([...ipcSelections[1], ...groupINOperatorData], [SEQUENCE], ["asc"]);
        return result.map(({ ...resultValue }) => ({ ...resultValue }));
    }
}
