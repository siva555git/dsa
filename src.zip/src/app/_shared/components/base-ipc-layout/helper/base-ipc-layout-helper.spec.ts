/* eslint-disable max-lines-per-function */
import { TestBed } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { MockAppDataService } from "../../../../testing/mock-app.data.service";
import { AppBroadCastService, AppDataService } from "../../../../_services";

import { MasterDataHelper } from "../../../master-data/helpers/master-data.helper";
import { BaseIPCSelectionHelper } from "./base-ipc-layout-helper";
import { MockMasterDataHelper } from "../../../../testing/mock-master-data-helper";

describe("BaseIPCSelectionHelper", () => {
    let service: BaseIPCSelectionHelper;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                AppBroadCastService,
                BaseIPCSelectionHelper,
                {
                    provide: MasterDataHelper,
                    useClass: MockMasterDataHelper,
                },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
            ],
        });
        service = TestBed.inject(BaseIPCSelectionHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call formatCriteriaFormData ", () => {
        spyOn(service, "formatCriteriaFormData").and.callThrough();
        const formdata = [
            {
                Criteria: "",
                AuxiliaryCriteria: "criteria.Auxillary",
                Operator: "criteria.Operator",
                Attributes: "criteria.Value1",
                AttributesTo: "criteria.Value2",
                Condition: "criteria.Condition",
            },
        ];
        service.formatCriteriaFormData(formdata);
        expect(service.formatCriteriaFormData).toHaveBeenCalled();
    });

    it("should call getIpcCriteriaList ", () => {
        spyOn(service, "getIpcCriteriaList").and.callThrough();
        service.getIpcCriteriaList();
        expect(service.getIpcCriteriaList).toHaveBeenCalled();
    });

    it("should call getDefaultData ", () => {
        spyOn(service, "getDefaultData").and.callThrough();
        service.getDefaultData();
        expect(service.getDefaultData).toHaveBeenCalled();
    });

    it("should call formatInOperatorFormData ", () => {
        const parameter = [
            {
                Sequence: 1,
                Criteria: "Bom",
                Auxillary: "Yes",
                Operator: "AND",
                Value1: "Value1",
                Value2: "Value2",
                Condition: "AND",
            },
        ];
        const spy = spyOn(service, "formatInOperatorFormData").and.callThrough();
        service.formatInOperatorFormData(parameter);
        expect(spy).toHaveBeenCalled();
    });
});
