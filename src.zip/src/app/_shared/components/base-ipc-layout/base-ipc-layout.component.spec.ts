/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import {
    UntypedFormArray,
    UntypedFormBuilder,
    UntypedFormControl,
    UntypedFormGroup,
    FormsModule,
    ReactiveFormsModule,
} from "@angular/forms";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { NGXLogger } from "ngx-logger";
import { of } from "rxjs";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChange } from "@angular/core";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { CRITERIA, DEFAULT_CRITERIA, FORM_CONTROL_NAME } from "./base-ipc-layout-constant";
import { BaseIpcLayoutComponent } from "./base-ipc-layout.component";
import { BaseIPCSelectionHelper } from "./helper/base-ipc-layout-helper";

describe("BaseIpcLayoutComponent", () => {
    let component: BaseIpcLayoutComponent;
    let fixture: ComponentFixture<BaseIpcLayoutComponent>;

    class MockBaseIPCSelection {
        getDefaultData = () => {
            return of([]);
        };

        getIpcCriteriaList = () => {
            return of([]);
        };

        formatInOperatorFormData = () => {
            return [
                {
                    Criteria: DEFAULT_CRITERIA,
                    AuxiliaryCriteria: "test",
                    Operator: "test",
                    Attributes: "test",
                    AttributesTo: "test",
                    Condition: "test",
                },
            ];
        };
    }

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [BaseIpcLayoutComponent],
            imports: [FormsModule, ReactiveFormsModule],
            providers: [
                AppStateService,
                AppBroadCastService,
                SecurityHelper,
                SpaceTrimPipe,
                { provide: BaseIPCSelectionHelper, useClass: MockBaseIPCSelection },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                UntypedFormBuilder,
                SecurityHelper
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BaseIpcLayoutComponent);
        component = fixture.componentInstance;
        const appStateService: AppStateService = TestBed.inject(AppStateService);
        spyOn(appStateService, "getCurrentUserSapEmpId").and.returnValue(true);
        const securityHelper: SecurityHelper = TestBed.inject(SecurityHelper);
        spyOn(securityHelper, "hasPermission").and.returnValue(true);
        component.ipcSelectionForm = new UntypedFormGroup({
            IpcSelection: new UntypedFormArray([]),
            Criteria: new UntypedFormControl(""),
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(component, "createipcSelectionForm").and.callThrough();
        spyOn(component, "defaultSetRows").and.returnValue();
        spyOn(component, "getIpcCriteriaList").and.returnValue();
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for producttype layoutForm() ", () => {
        const formControl = {
            value: [{ Criteria: "Product Type", Attributes: "ABSOLUTES" }],
        };
        component.defaultData = {
            productTypes: [
                {
                    prodtypecode: "ABSOLUTES",
                },
            ],
        };
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for flagcode layoutForm() ", () => {
        const formControl = {
            value: [{ Criteria: "Flags", Attributes: "00020358 BHT ROL-UP" }],
        };
        component.defaultData = {
            flags: [
                {
                    flagcode: "00020358 BHT ROL-UP",
                },
            ],
        };
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for plant layoutForm() ", () => {
        const formControl = {
            value: [{ Criteria: "Plant", Attributes: "FCFL" }],
        };
        component.defaultData = {
            costs: [
                {
                    costbookcode: "FCFL",
                },
            ],
        };
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for flavorclass layoutForm() ", () => {
        const formControl = {
            value: [{ Criteria: "Flavor Class", Attributes: "Alcohol" }],
        };
        component.defaultData = {
            flavorClasses: [
                {
                    name: "Alcohol",
                },
            ],
        };
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for flavortypes layoutForm() ", () => {
        const formControl = {
            value: [{ Criteria: "Flavor Type", Attributes: "Alcohol" }],
        };
        component.defaultData = {
            flavorTypes: [
                {
                    name: "Alcohol",
                },
            ],
        };
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should return FLAG error when form has invalid auxillary criteria value", () => {
        component.ipcSelectionForm.patchValue({
            [CRITERIA]: "Flags",
            [FORM_CONTROL_NAME.AUXILLARY_CRITERIA]: "abc",
        });
        const error = component.auxillaryCriteriaValidation(component.ipcSelectionForm);
        expect(error).toEqual(jasmine.objectContaining({ [FORM_CONTROL_NAME.AUXILLARY_CRITERIA]: true }));
    });

    it("should resolve for ngOnInit()", () => {
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnChanges", () => {
        component.userIpcSelectionFormData = [
            {
                SearchName: "test search",
                IsPrivate: "test",
                Criteria: {
                    Criteria: DEFAULT_CRITERIA,
                    AuxiliaryCriteria: "test",
                    Operator: "test",
                    Attributes: "test",
                    AttributesTo: "test",
                    Condition: "test",
                },
                ProductSearchLayout: [],
                isUpdateLayouts: false,
            },
        ];
        component.ngOnChanges({
            userIpcSelectionFormData: new SimpleChange(component.userIpcSelectionFormData, component.userIpcSelectionFormData, true),
        });
        expect(component.ipcSelectionForm.get("Columns").value[0].Criteria.Criteria).toBeUndefined();
    });

    it("should call on addNewCriteria", () => {
        const spy = spyOn(component, "addNewCriteria").and.callThrough();
        component.addNewCriteria();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onCloneCriteria", () => {
        component.ipcSelectionFormArray().push(component.ipcSelectionFormGroup());
        component.onCloneCriteria(0);
        expect(component.ipcSelectionFormArray().value.length).toEqual(2);
    });

    it("should call on deleteCriteria", () => {
        component.ipcSelectionFormArray().push(component.ipcSelectionFormGroup());
        component.onCloneCriteria(0);
        component.deleteCriteria(1);
        expect(component.ipcSelectionFormArray().value.length).toEqual(1);
    });

    it("should call on onSelectionCriteria", () => {
        const spy = spyOn(component, "onSelectionCriteria").and.callThrough();
        component.ipcSelectionFormArray().push(component.ipcSelectionFormGroup());
        component.onSelectionCriteria(0);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onChangeAttributes", () => {
        const spy = spyOn(component, "onChangeAttributes").and.callThrough();
        component.onChangeAttributes();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on loadAttributes and bindAttributesControl", () => {
        component.ipcSelectionFormArray().push(component.ipcSelectionFormGroup());
        component.loadAttributes(0);
        expect(component.filteredAttributes.length).toEqual(1);
    });

    it("should call on bindIpcSelectionFormData", () => {
        component.userIpcSelectionFormData = [
            {
                SearchName: "test search",
                IsPrivate: "test",
                Criteria: {
                    Criteria: DEFAULT_CRITERIA,
                    AuxiliaryCriteria: "test",
                    Operator: "test",
                    Attributes: "test",
                    AttributesTo: "test",
                    Condition: "test",
                },
                ProductSearchLayout: [],
                isUpdateLayouts: false,
            },
        ];
        component.bindIpcSelectionFormData(component.userIpcSelectionFormData);
        expect(component.ipcSelectionForm.get("Columns").value[0].Criteria.Criteria).toBeUndefined();
    });
});
