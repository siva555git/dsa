/* eslint-disable id-length */

import { FlagsOperator } from "@te-shared/enums/ipc-selection.enum";

const PRODUCT_TYPE = "Product Type";
const FLAVOR_CLASS = "Flavor Class";
const FLAVOR_TYPE = "Flavor Type";
const PRODUCT_ALLOC = "Product Allocation";

/* eslint-disable max-lines */
export const CRITERIA_LIST = {
    IPC: "IPC",
    IPC_DESC: "IPC Description",
    PRODUCT_TYPE,
    COST: "Cost",
    FLAGS: "Flags",
    CBW_FLAGS: "CBW Flags",
    SPEC: "Spec",
    PLANT: "Plant",
    FLAVOR_CLASS,
    FLAVOR_TYPE,
    PRODUCT_ALLOC,
    BOM: "BOM",
    BOM_LOCKED: "BOM Locked",
    SOLUTION: "Solution",
    DIVISION: "Division",
    TECHNOLOGY: "Technology",
    IPC_LIST: "IPC List",
};

export const DEFAULT_OPERATOR = "EQUAL TO";

export const DEFAULT_NOT_OPERATOR = "NOT EQUAL TO";

export const DEFAULT_AUXILLARY_CRITERIA = "ALL";

export const BETWEEN_OPERATOR = "BETWEEN";

export const STAR_VALUE = "*";

export const DEFAULT_LOGICAL_OPERATOR = "AND";

export const ROW_DELETE_ERROR_TIME = 5000;

export const MANDATORY_ATTRIBUTES_CRITERIA = [
    PRODUCT_TYPE,
    "Technology",
    "Flags",
    "CBW Flags",
    "Plant",
    FLAVOR_CLASS,
    FLAVOR_TYPE,
    PRODUCT_ALLOC,
    "BOM",
    "BOM Locked",
    "Division",
    "IPC List",
];

export const NOT_MANDATORY_ATTRIBUTES_CRITERIA = ["IPC", "IPC_DESC", "SPEC"];

export const DEFAULT_CRITERIA = "Flags";

export const DEFAULT_FLAGS_LIST = ["NO NEW USE"];

export const IPC_NUMRIC_LIMITS = {
    NUMBER_LIMIT: 20,
};

export const OPERATOR_LIST = {
    AND: "AND",
    // eslint-disable-next-line id-length
    OR: "OR",
};

export const OPERATOR_DETAIL = {
    IPC: {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "multipleipcs",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "tasteipc",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "NOT EQUAL TO": "notequalto",
            "BEGINS WITH": "startswith",
            "DOES NOT BEGINS WITH": "doesnotstartswith",
            CONTAINS: "contains",
            "DOES NOT CONTAINS": "doesnotcontains",
            IN: "equalsto",
        },
    },
    "IPC Description": {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "description",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "byfields",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "NOT EQUAL TO": "notequalto",
            "BEGINS WITH": "startswith",
            CONTAINS: "contains",
            "DOES NOT CONTAINS": "doesnotcontains",
        },
    },
    "Product Type": {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "tasteprodtype",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "tasteprodtypeOR",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "NOT EQUAL TO": "notequalto",
            IN: "equalsto",
        },
    },
    Flags: {
        AND: {
            AND_ES_KEY: "filter",
            TITLE: "flagswithinheritedmustnot",
            "HAS TITLE": "flagswithinheritedmust",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "flags",
        },
        OPERATOR: {
            HAS: "has",
            "DOES NOT HAVE": "doesnothave",
            IN: "has",
        },
    },
    "CBW Flags": {
        AND: {
            AND_ES_KEY: "filter",
            TITLE: "flagswithinheritedmustnot",
            "HAS TITLE": "flagswithinheritedmust",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "flagswithinheritedin",
        },
        OPERATOR: {
            HAS: "has",
            "DOES NOT HAVE": "doesnothave",
        },
    },
    Spec: {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "specand",
            RANGE_TITLE: "range",
            SPEC_IN: "specs",
            SPEC_NOT_IN: "speccodesnotin",
            SPEC_RANGE: "speccoderange",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "specOR",
            RANGE_TITLE: "range",
            SPEC_IN: "specs",
            SPEC_NOT_IN: "speccodesnotin",
            SPEC_RANGE: "speccoderange",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "BEGINS WITH": "startswith",
            CONTAINS: "contains",
            IN: "in",
        },
    },
    Cost: {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "costbookmnc",
            "EQUAL TO TITLE": "mncequals",
            SUB_TITLE: "mnc",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "costbooks",
            "EQUAL TO TITLE": "mncequalsOR",
            SUB_TITLE: "mnc",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            BETWEEN: "between",
        },
    },
    Plant: {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "plantcode",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "plantcodeOR",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "NOT EQUAL TO": "notequalto",
            IN: "equalsto",
        },
    },
    "Flavor Class": {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "flavorclass",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "flavorclassOR",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "NOT EQUAL TO": "notequalto",
            IN: "equalsto",
        },
    },
    "Flavor Type": {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "flavortype",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "flavortypeOR",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "NOT EQUAL TO": "notequalto",
            IN: "equalsto",
        },
    },
    "Product Allocation": {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "prodallocationcode",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "prodallocationcodeOR",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "NOT EQUAL TO": "notequalto",
            IN: "equalsto",
        },
    },
    BOM: {
        AND: {
            AND_ES_KEY: "filter",
            TITLE: "isbom",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "isbom",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
        },
    },
    "BOM Locked": {
        AND: {
            AND_ES_KEY: "filter",
            TITLE: "isbomlocked",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "isbomlocked",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
        },
    },
    Solution: {
        AND: {
            AND_ES_KEY: "filter",
            TITLE: "issolution",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "issolution",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
        },
    },
    Division: {
        AND: {
            AND_ES_KEY: "filter",
            TITLE: "divisions",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "divisions",
        },
        OPERATOR: {
            "EQUAL TO": "equalsto",
            "NOT EQUAL TO": "notequalto",
            IN: "contains",
        },
    },
    "IPC List": {
        AND: {
            AND_ES_KEY: "query",
            TITLE: "multipleipcs",
        },
        OR: {
            OR_ES_KEY: "filter",
            TITLE: "ipcs",
        },
        OPERATOR: {
            IN: "equalsto",
        },
    },
};

export const IPC_SELECTION = "IpcSelection";

export const SEARCH_NAME = "SearchName";
export const LAYOUT_NAME = "LayoutName";
export const IPC_PUBLIC_FLAG = "0";

export const FORM_INVALID = "INVALID";

export const FORM_CONTROL_NAME = {
    AUXILLARY_CRITERIA: "AuxiliaryCriteria",
    ATTRIBUTES: "Attributes",
    OPERATOR: "Operator",
};

export const DISPLAY_VALUE_KEYS = ["prodtypecode", "name", "costbookcode", "speccode", "flagcode"];

export const VALUE = "value";

export const INHERITED_ONLY = "INHERITED ONLY";

export const NON_INHERITED_ONLY = "NON INHERITED ONLY";

export const DEFAULT_FLAGS_OPERATOR = [FlagsOperator.DEFAULT_HAS_OPERATOR, FlagsOperator.DEFAULT_DOES_NOT_HAVE_OPERATOR];

export const CRITERIA = "Criteria";

export const BOM_CRITERIA_ATTRIBUTES = ["Yes", "No"];

export const DIVISION_CRITERIA_ATTRIBUTES = ["FLAV", "FRAG"];

export const DEFAULT_BOM_CRITERIA_ATTRIBUTE = "Yes";

export const IPC_SELECTION_NOT_DISABLE = [
    "IPC",
    "IPC Description",
    PRODUCT_TYPE,
    "Cost",
    "Flags",
    "CBW Flags",
    "Spec",
    "Plant",
    FLAVOR_CLASS,
    FLAVOR_TYPE,
    PRODUCT_ALLOC,
    "Division",
    "Technology",
];

export const IPC_SELECTION_WITH_IN_CLAUSE = [
    { criteria: PRODUCT_TYPE, attributes: [] },
    { criteria: "Flags", attributes: [] },
    { criteria: "Plant", attributes: [] },
    { criteria: FLAVOR_CLASS, attributes: [] },
    { criteria: FLAVOR_TYPE, attributes: [] },
    { criteria: PRODUCT_ALLOC, attributes: [] },
    { criteria: "Division", attributes: [] },
];

export const IPC_INVALID = "Invalid";

export const RESULTS = "_results";

export const ADD_IPC_COLUMN_LIST = ["IPC", "Description", "ProductType", "Remove"];
