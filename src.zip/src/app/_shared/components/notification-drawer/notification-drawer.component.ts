/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-lines-per-function */
import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    Output,
    SimpleChanges,
    OnInit,
    ElementRef,
    ViewChildren,
    QueryList,
    HostListener,
} from "@angular/core";
import { MatCheckboxChange } from "@angular/material/checkbox";
import { cloneDeep, forEach, delay } from "lodash";
import { MatDialog } from "@angular/material/dialog";
import {
    DATE_RANGE_DROPDOWN,
    ITEMLIST_TYPE,
    NOTIFICATIONS_TYPE,
    NOTIFICATION_DELETE_MESSAGE,
    COLUMN_LAYOUT_HIGH_LIGHT_TIME,
    COMMON_DIALOG_OLD,
} from "../../constants/common.constant";
import { NOTIF_EVENT_TYPE } from "../../constants/notification.constant";
import { CustomCheckboxListHelper } from "../../helpers/custom-checkbox-list-helper";
// eslint-disable-next-line import/named
import { NotificationFilterModel, NotificationResponse, NotificationResultModel } from "../../models/notification.model";
import { ConfirmationDialogComponent } from "../confirmation-dialog/confirmation-dialog.component";
import { NotificationHelper } from "./helper/notification-helper";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";

@Component({
    selector: "app-notification-drawer",
    templateUrl: "./notification-drawer.component.html",
})
export class NotificationDrawerComponent implements OnChanges, OnInit {
    public datesRangeDropDown = DATE_RANGE_DROPDOWN;

    public dateRangByDefault = DATE_RANGE_DROPDOWN[2].OneWeek;

    public searchFilterDuration = DATE_RANGE_DROPDOWN[2].displayValue;

    public notificationResult: NotificationResultModel[];

    public notificationResultList: NotificationResultModel[];

    public selectedCheckList = [];

    public notificationType = cloneDeep(NOTIFICATIONS_TYPE);

    public searchValue: string;

    public showLoading = false;

    public highLightUnreadNotifications = false;

    public currentDateRange: string;

    public notificationTypes = NOTIF_EVENT_TYPE;

    @Input()
    public notificationList: NotificationResponse;

    @Output()
    public notificationToggle = new EventEmitter();

    public masterCheckBox = false;

    public lastSelected = 0;

    @HostListener("document:keydown.escape", ["$event"]) onKeydownHandler(): void {
        this.onCancelDrawer();
    }

    @ViewChildren("keywordsInput") keywordsInput: QueryList<ElementRef>;

    constructor(
        private readonly notificationHelper: NotificationHelper,
        public dialog: MatDialog,
        public customCheckboxListHelper: CustomCheckboxListHelper,
        private readonly appBroadCastService: AppBroadCastService,
    ) {
        this.customCheckboxListHelper.itemlistType = ITEMLIST_TYPE.ARRAY_OF_ARRAYS;
    }

    public ngOnInit(): void {
        this.listenSubscriptions();
    }

    /**
     * Method to listen events
     *
     * @memberof NotificationDrawerComponent
     */
    public listenSubscriptions(): void {
        this.appBroadCastService.pushNotificationSubject.subscribe(() => {
            this.notificationHelper.viewAllNotifications(this.currentDateRange ?? DATE_RANGE_DROPDOWN[2].OneWeek);
        });
    }

    public ngOnChanges(changes: SimpleChanges): void {
        this.notificationResult = [];
        if (!this.showLoading) {
            this.dateRangByDefault = this.currentDateRange ?? DATE_RANGE_DROPDOWN[2].OneWeek;
        }
        this.showLoading = false;
        if (changes.notificationList.currentValue && changes.notificationList.currentValue.length > 0) {
            const selectedCheckBox = this.getSelectedFilter();
            this.highlightUnreadNotification();
            this.notificationResultList = cloneDeep(changes.notificationList.currentValue);
            if (selectedCheckBox.length === 0) {
                this.notificationResult = [];
            } else {
                this.applyCheckBoxFilter();
            }
        }
    }

    public ngAfterViewInit(): void {
        this.keywordsInput.changes.subscribe((result) => {
            delay(() => {
                // eslint-disable-next-line no-underscore-dangle
                const items = result._results;
                items.forEach((element) => {
                    const getExpId = element.nativeElement?.querySelector("a")?.innerText;
                    // eslint-disable-next-line no-unused-expressions
                    element.nativeElement?.querySelector("a")?.addEventListener("click", () => this.notificationExpOpen(getExpId));
                });
            }, 300);
        });
    }

    /**
     * Method to open experiment from notification
     * @memberof NotificationDrawerComponent
     */
    public notificationExpOpen(expCode: string): void {
        this.appBroadCastService.onSharedExperimentNotify({
            experimentCode: expCode,
        });
        this.onCancelDrawer();
    }

    /**
     * Method to close notification drawer
     * @returns {void}
     * @memberof NotificationDrawerComponent
     */
    public onCancelDrawer(): void {
        this.notificationToggle.emit();
    }

    /**
     * Method to get date value from drop down
     * @param {stirng} event
     * @returns {void}
     * @memberof NotificationDrawerComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types, consistent-return
    public onChangeDateRange(event: any): void {
        this.currentDateRange = event.value;
        this.searchFilterDuration = this.datesRangeDropDown.find((date) => date.value === event.value).displayValue;
        this.resetList();
        this.notificationResult = [];
        this.showLoading = true;
        this.notificationHelper.viewAllNotifications(event.value);
    }

    /**
     * Method to hightlight unread notification
     * @returns {void}
     * @memberof NotificationDrawerComponent
     */
    public highlightUnreadNotification(): void {
        this.highLightUnreadNotifications = true;
        delay(() => {
            this.highLightUnreadNotifications = false;
        }, COLUMN_LAYOUT_HIGH_LIGHT_TIME);
    }

    /**
     * Method to filter the notification
     *
     * @param {MatCheckboxChange} event
     * @param {NotificationFilterModel} notification
     * @memberof NotificationDrawerComponent
     */
    public onFilterNotification(event: MatCheckboxChange, notification: NotificationFilterModel): void {
        this.resetList();
        forEach(this.notificationType, (list) => {
            if (list.name === notification.name) {
                // eslint-disable-next-line no-param-reassign
                list.checked = event.checked;
            }
        });
        this.applyCheckBoxFilter();
    }

    /**
     * Method to reset
     * @memberof NotificationDrawerComponent
     */
    public resetList(): void {
        this.onMasterCheckboxChange({ checked: false });
    }

    /**
     * Method to get the notification ids to delete
     * @memberof NotificationDrawerComponent
     */
    public onDeleteNotification(): void {
        const notificationIDs = this.selectedCheckList.map((notification) => notification.NotificationID);
        this.openConfirmationDialog(this.deleteNotification.bind(this), NOTIFICATION_DELETE_MESSAGE, notificationIDs);
    }

    /**
     * Method to delete the notification after we got yes from the popup
     * @param notificationIDs
     * @memberof NotificationDrawerComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public deleteNotification(notificationIDs?): void {
        if (notificationIDs) {
            this.selectedCheckList = [];
            this.notificationHelper.deleteNotifications(notificationIDs, this.dateRangByDefault);
        }
    }

    /**
     *
     * Method to show the alert popup to delete the notification
     * @param {*} callBack
     * @param {*} dialogMessage
     * @param {Array<number>} [notificationIDs]
     * @memberof NotificationDrawerComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public openConfirmationDialog(callBack: any, dialogMessage: any, notificationIDs?: Array<number>): void {
        const dialogOptions = COMMON_DIALOG_OLD;
        dialogOptions.data = dialogMessage;
        const dialogReference = this.dialog.open(ConfirmationDialogComponent, dialogOptions);
        dialogReference.afterClosed().subscribe((dialogResult) => {
            if (dialogResult) callBack(notificationIDs);
            else callBack();
        });
    }

    /**
     * Method for master checkbox change event
     * @param event
     * @memberof NotificationDrawerComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public onMasterCheckboxChange($event: any): void {
        const responseData = this.customCheckboxListHelper.masterCheckboxChange($event, this.notificationResult, this.masterCheckBox);
        this.selectedCheckList = responseData.selectedCheckList;
        this.masterCheckBox = responseData.masterCheckBox;
    }

    /**
     *
     * Method to handle the chechbox click event
     * @param event
     * @param index
     * @memberof NotificationDrawerComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public onCheckboxClicked(event: any, outerLoopIndex: number, innerLoopIndex: number): any {
        const index = this.notificationHelper.findIndexFromList(outerLoopIndex, innerLoopIndex, this.notificationResult);
        this.lastSelected = index;
    }

    /**
     * Method to handle the checkbox change event
     * @memberof NotificationDrawerComponent
     */
    public onCheckboxChanged(): void {
        const responseData = this.customCheckboxListHelper.onCheckBoxChange(this.selectedCheckList, this.notificationResult);
        this.selectedCheckList = responseData.selectedCheckList;
        this.masterCheckBox = responseData.masterCheckBox;
    }

    /**
     * Method to apply checkbox filter on notificationResultList.
     * @returns {void}
     * @memberof NotificationDrawerComponent
     */
    private applyCheckBoxFilter(): void {
        const selectedFilter = this.getSelectedFilter();
        this.notificationResult = this.notificationHelper.filterNotificationOnType(selectedFilter, this.notificationResultList);
    }

    /**
     * Method to collected checked filter from notificationType array
     * @returns {NotificationFilterModel[]}
     * @memberof NotificationDrawerComponent
     */
    private getSelectedFilter(): NotificationFilterModel[] {
        return this.notificationType.filter((notification) => notification.checked);
    }
}
