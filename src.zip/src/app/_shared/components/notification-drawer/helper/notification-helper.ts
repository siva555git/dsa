/* eslint-disable class-methods-use-this */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from "@angular/core";
import { NGXLogger } from "ngx-logger";
import * as moment from "moment";
import { filter, findIndex, flattenDeep, groupBy, forEach, orderBy, uniq } from "lodash";
import { ToastrService } from "ngx-toastr";
import { DELETE_NOTIFICATION, EMPTY } from "../../../../app.constant";
import { NOTIFICATION_ERROR } from "../../../constants/notification.constant";
import {
    DeleteNotificationPayload,
    GetNotificationPayload,
    NotificationFilterModel,
    NotificationPayload,
    NotificationResultModel,
} from "../../../models/notification.model";
import { AppBroadCastService } from "../../../../_services/app-broadcast/app.broadcast.service";
import { AppDataService } from "../../../../_services/app-data/app.data.service";
import { DATE_RANGE_DROPDOWN, NOTIFICATION_DATE_FORMAT } from "../../../constants/common.constant";

@Injectable()
export class NotificationHelper {
    public notificationCount = 0;

    constructor(
        private readonly appDataService: AppDataService,
        private readonly logger: NGXLogger,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly toastrService: ToastrService,
    ) {}

    public notificationPayload(userIdList: number[], notificationmessage): NotificationPayload[] {
        const notifications = [];
        userIdList.forEach((user) => {
            const notification = {
                Subject: notificationmessage.Subject,
                Body: notificationmessage.Body,
                ExpCode: notificationmessage.ExpCode,
                UserName: notificationmessage.UserName,
                CreatedTo: user,
                NotificationTypeID: notificationmessage.TypeID,
                NotificationEventID: notificationmessage.EventID,
                IsPushMessage: notificationmessage.IsPush,
                UserSettingCode: notificationmessage.UserSettingCode,
            };
            notifications.push(notification);
        });
        return notifications;
    }

    /**
     * Method to get all notifications from api
     * @returns {void}
     * @memberof NotificationHelper
     */
    public viewAllNotifications(selectedDateValue: string): void {
        const notificationPoayload: GetNotificationPayload = { dateRange: selectedDateValue };
        this.appDataService.post(`${this.appDataService.url.notificationsList}`, [], notificationPoayload).subscribe({
            next: (result) => {
                if (result) {
                    const response = result;
                    response.notifications = this.groupNotificationBasedOnDate(result.notifications);
                    this.appBroadCastService.getAllNotifications(response);
                }
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to find the index of the list
     * @param outerLoopIndex
     * @param innerLoopIndex
     * @param list
     * @memberof NotificationHelper
     */
    public findIndexFromList(outerLoopIndex: number, innerLoopIndex: number, list: NotificationResultModel[]): number {
        let itemlist = list.slice(0, outerLoopIndex);
        if (itemlist.length > 0) {
            itemlist = flattenDeep(itemlist);
            return itemlist.length + innerLoopIndex;
        }

        return innerLoopIndex;
    }

    /**
     * Method to delete the notification
     * @param notificationIDs
     * @param value
     * @memberof NotificationHelper
     */
    public deleteNotifications(notificationIDs: Array<any>, value: string): void {
        const payload: DeleteNotificationPayload = {
            notifIds: notificationIDs,
        };
        this.appBroadCastService.onUpdateAppSpinnerPrompt(DELETE_NOTIFICATION);
        this.appDataService.post(`${this.appDataService.url.deleteNotifications}`, [], payload).subscribe({
            next: (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);

                if (result) {
                    this.toastrService.success(NOTIFICATION_ERROR.DELETE_NOTIFICATION_SUCCESS);
                    this.viewAllNotifications(value);
                }
            },
            error: (error) => {
                this.logger.error(error);
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.toastrService.error(NOTIFICATION_ERROR.DELETE_NOTIFICATION_ERROR);
            },
        });
    }

    /**
     * Method to update all notifications as read
     * @returns {void}
     * @memberof NotificationHelper
     */
    public updateNotifications(): void {
        this.appDataService.get(`${this.appDataService.url.updateNotifications}`, []).subscribe({
            // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
            next: () => {},
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to group notifications list data based on date
     * @param notificationDataList
     * @memberof NotificationHelper
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public groupNotificationBasedOnDate(notificationDataList: NotificationResultModel[]): any {
        const todayDate = moment();
        notificationDataList.forEach((notificationData: any) => {
            const notification = notificationData;
            const daysCount = todayDate.diff(moment(new Date(notification.CreatedOn)).startOf("day"), "day");
            if (daysCount > 1) {
                notification.CreatedOnCategory = moment(new Date(notification.CreatedOn)).format(NOTIFICATION_DATE_FORMAT.DATE_FORMAT);
            } else {
                notification.CreatedOnCategory =
                    daysCount === 0 ? DATE_RANGE_DROPDOWN[0].displayValue : DATE_RANGE_DROPDOWN[1].displayValue;
            }
            notification.IsChecked = false;
        });
        const responseData = groupBy(notificationDataList, "CreatedOnCategory");
        const orderByCreatedOnCategory = orderBy(responseData, "CreatedOnCategory");
        return orderByCreatedOnCategory;
    }

    /**
     * Method to filter the notification on type
     *
     * @returns {NotificationResponse}
     * @memberof NotificationHelper
     */
    public filterNotificationOnType(selectedFilter: NotificationFilterModel[], notificationResultList: NotificationResultModel[]): any {
        if (findIndex(selectedFilter, ["name", "All"]) >= 0) {
            return notificationResultList;
        }
        const flattenList = flattenDeep(notificationResultList);
        const filteredItem = [];
        if (selectedFilter?.length <= 3) {
            forEach(selectedFilter, (select: NotificationFilterModel) => {
                const filteredData = filter(flattenList, (itemList) => {
                    return itemList.ReferenceNotificationType.Description === select.name;
                });
                filteredItem.push(...filteredData);
            });
        }
        return this.groupNotificationBasedOnDate(uniq(filteredItem));
    }
}
