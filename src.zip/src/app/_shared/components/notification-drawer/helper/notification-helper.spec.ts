/* eslint-disable max-lines-per-function */
import { TestBed } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { of, throwError } from "rxjs";
import {
    NotificationEventModel,
    NotificationFilterModel,
    NotificationResultModel,
    NotificationTypeModel,
} from "../../../models/notification.model";
import { MockToastrService } from "../../../../testing/mock-toastr.service";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { MockAppDataService } from "../../../../testing/mock-app.data.service";
import { AppBroadCastService, AppDataService, AppStateService } from "../../../../_services";
import { NotificationHelper } from "./notification-helper";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";

describe("NotificationHelper", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            providers: [
                NotificationHelper,
                AppBroadCastService,
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
            ],
        }),
    );

    it("should create", () => {
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        expect(service).toBeTruthy();
    });

    it("should call CooperatorNotifications ", () => {
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "notificationPayload").and.callThrough();
        service.notificationPayload([30_979], {
            Subject: "Share Experiment",
            Body: `experiment shared`,
            ExpCode: `RXP00033AA`,
            UserName: `Ranjithkumar Premanandkumar`,
            TypeID: `Information`,
            EventID: `1`,
            IsPush: `false`,
        });
        expect(service.notificationPayload).toHaveBeenCalled();
    });

    it("should call updateNotifications if throw error", () => {
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(appDataService, "get").and.returnValue(throwError(() => {}));
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "updateNotifications").and.callThrough();
        service.updateNotifications();
        expect(service.updateNotifications).toHaveBeenCalled();
    });

    it("should call filterNotificationOnType ", () => {
        const data: NotificationFilterModel[] = [
            {
                checked: true,
                class: "information",
                name: "Information",
            },
        ];

        const dataReferenceEvent: NotificationEventModel = { NotificationEventID: 1, Description: "Shared Experiment", IsActive: true };
        const dataType: NotificationTypeModel = { NotificationTypeID: 1, Description: "Information", IsActive: true };

        const details: NotificationResultModel[] = [
            {
                NotificationID: "41",
                Subject: "Share Experiment",
                Body: "<b>Aravinth Sankar Balasubramanian</b> has shared <b>AXB00083AA</b> experiment",
                NotificationTypeID: 1,
                NotificationEventID: 1,
                CreatedTo: "47333",
                IsRead: true,
                CreatedBy: "33323",
                IsPushMessage: false,
                CreatedOn: new Date(),
                ReferenceNotificationEvent: dataReferenceEvent,
                ReferenceNotificationType: dataType,
            },
        ];

        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "filterNotificationOnType").and.callThrough();
        service.filterNotificationOnType(data, details);
        expect(service.filterNotificationOnType).toHaveBeenCalled();
    });

    it("should call viewAllNotifications if return response", () => {
        const appBroadCastService: AppBroadCastService = TestBed.inject(AppBroadCastService);
        spyOn(appBroadCastService, "getAllNotifications");
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        spyOn(appDataService, "post").and.returnValue(of([]));
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "groupNotificationBasedOnDate");
        spyOn(service, "viewAllNotifications").and.callThrough();
        service.viewAllNotifications("Test");
        expect(service.viewAllNotifications).toHaveBeenCalled();
    });

    it("should call viewAllNotifications if throw error", () => {
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(appDataService, "post").and.returnValue(throwError(() => {}));
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "viewAllNotifications").and.callThrough();
        service.viewAllNotifications("Test");
        expect(service.viewAllNotifications).toHaveBeenCalled();
    });

    it("should call updateNotifications if return response", () => {
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        spyOn(appDataService, "get").and.returnValue(of([]));
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "updateNotifications").and.callThrough();
        service.updateNotifications();
        expect(service.updateNotifications).toHaveBeenCalled();
    });

    it("should call deleteNotifications when return response", () => {
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        spyOn(appDataService, "post").and.returnValue(of([]));
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "viewAllNotifications");
        spyOn(service, "deleteNotifications").and.callThrough();
        service.deleteNotifications([123], "Test");
        expect(service.deleteNotifications).toHaveBeenCalled();
    });

    it("should call deleteNotifications when throw error", () => {
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(appDataService, "post").and.returnValue(throwError(() => {}));
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "deleteNotifications").and.callThrough();
        service.deleteNotifications([123], "Test");
        expect(service.deleteNotifications).toHaveBeenCalled();
    });

    it("should call findIndexFromList", () => {
        const service: NotificationHelper = TestBed.inject(NotificationHelper);
        spyOn(service, "findIndexFromList").and.callThrough();
        service.findIndexFromList(1234, 5678, []);
        expect(service.findIndexFromList).toHaveBeenCalled();
    });
});
