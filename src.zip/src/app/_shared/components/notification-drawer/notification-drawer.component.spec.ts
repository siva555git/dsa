/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialog } from "@angular/material/dialog";
import { of } from "rxjs";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChange } from "@angular/core";
import { MatCheckboxChange, MatCheckboxModule } from "@angular/material/checkbox";
import { MockNotificationHelper } from "../../../testing/mock-notification.helper";
import { ITEMLIST_TYPE } from "../../constants/common.constant";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { CustomCheckboxListHelper } from "../../helpers/custom-checkbox-list-helper";
import { NotificationHelper } from "./helper/notification-helper";

import { NotificationDrawerComponent } from "./notification-drawer.component";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatSelectModule } from "@angular/material/select";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

describe("NotificationDrawerComponent", () => {
    let component: NotificationDrawerComponent;
    let fixture: ComponentFixture<NotificationDrawerComponent>;
    let selectedFilter;

    const dialogReferenceStub = {
        afterClosed() {
            return of("result"); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    const dialogStub = { open: () => dialogReferenceStub };
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [NotificationDrawerComponent],
            providers: [
                { provide: NotificationHelper, useClass: MockNotificationHelper },
                {
                    provide: MatDialog,
                    useValue: dialogStub,
                },
                CustomCheckboxListHelper,
                AppBroadCastService,
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                MatFormFieldModule,
                MatInputModule,
                MatSelectModule,
                MatCheckboxModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NotificationDrawerComponent);
        component = fixture.componentInstance;
        selectedFilter = spyOn<any>(component, "getSelectedFilter");
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call onCancelDrawer", () => {
        const spy = spyOn(component, "onCancelDrawer").and.callThrough();
        component.onCancelDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should call onChangeDateRange", () => {
        const event = {
            value: "today",
        };
        component.customCheckboxListHelper.itemlistType = ITEMLIST_TYPE.ARRAY_OF_OBJECTS;
        component.notificationResult = [
            {
                NotificationID: "41",
                Subject: "Share Experiment",
                Body: "<b>Aravinth Sankar Balasubramanian</b> has shared <b>AXB00083AA</b> experiment",
                NotificationTypeID: 1,
                NotificationEventID: 1,
                CreatedTo: "47333",
                IsRead: true,
                CreatedBy: "33323",
                IsPushMessage: false,
                CreatedOn: new Date(),
                ReferenceNotificationEvent: { NotificationEventID: 1, Description: "Shared Experiment", IsActive: true },
                ReferenceNotificationType: { NotificationTypeID: 1, Description: "Information", IsActive: true },
            },
        ];
        const spy = spyOn(component, "onChangeDateRange").and.callThrough();
        component.onChangeDateRange(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onKeydownHandler", () => {
        const spy = spyOn(component, "onKeydownHandler").and.callThrough();
        component.onKeydownHandler();
        expect(spy).toHaveBeenCalled();
    });

    it("should call onCheckboxClicked", () => {
        const service: CustomCheckboxListHelper = TestBed.inject(CustomCheckboxListHelper);
        spyOn(service, "clickHandler").and.returnValue();
        const spy = spyOn(component, "onCheckboxClicked").and.callThrough();
        component.onCheckboxClicked({}, 2, 3);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onCheckboxChanged", () => {
        const spy = spyOn(component, "onCheckboxChanged").and.callThrough();
        component.onCheckboxChanged();
        expect(spy).toHaveBeenCalled();
    });

    it("should call applyCheckBoxFilter", () => {
        const spy = spyOn<any>(component, "applyCheckBoxFilter").and.callThrough();
        component["applyCheckBoxFilter"]();
        expect(spy).toHaveBeenCalled();
    });

    it("should call getSelectedFilter", () => {
        const spy = selectedFilter.and.callThrough();
        component["getSelectedFilter"]();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnChanges ", () => {
        selectedFilter.and.returnValue([]);
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const valueChanges: any = {
            notificationList: {
                currentValue: [
                    {
                        unReadCount: 1,
                        notifications: [{ Subject: "Note", Body: "body" }],
                    },
                ],
            },
        };
        component.ngOnChanges(valueChanges);
        expect(spy).toHaveBeenCalled();
    });

    it("should call highlightUnreadNotification", () => {
        const spy = spyOn(component, "highlightUnreadNotification").and.callThrough();
        component.highlightUnreadNotification();
        expect(spy).toHaveBeenCalled();
    });

    it("should call onFilterNotification", () => {
        spyOn(component, "resetList").and.returnValue();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(component, "applyCheckBoxFilter").and.returnValue({});
        const spy = spyOn(component, "onFilterNotification").and.callThrough();
        component.onFilterNotification({ checked: true } as unknown as MatCheckboxChange, {
            name: "All",
            checked: false,
            class: "",
        });
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnInit", () => {
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on listenSubscriptions", () => {
        const spy = spyOn(component, "listenSubscriptions").and.callThrough();
        component.listenSubscriptions();
        expect(spy).toHaveBeenCalled();
    });

    xit("should call on ngOnChanges", () => {
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        const data = [{ unReadCount: 0, notifications: [] }];
        component.ngOnChanges({
            notificationList: new SimpleChange(data, data, true),
        });
        expect(spy).toHaveBeenCalled();
    });

    xit("should call on ngAfterViewInit", () => {
        const spy = spyOn(component, "ngAfterViewInit").and.callThrough();
        component.ngAfterViewInit();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on notificationExpOpen", () => {
        const spy = spyOn(component, "notificationExpOpen").and.callThrough();
        const expCode = "test value";
        component.notificationExpOpen(expCode);
        expect(spy).toHaveBeenCalled();
    });

    xit("should call on resetList", () => {
        const spy = spyOn(component, "resetList").and.callThrough();
        component.notificationResult = [];
        component.masterCheckBox = false;
        component.resetList();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onDeleteNotification", () => {
        const spy = spyOn(component, "onDeleteNotification").and.callThrough();
        component.onDeleteNotification();
        expect(spy).toHaveBeenCalled();
    });
});
