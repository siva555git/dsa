import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from "@angular/core";
import { UntypedFormGroup, UntypedFormBuilder, UntypedFormControl, Validators } from "@angular/forms";
import { toLower, delay } from "lodash";
import { map as rxMap, startWith } from "rxjs/operators";
import { Observable } from "rxjs";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { CurrenciesModel } from "../../../experiment-editor/models/currencies-model";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { AppStateService } from "../../../_services/app-state/app.state.service";
import { CurrencyRateModel } from "../../models/currencies-rate-model";
import { CURRENCY, CUSTOM_EVENT_TYPE, DEFAULT_CURRENCY, INVALID } from "../../constants";
import { TasteEditorUtilClass } from "../../helpers/taste-editor-utils";
import { INVALID_VALUES } from "../../../master-data/constants/unapproved.constant";
import { EMPTY } from "../../../app.constant";

@Component({
    selector: "app-currency",
    templateUrl: "./currency.component.html",
})
export class CurrencyComponent implements OnInit, OnChanges {
    public defaultValuesForm: UntypedFormGroup;

    @Input() isAutoUpdateMode = true;

    @Input() defaultCurrency: string;

    @Input() currencies: CurrenciesModel[];

    @Input() currenciesRate: CurrencyRateModel[];

    @Output() currenyValueChange = new EventEmitter();

    @Output() currencyClick = new EventEmitter();

    @Output() formValidation = new EventEmitter();

    public filteredCurrency: Observable<CurrenciesModel[]>;

    private previousCurrencyValue: string;

    public applicationPermissions = APPLICATION_PERMISSIONS;

    constructor(
        private readonly formBuilder: UntypedFormBuilder,
        public appBroadCastService: AppBroadCastService,
        private appStateService: AppStateService,
    ) {}

    ngOnInit(): void {
        this.getDefaultUserCurrrency();
        this.onFormValidation();
    }

    /**
     * Method to get output for the form validation
     *
     * @private
     * @memberof CurrencyComponent
     */
    private onFormValidation(): void {
        this.defaultValuesForm.controls.Currency.statusChanges.subscribe((value) => {
            let isInValid = false;
            let errorMessage = EMPTY;
            if (value === INVALID) isInValid = true;
            if (this.defaultValuesForm.controls.Currency.value.length > 0) {
                const validCurrency = this.currencies.find(
                    (currency) => currency.currencycode === this.defaultValuesForm.controls.Currency?.value?.toUpperCase(),
                );
                if (!validCurrency) {
                    isInValid = true;
                    errorMessage = INVALID_VALUES.VALID_CURRENCY;
                }
            }
            this.formValidation.emit({ isInValid, errorMessage, value: this.defaultValuesForm.controls.Currency.value });
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.defaultValuesForm = this.createDefaultValuesForm();
        if (changes.defaultCurrency?.currentValue) {
            this.patchCurrencyValue(changes.defaultCurrency.currentValue);
            this.previousCurrencyValue = changes.defaultCurrency.currentValue;
            this.OnCurrenyClick(changes.defaultCurrency.currentValue);
        }
    }

    /**
     * Method to initialize the create experiment form
     *
     * @private
     * @memberof CurrencyComponent
     */
    private createDefaultValuesForm = (): UntypedFormGroup => {
        return this.formBuilder.group({
            Currency: new UntypedFormControl("", [Validators.required]),
        });
    };

    /**
     * Method to patch the selected value to currency field
     * @param {string} currencyValue
     * @returns {void}
     * @memberof CurrencyComponent
     */
    public patchCurrencyValue(currencyValue: string): void {
        this.defaultValuesForm.patchValue({
            Currency: `${currencyValue}`,
        });
    }

    /**
     * Method to filter currency based on search
     * @returns {void}
     * @memberof CurrencyComponent
     */
    public bindAutoCompleteData(): void {
        this.filteredCurrency = this.defaultValuesForm.get(CURRENCY).valueChanges.pipe(
            startWith(""),
            rxMap((search) => {
                return TasteEditorUtilClass.getUniqueListBy(this.currencies, "currencycode").filter((currency: CurrenciesModel) =>
                    toLower(currency.currencycode).includes(toLower(search)),
                );
            }),
        );
    }

    /**
     * Method to set updated currency value
     * @returns {void}
     * @memberof CurrencyComponent
     */
    public getDefaultUserCurrrency(): void {
        this.appBroadCastService.getUserPrefCurrency.subscribe((value) => {
            if (value) {
                this.patchCurrencyValue(value);
                this.OnCurrenyClick(value);
            }
        });
    }

    /**
     * Method to emit selected currency and set updated currency and rate globally
     * @param {string} currencyCode
     * @returns {void}
     * @memberof CurrencyComponent
     */
    public OnCurrenyClick(currencyCode?: string): void {
        this.bindAutoCompleteData();
        const currencyFound = TasteEditorUtilClass.getCurrencyCode(this.currencies, currencyCode);
        const currencyCodeValues = currencyFound?.currencycode;
        const filteredCurrencyCode = currencyCodeValues || this.previousCurrencyValue;
        if (!currencyFound) {
            this.patchCurrencyValue(filteredCurrencyCode);
            return;
        }
        this.previousCurrencyValue = filteredCurrencyCode;
        this.currencyClick.emit(filteredCurrencyCode);
        // To MFE applications
        delay(() => {
            const customEvent = new CustomEvent(CUSTOM_EVENT_TYPE.DETAILS_FROM_HOST, {
                detail: {
                    currency: AppStateService.getCurrencyValue(),
                    currencyRate: AppStateService.getConversionRate(),
                },
            });
            // eslint-disable-next-line angular/window-service
            window.dispatchEvent(customEvent);
        }, 500);

        if (currencyFound && currencyFound.currencycode === DEFAULT_CURRENCY.ColumnValue && this.isAutoUpdateMode) {
            this.appStateService.setCurrencyValue(currencyFound, 1);
            return;
        }
        // eslint-disable-next-line no-unused-expressions
        this.isAutoUpdateMode && this.appStateService.setCurrencyValue(currencyFound, this.currenciesRate);
    }

    /**
     * Method to emit updated currency value
     * @returns {void}
     * @memberof CurrencyComponent
     */
    public onCurrenyValueChange(): void {
        const selectedCurrencyCode = this.defaultValuesForm.get(CURRENCY).value;
        const currencycode = selectedCurrencyCode || this.defaultCurrency;
        this.currenyValueChange.emit(currencycode);
    }

    /**
     * Method to get focusOut event
     * @returns {void}
     * @memberof CurrencyComponent
     */
    public onFocusOut(): void {
        delay(() => {
            this.OnCurrenyClick(this.defaultValuesForm?.value?.Currency);
        }, 300);
    }
}
