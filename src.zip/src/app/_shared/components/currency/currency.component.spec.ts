/* eslint-disable max-lines-per-function */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { CurrencyRateModel } from "@te-shared/models/currencies-rate-model";
import { mockCurrencies, mockCurrenciesRateArray } from "../../../testing/mock-ag-grid-data";
import { AppBroadCastService, AppStateService } from "../../../_services";
import { CurrencyComponent } from "./currency.component";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

describe("CurrencyComponent", () => {
    let component: CurrencyComponent;
    let fixture: ComponentFixture<CurrencyComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CurrencyComponent],
            imports: [MatAutocompleteModule, FormsModule, ReactiveFormsModule],
            providers: [UntypedFormBuilder, AppBroadCastService, AppStateService],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CurrencyComponent);
        component = fixture.componentInstance;
        component.defaultValuesForm = new UntypedFormGroup({ Currency: new UntypedFormControl() });
        component.currencies = mockCurrencies;
        component.currenciesRate = mockCurrenciesRateArray as unknown as CurrencyRateModel[];
        fixture.detectChanges();
    });

    it("should create", () => {
        component.currencies = mockCurrencies;
        expect(component).toBeTruthy();
    });

    it("should resolve for currency changes ", () => {
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        const valueChanges: any = {
            defaultCurrency: {
                currentValue: "AED",
            },
        };
        component.currencies = mockCurrencies;
        component.currenciesRate = mockCurrenciesRateArray as unknown as CurrencyRateModel[];
        component.ngOnChanges(valueChanges);
        expect(spy).toHaveBeenCalled();
    });

    it("should call patchCurrencyValue", () => {
        const spy = spyOn(component, "patchCurrencyValue").and.callThrough();
        component.patchCurrencyValue("AED");
        expect(spy).toHaveBeenCalled();
    });

    it("should call bindAutoCompleteData", () => {
        const spy = spyOn(component, "bindAutoCompleteData").and.callThrough();
        component.bindAutoCompleteData();
        expect(spy).toHaveBeenCalled();
    });

    it("should call getDefaultUserCurrrency", () => {
        const spy = spyOn(component, "getDefaultUserCurrrency").and.callThrough();
        component.getDefaultUserCurrrency();
        expect(spy).toHaveBeenCalled();
    });

    it("should call OnCurrenyClick", () => {
        const spy = spyOn(component, "OnCurrenyClick").and.callThrough();
        component.currencies = mockCurrencies;
        component.currenciesRate = mockCurrenciesRateArray as unknown as CurrencyRateModel[];
        component.OnCurrenyClick("AED");
        expect(spy).toHaveBeenCalled();
    });

    it("should call onFocusOut", () => {
        const spy = spyOn(component, "onFocusOut").and.callThrough();
        component.onFocusOut();
        expect(spy).toHaveBeenCalled();
    });

    it("should call onCurrenyValueChange", () => {
        const spy = spyOn(component, "onCurrenyValueChange").and.callThrough();
        component.onCurrenyValueChange();
        expect(spy).toHaveBeenCalled();
    });
});
