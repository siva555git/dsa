import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";

import { DisplayVariantComponent } from "./display-variant.component";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

describe("DisplayVariantComponent", () => {
    let component: DisplayVariantComponent;
    let fixture: ComponentFixture<DisplayVariantComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [DisplayVariantComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DisplayVariantComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
    it("should call ngOnChanges", () => {
        component.globalUserId = "TE_123";
        component.userName= "USER123"
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.ngOnChanges();
        expect(spy).toHaveBeenCalled();
        expect(component.userProfile.GlobalUserID).toBe(component.globalUserId);
        expect(component.userProfile.name).toBe(component.userName);
    });
});
