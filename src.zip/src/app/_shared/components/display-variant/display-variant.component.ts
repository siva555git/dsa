import { Component, Input, OnChanges } from "@angular/core";
import { UserProfileModel } from "@te-shared/master-data/models/profile-picture.model";

@Component({
    selector: "app-display-variant",
    templateUrl: "./display-variant.component.html",
})
export class DisplayVariantComponent implements OnChanges {
    @Input() public activeExperiment;

    @Input() public globalUserId;

    @Input() public userName;

    @Input() public ipcDescription;

    public userProfile: UserProfileModel;

    ngOnChanges(): void {
        this.userProfile = {
            GlobalUserID: this.globalUserId,
            name: this.userName,
        };
    }
}
