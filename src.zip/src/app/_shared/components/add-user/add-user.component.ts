import { Component, ElementRef, Input, OnInit, Output, ViewChild, EventEmitter, SimpleChanges } from "@angular/core";
import { UntypedFormControl } from "@angular/forms";
import { debounceTime } from "rxjs/operators";
import { ToastrService } from "ngx-toastr";
import { MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU, MENU_LIST } from "@te-shared/constants/context-menu.constant";
import { MatDialog } from "@angular/material/dialog";
import { CooperatorUserModel, UsersListSearchPayload } from "../../models/cooperator-access.model";
import { AppDataService, ErrorFormatService } from "../../../_services";
import { COLLABORATION_GROUP, COMMON_DIALOG_OLD, REMOVE_USER_COLLABORATION_DIALOG_MESSAGE } from "../../constants";
import { CollaborationGroupListModel, RemoveExpForUser } from "../../models/user-collaboration-group.model";
import { ConfirmationDialogComponent } from "../confirmation-dialog/confirmation-dialog.component";

@Component({
    selector: "app-add-user",
    templateUrl: "./add-user.component.html",
})
export class AddUserComponent implements OnInit {
    public users: Array<CooperatorUserModel> = [];

    public filteredStaffsList: Array<CooperatorUserModel> = [];

    public islimitReached = false;

    public searchValue: UntypedFormControl = new UntypedFormControl();

    public displayedColumns: string[] = ["Cooperators", "Remove"];

    public groupData: CollaborationGroupListModel;

    public removeUserList: Array<RemoveExpForUser> = [];

    public contextMenuList = EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU;

    @ViewChild("searchUserInput") searchUserInput: ElementRef;

    @Input() public maxUserLimit = 1;

    @Input() public dataSource: Array<CooperatorUserModel> = [];

    @Input() public columnHeader: string;

    @Input() addedUserList: CooperatorUserModel[];

    @Input() groupNameDetails: CollaborationGroupListModel;

    @Input() public viewCollaborationOption: string;

    @Input() public menuName: string;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Output() public userAdded = new EventEmitter<any>();

    @Output() public isUserInputEmpty = new EventEmitter<boolean>();

    @Output() removedUsers = new EventEmitter<Array<RemoveExpForUser>>();

    constructor(
        private readonly appDataService: AppDataService,
        private readonly toastrService: ToastrService,
        private readonly errorFormatService: ErrorFormatService,
        public readonly dialog: MatDialog,
    ) {}

    ngOnInit(): void {
        this.columnHeader = "Users";
        this.searchValue.valueChanges.pipe(debounceTime(500)).subscribe((value) => {
            this.filteredStaffsList = [];
            if (value.length >= 3) {
                this.getUsersListBySearch();
            }
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.addedUserList?.currentValue) {
            this.userListFormat(this.addedUserList);
        }
    }

    /**
     * Method to get list of users from api when start typing in search field
     * @memberof AddUserComponent
     */
    public getUsersListBySearch(): void {
        const payload: UsersListSearchPayload = { searchText: this.searchValue.value };
        this.appDataService.post(this.appDataService.url.getUsersListSearch, [], payload).subscribe({
            next: (result) => {
                if (result?.length > 0) {
                    const loggedInUserId = this.appDataService.getUserId();
                    const filteredLoggedInStaffData = result.filter((user) => user.globalUserID !== loggedInUserId);
                    this.filteredStaffsList = this.removeSelectedUsersFromList(filteredLoggedInStaffData);
                } else {
                    this.toastrService.error(COLLABORATION_GROUP.NO_USER_FOUND);
                    this.errorFormatService.logFormattedError(COLLABORATION_GROUP.NO_USER_FOUND, payload);
                }
            },
            error: (error) => {
                this.errorFormatService.logFormattedError(COLLABORATION_GROUP.USER_FETCH_ERROR, error);
            },
        });
    }

    /**
     * Method to remove user from mat chip list
     * @param {CooperatorUserModel} user
     * @memberof AddUserComponent
     */
    public removeUserFromChip(user: CooperatorUserModel): void {
        this.filteredStaffsList = [];
        const index = this.users.indexOf(user);
        if (index >= 0) {
            this.users.splice(index, 1);
        }
        this.checkForMaxLimit();
    }

    /**
     * Method to reset the added user and the form
     * @memberof AddUserComponent
     */
    public reset(): void {
        this.dataSource = [];
        this.removeAllUserFromChip();
    }

    /**
     * Method to remove all users from mat chip list
     * @memberof AddUserComponent
     */
    public removeAllUserFromChip(): void {
        this.users = [];
        this.filteredStaffsList = [];
        if (this.searchUserInput) this.searchUserInput.nativeElement.value = "";
        this.checkForMaxLimit();
    }

    /**
     * Method to select user from search drop down
     * @param { MatAutocompleteSelectedEvent } event
     * @memberof AddUserComponent
     */
    public selectedUser(event: MatAutocompleteSelectedEvent): void {
        this.filteredStaffsList = [];
        const userDetails = event.option.value;
        userDetails.globalUserId = userDetails.globalUserID;
        this.users.push(userDetails);
        this.searchUserInput.nativeElement.value = "";
        this.checkForMaxLimit();
        this.isUserInputEmpty.emit(true);
    }

    /**
     * Method to add searched users to the Added User list
     * @memberof AddUserComponent
     */
    public onAddStaffs(): void {
        if (this.dataSource.length < this.maxUserLimit) {
            this.userListFormat(this.users);
            const selectedUserIds = this.dataSource.map((user) => user.userId);
            this.userAdded.emit(selectedUserIds);
        }
        this.removeAllUserFromChip();
    }

    /**
     * Method to remove user from Added User list
     * @param {number} userIdToRemove
     * @memberof AddUserComponent
     */
    public onRemoveStaffs(userIdToRemove: number, removeAllExperiments = false): void {
        const filteredDataSource = this.dataSource.filter((user) => user.userId !== userIdToRemove);
        this.dataSource = filteredDataSource;
        this.removeUserList.push({ UserID: userIdToRemove, RemoveExperiments: removeAllExperiments });
        this.removedUsers.emit(this.removeUserList);
        const selectedUserIds = this.dataSource.map((user) => user.userId);
        this.userAdded.emit(selectedUserIds);
        this.checkForMaxLimit();
    }

    /**
     * Method to filter already selected users from list
     * @param {Array<CooperatorUserModel>} userList
     * @return {*}  {Array<CooperatorUserModel>}
     * @memberof AddUserComponent
     */
    public removeSelectedUsersFromList(userList: Array<CooperatorUserModel>): Array<CooperatorUserModel> {
        let staffList;
        const staffsArray = [...this.dataSource, ...this.users];
        if (staffsArray.length > 0) {
            // eslint-disable-next-line unicorn/explicit-length-check
            staffList = userList.filter((user) => !staffsArray.filter((staff) => staff.userId === user.userId).length);
        }
        return staffList || userList;
    }

    /**
     * Method to check maximum user limit
     * @memberof AddUserComponent
     */
    public checkForMaxLimit(): void {
        const addedUserCount = this.users.length + this.dataSource.length;
        this.islimitReached = addedUserCount >= this.maxUserLimit;
    }

    /* Method to format the user list
     * @param {Array<CooperatorUserModel>} user
     * @memberof AddUserComponent
     */
    public userListFormat(users: CooperatorUserModel[]): void {
        const userList = [];
        users.forEach((user) => {
            userList.push({
                userId: user.userId,
                firstName: user.firstName,
                surName: user.surName,
                regionName: user.regionName,
                department: user.department,
                globalUserId: user.globalUserID,
                name: `${user.firstName} ${user.surName}`,
            });
        });
        this.dataSource.push(...userList);
        this.checkForMaxLimit();
    }

    /**
     * Method to open dialog to confirm and remove user from Added User list
     * @param {number} userIdToRemove
     * @memberof AddUserComponent
     */
    public openDialogRemoveStaffs(userIdToRemove: number): void {
        if (this.menuName === MENU_LIST.EDIT_COLLABORATION_GROUP) {
            const userDetails = this.dataSource.find((user) => user.userId === userIdToRemove);
            if (userDetails) {
                const dialogOptions = COMMON_DIALOG_OLD;
                const dialogMessage = REMOVE_USER_COLLABORATION_DIALOG_MESSAGE;
                dialogMessage.message = `Are you sure you want to remove <br /> '<b>${userDetails.firstName} ${userDetails.surName}</b>' from '<b>${this.groupNameDetails?.GroupName}</b>' group?`;
                dialogMessage.data.removeAllExperiments = true;
                dialogOptions.data = dialogMessage;
                const dialogReference = this.dialog.open(ConfirmationDialogComponent, dialogOptions);
                dialogReference.afterClosed().subscribe((dialogResult) => {
                    if (!dialogResult) {
                        return;
                    }
                    this.onRemoveStaffs(userIdToRemove, dialogResult.removeAllExperiments);
                });
            }
        } else {
            this.onRemoveStaffs(userIdToRemove);
        }
    }
}
