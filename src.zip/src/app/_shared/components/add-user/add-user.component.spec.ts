/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatAutocompleteModule, MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { MENU_LIST } from "@te-shared/constants/context-menu.constant";
import { MatDialog } from "@angular/material/dialog";
import { of } from "rxjs";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatChipsModule } from "@angular/material/chips";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { MockToastrService } from "../../../testing/mock-toastr.service";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { MockErrorFormatService } from "../../../testing/mock-error-format.service";
import { AppDataService, AppBroadCastService, ErrorFormatService, AppStateService } from "../../../_services";
import { AddUserComponent } from "./add-user.component";

describe("AddUserComponent", () => {
    let component: AddUserComponent;
    let fixture: ComponentFixture<AddUserComponent>;
    const user = {
        countryCode: "IN",
        department: "department",
        email: "Vimal.RajKumar@iff.com",
        firstName: "Vimal",
        globalUserID: "RXP1926",
        initials: "RXP",
        isActive: "1",
        isLocked: "1",
        profilePicURL: "",
        regionName: "",
        surName: "Rajkumar",
        userId: 65_331,
    };
    const users = [user];

    const dialogReferenceStub = {
        afterClosed() {
            return of({ removeAllExperiments: true });
        },
    };
    const dialogStub = { open: () => dialogReferenceStub };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [AddUserComponent],
            imports: [MatAutocompleteModule, FormsModule, ReactiveFormsModule, MatChipsModule],
            providers: [
                AppBroadCastService,
                AppStateService,
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: ErrorFormatService,
                    useClass: MockErrorFormatService,
                },
                {
                    provide: MatDialog,
                    useValue: dialogStub,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AddUserComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        component.searchValue.setValue("Vimal");
        component.maxUserLimit = 20;
        component.dataSource = users;
        component.users = users;
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on getUsersListBySearch when response length is > 0", () => {
        const service: AppDataService = TestBed.inject(AppDataService);
        spyOn(service, "getUserId");
        spyOn(service, "post").and.returnValue(of([{ globalUserID: "AXB123" }]));
        const spy = spyOn(component, "getUsersListBySearch").and.callThrough();
        component.getUsersListBySearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on removeUserFromChip", () => {
        const spy = spyOn(component, "removeUserFromChip").and.callThrough();
        component.removeUserFromChip(user);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on reset", () => {
        const spy = spyOn(component, "reset").and.callThrough();
        component.reset();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for selectedUser()", () => {
        const event: MatAutocompleteSelectedEvent = {
            option: {
                value: [
                    {
                        userId: 65_331,
                    },
                ],
            },
        } as MatAutocompleteSelectedEvent;
        const spy = spyOn(component, "selectedUser").and.callThrough();
        component.selectedUser(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onAddStaffs", () => {
        const spy = spyOn(component, "onAddStaffs").and.callThrough();
        component.onAddStaffs();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onRemoveStaffs", () => {
        const spy = spyOn(component, "onRemoveStaffs").and.callThrough();
        component.onRemoveStaffs(65_331);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on removeSelectedUsersFromList", () => {
        const spy = spyOn(component, "removeSelectedUsersFromList").and.callThrough();
        component.removeSelectedUsersFromList(users);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on openDialogRemoveStaffs with edit collaboration group", () => {
        const spy = spyOn(component, "openDialogRemoveStaffs").and.callThrough();
        component.menuName = MENU_LIST.EDIT_COLLABORATION_GROUP;
        component.openDialogRemoveStaffs(65_331);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on openDialogRemoveStaffs with add to collaboration group", () => {
        const spy = spyOn(component, "openDialogRemoveStaffs").and.callThrough();
        component.menuName = MENU_LIST.ADD_TO_COLLABORATION_GROUP;
        component.openDialogRemoveStaffs(65_331);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnChanges", () => {
        const changes = {
            addedUserList: {
                currentValue: true,
            },
        } as unknown as SimpleChanges;
        spyOn(component, "userListFormat");
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getUsersListBySearch when response length is equal to 0", () => {
        const service: AppDataService = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of([]));
        const spy = spyOn(component, "getUsersListBySearch").and.callThrough();
        component.getUsersListBySearch();
        expect(spy).toHaveBeenCalled();
    });
});
