import { Pipe, PipeTransform } from "@angular/core";
import { isEqual } from "lodash";
import { EMPTY } from "../../../app.constant";
import { EditModeValue, FormDataCheck, VariantFormData } from "../../models/variant.model";
import { FORM_VALIDITY, VARIANT_SCREEN_REQUIRED_FIELDS, VARIANT_SOURCE } from "../../constants/common.constant";
import { SpaceTrimPipe } from "../../pipes/space-trim/space-trim.pipe";

@Pipe({
    name: "variantPipe",
})
export class VariantPipe implements PipeTransform {
    constructor(private readonly spaceTrim: SpaceTrimPipe) {}

    transform = (
        applyDisable: boolean,
        isErrorIPC: boolean,
        formStatus: string,
        formData: VariantFormData,
        editModeValue: EditModeValue,
        variantSource: string,
    ): boolean => {
        let formValid = formStatus;
        Object.keys(formData).forEach((key) => {
            if (VARIANT_SCREEN_REQUIRED_FIELDS.includes(key) && formData[key] && formData[key].trim() === EMPTY) {
                formValid = FORM_VALIDITY.FORM_INVALID;
            }
        });
        const isChangeConditionIdTypeCheck =
            formData.ChangeConditionId &&
            (!Number.isNaN(+formData.ChangeConditionId) || !Number.isNaN(Number(formData.ChangeConditionId?.changeConditionID)));
        if (
            variantSource !== VARIANT_SOURCE.EXP_FROM_EXP &&
            editModeValue &&
            formStatus === FORM_VALIDITY.FORM_VALID &&
            isChangeConditionIdTypeCheck
        ) {
            const changeConditionValue = formData.ChangeConditionId.changeConditionID ?? formData.ChangeConditionId;
            const data: FormDataCheck = {
                ChangeConditionID: changeConditionValue,
                ChangeDesc: this.spaceTrim.transform(formData.VariantChange),
                Remark: this.spaceTrim.transform(formData.Comments),
            };
            const value = this.getUpdateDetails(editModeValue, data);
            return !(value && value.length > 0 && formValid === FORM_VALIDITY.FORM_VALID);
        }
        return isErrorIPC || formValid !== FORM_VALIDITY.FORM_VALID || !isChangeConditionIdTypeCheck;
    };

    /**
     * compares updated form data value with the api fetched value for edit
     * @param editModeValue
     * @param formData
     * @returns [result]
     * @memberof VariantPipe
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getUpdateDetails = (editModeValue: EditModeValue, formData: FormDataCheck): Array<any> => {
        // eslint-disable-next-line unicorn/no-reduce, unicorn/no-array-reduce
        return Object.keys(editModeValue).reduce((result, key) => {
            if (Object.prototype.hasOwnProperty.call(formData, key) && isEqual(editModeValue[key], formData[key])) {
                const resultKeyIndex = result.indexOf(key);
                result.splice(resultKeyIndex, 1);
            }
            return result;
        }, Object.keys(formData));
    };
}
