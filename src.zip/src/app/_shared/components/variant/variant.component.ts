import { Component, ElementRef, Inject, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, ValidatorFn, Validators } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { NGXLogger } from "ngx-logger";
import { Observable } from "rxjs";
import { toLower } from "lodash";
import { map as rxMap, startWith } from "rxjs/operators";
import { UserProfileModel } from "@te-shared/master-data/models/profile-picture.model";
import { CreativeReviewHelper } from "../../../creative-review/helpers/creative-review-helper";
import { AppDataService } from "../../../_services/app-data/app.data.service";
import { ChangeConditionResponse, VariantPayload } from "../../models/variant.model";
import { IPC_EXPCODE_LENGTH, KEYBOARD_KEYS, VARIANT_CONSTANTS, VARIANT_SOURCE } from "../../constants";
import { SelectedRowDataModel } from "../../models/selected-row-data.model";
import { SpaceTrimPipe } from "../../pipes/space-trim/space-trim.pipe";

function validateChangeCondition(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: boolean } | null => {
        if (typeof control.value === "number" || typeof control.value?.changeConditionID === "number") {
            // eslint-disable-next-line unicorn/no-null
            return null;
        }
        return { isInvalidChangeCondition: true };
    };
}
@Component({
    selector: "app-variant",
    templateUrl: "./variant.component.html",
})
export class VariantComponent implements OnInit {
    public changeConditionList: Observable<ChangeConditionResponse[]>;

    public isErrorIPC = false;

    public applyDisable: boolean;

    public variantForm: UntypedFormGroup;

    public activeExperiment: SelectedRowDataModel;

    public variantHeaderTitle: string;

    public variantButtonTitle: string;

    public currentUser: string;

    public ipcDescription: string;

    public userProfile: UserProfileModel;

    public conditionList: ChangeConditionResponse[];

    public errorChange = false;

    public variantSourceConst = VARIANT_SOURCE;

    @ViewChild("ipc") ipcWithDescription: ElementRef<HTMLInputElement>;

    constructor(
        private readonly appDataService: AppDataService,
        private logger: NGXLogger,
        private readonly dialogReference: MatDialogRef<VariantComponent>,
        private readonly creativeReviewHelper: CreativeReviewHelper,
        private readonly formBuilder: UntypedFormBuilder,
        private readonly spaceTrim: SpaceTrimPipe,
        @Inject(MAT_DIALOG_DATA) public data: { activeExperiment; currentUser; globalUserId; ipcDetails; source },
    ) {}

    ngOnInit(): void {
        this.variantForm = this.createVariantForm();
        this.getChangeConditionList();
        this.activeExperiment = this.data.activeExperiment;
        this.currentUser = this.data.currentUser;
        this.userProfile = { GlobalUserID: this.data.globalUserId, fullname: this.currentUser, name: this.currentUser };
        this.variantHeaderTitle =
            this.activeExperiment.ExperimentVariant && this.data.source !== this.variantSourceConst.EXP_FROM_EXP
                ? VARIANT_CONSTANTS.EDIT
                : VARIANT_CONSTANTS.INSERT_HEADER;
        this.variantButtonTitle =
            this.activeExperiment.ExperimentVariant && this.data.source !== this.variantSourceConst.EXP_FROM_EXP
                ? VARIANT_CONSTANTS.SAVE
                : VARIANT_CONSTANTS.INSERT_BUTTON;
        this.dialogReference.keydownEvents().subscribe((event) => {
            if (event.key === KEYBOARD_KEYS.ESCAPE) {
                this.dialogReference.close();
            }
        });
    }

    /**
     * Method to bind variant data in pop up
     * @returns {void}
     * @memberof VariantComponent
     */
    public bindVariantData(): void {
        if (this.activeExperiment && this.activeExperiment.ExperimentVariant) {
            this.variantForm.patchValue({
                RootIpc: `${this.activeExperiment.ExperimentVariant?.RootIPC}`,
                VariantChange: this.spaceTrim.transform(this.activeExperiment.ExperimentVariant?.ChangeDesc),
                Comments: this.spaceTrim.transform(this.activeExperiment.ExperimentVariant?.Remark),
                CreatedBy: this.activeExperiment.ExperimentVariant?.CreatedBy,
                CreatedOn: this.activeExperiment.ExperimentVariant?.CreatedOn,
                ChangeConditionId: this.activeExperiment.ExperimentVariant?.ChangeConditionID,
            });
            this.ipcValidation(this.activeExperiment.ExperimentVariant?.RootIPC);
            if (this.data.source !== this.variantSourceConst.EXP_FROM_EXP) this.variantForm.get("RootIpc").disable();
        }
    }

    /**
     * Method to create form for variant pop up
     * @returns {FormGroup}
     * @memberof VariantComponent
     */
    public createVariantForm = (): UntypedFormGroup => {
        return this.formBuilder.group({
            RootIpc: new UntypedFormControl("", [Validators.required]),
            ChangeConditionId: new UntypedFormControl(0, [Validators.required, validateChangeCondition()]),
            VariantChange: new UntypedFormControl("", [Validators.required]),
            Comments: new UntypedFormControl(""),
            CreatedBy: new UntypedFormControl(""),
            CreatedOn: new UntypedFormControl(""),
        });
    };

    /**
     * Method to get change conditiondrop down value from api
     * @returns {void}
     * @memberof VariantComponent
     */
    public getChangeConditionList(): void {
        this.appDataService.get(`${this.appDataService.url.getChangeCondition}`, []).subscribe({
            next: (result) => {
                if (result) {
                    this.conditionList = result;
                    this.bindChangeConditionAutoComplete();
                    this.bindVariantData();
                }
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to bind auto complete data for change condition
     * @memberof VariantComponent
     */
    public bindChangeConditionAutoComplete(): void {
        this.changeConditionList = this.variantForm.get("ChangeConditionId").valueChanges.pipe(
            startWith(""),
            rxMap((search) => {
                const result = search
                    ? this.conditionList?.filter((list) => toLower(list.Description).includes(this.spaceTrim.transform(toLower(search))))
                    : this.conditionList?.slice();
                if (
                    result.length === 1 &&
                    this.spaceTrim.transform(toLower(result[0]?.Description)) === this.spaceTrim.transform(toLower(search))
                ) {
                    this.variantForm.get("ChangeConditionId").setValue(result[0]);
                }
                return result;
            }),
        );
        this.displayIpcAndIpcdescription();
    }

    /**
     * Method to bind variant data in pop up
     * @param {string} action
     * @returns {void}
     * @memberof VariantComponent
     */
    public onCreateVariant(action: string): void {
        if (this.variantForm.value.ChangeConditionId === undefined) {
            return;
        }
        const payload: VariantPayload =
            action === VARIANT_CONSTANTS.INSERT_BUTTON
                ? {
                      RootIPC: this.variantForm.value.RootIpc,
                      ExpID: this.activeExperiment.ExpID,
                      ChangeConditionID:
                          this.variantForm.value.ChangeConditionId.changeConditionID ?? this.variantForm.value.ChangeConditionId,
                      ChangeDesc: this.spaceTrim.transform(this.variantForm.value.VariantChange),
                      Remark: this.spaceTrim.transform(this.variantForm.value.Comments),
                      changeConditionDesc: this.variantForm.value.ChangeConditionId.Description,
                      IPCDescription: this.ipcDescription,
                      VariantSource: this.data?.source,
                  }
                : {
                      ExpVariantID: this.activeExperiment.ExperimentVariant.ExpVariantID,
                      ChangeConditionID:
                          this.variantForm.value.ChangeConditionId.changeConditionID || this.variantForm.value.ChangeConditionId,
                      ChangeDesc: this.spaceTrim.transform(this.variantForm.value.VariantChange),
                      Remark: this.spaceTrim.transform(this.variantForm.value.Comments),
                      changeConditionDesc: this.variantForm.value.ChangeConditionId.Description || this.findChangeValue(),
                      IPCDescription: this.ipcDescription,
                      VariantSource: this.data?.source,
                  };
        this.dialogReference.close(payload);
    }

    /**
     * Method to find value for change condition based id
     * @returns {string}
     * @memberof VariantComponent
     */
    public findChangeValue(): string {
        const matchedValue = this.conditionList?.find((data) => {
            return data.changeConditionID === this.variantForm.value.ChangeConditionId
                ? this.variantForm.value.ChangeConditionId
                : this.variantForm.value.ChangeConditionId.changeConditionID;
        });
        return `${matchedValue ? matchedValue.Description : ""}`;
    }

    /**
     * Method to get change condition value
     * @returns {void}
     * @memberof VariantComponent
     */
    public onFocusOutEvent(): void {
        if (this.variantForm.value && this.variantForm.value.RootIpc) {
            const ipcValue = this.variantForm.value.RootIpc;
            if (ipcValue.length === IPC_EXPCODE_LENGTH.IPC_LENGTH) {
                this.ipcValidation(ipcValue);
                return;
            }
            this.isErrorIPC = true;
            this.ipcDescription = "";
        }
    }

    /**
     * Method to validate ipc
     * @returns {void}
     * @memberof VariantComponent
     */
    public ipcValidation(rootIpc: string): void {
        this.creativeReviewHelper.validateIpc([rootIpc]).subscribe(
            (result) => {
                if (result?.length > 0 && result[0]) {
                    this.isErrorIPC = !result[0].isValid;
                    this.ipcDescription = result[0].description;
                    this.ipcWithDescription.nativeElement.value = result[0].isValid
                        ? `${result[0].IPC} - ${result[0].description}`
                        : `${result[0].IPC}`;
                }
            },
            (error) => {
                this.logger.error(error);
                this.isErrorIPC = true;
                this.ipcDescription = "";
            },
        );
    }

    /**
     * Method to close variant pop up
     * @returns {void}
     * @memberof VariantComponent
     */
    public onCancel(): void {
        this.dialogReference.close();
    }

    /**
     * Method to display the change condition value
     * @param {*} value
     * @returns {string}
     * @memberof VariantComponent
     */
    public displayChangeCondition(value?: ChangeConditionResponse): string {
        return value && value.Description ? `${value.Description}` : this.findChangeValue();
    }

    /**
     * Method to append ipc and ipc description when open popup from product screen
     * @returns {void}
     * @memberof VariantComponent
     */
    public displayIpcAndIpcdescription(): void {
        if (this.data?.ipcDetails?.ipc) {
            this.variantForm.patchValue({
                RootIpc: `${this.data?.ipcDetails.ipc}`,
            });
            this.ipcWithDescription.nativeElement.value = `${this.data?.ipcDetails.ipc} - ${this.data?.ipcDetails.ipcDescription}`;
        }
    }
}
