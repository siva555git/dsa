/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { UntypedFormBuilder, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { of, throwError } from "rxjs";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { AppDataService, AppStateService } from "../../../_services";
import { VariantComponent } from "./variant.component";
import { CreativeReviewHelper } from "../../../creative-review/helpers/creative-review-helper";
import { MockAppStateService } from "../../../testing/mock-app.state.service";
import { MockDialogReference } from "../../../testing/mock-dialog.reference";
import { MockCreativereview } from "../../../testing/mock-creativereview-helper";
import { SpaceTrimPipe } from "../../pipes/space-trim/space-trim.pipe";
import { VariantPipe } from "./variant.pipe";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

describe("VariantComponent", () => {
    let component: VariantComponent;
    let fixture: ComponentFixture<VariantComponent>;
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [VariantComponent, VariantPipe],
            imports: [MatAutocompleteModule, FormsModule, ReactiveFormsModule],
            providers: [
                UntypedFormBuilder,
                SpaceTrimPipe,
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                { provide: MatDialogRef, useClass: MockDialogReference },
                {
                    provide: MAT_DIALOG_DATA,
                    useValue: {
                        activeExperiment: {
                            ExperimentVariant: {
                                ChangeConditionID: 1,
                                ChangeDesc: "test",
                                ExpID: 1_234_567,
                                ExpVariantID: 500_078,
                                RootIPC: "00010076",
                                Remark: "test",
                            },
                        },
                        currentUser: "test",
                        profilePicURL: "",
                    },
                },
                {
                    provide: CreativeReviewHelper,
                    useClass: MockCreativereview,
                },
                { provide: AppStateService, useClass: MockAppStateService },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(VariantComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call onCancel", () => {
        const spy = spyOn(component, "onCancel").and.callThrough();
        component.onCancel();
        expect(spy).toHaveBeenCalled();
    });

    xit("should call createVariantForm", () => {
        const spy = spyOn(component, "createVariantForm").and.callThrough();
        component.createVariantForm();
        expect(spy).toHaveBeenCalled();
    });

    xit("should call onFocusOutEvent", () => {
        component.variantForm.value.RootIpc = "00010076";
        const spy = spyOn(component, "onFocusOutEvent").and.callThrough();
        component.onFocusOutEvent();
        expect(spy).toHaveBeenCalled();
    });

    it("should call onFocusOutEvent", () => {
        component.variantForm.value.RootIpc = "000100";
        const spy = spyOn(component, "onFocusOutEvent").and.callThrough();
        component.onFocusOutEvent();
        expect(spy).toHaveBeenCalled();
    });

    xit("should call onCreateVariant if action is insert", () => {
        component.conditionList = [{ changeConditionID: 1, Description: "Color", IsActive: true }];
        component.variantForm.value.ChangeConditionId = 1;
        const spy = spyOn(component, "onCreateVariant").and.callThrough();
        component.onCreateVariant("INSERT");
        expect(spy).toHaveBeenCalled();
    });

    it("should call onCreateVariant if action is save", () => {
        component.conditionList = [{ changeConditionID: 1, Description: "Color", IsActive: true }];
        component.variantForm.value.ChangeConditionId = 1;
        const spy = spyOn(component, "onCreateVariant").and.callThrough();
        component.onCreateVariant("SAVE");
        expect(spy).toHaveBeenCalled();
    });

    it("should call getChangeConditionList", () => {
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(appDataService, "get").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "getChangeConditionList").and.callThrough();
        component.getChangeConditionList();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ipcValidation if return response", () => {
        const helper: CreativeReviewHelper = TestBed.inject(CreativeReviewHelper);
        spyOn(helper, "validateIpc").and.returnValue(of([{ isValid: false, description: "Test" }]));
        const spy = spyOn(component, "ipcValidation").and.callThrough();
        component.ipcValidation("1RR043333");
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ipcValidation if throw error", () => {
        const helper: CreativeReviewHelper = TestBed.inject(CreativeReviewHelper);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(helper, "validateIpc").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "ipcValidation").and.callThrough();
        component.ipcValidation("1RR043333");
        expect(spy).toHaveBeenCalled();
    });

    it("should call displayIpcAndIpcdescription", () => {
        component.data = {
            ipcDetails: {
                ipc: "1RR04333",
            },
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } as any;
        const spy = spyOn(component, "displayIpcAndIpcdescription").and.callThrough();
        component.displayIpcAndIpcdescription();
        expect(spy).toHaveBeenCalled();
    });
});
