/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { SelectionModel } from "@angular/cdk/collections";
import {
    Component,
    ElementRef,
    EventEmitter,
    OnInit,
    Output,
    QueryList,
    ViewChild,
    ViewChildren,
    Input,
    OnDestroy,
    SimpleChanges,
} from "@angular/core";
import { UntypedFormControl } from "@angular/forms";
import { MatAutocompleteSelectedEvent, MatAutocompleteTrigger } from "@angular/material/autocomplete";
import { delay, isEqual, uniqWith } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { Subscription } from "rxjs";
import { debounceTime, filter, map, switchMap, tap, startWith } from "rxjs/operators";
import { MatomoCategory, MatomoAction, MatomoLabel } from "@te-shared/enums";
import { AddFavoriteItem, AddFavoritesModel } from "../../../../experiment-editor/models/add-favorites.model";
import { BomSearchHelper } from "../../../helpers/bom-search.helper";
import { TabHelper } from "../../../helpers/tab-helper";
import { WorkSpaces } from "../../../models/create-tab.model";
import { ExperimentHelper } from "../../../helpers/experiment-helper";
import { InstructionSearchModel } from "../../../models/experiments.model";
import { AppBroadCastService, AppDataService, MatomoService } from "../../../../_services";
import { EMPTY, LOADING } from "../../../../app.constant";
import { ZERO_WITH_DECIMAL } from "../../../../creative-review/creative-review.constant";
import {
    ADD_TO_CART,
    BOM_TYPE,
    CATEGORY,
    MIN_SEARCH_VALUE_LENGTH,
    INSTRUCTION_SEARCH,
    PRODUCT_SEARCH_CONSTANTS,
    REFERENCE_ERRORS,
    FAV_TOOL_TIP,
} from "../../../constants";
import { MARK_FOR_UNDELETE_FLAG } from "../../../constants/experiment.constant";

import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";

@Component({
    selector: "app-instruction-search",
    templateUrl: "./instruction-search.component.html",
})
export class InstructionSearchComponent implements OnInit, OnDestroy {
    public categoryHeading = CATEGORY;

    public categoriesList = [];

    public searchResultList: any = [];

    public searchCriteria: any;

    public selectedCategory: any;

    public defaultCategory = INSTRUCTION_SEARCH.DEFAULT_CATEGORY;

    public favoriteCategory = INSTRUCTION_SEARCH.FAVORITE_CATEGORY;

    public defaultClause = INSTRUCTION_SEARCH.DEFAULT_SEARCH_CLAUSE;

    public dataSource = [];

    public searchValue: UntypedFormControl = new UntypedFormControl();

    public displayedColumns: string[] = INSTRUCTION_SEARCH.INSTRUCTION_COLUMN_LIST;

    public Category: UntypedFormControl = new UntypedFormControl(INSTRUCTION_SEARCH.DEFAULT_CATEGORY);

    public start = PRODUCT_SEARCH_CONSTANTS.START_FROM;

    public limit = PRODUCT_SEARCH_CONSTANTS.LIMIT;

    public addToCart = ADD_TO_CART;

    public favouriteTooltip = FAV_TOOL_TIP;

    public SortType = PRODUCT_SEARCH_CONSTANTS.SORT_ORDER;

    public SortBy = INSTRUCTION_SEARCH.SORT_CODE;

    public end = this.limit + this.start;

    public totalCount = 0;

    public isLoading = false;

    public noDataFound = false;

    public selectedRowIndex = -1;

    private componentSubscriptions: Subscription = new Subscription();

    public selection: SelectionModel<any> = new SelectionModel();

    public instruction: UntypedFormControl = new UntypedFormControl();

    public currentWorkspace: WorkSpaces;

    @ViewChildren("instructionDataTable") instructionDataTable: QueryList<ElementRef>;

    @ViewChild("searchTextBox") searchTextBox: ElementRef;

    @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;

    @ViewChild("instructionInput") instructionInput: ElementRef;

    @Input() public searchFilterData;

    @Input() public selectedMiniEditorInst: string;

    @Output()
    public emitCartData = new EventEmitter();

    @Output()
    public focusCartData = new EventEmitter();

    @Output()
    public emitSelectedInstruction = new EventEmitter();

    constructor(
        private readonly appDataService: AppDataService,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly toastrService: ToastrService,
        private readonly logger: NGXLogger,
        private readonly spaceTrim: SpaceTrimPipe,
        private readonly tabHelper: TabHelper,
        private readonly experimentHelper: ExperimentHelper,
        private readonly matomoService: MatomoService,
    ) {}

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes?.selectedMiniEditorInst?.currentValue) {
            this.instruction.setValue(changes?.selectedMiniEditorInst?.currentValue);
            this.emitSelectedInstruction.emit();
            this.selection.clear();
            delay(() => {
                this.instructionInput.nativeElement.focus();
            }, 0);
        }
    }

    public ngOnInit(): void {
        this.getInstructionCategories();
        this.bindAttributesControl();
        this.instruction.setValue(EMPTY);
        this.matomoService.trackEvent(MatomoCategory.INSTRUCTION_SEARCH, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    public ngOnDestroy(): void {
        this.componentSubscriptions.unsubscribe();
    }

    /**
     * Method to get the list of the ipc selection
     *
     * @memberof InstructionSearchComponent
     */
    public getInstructionCategories(): void {
        this.componentSubscriptions.add(
            this.appDataService.get(this.appDataService.url.getInstructionSearchCriteria, []).subscribe({
                next: (result) => {
                    if (!result || !result.Categories) return;
                    const defaultCategory = {
                        CategoryName: INSTRUCTION_SEARCH.DEFAULT_CATEGORY,
                    };
                    const favoriteCategory = {
                        CategoryName: INSTRUCTION_SEARCH.FAVORITE_CATEGORY,
                    };
                    // eslint-disable-next-line @typescript-eslint/naming-convention
                    const { Categories } = result;
                    Categories.unshift(defaultCategory);
                    Categories.unshift(favoriteCategory);
                    this.categoriesList = Categories;
                    this.getInstructionSearchFilter();
                },
                error: (error) => {
                    this.errorHandler(error);
                },
            }),
        );
    }

    /**
     * Method to search the instructions
     *
     * @memberof InstructionSearchComponent
     */
    public searchInstructions(): void {
        this.componentSubscriptions.add(
            this.experimentHelper.getFavoriteInstructions(this.searchCriteria).subscribe({
                next: (result) => {
                    this.isLoading = false;
                    this.combineDatasource(result);
                },
                error: (error) => {
                    this.isLoading = false;
                    this.errorHandler(error);
                },
            }),
        );
    }

    /**
     * Method to prepare the datasource
     *
     * @memberof InstructionSearchComponent
     */
    public combineDatasource(data: any): void {
        if (data?.Instructions.count) {
            // eslint-disable-next-line unicorn/prefer-spread
            this.dataSource = uniqWith(this.dataSource.concat(data.Instructions.rows), isEqual);
            if (!this.totalCount) {
                this.totalCount = data.Instructions.count;
                this.noDataFound = false;
            }
        } else {
            this.noDataFound = true;
        }
    }

    /**
     * Method to enter the search button
     *
     * @memberof InstructionSearchComponent
     */
    public onEnterSearch(): void {
        if (this.isLoading) return;
        this.Category.setValue(this.selectedCategory ?? this.defaultCategory);
        this.isLoading = true;
        this.onSelectCategory();
        this.searchInstructions();
    }

    /**
     * Method to bind the valueChanges functions for component forms
     *
     * @memberof InstructionSearchComponent
     */
    public bindAttributesControl() {
        this.searchResultList = this.Category.valueChanges.pipe(
            startWith(""),
            map((value) => BomSearchHelper.filterCategoryValues(this.categoriesList, "CategoryName", value)),
        );

        this.componentSubscriptions.add(
            this.searchValue.valueChanges
                .pipe(
                    filter((selectedValue) => {
                        this.totalCount = 0;
                        this.isLoading = selectedValue?.length >= MIN_SEARCH_VALUE_LENGTH && this.searchValue.dirty;
                        this.dataSource = [];
                        this.selectedRowIndex = -1;
                        return this.isLoading;
                    }),
                    debounceTime(500),
                    tap(() => {
                        this.onSelectCategory();
                    }),
                    // eslint-disable-next-line consistent-return
                    switchMap((): any => {
                        return this.appDataService.post(this.appDataService.url.getInstructionList, [], this.searchCriteria);
                    }),
                )
                .subscribe({
                    next: (result: any) => {
                        this.isLoading = false;
                        this.combineDatasource(result);
                    },
                    error: (error) => {
                        this.isLoading = false;
                        this.errorHandler(error);
                    },
                }),
        );
    }

    /**
     * Method to set the search criteria
     *
     * @param {MatAutocompleteSelectedEvent} [selectedCategory]
     * @memberof InstructionSearchComponent
     */
    public onSelectCategory(selectedCategory?: MatAutocompleteSelectedEvent): void {
        delay(() => {
            this.searchTextBox.nativeElement.focus();
        }, 0);
        this.resetAttributes();
        if (selectedCategory) {
            this.selectedCategory = selectedCategory.option.value;
            this.searchValue.setValue("");
        }
        this.searchCriteria = {
            category: this.selectedCategory ?? this.defaultCategory,
            description: this.spaceTrim.transform(this.searchValue.value),
            searchType: this.defaultClause,
            offset: PRODUCT_SEARCH_CONSTANTS.START_FROM,
            limit: PRODUCT_SEARCH_CONSTANTS.LIMIT,
            SortType: PRODUCT_SEARCH_CONSTANTS.SORT_ORDER,
            SortBy: INSTRUCTION_SEARCH.SORT_CODE,
        };
        this.onEnterSearch();
    }

    /**
     * Method to reset the values
     *
     * @memberof InstructionSearchComponent
     */
    public resetAttributes(): void {
        this.dataSource = [];
        this.selectedRowIndex = -1;
        this.totalCount = 0;
        this.start = PRODUCT_SEARCH_CONSTANTS.START_FROM;
        this.limit = PRODUCT_SEARCH_CONSTANTS.LIMIT;
        this.end = this.limit + this.start;
        this.noDataFound = false;
    }

    /**
     * Method to invoke when scrolling the table
     *
     * @param {*} event
     * @returns {*}
     * @memberof InstructionSearchComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public onTableScroll(event: any): any {
        const tableViewHeight = event.target.offsetHeight;
        const tableScrollHeight = event.target.scrollHeight;
        const scrollLocation = event.target.scrollTop;

        // If the user has scrolled within 200px of the bottom, add more data
        const buffer = 200;
        const limit = tableScrollHeight - tableViewHeight - buffer;
        if (scrollLocation > limit && !this.isLoading && this.dataSource.length < this.totalCount) {
            this.isLoading = true;
            this.searchInstructions();
            this.updateIndex();
        }
    }

    /**
     * Method to update the count of start and limit
     *
     * @memberof InstructionSearchComponent
     */
    public updateIndex(): void {
        this.start = this.end;
        this.end = this.limit + this.start;
        this.searchCriteria.offset = this.start;
    }

    /**
     * Method to handle errors
     *
     * @memberof InstructionSearchComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public errorHandler(error: any): void {
        this.toastrService.error(REFERENCE_ERRORS.PRODUCT_SEARCH_ERROR);
        this.logger.error(error);
    }

    /**
     * Method to add the instruction to cart
     * @param {*} instruction
     * @memberof InstructionSearchComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public onAddInstructionToCart(instruction: any): void {
        this.selectedRowIndex = -1;
        const cartInstructionData = {
            ExpFormulaID: EMPTY,
            instruction: instruction?.Description ?? instruction.value,
            description: instruction?.Description ?? instruction.value,
            code: undefined,
            SUBType: BOM_TYPE.INSTRUCTION,
            Parts: ZERO_WITH_DECIMAL,
            IsDelete: MARK_FOR_UNDELETE_FLAG,
            Instruction: instruction?.Description ?? instruction.value,
        };
        this.emitCartData.emit(cartInstructionData);
        delay(() => {
            this.instructionInput.nativeElement.focus();
        }, 500);
        this.matomoService.trackEvent(MatomoCategory.INSTRUCTION_SEARCH, MatomoAction.CLICK, MatomoLabel.ON_ADD_INSTRUCTION_TO_CART);
    }

    /**
     * Method to shift focus to cart from search results table
     *
     * @param {KeyboardEvent} event
     * @memberof InstructionSearchComponent
     */
    public shiftFocusToCart(event: KeyboardEvent): void {
        event.stopPropagation();
        event.preventDefault();
        this.autocomplete.closePanel();
        this.focusCartData.emit();
    }

    /**
     * Method to switch page focus to first data row
     *
     * @memberof InstructionSearchComponent
     */
    public focusOnFirstDataRow(event?: KeyboardEvent): void {
        this.autocomplete.closePanel();
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        if (this.dataSource?.length > 0) {
            this.selectedRowIndex = 0;
            this.selection.select(this.dataSource[this.selectedRowIndex]);

            BomSearchHelper.focusSelectedRowInTable(this.instructionDataTable, this.selectedRowIndex);
        }
    }

    /**
     * Method to switch page focus to search text box
     *
     * @memberof InstructionSearchComponent
     */
    public focusSearchTextBox(shouldSelect = false): void {
        BomSearchHelper.focusOrSelectTextbox(this.searchTextBox, shouldSelect);
    }

    /**
     * Method to store the search filter in session
     * @returns {void}
     * @memberof InstructionSearchComponent
     */
    public storeInstructionsSearchFilter(): void {
        this.currentWorkspace = this.tabHelper.getActiveTab();
        this.currentWorkspace.SearchFilters.Instruction = {
            category: this.selectedCategory,
            usingOption: this.defaultClause,
            searchText: this.searchValue.value,
        };
    }

    /**
     * Method to get the search filter value from session and bind
     * @returns {void}
     * @memberof InstructionSearchComponent
     */
    public getInstructionSearchFilter(): void {
        if (this.searchFilterData && this.searchFilterData?.Instruction) {
            const instruction = this.searchFilterData.Instruction;
            const isCategoryExist = this.categoriesList.find((category) => category.CategoryName === instruction.category);
            this.defaultCategory = isCategoryExist ? instruction.category : this.defaultCategory;
            this.Category.setValue(this.defaultCategory);
            this.selectedCategory = this.defaultCategory;
            this.defaultClause = instruction.usingOption;
            this.searchValue.setValue(instruction.searchText);
            BomSearchHelper.selectAutocompleteOption(this.autocomplete);
        }
    }

    /**
     * Method to Mark instructions as favourites
     * @param {*} instruction
     * @returns {void}
     * @memberof InstructionSearchComponent
     */
    public getInstructionIsFavorite(instruction: AddFavoritesModel): void {
        const addfavourite = instruction;
        const payLoad: AddFavoriteItem[] = [
            {
                PrefTypeCode: INSTRUCTION_SEARCH.FAV_INSTRUCTION,
                ColumnValue: addfavourite.Description,
                IsChecked: !addfavourite.IsFavourite,
                UserPrefID: addfavourite.ReferenceUserPreference?.UserPrefID,
            },
        ];
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.componentSubscriptions.add(
            this.experimentHelper.addFavoriteInstructions(payLoad).subscribe({
                next: () => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    addfavourite.IsFavourite = !addfavourite.IsFavourite;
                    if (this.selectedCategory === this.favoriteCategory) {
                        this.dataSource = this.dataSource.filter((instructionList) => instructionList.IsFavourite);
                    }
                    this.matomoService.trackEvent(
                        MatomoCategory.INSTRUCTION_SEARCH,
                        MatomoAction.CLICK,
                        MatomoLabel.GET_INSTRUCTION_IS_FAVORITE,
                    );
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to set the text box value by clicking the row
     * @param {InstructionSearchModel} event
     * @returns {void}
     * @memberof InstructionSearchComponent
     */
    public onInstructionRowClicked(event: InstructionSearchModel): void {
        this.instruction.setValue(event.Description);
        delay(() => {
            this.instructionInput.nativeElement.focus();
        }, 0);
        this.matomoService.trackEvent(MatomoCategory.INSTRUCTION_SEARCH, MatomoAction.CLICK, MatomoLabel.ON_INSTRUCTION_ROW_CLICKED);
    }

    /**
     * Method to enter the search button for text box
     * @returns {void}
     * @memberof InstructionSearchComponent
     */
    public onSearchEnter(): void {
        if (this.isLoading) return;
        if (this.instruction?.value && this.instruction?.value.trim() !== EMPTY) {
            this.onAddInstructionToCart(this.instruction);
            this.instruction.setValue(EMPTY);
            delay(() => {
                this.instructionInput.nativeElement.focus();
            }, 200);
        }
    }
}
