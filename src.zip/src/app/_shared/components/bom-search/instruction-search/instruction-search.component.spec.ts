import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";

import { HttpClient, HttpHandler } from "@angular/common/http";
import { OAuthService, UrlHelperService, OAuthLogger } from "angular-oauth2-oidc";
import { ToastrService } from "ngx-toastr";
import { NGXLogger } from "ngx-logger";
import { QueryList, ElementRef, SimpleChanges, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { Router } from "@angular/router";
import { MockAppcacheHelper } from "@te-testing/mock-app-cache-helper";
import { AppCacheHelper } from "@te-shared/helpers/app-cache.service";
import { MockGridapiService } from "@te-testing/mock-gridapi.service";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { ExperimentEditorHelper } from "@te-experiment-editor/helpers/experiment-editor.helper";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { cloneDeep } from "lodash";
import { MatAutocompleteSelectedEvent, MatAutocomplete, MatAutocompleteTrigger, MatAutocompleteModule } from "@angular/material/autocomplete";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { of } from "rxjs";
import { MockExperimentAccessHelper } from "@te-testing/mock-experiment-access.helper";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { TasteEditorDialogService } from "@te-shared/helpers/te-dialog.service";
import { MatDialog } from "@angular/material/dialog";
import { MockTabHelperService } from "@te-testing/mock-tabhelper.service";
import { MatomoService } from "@te-services/app-common";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { mockInstructionSearchFilter, MOCK_WORKSPACES, mockInstructionModelFilter } from "../../../../testing/mock-tabhelper-data";
import { InstructionSearchModel } from "../../../models/experiments.model";
import { AppDataService } from "../../../../_services/app-data/app.data.service";
import { AppStateService } from "../../../../_services/app-state/app.state.service";
import { MockToastrService } from "../../../../testing/mock-toastr.service";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { InstructionSearchComponent } from "./instruction-search.component";
import { MockAppDataService } from "../../../../testing/mock-app.data.service";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatSelectModule } from "@angular/material/select";
import { MatTableModule } from "@angular/material/table";
import { MatInputModule } from "@angular/material/input";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { _MatOptionBase } from "@angular/material/core";

// eslint-disable-next-line max-lines-per-function
describe("InstructionSearchComponent", () => {
    let component: InstructionSearchComponent;
    let fixture: ComponentFixture<InstructionSearchComponent>;
    const mockRouter = { navigate: jasmine.createSpy("navigate") };
    const event = {
        target: {
            offsetHeight: 400,
            scrollHeight: 500,
            scrollTop: 1000,
        },
    };
    const instruction = {
        CategoryName: "favorite",
        // eslint-disable-next-line unicorn/no-null
        CostBookCode: null,
        Description: "add",
        InstructionID: 1,
        IsFavourite: true,
        SortCode: "A",
        ColumnValue: 1234,
        ReferenceUserPreference: {
            UserPrefID: 1234,
        },
    };
    const dialogReferenceStub = {
        afterClosed() {
            return of(); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    const data = { Instructions: { count: 10, rows: [{ InstructionID: 123 }] } };
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [InstructionSearchComponent, MatAutocomplete, MatAutocompleteTrigger],
            providers: [
                SpaceTrimPipe,
                { provide: AppDataService, useClass: MockAppDataService },
                HttpClient,
                HttpHandler,
                { provide: AppStateService, useClass: MockAppStateService },
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                { provide: ToastrService, useClass: MockToastrService },
                { provide: NGXLogger, useClass: MockLoggerService },
                AppBroadCastService,
                { provide: Router, useValue: mockRouter },
                { provide: ExperimentEditorHelper, useValue: {} },
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: AppCacheHelper, useClass: MockAppcacheHelper },
                {
                    provide: ExperimentHelper,
                    useClass: MockExperimentHelper,
                },
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                TasteEditorDialogService,
                { provide: TabHelper, useClass: MockTabHelperService },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
            imports: [
                MatFormFieldModule,
                MatSelectModule,
                MatTableModule,
                MatInputModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule,
                MatAutocompleteModule
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(InstructionSearchComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        component.categoriesList = [{ CategoryName: "3D" }, { CategoryName: "AGGL.- COFFEE BASED." }];
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for onAddInstructionToCart()", () => {
        const item = { ipc: "123", description: "test" };
        const spy = spyOn(component, "onAddInstructionToCart").and.callThrough();
        component.onAddInstructionToCart(item);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTableScroll() when if condition is satisfied", () => {
        component.isLoading = false;
        component.totalCount = 400;
        component.searchCriteria = { from: 0 };
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTableScroll() when false condition is satisfied", () => {
        component.isLoading = true;
        component.totalCount = 0;
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSelectCategory() when if condition is satisfied", () => {
        const spy = spyOn(component, "onSelectCategory").and.callThrough();
        const selectedCategory = { option: { value: "Basic Cat" } };
        component.onSelectCategory(selectedCategory as unknown as MatAutocompleteSelectedEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSelectCategory() when false condition is satisfied", () => {
        const spy = spyOn(component, "onSelectCategory").and.callThrough();
        component.onSelectCategory();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterSearch() when isLoading is false", () => {
        component.isLoading = false;
        const spy = spyOn(component, "onEnterSearch").and.callThrough();
        component.onEnterSearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterSearch() when isLoading is true", () => {
        component.isLoading = true;
        const spy = spyOn(component, "onEnterSearch").and.callThrough();
        component.onEnterSearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is not empty and totalCount is 0", () => {
        component.totalCount = 0;
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is not empty and totalCount is 10", () => {
        component.totalCount = 10;
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is empty", () => {
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource({ Instructions: { count: "" } });
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for shiftFocusToCart()", () => {
        const spy = spyOn(component, "shiftFocusToCart").and.callThrough();
        const mockEvent = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { closePanel: () => {} };
        component.autocomplete = childComponents as unknown as MatAutocompleteTrigger;
        component.shiftFocusToCart(mockEvent as unknown as KeyboardEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for shiftFocusToCart() when event is defined", () => {
        component.selectedRowIndex = 5;
        const mockEvent1 = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        const mockEvent2 = {
            focus() {
                return true;
            },
            scrollIntoViewIfNeeded() {
                return true;
            },
        };
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { closePanel: () => {} };
        component.autocomplete = childComponents as unknown as MatAutocompleteTrigger;
        const mockDataTable = { first: { _elementRef: { nativeElement: { tBodies: [{ rows: [mockEvent2] }] } } } };
        component.instructionDataTable = mockDataTable as unknown as QueryList<ElementRef>;
        component.totalCount = 10;
        component.combineDatasource(data);
        component.focusOnFirstDataRow(mockEvent1 as unknown as KeyboardEvent);
        expect(component.selectedRowIndex).toBe(0);
    });

    it("should resolve for errorHandler()", () => {
        const spy = spyOn(component, "errorHandler").and.callThrough();
        component.errorHandler(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for focusSearchTextBox()", () => {
        const spy = spyOn(component, "focusSearchTextBox").and.callThrough();
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { nativeElement: { focus: () => {} } };
        component.searchTextBox = childComponents;
        component.focusSearchTextBox();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for storeInstructionsSearchFilter", () => {
        const tabService: TabHelper = TestBed.inject(TabHelper);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(tabService, "getActiveTab").and.returnValue(MOCK_WORKSPACES[0]);
        component.storeInstructionsSearchFilter();
        expect(component.defaultCategory).toEqual("ALL");
    });

    xit("should resolve for getInstructionSearchFilter", () => {
        component.categoriesList = [{ CategoryName: "ALL" }];
        const mockData = cloneDeep(mockInstructionSearchFilter);
        component.searchFilterData = mockData.SearchFilters;
        let childComponents = { autocomplete: {options: {}}};
        component.autocomplete = childComponents as unknown as MatAutocompleteTrigger;
        component.getInstructionSearchFilter();
        expect(component.searchValue.value).toEqual("Lemon");
    });

    it("shoud get instruction as favorite getInstructionIsFavorite()", () => {
        const service: ExperimentHelper = TestBed.inject(ExperimentHelper);
        spyOn(service, "addFavoriteInstructions").and.returnValue(of([]));
        const spy = spyOn(component, "getInstructionIsFavorite").and.callThrough();
        component.getInstructionIsFavorite(instruction);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onInstructionRowClicked and set the Value()", () => {
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { nativeElement: { focus: () => {} } };
        component.instructionInput = childComponents;
        const mockData = cloneDeep(mockInstructionModelFilter);
        component.onInstructionRowClicked(mockData as InstructionSearchModel);
        expect(component.instruction.value).toEqual("Instruction");
    });

    it("should resolve for onRowClicked()", () => {
        const spy = spyOn(component, "onInstructionRowClicked").and.callThrough();
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { nativeElement: { focus: () => {} } };
        component.instructionInput = childComponents;
        component.onInstructionRowClicked({} as InstructionSearchModel);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSearchEnter()", () => {
        const spy = spyOn(component, "onSearchEnter").and.callThrough();
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { nativeElement: { focus: () => {} }, value: "test", ipc: "123", description: "test" };
        component.instructionInput = childComponents;
        component.onSearchEnter();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnChanges", () => {
        const changes = {
            selectedMiniEditorInst: {
                currentValue: "Selected Instruction",
            },
        } as unknown as SimpleChanges;
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });
});
