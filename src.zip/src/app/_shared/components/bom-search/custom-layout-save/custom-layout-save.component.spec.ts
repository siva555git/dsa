/* eslint-disable max-classes-per-file */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialogRef, MatDialog, MatDialogModule } from "@angular/material/dialog";
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder } from "@angular/forms";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { Observable, of } from "rxjs";
import { KEYBOARD_KEYS } from "@te-shared/constants";
import { MatomoService } from "@te-services/app-common";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { CustomLayoutSaveComponent } from "./custom-layout-save.component";
import { ColumnLayoutHelper } from "../../../../master-data/helpers/column.layout.helper";
import { BaseColumnHelper } from "../../base-column-layout/helper/base-column-helper";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { BrowserModule } from "@angular/platform-browser";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

// eslint-disable-next-line max-lines-per-function
describe("CustomLayoutSaveComponent", () => {
    let component: CustomLayoutSaveComponent;
    let fixture: ComponentFixture<CustomLayoutSaveComponent>;
    const layoutTypes = [
        {
            ColumnLayoutTypeID: 931,
            IsActive: "1",
            IsChecked: "0",
            IsDefault: "0",
            LayoutName: "&#@&%#$%",
            LayoutType: "MCL",
            UserColumnLayout: [{ Sequence: 1, ColumnName: "Stock", ColumnLayoutID: 17_090, ColumnLayoutTypeID: 931 }],
            ColumnHeader: "TEFL",
            ColumnLayoutID: 17_090,
            ColumnName: "Stock",
            ColumnSelectedValue: "TEFL",
            Sequence: 1,
            UserID: 66_198,
        },
    ];
    class MockDialogReference {
        public keydownEvents = () => {
            return of({ key: KEYBOARD_KEYS.ESCAPE });
        };

        public close = () => {
            return of();
        };
    }
    class MockBaseColumnHelper {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        getSavedColumnLayoutList(): Observable<any> {
            return of([{ IsDefault: "0", LayoutName: "test", UserColumnLayout: [] }]);
        }

        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        formatColumnLayoutInfo() {}
    }
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CustomLayoutSaveComponent],
            imports: [HttpClientTestingModule, FormsModule, ReactiveFormsModule, BrowserModule, MatDialogModule],
            providers: [
                ColumnLayoutHelper,
                UntypedFormBuilder,
                SpaceTrimPipe,
                {
                    provide: ColumnLayoutHelper,
                    useValue: {
                        // eslint-disable-next-line @typescript-eslint/no-empty-function
                        getColumnLayouts: () => layoutTypes,
                        checkLayoutDuplicate: () => true,
                    },
                },
                { provide: MatDialogRef, useClass: MockDialogReference },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
                    useValue: { open: () => {} },
                },
                { provide: BaseColumnHelper, useClass: MockBaseColumnHelper },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CustomLayoutSaveComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on createSaveCustomLayoutForm", () => {
        spyOn(component, "createSaveCustomLayoutForm").and.callThrough();
        const formResult = component.createSaveCustomLayoutForm();
        expect(formResult).toBeDefined();
    });

    it("should call on onEnterLayoutName", () => {
        spyOn(component, "onEnterLayoutName").and.callThrough();
        component.onEnterLayoutName();
        expect(component).toBeTruthy();
    });

    it("should call on onSave", () => {
        const spy = spyOn(component, "onSave").and.callThrough();
        component.onSave();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnInit", () => {
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });
});
