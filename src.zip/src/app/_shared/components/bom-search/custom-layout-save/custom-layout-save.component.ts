import { Component, OnInit } from "@angular/core";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { MatDialogRef } from "@angular/material/dialog";
import { filter } from "rxjs/operators";
import { Subscription } from "rxjs";
import { MatomoService } from "@te-services/app-common/matomo/matomo.service";
import { MatomoCategory, MatomoAction, MatomoLabel } from "@te-shared/enums";
import { ColumnLayoutHelper } from "../../../../master-data/helpers/column.layout.helper";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { KEYBOARD_KEYS } from "../../../constants/common.constant";

@Component({
    selector: "app-custom-layout-save",
    templateUrl: "./custom-layout-save.component.html",
})
export class CustomLayoutSaveComponent implements OnInit {
    public customLayoutSaveForm: UntypedFormGroup;

    public checkDuplicate = false;

    public checkEmptyForm = false;

    private componentSubscriptions: Subscription = new Subscription();

    constructor(
        private readonly dialogReference: MatDialogRef<CustomLayoutSaveComponent>,
        private readonly formBuilder: UntypedFormBuilder,
        private readonly columnLayoutHelper: ColumnLayoutHelper,
        private readonly spaceTrimPipe: SpaceTrimPipe,
        private readonly matomoService: MatomoService,
    ) {}

    ngOnInit(): void {
        this.componentSubscriptions.add(
            this.dialogReference
                .keydownEvents()
                .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.dialogReference.close();
                }),
        );
        this.customLayoutSaveForm = this.createSaveCustomLayoutForm();
        this.matomoService.trackEvent(MatomoCategory.CUSTOM_LAYOUT_SAVE, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    public ngOnDestroy(): void {
        this.componentSubscriptions.unsubscribe();
    }

    /**
     * Method to intiate the form group
     * @memberof CustomLayoutSaveComponent
     */
    public createSaveCustomLayoutForm = (): UntypedFormGroup => {
        return this.formBuilder.group({
            LayoutName: new UntypedFormControl("", [Validators.required]),
        });
    };

    /**
     * Method to validate layout name
     * @returns {void}
     * @memberof CustomLayoutSaveComponent
     */
    public onEnterLayoutName(): void {
        if (this.spaceTrimPipe.transform(this.customLayoutSaveForm.value?.LayoutName)) {
            this.checkEmptyForm = false;
            this.checkDuplicate = this.columnLayoutHelper.checkLayoutDuplicate(this.customLayoutSaveForm);
        } else {
            this.checkEmptyForm = true;
            this.checkDuplicate = false;
        }
    }

    /**
     * Method to save newly created column layout
     * @returns {void}
     * @memberof CustomLayoutSaveComponent
     */
    public onSave(): void {
        const saveData = { formData: this.customLayoutSaveForm.value, screenActive: true };
        this.dialogReference.close(saveData);
        this.matomoService.trackEvent(MatomoCategory.CUSTOM_LAYOUT_SAVE, MatomoAction.CLICK, MatomoLabel.SAVE);
    }
}
