/* eslint-disable max-lines */
/* eslint-disable no-param-reassign */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { SelectionModel } from "@angular/cdk/collections";
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, QueryList, ViewChild, ViewChildren, OnDestroy } from "@angular/core";
import { UntypedFormControl } from "@angular/forms";
import { MatAutocompleteSelectedEvent, MatAutocompleteTrigger } from "@angular/material/autocomplete";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { WorkSpaces } from "@te-shared/models/create-tab.model";
import { clone, cloneDeep, delay, includes, map, orderBy, toLower } from "lodash";
import * as moment from "moment";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { Subscription } from "rxjs";
import { debounceTime, filter, map as rxMap, switchMap, tap, startWith } from "rxjs/operators";
import { MatomoCategory, MatomoAction, MatomoLabel } from "@te-shared/enums";
import { EMPTY } from "../../../../app.constant";
import { ZERO_WITH_DECIMAL } from "../../../../creative-review/creative-review.constant";
import { AppDataService, MatomoService } from "../../../../_services";
import {
    ADD_TO_CART,
    BOM_TYPE,
    COLUMN_ID,
    PRODUCT_SEARCH_CONSTANTS,
    REFERENCE_ERRORS,
    UNAPPROVED_ID,
    UNAPPROVED_SEARCH,
    UNAPPROVED_SEARCH_TABLE,
    MIN_SEARCH_VALUE_LENGTH,
} from "../../../constants";
import { MARK_FOR_UNDELETE_FLAG } from "../../../constants/experiment.constant";
import { SearchDrawerHelper } from "../../../helpers/search-drawer.helper";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { DisplayGridColumnModel } from "../../display-grid-data/display.grid.model";

@Component({
    selector: "app-unapproved-search",
    templateUrl: "./unapproved-search.component.html",
})
export class UnapprovedSearchComponent implements OnInit, OnDestroy {
    public categoriesList: any = [];

    public searchResultList: any = [];

    public searchCriteria: any;

    public selectedCategory: any;

    public defaultCategory = UNAPPROVED_SEARCH.DEFAULT_CATEGORY;

    public defaultClause = UNAPPROVED_SEARCH.DEFAULT_SEARCH_CLAUSE;

    public addToCart = ADD_TO_CART;

    public dataSource = [];

    public searchValue: UntypedFormControl = new UntypedFormControl();

    public Category: UntypedFormControl = new UntypedFormControl(UNAPPROVED_SEARCH.DEFAULT_CATEGORY);

    public displayedColumns: string[] = [
        UNAPPROVED_SEARCH.UNAPPROVEDID,
        UNAPPROVED_SEARCH.DESCRIPTION,
        UNAPPROVED_SEARCH.COSTKG,
        UNAPPROVED_SEARCH.COSTKGCURRENCY,
        UNAPPROVED_SEARCH.Category,
        UNAPPROVED_SEARCH.MarketCode,
        UNAPPROVED_SEARCH.CreatedBy,
        UNAPPROVED_SEARCH.CreatedOn,
    ];

    public start = PRODUCT_SEARCH_CONSTANTS.START_FROM;

    public limit = PRODUCT_SEARCH_CONSTANTS.LIMIT;

    public end = this.limit + this.start;

    public totalCount = 0;

    public isLoading = false;

    public noDataFound = false;

    @ViewChild("searchTextBox") searchTextBox: ElementRef;

    @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;

    public searchCheckBoxList = cloneDeep(UNAPPROVED_SEARCH.UNAPPROVED_SEARCH_CHECKBOX_LIST);

    public defaultCheckbox = clone(UNAPPROVED_SEARCH.DEFAULT_CHECKBOX_SELECTION);

    public unApprovedHeaderList = UNAPPROVED_SEARCH_TABLE;

    @Input() public searchFilterData;

    @Output()
    public emitCartData = new EventEmitter();

    @Output()
    public focusCartData = new EventEmitter();

    @ViewChildren("unApprovedDataTable") unApprovedDataTable: QueryList<ElementRef>;

    public selectedRowIndex = -1;

    public selection: SelectionModel<any> = new SelectionModel();

    public displayGridColumns: DisplayGridColumnModel[];

    private componentSubscriptions: Subscription = new Subscription();

    public currentWorkspace: WorkSpaces;

    constructor(
        private readonly appDataService: AppDataService,
        private readonly toastrService: ToastrService,
        private readonly logger: NGXLogger,
        private readonly spaceTrim: SpaceTrimPipe,
        public tabHelper: TabHelper,
        private readonly matomoService: MatomoService,
    ) {}

    public ngOnInit(): void {
        this.displayGridColumns = SearchDrawerHelper.configUnapprovedHeaderColumns();
        this.displayedColumns = map(this.displayGridColumns, COLUMN_ID);
        this.getUnapprovedCategories();
        this.bindAttributesControl();
        this.matomoService.trackEvent(MatomoCategory.UNAPPROVED_SEARCH, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    public ngOnDestroy(): void {
        this.componentSubscriptions.unsubscribe();
    }

    /**
     * Method to shift focus to cart from search results table
     *
     * @param {KeyboardEvent} event
     * @memberof UnapprovedSearchComponent
     */
    public shiftFocusToCart(event: KeyboardEvent): void {
        event.stopPropagation();
        event.preventDefault();
        this.autocomplete.closePanel();
        this.focusCartData.emit();
    }

    /**
     * Method to switch page focus to first data row
     *
     * @param {KeyboardEvent} [event]
     * @memberof UnapprovedSearchComponent
     */
    public focusOnFirstDataRow(event?: KeyboardEvent): void {
        this.autocomplete.closePanel();
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        if (this.dataSource?.length > 0) {
            this.selectedRowIndex = 0;
            this.selection.select(this.dataSource[this.selectedRowIndex]);

            BomSearchHelper.focusSelectedRowInTable(this.unApprovedDataTable, this.selectedRowIndex);
        }
    }

    /**
     * Method to switch page focus to search text box
     *
     * @memberof UnapprovedSearchComponent
     */
    public focusSearchTextBox(shouldSelect = false): void {
        BomSearchHelper.focusOrSelectTextbox(this.searchTextBox, shouldSelect);
    }

    /**
     * Method to get the list of the ipc selection
     *
     * @memberof UnapprovedSearchComponent
     */
    public getUnapprovedCategories(): void {
        this.componentSubscriptions.add(
            this.appDataService.get(this.appDataService.url.getUnapprovedCategories, []).subscribe({
                next: (result) => {
                    if (result) {
                        const defaultCategory = {
                            CategoryID: UNAPPROVED_SEARCH.DEFAULT_CATEGORY,
                            Description: UNAPPROVED_SEARCH.DEFAULT_CATEGORY,
                        };
                        this.categoriesList = result.Categories
                            ? [defaultCategory, ...orderBy(result.Categories, UNAPPROVED_SEARCH.DESCRIPTION)]
                            : [];
                    }
                    this.getUnApprovedSearchFilters();
                },
                error: (error) => {
                    this.errorHandler(error);
                },
            }),
        );
    }

    /**
     * Method to search the unapproveds
     *
     * @memberof UnapprovedSearchComponent
     */
    public searchUnapproved(): void {
        this.componentSubscriptions.add(
            this.appDataService.post(this.appDataService.url.getUnapprovedList, [], this.searchCriteria).subscribe({
                next: (result) => {
                    this.isLoading = false;
                    this.combineDatasource(result);
                },
                error: (error) => {
                    this.isLoading = false;
                    this.errorHandler(error);
                },
            }),
        );
    }

    /**
     * Method to bind the valueChanges functions for component forms
     *
     * @memberof UnapprovedSearchComponent
     */
    public bindAttributesControl() {
        this.searchResultList = this.Category.valueChanges.pipe(
            startWith(""),
            rxMap((value) => BomSearchHelper.filterCategoryValues(this.categoriesList, "Description", value)),
        );

        this.componentSubscriptions.add(
            this.searchValue.valueChanges
                .pipe(
                    filter((selectedValue) => {
                        this.totalCount = 0;
                        this.isLoading =
                            selectedValue?.length >= MIN_SEARCH_VALUE_LENGTH && this.defaultCheckbox.length > 0 && this.searchValue.dirty;
                        this.dataSource = [];
                        this.selectedRowIndex = -1;
                        return this.isLoading;
                    }),
                    debounceTime(500),
                    tap(() => {
                        this.onSelectCategory();
                    }),
                    // eslint-disable-next-line consistent-return
                    switchMap((): any => {
                        return this.appDataService.post(this.appDataService.url.getUnapprovedList, [], this.searchCriteria);
                    }),
                )
                .subscribe({
                    next: (result: any) => {
                        this.isLoading = false;
                        this.combineDatasource(result);
                    },
                    error: (error) => {
                        this.isLoading = false;
                        this.errorHandler(error);
                    },
                }),
        );
    }

    /**
     * Method to prepare the datasource
     *
     * @memberof UnapprovedSearchComponent
     */
    public combineDatasource(data: any): void {
        if (data?.Unapproved?.count) {
            // eslint-disable-next-line unicorn/prefer-spread
            this.dataSource = TasteEditorUtilClass.getUniqueListBy(this.dataSource.concat(data.Unapproved.rows), UNAPPROVED_ID);
            this.dataSource.forEach((unApprovedData) => {
                unApprovedData.Category = unApprovedData.CategoryName?.Category;
                unApprovedData.CreatedOn = unApprovedData.CreatedOn
                    ? moment(new Date(unApprovedData.CreatedOn)).format(UNAPPROVED_SEARCH.CreatedOn_Format)
                    : "";
                unApprovedData.CreatedBy = `${unApprovedData.CreatedByUser?.FirstName} - ${unApprovedData.CreatedByUser?.Surname}`;
            });
            if (!this.totalCount) {
                this.totalCount = data.Unapproved.count;
                this.noDataFound = false;
            }
        } else {
            this.noDataFound = true;
        }
    }

    /**
     * Method to enter the search button
     *
     * @memberof UnapprovedSearchComponent
     */
    public onEnterSearch(): void {
        if (this.isLoading || this.defaultCheckbox.length === 0) return;
        this.Category?.setValue(this.selectedCategory ?? this.defaultCategory);
        this.isLoading = true;
        this.onSelectCategory();
        this.searchUnapproved();
    }

    /**
     * Method to set the search criteria
     *
     * @param {*} selectedCategory
     * @returns {*}
     * @memberof UnapprovedSearchComponent
     */
    public onSelectCategory(selectedCategory?: MatAutocompleteSelectedEvent): void {
        delay(() => {
            this.searchTextBox.nativeElement.focus();
        }, 0);
        this.resetAttributes();
        if (selectedCategory) {
            this.selectedCategory = selectedCategory.option.value.toString();
        }
        const categoryCriteria =
            this.categoriesList.find((category) => category.Description === this.selectedCategory)?.CategoryID.toString() ??
            this.defaultCategory;
        this.searchCriteria = {
            category: categoryCriteria,
            description: this.spaceTrim.transform(this.searchValue.value),
            searchBy: this.defaultCheckbox,
            searchType: this.defaultClause,
            offset: PRODUCT_SEARCH_CONSTANTS.START_FROM,
            limit: PRODUCT_SEARCH_CONSTANTS.LIMIT,
        };
    }

    /**
     * Method to reset the values
     *
     * @memberof UnapprovedSearchComponent
     */
    public resetAttributes(): void {
        this.dataSource = [];
        this.selectedRowIndex = -1;
        this.totalCount = 0;
        this.start = PRODUCT_SEARCH_CONSTANTS.START_FROM;
        this.limit = PRODUCT_SEARCH_CONSTANTS.LIMIT;
        this.end = this.limit + this.start;
        this.noDataFound = false;
    }

    /**
     * Method to invoke when scrolling the table
     *
     * @param {*} event
     * @returns {*}
     * @memberof UnapprovedSearchComponent
     */
    public onTableScroll(event: any): any {
        const tableViewHeight = event.target.offsetHeight;
        const tableScrollHeight = event.target.scrollHeight;
        const scrollLocation = event.target.scrollTop;

        // If the user has scrolled within 200px of the bottom, add more data
        const buffer = 200;
        const limit = tableScrollHeight - tableViewHeight - buffer;
        if (scrollLocation > limit && !this.isLoading && this.dataSource.length < this.totalCount) {
            this.isLoading = true;
            this.searchUnapproved();
            this.updateIndex();
        }
    }

    /**
     * Method to update the count of start and limit
     *
     * @memberof UnapprovedSearchComponent
     */
    public updateIndex() {
        this.start = this.end;
        this.end = this.limit + this.start;
        this.searchCriteria.offset = this.start;
    }

    /**
     * Method to handle errors
     *
     * @memberof UnapprovedSearchComponent
     */
    public errorHandler(error: any) {
        this.toastrService.error(REFERENCE_ERRORS.PRODUCT_SEARCH_ERROR);
        this.logger.error(error);
    }

    /**
     * Method to add the unapproved to cart
     *
     * @memberof UnapprovedSearchComponent
     */
    public onAddUnapprovedToCart(element): void {
        const cartUnpprovedData = {
            ExpFormulaID: EMPTY,
            SUBCode: element.UnapprovedID,
            ipc: element.UnapprovedID,
            ingredientName: element.Description,
            Instruction: element.Description,
            UnapprovedDescription: element.Description,
            description: element.Description,
            code: element.UnapprovedID,
            SUBType: BOM_TYPE.UNAPPROVED,
            Parts: ZERO_WITH_DECIMAL,
            IsDelete: MARK_FOR_UNDELETE_FLAG,
        };
        this.emitCartData.emit(cartUnpprovedData);
        this.matomoService.trackEvent(MatomoCategory.UNAPPROVED_SEARCH, MatomoAction.CLICK, MatomoLabel.ON_ADD_UNAPPROVED_TO_CART);
    }

    /**
     * Method to select the checkbox
     *
     * @param {*} event
     * @param {string} value
     * @returns {*}
     * @memberof UnapprovedSearchComponent
     */
    // eslint-disable-next-line consistent-return
    public onSelectionList(event: any, value: string): any {
        this.searchCheckBoxList.forEach((checkBox) => {
            if (value === checkBox.searchCriteria) checkBox.checked = event.checked;
        });
        const lowerCaseValue = toLower(value);
        const hasDefaultCheckboxValues = includes(this.defaultCheckbox, lowerCaseValue);
        if (!hasDefaultCheckboxValues && event.checked) {
            this.defaultCheckbox.push(lowerCaseValue);
        } else {
            const index = this.defaultCheckbox.indexOf(lowerCaseValue);
            this.defaultCheckbox.splice(index, 1);
        }
    }

    /**
     * Method to store the search filters in session
     * @returns {void}
     * @memberof UnapprovedSearchComponent
     */
    public storeUnApprovedSearchFilters(): void {
        const selectedCategory = this.categoriesList?.find((item) => item.Description === this.selectedCategory);
        this.currentWorkspace = this.tabHelper.getActiveTab();
        this.currentWorkspace.SearchFilters.UnApproved = {
            category: selectedCategory?.Description,
            usingOption: this.defaultClause,
            searchText: this.searchValue.value,
            // eslint-disable-next-line unicorn/no-useless-spread
            checkBox: [...this.searchCheckBoxList.filter((checkBox) => checkBox.checked).map((checkBox) => checkBox.searchCriteria)],
        };
    }

    /**
     * Method to get the search filters values from session
     * @returns {void}
     * @memberof UnapprovedSearchComponent
     */
    public getUnApprovedSearchFilters(): void {
        if (this.searchFilterData && this.searchFilterData?.UnApproved) {
            const unApproved = this.searchFilterData.UnApproved;
            const selectedCategory = this.categoriesList.find((item) => item.Description === unApproved.category);
            this.defaultCategory = selectedCategory?.Description ?? this.defaultCategory;
            this.searchCheckBoxList.forEach((searchCheckBox) => {
                const checkBox = searchCheckBox;
                checkBox.checked = unApproved.checkBox.includes(checkBox.searchCriteria);
            });
            this.defaultClause = unApproved.usingOption;
            this.searchValue?.setValue(unApproved.searchText);
            this.Category?.setValue(this.defaultCategory);
            BomSearchHelper.selectAutocompleteOption(this.autocomplete);
        }
    }
}
