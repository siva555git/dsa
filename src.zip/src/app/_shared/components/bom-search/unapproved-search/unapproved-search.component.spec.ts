import { HttpClient, HttpHandler } from "@angular/common/http";
import { CUSTOM_ELEMENTS_SCHEMA, ElementRef, QueryList } from "@angular/core";
import { ComponentFixture, TestBed, fakeAsync, tick, waitForAsync } from "@angular/core/testing";
import {
    MatAutocomplete,
    MatAutocompleteModule,
    MatAutocompleteSelectedEvent,
    MatAutocompleteTrigger,
} from "@angular/material/autocomplete";
import { Router } from "@angular/router";
import { ExperimentEditorHelper } from "@te-experiment-editor/helpers/experiment-editor.helper";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { AppCacheHelper } from "@te-shared/helpers/app-cache.service";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { MockAppcacheHelper } from "@te-testing/mock-app-cache-helper";
import { MockGridapiService } from "@te-testing/mock-gridapi.service";
import { mockUnApprovedSearchFilter, MOCK_WORKSPACES } from "@te-testing/mock-tabhelper-data";
import { OAuthLogger, OAuthService, UrlHelperService } from "angular-oauth2-oidc";
import { cloneDeep } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { MockExperimentAccessHelper } from "@te-testing/mock-experiment-access.helper";
import { TasteEditorDialogService } from "@te-shared/helpers/te-dialog.service";
import { MatDialog } from "@angular/material/dialog";
import { MockTabHelperService } from "@te-testing/mock-tabhelper.service";
import { of } from "rxjs";
import { MatomoService } from "@te-services/app-common";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { ReactiveFormsModule } from "@angular/forms";
import { MatTableModule } from "@angular/material/table";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { MockAppDataService } from "../../../../testing/mock-app.data.service";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { MockToastrService } from "../../../../testing/mock-toastr.service";
import { AppDataService } from "../../../../_services/app-data/app.data.service";
import { AppStateService } from "../../../../_services/app-state/app.state.service";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { UnapprovedSearchComponent } from "./unapproved-search.component";

// eslint-disable-next-line max-lines-per-function
describe("UnapprovedSearchComponent", () => {
    let component: UnapprovedSearchComponent;
    let fixture: ComponentFixture<UnapprovedSearchComponent>;
    const mockRouter = { navigate: jasmine.createSpy("navigate") };
    const event = {
        target: {
            offsetHeight: 400,
            scrollHeight: 500,
            scrollTop: 1000,
        },
    };
    const dialogReferenceStub = {
        afterClosed() {
            return of(); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    const data = { Unapproved: { count: 10, rows: [{ UnapprovedID: 12 }] } };
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [UnapprovedSearchComponent, MatAutocomplete],
            providers: [
                SpaceTrimPipe,
                { provide: AppDataService, useClass: MockAppDataService },
                HttpClient,
                HttpHandler,
                { provide: AppStateService, useClass: MockAppStateService },
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                { provide: ToastrService, useClass: MockToastrService },
                { provide: NGXLogger, useClass: MockLoggerService },
                AppBroadCastService,
                { provide: Router, useValue: mockRouter },
                { provide: ExperimentEditorHelper, useValue: {} },
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: AppCacheHelper, useClass: MockAppcacheHelper },
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                TasteEditorDialogService,
                { provide: TabHelper, useClass: MockTabHelperService },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [MatAutocompleteModule, ReactiveFormsModule, MatTableModule],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UnapprovedSearchComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        component.categoriesList = [
            { CategoryID: 88, Description: "ALCOHOLIC BEVERAGES" },
            { CategoryID: 91, Description: "COMPETITOR FLAVORS" },
        ];
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for onAddUnapprovedToCart()", () => {
        const item = { ipc: "123", description: "test" };
        const spy = spyOn(component, "onAddUnapprovedToCart").and.callThrough();
        component.onAddUnapprovedToCart(item);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTableScroll() when if condition is satisfied", () => {
        component.isLoading = false;
        component.totalCount = 100;
        component.searchCriteria = { from: 0 };
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTableScroll() when false condition is satisfied", () => {
        component.isLoading = true;
        component.totalCount = 0;
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSelectCategory() when if condition is satisfied", () => {
        const spy = spyOn(component, "onSelectCategory").and.callThrough();
        const selectedCategory = { option: { value: "Basic Cat" } };
        component.onSelectCategory(selectedCategory as unknown as MatAutocompleteSelectedEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSelectCategory() when false condition is satisfied", () => {
        const spy = spyOn(component, "onSelectCategory").and.callThrough();
        component.onSelectCategory();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterSearch() when isLoading is false", () => {
        component.isLoading = false;
        const spy = spyOn(component, "onEnterSearch").and.callThrough();
        component.onEnterSearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterSearch() when isLoading is true", () => {
        component.isLoading = true;
        const spy = spyOn(component, "onEnterSearch").and.callThrough();
        component.onEnterSearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is not empty and totalCount is 0", () => {
        component.totalCount = 0;
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is not empty and totalCount is 10", () => {
        component.totalCount = 10;
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is empty", () => {
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource({ Unapproved: { count: "" } });
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for shiftFocusToCart()", () => {
        const spy = spyOn(component, "shiftFocusToCart").and.callThrough();
        const mockEvent = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { closePanel: () => {} };
        component.autocomplete = childComponents as unknown as MatAutocompleteTrigger;
        component.shiftFocusToCart(mockEvent as unknown as KeyboardEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for shiftFocusToCart() when event is defined", () => {
        component.selectedRowIndex = 5;
        const mockEvent1 = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        const mockEvent2 = {
            focus() {
                return true;
            },
            scrollIntoViewIfNeeded() {
                return true;
            },
        };
        const mockDataTable = { first: { _elementRef: { nativeElement: { tBodies: [{ rows: [mockEvent2] }] } } } };
        component.unApprovedDataTable = mockDataTable as unknown as QueryList<ElementRef>;
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { closePanel: () => {} };
        component.autocomplete = childComponents as unknown as MatAutocompleteTrigger;
        component.totalCount = 10;
        component.combineDatasource(data);
        component.focusOnFirstDataRow(mockEvent1 as unknown as KeyboardEvent);
        expect(component.selectedRowIndex).toBe(0);
    });

    it("should resolve for errorHandler()", () => {
        const spy = spyOn(component, "errorHandler").and.callThrough();
        component.errorHandler(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for focusSearchTextBox()", () => {
        const spy = spyOn(component, "focusSearchTextBox").and.callThrough();
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { nativeElement: { focus: () => {} } };
        component.searchTextBox = childComponents;
        component.focusSearchTextBox();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for storeUnApprovedSearchFilters", () => {
        component.categoriesList = [{ CategoryID: "213" }];
        const tabService: TabHelper = TestBed.inject(TabHelper);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(tabService, "getActiveTab").and.returnValue(MOCK_WORKSPACES[0]);
        component.storeUnApprovedSearchFilters();
        expect(component.defaultClause).toEqual("contains");
    });

    it("should resolve for getUnApprovedSearchFilters", fakeAsync(() => {
        component.categoriesList = [{ CategoryID: "213" }];
        const mockData = cloneDeep(mockUnApprovedSearchFilter);
        component.searchFilterData = mockData.SearchFilters;
        const childComponents = {
            autocomplete: {
                options: {
                    toArray: () => [{ select: jasmine.createSpy() }],
                },
            },
        };
        component.autocomplete = childComponents as unknown as MatAutocompleteTrigger;
        component.getUnApprovedSearchFilters();
        tick(0);
        spyOn(BomSearchHelper, "selectAutocompleteOption").and.callThrough();
        expect(component.searchValue.value).toEqual("Lemon");
    }));
});
