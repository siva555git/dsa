/* eslint-disable max-classes-per-file */
/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-empty-function */
/* eslint-disable id-length */
/* eslint-disable max-lines-per-function */
/* eslint-disable class-methods-use-this */
import { CdkDragDrop } from "@angular/cdk/drag-drop";
import { CUSTOM_ELEMENTS_SCHEMA, ElementRef, NO_ERRORS_SCHEMA, QueryList } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { CartItemModel, SearchType } from "@te-experiment-editor/models/experiment-editor.model";
import { BOM_MENU, KEYBOARD_KEYS } from "@te-shared/constants";
import { AppCacheHelper } from "@te-shared/helpers/app-cache.service";
import { MiniEditorSuggestionHelper } from "@te-shared/helpers/mini-editor-suggestion.helper";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { MockAppcacheHelper } from "@te-testing/mock-app-cache-helper";
import { MockGridapiService } from "@te-testing/mock-gridapi.service";
import { MockMiniEditorSuggestionHelper } from "@te-testing/mock-mini-editor-suggestion.helper";
import { MockProductDataCostHelper } from "@te-testing/mock-product-data-cost-helper";
import { MOCK_WORKSPACES } from "@te-testing/mock-tabhelper-data";
import { cloneDeep } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { of, Observable } from "rxjs";
import { DialogHelper } from "@te-shared/helpers/dialog-helper";
import { CreativeReviewHelper } from "src/app/creative-review/helpers/creative-review-helper";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { MockExperimentAccessHelper } from "@te-testing/mock-experiment-access.helper";
import { TasteEditorDialogService } from "@te-shared/helpers/te-dialog.service";
import { MockTabHelperService } from "@te-testing/mock-tabhelper.service";
import { MatomoService } from "@te-services/app-common";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { ExperimentEditorHelper } from "../../../experiment-editor/helpers/experiment-editor.helper";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { MockAppStateService } from "../../../testing/mock-app.state.service";
import { mockGridDataSource } from "../../../testing/mock-context-menu.helper";
import { MockDialogReference } from "../../../testing/mock-dialog.reference";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { MockToastrService } from "../../../testing/mock-toastr.service";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { AppDataService } from "../../../_services/app-data/app.data.service";
import { AppStateService } from "../../../_services/app-state/app.state.service";
import { SearchButtonPipe } from "../../pipes/search-button.pipe";
import { BaseColumnHelper } from "../base-column-layout/helper/base-column-helper";
import { ProductDataCostHelper } from "../product-data/product-data-cost/product-data-cost.helper";
import { BomSearchComponent } from "./bom-search.component";
import { ExperimentsSearchComponent } from "./experiments-search/experiments-search.component";
import { InstructionSearchComponent } from "./instruction-search/instruction-search.component";
import { ProductSearchComponent } from "./product-search/product-search.component";
import { UnapprovedSearchComponent } from "./unapproved-search/unapproved-search.component";

describe("BomSearchComponent", () => {
    let component: BomSearchComponent;
    let fixture: ComponentFixture<BomSearchComponent>;
    const mockRouter = { navigate: jasmine.createSpy("navigate") };
    const item = {
        description: "TALLOW",
        instruction: undefined,
        SUBCode: "10722088",
        type: "I",
        isSolution: true,
        isFema: false,
        isEnum: false,
        SUBType: "I",
        isNewlyAddedItem: false,
        otherdetails: {
            specs: [
                {
                    speccode: "1-DECANOL",
                },
            ],
        },
    };
    const childComponents = {
        searchTextBox: { nativeElement: { focus: () => {} } },
        storeProductSearchFilters: () => {},
        storeInstructionsSearchFilter: () => {},
        storeUnApprovedSearchFilters: () => {},
        storeExperimentSearchFilter: () => {},
        storeSearchColumnHeaderWidth: () => {},
        focusOnFirstDataRow: () => {},
    };

    const dialogData = {
        activeExperiment: {},
        gridSelectedExpCodes: {},
        filteredGridDataSource: {},
        facility: [],
        isIpcView: false,
        criteria: {},
        type: 1,
        bomDetails: cloneDeep(mockGridDataSource),
    };
    class MockBaseColumnHelper {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        getSavedColumnLayout(): Observable<any> {
            return of([{ IsDefault: "0", LayoutName: "test", UserColumnLayout: [] }]);
        }

        formatColumnLayoutInfo() {}
    }
    class MockSecurityHelper {
        hasPermission = () => {
            return true;
        };
    }

    const dialogReferenceStub = {
        afterClosed() {
            return of(); // this can be whatever, esp handy if you actually care about the value returned
        },
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [BomSearchComponent],
            imports: [BrowserAnimationsModule],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
            providers: [
                { provide: BaseColumnHelper, useClass: MockBaseColumnHelper },
                { provide: ExperimentEditorHelper, useValue: {} },
                { provide: AppDataService, useClass: MockAppDataService },
                { provide: ToastrService, useClass: MockToastrService },
                { provide: NGXLogger, useClass: MockLoggerService },
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: MAT_DIALOG_DATA, useValue: dialogData },
                { provide: AppStateService, useClass: MockAppStateService },
                AppBroadCastService,
                SearchButtonPipe,
                { provide: MiniEditorSuggestionHelper, useClass: MockMiniEditorSuggestionHelper },
                { provide: ProductDataCostHelper, useClass: MockProductDataCostHelper },
                { provide: Router, useValue: mockRouter },
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: AppCacheHelper, useClass: MockAppcacheHelper },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => {} },
                },
                DialogHelper,
                CreativeReviewHelper,
                {
                    provide: SecurityHelper,
                    useClass: MockSecurityHelper,
                },
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                TasteEditorDialogService,
                { provide: TabHelper, useClass: MockTabHelperService },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BomSearchComponent);
        component = fixture.componentInstance;
        component.selectedCartItemIndex = 5;
        component.cartLists = [
            {
                Parts: "5",
                ExpFormulaID: "231234",
                SUBType: "E",
                Instruction: "test",
                IsDelete: 1,
            },
            {
                Parts: "51",
                ExpFormulaID: "231234",
                SUBType: "E",
                Instruction: "test",
                IsDelete: 1,
            },
        ];
        spyOn(component, "getSearchColumnHeaderWidth").and.returnValue();
        fixture.detectChanges();
        component.productSearchComp = childComponents as unknown as ProductSearchComponent;
        component.instructionSearchComp = childComponents as unknown as InstructionSearchComponent;
        component.unapprovedSearchComp = childComponents as unknown as UnapprovedSearchComponent;
        component.experimentSearchComp = childComponents as unknown as ExperimentsSearchComponent;
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for onRemoveCartItem()", () => {
        const spy = spyOn(component, "onRemoveCartItem").and.callThrough();
        component.onRemoveCartItem(item, 1);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onRemoveCartItem() NewlyAddedItem", () => {
        const cartItem = cloneDeep(item);
        cartItem.isNewlyAddedItem = true;
        component.onRemoveCartItem(item, 0);
        expect(component.cartLists.indexOf(cartItem as unknown as CartItemModel)).toBe(-1);
    });

    it("should resolve for onAddToCart()", () => {
        component.bomSearchModel = {
            searchType: 1,
            softDeletedItems: [],
            deletedItems: [],
            data: dialogData,
            cartListCopy: [],
        };
        const spy = spyOn(component, "onAddToCart").and.callThrough();
        component.onAddToCart(item as unknown as CartItemModel);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onInsertToBom()", () => {
        spyOn(component, "storeTabDetails").and.returnValue();
        component.onInsertToBom();
        expect(component.cartLists).toEqual([]);
    });

    it("should resolve for onCancelDrawer()", () => {
        spyOn(component, "storeTabDetails").and.returnValue();
        component.onCancelDrawer();
        expect(component.productSearchComp).toBeDefined();
    });

    it("should resolve for switchToCart() ipcView", () => {
        const data = { type: SearchType.ipcView };
        component.data = data;
        component.switchToCart();
        expect(component.currentListItem).toBe(BOM_MENU.BOM_LAYOUT);
    });

    it("should resolve for switchToCart() openProductOrExperiment", () => {
        component.data.type = SearchType.openProductOrExperiment;
        component.switchToCart(true);
        expect(component.currentListItem).toBe(BOM_MENU.BOM_CART);
    });

    it("should resolve for layoutExpandCollapse()", () => {
        const spy = spyOn(component, "layoutExpandCollapse").and.callThrough();
        component.layoutExpandCollapse("bomCart");
        expect(spy).toHaveBeenCalled();
    });

    xit("should resolve for onTabChange()", () => {
        component.tabGroup.selectedIndex = 1;
        component.currentListItem = BOM_MENU.BOM_LAYOUT;
        component.onTabChange();
        expect(component.disableBomMenu).toBeTruthy();
    });

    it("should resolve for getCartDataFromGrid()", () => {
        component.data.bomDetails = dialogData.bomDetails;
        const result = component.getCartDataFromGrid();
        expect(result.length).toBe(2);
    });

    it("should resolve for drop()", () => {
        const spy = spyOn(component, "drop").and.callThrough();
        const cdkDragDrop: CdkDragDrop<string[]> = {
            previousIndex: 1,
            currentIndex: 2,
            item: undefined,
            container: undefined,
            previousContainer: undefined,
            isPointerOverContainer: false,
            dropPoint: {
                x: 1,
                y: 5,
            },
            distance: {
                x: 1,
                y: 5,
            },
        } as CdkDragDrop<string[]>;
        component.drop(cdkDragDrop);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for focusOnSelectedCartItem()", () => {
        const spy = spyOn(component, "focusOnSelectedCartItem").and.callThrough();
        component.focusOnSelectedCartItem();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onClickParts()", () => {
        const spy = spyOn(component, "onClickParts").and.callThrough();
        const mockEvent = {
            target: {
                value: "",
                select() {
                    return true;
                },
            },
        };
        component.selectedCartItemIndex = 6;
        component.onClickParts(5, mockEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for triggerEditSuggestPopup()", () => {
        const spy = spyOn(component, "triggerEditSuggestPopup").and.callThrough();
        component.triggerEditSuggestPopup(item);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for removeDeletedItem()", () => {
        const spy = spyOn(component, "removeDeletedItem").and.callThrough();
        component.removeDeletedItem();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onClickExpandCollapse()", () => {
        component.expandProductSidebar = true;
        spyOn(component, "layoutExpandCollapse").and.returnValue();
        const spy = spyOn(component, "onClickExpandCollapse").and.callThrough();
        spyOn(component, "onSelectCartItem").and.returnValue();
        component.onClickExpandCollapse();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for listenSuggestionChanges()", () => {
        const bom = {
            FormulaSeq: 20,
            SUBCode: "123456",
            SUBType: "I",
            otherdetails: [],
            description: "ALLYL",
        };
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        service.editSuggestSubject.next({
            action: "REPLACE",
            suggestionItem: bom,
            suggestedBom: { FormulaSeq: 20 },
            isMiniEditor: true,
            parentAttribute: { ipc: "70801094" },
        });
        const spy = spyOn(component, "listenSuggestionChanges").and.callThrough();
        component.listenSuggestionChanges();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for isDeletedItem() when keydown", () => {
        const spy = spyOn(component, "isDeletedItem").and.callThrough();
        component.isDeletedItem(true);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for isDeletedItem() when keyup", () => {
        const spy = spyOn(component, "isDeletedItem").and.callThrough();
        component.isDeletedItem(false);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onFocusOutParts when valid index", () => {
        const mockEvent = {
            target: {
                value: "5",
            },
        };
        component.onFocusParts(mockEvent as unknown as FocusEvent);
        component.onFocusOutParts(0);
        expect(component.disableBtn).toBeTruthy();
    });

    it("should resolve for onFocusOutParts when invalid index", () => {
        const index = 0;
        const mockEvent = {
            target: {
                value: "5",
            },
        };
        component.onFocusParts(mockEvent as unknown as FocusEvent);
        component.onFocusOutParts(index);
        expect(component.cartLists[index].Parts).toBe(mockEvent.target.value);
    });

    it("should resolve for onSelectCartItem when invalid index", () => {
        component.selectedCartItemIndex = 1;
        component.cartListInputs = [
            { nativeElement: { id: 2, focus: () => {}, select: () => {}, blur: () => {} } },
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        ] as unknown as QueryList<ElementRef<any>>;
        const index = 0;
        component.onSelectCartItem(index, {
            Instruction: "ADD THE FOLLOWING TO KETTLE",
            ExpFormulaID: "",
            SUBType: "",
            IsDelete: 0,
        });
        expect(component.selectedCartItemIndex).toBe(index);
    });

    it("should resolve for onKeydownEvents() when keydown", () => {
        component.selectedCartItemIndex = 2;
        const keyboardEvent = new KeyboardEvent("keydown", { key: KEYBOARD_KEYS.DELETE });
        const isResult = component.onKeydownEvents(keyboardEvent);
        expect(isResult).toBeTruthy();
    });

    it("should resolve for onKeydownEvents() when keyup", () => {
        component.selectedCartItemIndex = 1;
        const keyboardEvent = new KeyboardEvent("keydown", { key: KEYBOARD_KEYS.UP_ARROW });
        const isResult = component.onKeydownEvents(keyboardEvent);
        expect(isResult).toBeFalsy();
    });

    it("should call onIpcTextClick", () => {
        spyOn(component, "onIpcTextClick").and.callThrough();
        component.onIpcTextClick("123456");
        expect(component.onIpcTextClick).toHaveBeenCalled();
    });

    xit("should resolve for changeTab when goToPreviousTab true", () => {
        component.tabGroup.selectedIndex = 1;
        component.currentListItem = BOM_MENU.BOM_LAYOUT;
        const mockEvent = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        component.changeTab(mockEvent as unknown as KeyboardEvent, true);
        expect(component.tabGroup.selectedIndex).toBe(0);
    });

    it("should call focusOnSearchResults", () => {
        component.tabGroup.selectedIndex = 1;
        spyOn(component, "focusOnSearchResults").and.callThrough();
        component.focusOnSearchResults();
        expect(component.focusOnSearchResults).toHaveBeenCalled();
    });

    it("should resolve for storeTabDetails()", () => {
        component.isOpenProductExperiment = false;
        const tabService: TabHelper = TestBed.inject(TabHelper);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(tabService, "getActiveTab").and.returnValue(MOCK_WORKSPACES[0]);
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        spyOn(service, "getWorkSpaceBomSearchFromCache");
        component.storeTabDetails();
        expect(MOCK_WORKSPACES[0].SearchFilters.activeTab).toEqual(component.tabGroup.selectedIndex);
    });

    it("should call removeSelectedInst", () => {
        component.selectedMiniEditorInst = "";
        const spy = spyOn(component, "removeSelectedInst").and.callThrough();
        component.removeSelectedInst();
        expect(spy).toHaveBeenCalled();
    });
});
