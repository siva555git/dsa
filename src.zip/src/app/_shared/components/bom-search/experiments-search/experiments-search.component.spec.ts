/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/no-empty-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialog } from "@angular/material/dialog";
import { OAuthLogger, OAuthService, UrlHelperService } from "angular-oauth2-oidc";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { MatMenuModule } from "@angular/material/menu";
import { of } from "rxjs";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { QueryList, ElementRef, CUSTOM_ELEMENTS_SCHEMA, forwardRef } from "@angular/core";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { Router } from "@angular/router";
import { ExperimentEditorHelper } from "@te-experiment-editor/helpers/experiment-editor.helper";
import { AppCacheHelper } from "@te-shared/helpers/app-cache.service";
import { MockAppcacheHelper } from "@te-testing/mock-app-cache-helper";
import { MockGridapiService } from "@te-testing/mock-gridapi.service";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { mockExpSearchFilter, MOCK_WORKSPACES } from "@te-testing/mock-tabhelper-data";
import { ExperimentFolderSelectorComponent } from "@te-shared/ag-grid-components/experiment-folder-selector/experiment-folder-selector.component";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { cloneDeep } from "lodash";
import { MockExperimentApiService } from "@te-testing/mock-experiment-api.service";
import { MockAppDataService } from "@te-testing/mock-app.data.service";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { ExperimentsSearchComponent } from "./experiments-search.component";
import { MockExperimentAccessHelper } from "../../../../testing/mock-experiment-access.helper";
import { ExperimentAccessHelper } from "../../../helpers/experiment-access.helper";
import { AppBroadCastService, AppDataService, AppStateService, MatomoService } from "../../../../_services";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";
import { mockActiveExperiment } from "../../../../testing/mock-ag-grid-data";
import { MockToastrService } from "../../../../testing/mock-toastr.service";
import { ExperimentApiService } from "../../../helpers/experiment-api.service";
import { EXPERIMENTS_SEARCH_CATEGORIES } from "../../../constants";
import { SearchCriteria } from "../../../models/search-criteria.model";
import { RecentlyUsedExpInSearch } from "../../../models/experiments.model";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatTableModule } from "@angular/material/table";
import { MatSelectModule } from "@angular/material/select";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

// eslint-disable-next-line max-lines-per-function
describe("ExperimentsSearchComponent", () => {
    let component: ExperimentsSearchComponent;
    let fixture: ComponentFixture<ExperimentsSearchComponent>;
    const mockRouter = { navigate: jasmine.createSpy("navigate") };
    const event = {
        target: {
            offsetHeight: 400,
            scrollHeight: 500,
            scrollTop: 1000,
        },
    };

    const data = { count: 10, rows: [{ ExpID: 12 }] };
    const mockExperimentFolderSelectorComponent = {
        // eslint-disable-next-line no-empty-function
        configAgGrid: () => {},
        // eslint-disable-next-line no-empty-function
        refreshGrid: () => {},
        // eslint-disable-next-line no-empty-function
        allExpParentFolder: () => {},
    } as unknown as ExperimentFolderSelectorComponent;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ExperimentsSearchComponent, ExperimentFolderSelectorComponent],
            providers: [
                SpaceTrimPipe,
                { provide: AppDataService, useClass: MockAppDataService },
                { provide: ExperimentApiService, useClass: MockExperimentApiService },
                { provide: AppStateService, useClass: MockAppStateService },
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                AppBroadCastService,
                { provide: ToastrService, useClass: MockToastrService },
                { provide: NGXLogger, useClass: MockLoggerService },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line no-empty-function
                    useValue: { open: () => {} },
                },
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                { provide: ExperimentHelper, useClass: MockExperimentHelper },
                { provide: Router, useValue: mockRouter },
                { provide: ExperimentEditorHelper, useValue: {} },
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: AppCacheHelper, useClass: MockAppcacheHelper },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
            imports: [
                HttpClientTestingModule,
                MatMenuModule,
                MatCheckboxModule,
                MatTableModule,
                BrowserModule,
                ReactiveFormsModule,
                FormsModule,
                MatSelectModule,
                MatFormFieldModule,
                MatInputModule,
                BrowserAnimationsModule
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExperimentsSearchComponent);
        component = fixture.componentInstance;
        component.openedExperimentOrProduct = [];
        component.cartLists = [];
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for onTableScroll() when if condition is satisfied", () => {
        component.isLoading = false;
        component.totalCount = 100;
        component.searchCriteria = {} as SearchCriteria;
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTableScroll() when false condition is satisfied", () => {
        component.isLoading = true;
        component.totalCount = 0;
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is not empty and totalCount is 0", () => {
        component.totalCount = 0;
        component.activeExperiment = mockActiveExperiment;
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource({ count: 10, rows: [] } as RecentlyUsedExpInSearch);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is not empty and totalCount is 10", () => {
        component.totalCount = 10;
        component.activeExperiment = mockActiveExperiment;
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource({ count: 10, rows: [] } as RecentlyUsedExpInSearch);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for combineDatasource() when data is empty", () => {
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource({} as RecentlyUsedExpInSearch);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterSearch() when isLoading is true", () => {
        component.isLoading = true;
        const spy = spyOn(component, "onEnterSearch").and.callThrough();
        component.onEnterSearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterSearch() when isLoading is false", () => {
        spyOn(component, "onEnterSearch").and.callThrough();
        component.isLoading = false;
        component.searchCategoryValue = "Collaboration Group";
        component.userCollaborationGroupList.length = 2;
        component.isAllUnChecked = false;
        component.onEnterSearch();
        expect(component.isLoading).toEqual(false);
    });

    it("should resolve for getSearchExperiments()", () => {
        component.isLoading = false;
        // eslint-disable-next-line prefer-destructuring
        if (EXPERIMENTS_SEARCH_CATEGORIES.length === 2) component.searchCategoryValue = EXPERIMENTS_SEARCH_CATEGORIES[1];
        const spy = spyOn(component, "getSearchExperiments").and.callThrough();
        component.getSearchExperiments();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for selectSearchCriteria() if searchValue is empty", () => {
        const spy = spyOn(component, "selectSearchCriteria").and.callThrough();
        component.selectSearchCriteria();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSelectionList() if defaultCheckbox is empty", () => {
        component.searchCheckBoxList = [
            { searchCriteria: "Code", checked: true },
            { searchCriteria: "Name", checked: true },
        ];
        spyOn(component, "onSelectionList").and.callThrough();
        component.onSelectionList();
        expect(component.isAllUnChecked).toEqual(false);
    });

    it("should resolve for onSelectionList() if defaultCheckbox is empty", () => {
        component.searchCheckBoxList = [
            { searchCriteria: "Code", checked: false },
            { searchCriteria: "Name", checked: false },
        ];
        spyOn(component, "onSelectionList").and.callThrough();
        component.onSelectionList();
        expect(component.isAllUnChecked).toEqual(true);
    });

    it("should resolve for onAddExpToCart() if condition", () => {
        const element = {
            IsPublic: true,
            isLocked: "1",
        };
        component.openedExperimentOrProduct = undefined;
        const spy = spyOn(component, "onAddExpToCart").and.callThrough();
        component.onAddExpToCart(element);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onAddExpToCart() else condition", () => {
        const element = {
            IsPublic: false,
            isLocked: "1",
        };
        const spy = spyOn(component, "onAddExpToCart").and.callThrough();
        component.onAddExpToCart(element);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onSelectCategories with category value", () => {
        const categoryData = [
            { searchCriteria: "Code", checked: true },
            { searchCriteria: "Name", checked: true },
            { searchCriteria: "Exp ID", checked: true },
        ];
        const cacheExpSearchFilter = undefined;
        // eslint-disable-next-line sonarjs/no-duplicate-string
        component.searchCategoryValue = "All My Experiments";
        spyOn(component, "onSelectCategories").and.callThrough();
        component.onSelectCategories("All My Experiments", cacheExpSearchFilter);
        expect(component.searchCheckBoxList).toEqual(categoryData);
    });

    it("should call onSelectCategories with category value", () => {
        const cacheFilterData = undefined;
        component.searchCategoryValue = "Recently Used Experiments";
        component.selectedExpFolderName = "";
        spyOn(component, "clearFolderField").and.returnValue();
        component.onSelectCategories("Recently Used Experiments", cacheFilterData);
        expect(component.selectedExpFolderName).toEqual("");
    });

    it("should call onSelectCategoriesSub 1", () => {
        const mockData = cloneDeep(MOCK_WORKSPACES[0].SearchFilters.Experiment);
        component.searchCategoryValue = "Collaboration Group";
        spyOn(component, "resetOffsetLimit").and.returnValue();
        spyOn(component, "getCollaborationsGroup").and.returnValue();
        component.onSelectCategoriesSub(mockData);
        expect(component.noExpFoundInCollaborationGroup).toBeFalsy();
    });

    it("should call getCollaborationsGroup", () => {
        const mockExperimentSearchData = cloneDeep(MOCK_WORKSPACES[0].SearchFilters.Experiment);
        const service: AppDataService = TestBed.inject(AppDataService);
        spyOn(service, "get").and.returnValue(of([{ CollaborationGroupID: 1 }]));
        component.getCollaborationsGroup(mockExperimentSearchData);
        expect(component.searchCollaborationValue).toBeUndefined();
    });

    it("should call onChangeCollaborationGroup", () => {
        const spy = spyOn(component, "onChangeCollaborationGroup").and.callThrough();
        const response = {
            rows: [],
            count: 0,
        };
        spyOn(component, "getSearchExperiments").and.returnValue(of(response));
        component.onChangeCollaborationGroup();
        expect(spy).toHaveBeenCalled();
    });

    it("should call clearFolderField", () => {
        component.selectedExpFolderName = "Testing";
        component.clearFolderField();
        expect(component.activeExpFolderId).toBeFalsy();
    });

    it("should call onMenuOpened", () => {
        component.searchCategoryValue = component.expSearchCategoryList.MY_FOLDER;
        component.experimentFolderSelectorComponent = mockExperimentFolderSelectorComponent;
        const spy = spyOn(component, "onMenuOpened").and.callThrough();
        component.onMenuOpened();
        expect(spy).toHaveBeenCalled();
    });

    it("should call getSelectedCheckboxList", () => {
        component.searchCheckBoxList = [
            { searchCriteria: "Code", checked: false },
            { searchCriteria: "Name", checked: true },
        ];
        spyOn(component, "getSelectedCheckboxList").and.callThrough();
        const spy = component.getSelectedCheckboxList();
        expect(spy).toEqual(["name"]);
    });

    it("should resolve for shiftFocusToCart()", () => {
        const spy = spyOn(component, "shiftFocusToCart").and.callThrough();
        const mockEvent = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        component.shiftFocusToCart(mockEvent as unknown as KeyboardEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for shiftFocusToCart() when event is defined", () => {
        component.selectedRowIndex = 5;
        const mockEvent1 = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        const mockEvent2 = {
            focus() {
                return true;
            },
            scrollIntoViewIfNeeded() {
                return true;
            },
        };
        const mockDataTable = { first: { _elementRef: { nativeElement: { tBodies: [{ rows: [mockEvent2] }] } } } };
        component.experimentDataTable = mockDataTable as unknown as QueryList<ElementRef>;
        component.totalCount = 10;
        component.combineDatasource(data as unknown as RecentlyUsedExpInSearch);
        component.focusOnFirstDataRow(mockEvent1 as unknown as KeyboardEvent);
        expect(component.selectedRowIndex).toBe(0);
    });

    it("should resolve for errorHandler()", () => {
        const spy = spyOn(component, "errorHandler").and.callThrough();
        const error: any = "test error";
        component.errorHandler(error);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for focusSearchTextBox()", () => {
        const spy = spyOn(component, "focusSearchTextBox").and.callThrough();
        // eslint-disable-next-line no-empty-function
        const childComponents = { nativeElement: { focus: () => {} } };
        component.searchTextBox = childComponents;
        component.focusSearchTextBox();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getSelectedFolderNameHander()", () => {
        const mockFolder = {
            FolderName: "Valimai finally releasing",
            FolderID: 24_022_022,
        };
        component.onFolderSelected(mockFolder);
        expect(component.activeExpFolderId).toBe(mockFolder.FolderID);
    });

    it("should resolve for storeExperimentSearchFilter", () => {
        const tabService: TabHelper = TestBed.inject(TabHelper);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(tabService, "getActiveTab").and.returnValue(MOCK_WORKSPACES[0]);
        component.storeExperimentSearchFilter();
        expect(component.selectedQuery).toEqual("contains");
    });

    it("should resolve for getExperimentSearchFilter", () => {
        spyOn(component, "onSelectCategories").and.returnValue();
        const mockData = cloneDeep(mockExpSearchFilter);
        component.isOpenproduct = false;
        component.searchCategories = ["All My Experiments"];
        component.searchFilterData = mockData.SearchFilters;
        component.getExperimentSearchFilter();
        expect(component.searchValue.value).toEqual("Lemon");
    });
});
