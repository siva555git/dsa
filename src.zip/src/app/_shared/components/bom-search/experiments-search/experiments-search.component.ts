/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
    Component,
    ElementRef,
    EventEmitter,
    Input,
    Output,
    ViewChild,
    ViewChildren,
    QueryList,
    ChangeDetectorRef,
    OnDestroy,
} from "@angular/core";
import { UntypedFormControl } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { MatMenuTrigger } from "@angular/material/menu";
import { cloneDeep, delay, forEach, toLower } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { SelectionModel } from "@angular/cdk/collections";
import { Observable, Subscription, EMPTY as RxEMPTY } from "rxjs";
import { debounceTime, filter, switchMap, tap } from "rxjs/operators";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { InsertSearchFilterModel, WorkSpaces } from "@te-shared/models/create-tab.model";
import { AppCacheHelper } from "@te-shared/helpers/app-cache.service";
import { EXPERIMENT_ACCESS } from "@te-shared/constants";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { ExperimentFolderSelectorComponent } from "@te-shared/ag-grid-components/experiment-folder-selector/experiment-folder-selector.component";
import { EXPERIMENT } from "@te-shared/constants/context-menu.constant";
import {
    ADD_TO_CART,
    ALREADY_ADDED_IN_CART,
    ALREADY_OPEN,
    BOM_TYPE,
    CANT_OPEN_MORE_EXPERIMENTS,
    CANT_OPEN_OTHERS_UNACCESS_EXPERIMENTS,
    COMMON_DIALOG_OLD,
    EXPERIMENTS_SEARCH,
    EXPERIMENTS_SEARCH_CATEGORIES,
    EXP_ID,
    EXP_SEARCH_CATEGORIES,
    LOCKED_BY_STATUS,
    OTHERUSER_EXP_MSG,
    SEARCH_DEBOUNCE_TIME,
    COLLABORATION_OWN_GROUP,
    SEARCH_EXPERIMENTS_CATEGORY_CHECKBOX,
    CATEGORY,
    MIN_SEARCH_VALUE_LENGTH,
    experimentFolderName,
    MAX_EXPORPRO_OPEN_LENGTH,
    PRODUCT_SEARCH_CONSTANTS,
} from "../../../constants/common.constant";
import { TreeViewModel } from "../../../models";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { CollaborationGroupListModel } from "../../../models/user-collaboration-group.model";
import { RecentlyUsedExpInSearch } from "../../../models/experiments.model";
import { BomDetailExperimentsModel, ExperimentsModel } from "../../../models/experiment-bom.model";
import { SearchDrawerHelper } from "../../../helpers/search-drawer.helper";
import { ExperimentApiService } from "../../../helpers/experiment-api.service";
import { MatomoAction, MatomoCategory, MatomoLabel, SUBTypes } from "../../../enums";
import { MARK_FOR_UNDELETE_FLAG } from "../../../constants/experiment.constant";
import { ConfirmationDialogComponent } from "../../confirmation-dialog/confirmation-dialog.component";
import { AppBroadCastService, AppDataService, AppStateService, MatomoService } from "../../../../_services";
import { EMPTY, LOADING } from "../../../../app.constant";
import { ZERO_WITH_DECIMAL } from "../../../../creative-review/creative-review.constant";
import { SearchCriteria } from "../../../models/search-criteria.model";
import { REFERENCE_ERRORS } from "../../../constants/notification.constant";
import { QUICK_SEARCH_AUDIT_VALIDATION } from  "@te-experiment-editor/constants/experiment-editor.constant";
@Component({
    selector: "app-experiments-search",
    templateUrl: "./experiments-search.component.html",
    styleUrls: ["./experiments-search.component.scss"],
})
export class ExperimentsSearchComponent implements OnDestroy {
    public categoryHeading = CATEGORY;

    public searchCheckBoxList = cloneDeep(EXPERIMENTS_SEARCH.EXPERIMENTS_SEARCH_CHECKBOX_LIST);

    public searchCheckBoxText = SEARCH_EXPERIMENTS_CATEGORY_CHECKBOX;

    public selectedQuery = EXPERIMENTS_SEARCH.DEFAULT_SEARCH_CLAUSE;

    public searchCategories = EXPERIMENTS_SEARCH_CATEGORIES.sort();

    public searchValue: UntypedFormControl = new UntypedFormControl();

    public dataSource = [];

    public searchCategoryValue = EXPERIMENTS_SEARCH_CATEGORIES[0];

    public displayedColumns: string[] = EXPERIMENTS_SEARCH.EXPERIMENT_GRID_COLUMN_LIST;

    public isLoading = false;

    public searchCriteria: SearchCriteria;

    public totalCount = 0;

    public noDataFound = false;

    public start = EXPERIMENTS_SEARCH.START_FROM;

    public limit = PRODUCT_SEARCH_CONSTANTS.LIMIT;

    public end = this.limit + this.start;

    public userId: number;

    public lockStatus = LOCKED_BY_STATUS;

    public addToCart = ADD_TO_CART;

    public otherUserExpMsg = OTHERUSER_EXP_MSG;

    public userCollaborationGroupList: CollaborationGroupListModel[] = [];

    public searchCollaborationValue: number;

    public noExpFoundInCollaborationGroup: boolean;

    public selectedExpFolderName: string;

    public activeExpFolderId;

    public expSearchCategoryList = EXP_SEARCH_CATEGORIES;

    public collaborationOwnGroup = COLLABORATION_OWN_GROUP;

    public noExperimentAccess = CANT_OPEN_OTHERS_UNACCESS_EXPERIMENTS;

    public isAllUnChecked = false;

    public selection: SelectionModel<any> = new SelectionModel();

    public selectedRowIndex = -1;

    private componentSubscriptions: Subscription = new Subscription();

    private maxWSOpenExpLength = MAX_EXPORPRO_OPEN_LENGTH;

    private isExpFoldersLoaded = false;

    @Input() public activeExperiment: ExperimentsModel;

    @Input() public openedExperimentOrProduct: BomDetailExperimentsModel[];

    @Input() public cartLists;

    @Input() public isOpenproduct: boolean;

    @Input() public searchFilterData;

    @Output() public emitCartData = new EventEmitter();

    @Output()
    public focusCartData = new EventEmitter();

    @ViewChild("searchTextBox") searchTextBox: ElementRef;

    @ViewChild("folderSelector") experimentFolderSelectorComponent: ExperimentFolderSelectorComponent;

    @ViewChildren("experimentDataTable") experimentDataTable: QueryList<ElementRef>;

    @ViewChild(MatMenuTrigger, { static: false }) menu: MatMenuTrigger;

    public currentWorkspace: WorkSpaces;

    constructor(
        private readonly experimentApiService: ExperimentApiService,
        private readonly toastrService: ToastrService,
        private readonly dialog: MatDialog,
        private readonly logger: NGXLogger,
        private readonly appStateService: AppStateService,
        private readonly spaceTrim: SpaceTrimPipe,
        private readonly appDataService: AppDataService,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly experimentAccessHelper: ExperimentAccessHelper,
        private readonly tabHelper: TabHelper,
        private readonly appCacheHelper: AppCacheHelper,
        private readonly cdr: ChangeDetectorRef,
        private readonly matomoService: MatomoService,
    ) {}

    public ngAfterViewInit(): void {
        this.updateSearchTerm();
        this.cdr.detectChanges();
    }

    public ngOnInit(): void {
        const { userInfo } = this.appStateService.stateId;
        this.userId = this.appStateService.get(userInfo).sapempid;
        this.detectValueChangesAndFilter(); 
        const selectedCheckboxList = this.getSelectedCheckboxList();
        this.searchCriteria = {
            searchText: this.spaceTrim.transform(this.searchValue.value),
            limit: PRODUCT_SEARCH_CONSTANTS.LIMIT,
            offset: EXPERIMENTS_SEARCH.START_FROM,
            searchBy: selectedCheckboxList,
            searchType: this.selectedQuery,
            activeExpID: Number(this.activeExperiment?.ExpID),
        };
        this.matomoService.trackEvent(MatomoCategory.EXPERIMENTS_SEARCH, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    public ngOnDestroy(): void {
        this.componentSubscriptions.unsubscribe();
    }

    /**
     * Method to shift focus to cart from search results table
     *
     * @param {KeyboardEvent} event
     * @memberof ExperimentsSearchComponent
     */
    public shiftFocusToCart(event: KeyboardEvent): void {
        event.stopPropagation();
        event.preventDefault();
        this.focusCartData.emit();
    }

    /**
     * Method to switch page focus to first data row
     *
     * @memberof ExperimentsSearchComponent
     */
    public focusOnFirstDataRow(event?: KeyboardEvent): void {
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        if (this.dataSource?.length > 0) {
            this.selectedRowIndex = 0;
            this.selection.select(this.dataSource[this.selectedRowIndex]);

            BomSearchHelper.focusSelectedRowInTable(this.experimentDataTable, this.selectedRowIndex);
        }
    }

    /**
     * Method to switch page focus to search text box
     *
     * @memberof ExperimentsSearchComponent
     */
    public focusSearchTextBox(shouldSelect = false): void {
        BomSearchHelper.focusOrSelectTextbox(this.searchTextBox, shouldSelect);
    }

    /**
     * Method to select the checkbox
     *
     * @returns {*}
     * @memberof ExperimentsSearchComponent
     */
    public onSelectionList(): void {
        this.isAllUnChecked = this.searchCheckBoxList !== undefined && this.searchCheckBoxList.every((list) => !list.checked);
    }

    /**
     * Method to set the search criteria
     *
     * @returns {*}
     * @memberof ExperimentsSearchComponent
     */
    public selectSearchCriteria(): void {
        this.resetAttributes();
        const selectedCheckboxList = this.getSelectedCheckboxList();
        this.searchCriteria = {
            searchText: this.spaceTrim.transform(this.searchValue.value),
            limit: PRODUCT_SEARCH_CONSTANTS.LIMIT,
            offset: EXPERIMENTS_SEARCH.START_FROM,
            searchBy: selectedCheckboxList,
            searchType: this.selectedQuery,
            activeExpID: Number(this.activeExperiment?.ExpID),
            searchCategory: this.searchCategoryValue,
        };
        if (this.searchCategoryValue === this.expSearchCategoryList.MY_FOLDER && this.selectedExpFolderName !== EMPTY) {
            this.searchCriteria.folderId = this.activeExpFolderId;
        }
    }

    /**
     * Method to enter the search button
     *
     * @memberof ExperimentsSearchComponent
     */
    public onEnterSearch(): void {
        if (
            this.isLoading ||
            this.isAllUnChecked ||
            (this.searchCategoryValue === this.expSearchCategoryList.MY_FOLDER && this.selectedExpFolderName === EMPTY) ||
            (this.searchCategoryValue === this.expSearchCategoryList.COLLABORATION_GROUP && this.userCollaborationGroupList.length <= 0) ||
            ((this.spaceTrim.transform(this.searchValue.value)?.length === 0 || !this.searchValue.value) &&
                this.searchCategoryValue === this.expSearchCategoryList.ALL_OTHER_EXPERIMENTS)
        ) {
            return;
        }

        this.selectSearchCriteria();
        this.searchExperiments();
    }

    /**
     * Method to search the experiments
     *
     * @memberof ExperimentsSearchComponent
     */
    public searchExperiments(): void {
        this.isLoading = true;
        this.componentSubscriptions.add(
            this.getSearchExperiments().subscribe({
                next: (result) => {
                    this.isLoading = false;
                    this.combineDatasource(result);
                },
                error: (error) => {
                    this.errorHandler(error);
                },
            }),
        );
    }

    /**
     * Return the observable of recent used experiment or all experiment search
     * @returns {Observable<RecentlyUsedExpInSearch>}
     * @memberof ExperimentsSearchComponent
     */
    // eslint-disable-next-line consistent-return
    public getSearchExperiments(): Observable<RecentlyUsedExpInSearch> {
        if (this.searchCategoryValue === this.expSearchCategoryList.RECENTLY_USED) {
            return this.experimentApiService.getRecentlyUsed(
                SUBTypes.EXPERIMENT,
                this.searchCriteria,
            ) as unknown as Observable<RecentlyUsedExpInSearch>;
        }
        if (this.searchCategoryValue === this.expSearchCategoryList.COLLABORATION_GROUP) {
            return this.experimentApiService.getCollaborationsGroupExperiments(this.searchCollaborationValue, this.searchCriteria);
        }
        if (this.searchCategoryValue === this.expSearchCategoryList.MY_FOLDER && !this.searchCriteria.folderId) {
            this.isLoading = false;
            return RxEMPTY;
        }

        return this.appDataService.post(this.appDataService.url.searchExperiment, [], this.searchCriteria);
    }

    /**
     * Method to prepare the datasource
     * @param {RecentlyUsedExpInSearch} data
     * @memberof ExperimentsSearchComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public combineDatasource(data: RecentlyUsedExpInSearch): void {
        if (!data || !data.count) {
            this.noDataFound = !this.noExpFoundInCollaborationGroup;
            return;
        }
        // eslint-disable-next-line unicorn/prefer-spread
        this.dataSource = TasteEditorUtilClass.getUniqueListBy(this.dataSource.concat(data.rows), EXP_ID);

        if (!this.totalCount) {
            this.totalCount = data.count;
            this.noDataFound = false;
        }
    }

    /**
     * Method to handle errors
     *
     * @param {Error} error
     * @memberof ExperimentsSearchComponent
     */
    public errorHandler(error: Error) {
        this.isLoading = false;
        this.toastrService.error(REFERENCE_ERRORS.EXPERIMENT_SEARCH_ERROR);
        this.logger.error(error);
    }

    /**
     * Method to invoke when scrolling the table
     *
     * @param {*} event
     * @returns {*}
     * @memberof ExperimentsSearchComponent
     */
    public onTableScroll(event: any): void {
        const tableViewHeight = event.target.offsetHeight;
        const tableScrollHeight = event.target.scrollHeight;
        const scrollLocation = event.target.scrollTop;

        // If the user has scrolled within 200px of the bottom, add more data
        const buffer = 200;
        const limit = tableScrollHeight - tableViewHeight - buffer;
        if (scrollLocation <= limit || this.isLoading || this.dataSource.length >= this.totalCount) return;

        this.updateIndex();
        this.searchExperiments();
    }

    /**
     * Method to update the count of start and limit
     *
     * @memberof ExperimentsSearchComponent
     */
    public updateIndex(): void {
        this.start = this.end;
        this.end = this.limit + this.start;
        this.searchCriteria.offset = this.start;
    }

    /**
     * Method to reset the values
     *
     * @memberof ExperimentsSearchComponent
     */
    public resetAttributes(): void {
        this.dataSource = [];
        this.selectedRowIndex = -1;
        this.totalCount = 0;
        this.start = EXPERIMENTS_SEARCH.START_FROM;
        this.limit = PRODUCT_SEARCH_CONSTANTS.LIMIT;
        this.end = this.limit + this.start;
        this.noDataFound = false;
    }

    /**
     * Method to add experiment to the cart
     *
     * @param {any} experimentItem
     * @memberof ExperimentsSearchComponent
     */
    public onAddExpToCart(experimentItem): void {
        if(experimentItem?.ExpID === this.activeExperiment?.ExpID) {
            this.toastrService.error(QUICK_SEARCH_AUDIT_VALIDATION.ADDING_SAME_EXPERIMENT);
            return;
        }
        const accessFunction = this.openedExperimentOrProduct
            ? EXPERIMENT_ACCESS.OPEN_EXPERIMEMT_IN_WORKSPACE
            : EXPERIMENT_ACCESS.INSERT_EXPERIMENT_AS_INTERMEDIATE;
        const accessInfo = this.experimentAccessHelper.getExperimentAccessCheck([experimentItem], Number(this.userId), accessFunction);
        if (!accessInfo?.isPermitted) {
            this.experimentAccessHelper.openExperiemntAccessInfoDialog(accessInfo, experimentItem.ExpID);
            return;
        }
        if (this.validateOpenExperiment(experimentItem)) {
            const experiment = cloneDeep(experimentItem);
            experiment.ExpFormulaID = EMPTY;
            experiment.SUBType = BOM_TYPE.EXPERIMENT;
            if (experiment.IPC && !this.isOpenproduct) {
                experiment.SUBCode = experiment.IPC;
                experiment.SUBType = BOM_TYPE.PRODUCT;
                experiment.ExpName = experiment?.otherdetails?.description;
            } else {
                experiment.SUBCode = experiment.ExpID;
            }
            experiment.Parts = ZERO_WITH_DECIMAL;
            experiment.IsDelete = MARK_FOR_UNDELETE_FLAG;
            this.emitCartData.emit(experiment);
        }
        this.matomoService.trackEvent(MatomoCategory.EXPERIMENTS_SEARCH, MatomoAction.CLICK, MatomoLabel.ON_ADD_TO_CART);
    }

    /**
     * Method to add experiment to the cart
     *
     * @param {ExperimentsModel} experiment
     * @return {boolean}
     * @memberof ExperimentsSearchComponent
     */
    public validateOpenExperiment(experiment: ExperimentsModel): boolean {
        if (!this.isOpenproduct) return true;
        // eslint-disable-next-line no-param-reassign
        experiment.Type = EXPERIMENT;
        const isMaxExpExceeds = SearchDrawerHelper.isMaxExpExceeds(this.openedExperimentOrProduct, this.cartLists);
        if (isMaxExpExceeds) {
            const dialogMessage = CANT_OPEN_MORE_EXPERIMENTS;
            dialogMessage.subMesssage = `Cannot add ${
                this.cartLists.length + 1
            } BOM items to compare since it exceeds maximum capacity of ${
                this.maxWSOpenExpLength
            } BOMs that can be opened in Experiment BOM. You can open ${
                this.maxWSOpenExpLength - this.openedExperimentOrProduct.length
            } BOMs to compare.`;
            const dialogOptions = COMMON_DIALOG_OLD;
            dialogOptions.data = dialogMessage;
            this.dialog.open(ConfirmationDialogComponent, dialogOptions);
            return false;
        }
        const isAlreadyOpened = SearchDrawerHelper.isAlreadyOpened(experiment, this.openedExperimentOrProduct);
        if (isAlreadyOpened) {
            const dialogMessage = ALREADY_OPEN;
            dialogMessage.subMesssage = `${experiment.ExpCode} is already open in the current tab of the Experiment BOM screen.`;
            dialogMessage.message = `Experiment already open in the workspace.`;
            const dialogOptions = COMMON_DIALOG_OLD;
            dialogOptions.data = ALREADY_OPEN;
            this.dialog.open(ConfirmationDialogComponent, dialogOptions);
            return false;
        }
        const isAddedInCart = SearchDrawerHelper.isAddedInCart(experiment, this.cartLists);
        if (isAddedInCart) {
            const dialogMessage = ALREADY_ADDED_IN_CART;
            dialogMessage.subMesssage = `${experiment.ExpCode} is already added in the cart`;
            dialogMessage.message = `Experiment already in cart.`;
            const dialogOptions = COMMON_DIALOG_OLD;
            dialogOptions.data = ALREADY_ADDED_IN_CART;
            this.dialog.open(ConfirmationDialogComponent, dialogOptions);
            return false;
        }
        return true;
    }

    /**
     * Method to get folder list from API
     * @param {string} selectedValue
     * @param {InsertSearchFilterModel} experiment
     * @return {void}
     * @memberof ExperimentsSearchComponent
     */
    public onSelectCategories(selectedValue: string, experiment: InsertSearchFilterModel): void {
        if (!experiment) {
            forEach(this.searchCheckBoxList, (list) => {
                const checkbox = list;
                checkbox.checked = !(
                    this.searchCategoryValue === this.expSearchCategoryList.ALL_OTHER_EXPERIMENTS &&
                    list.searchCriteria === SEARCH_EXPERIMENTS_CATEGORY_CHECKBOX.NAME
                );
            });
            this.onSelectionList();
        }
        delay(() => {
            this.onSelectCategoriesSub(experiment);
        }, 0);
        if (selectedValue !== this.expSearchCategoryList.MY_FOLDER) {
            this.clearFolderField();
        }
        this.updateSearchTerm();
    }

    /**
     * Method to get selected folder name and folderid and display in UI
     * @param {TreeViewModel} selectedValue
     * @return {void}
     * @memberof ExperimentsSearchComponent
     */
    public onFolderSelected(folder: TreeViewModel): void {
        this.selectedExpFolderName = folder.FolderName;
        this.activeExpFolderId = folder.FolderID;
        this.menu.closeMenu();
        this.focusSearchTextBox();
        if (this.searchValue.disabled) this.searchValue.enable();
        const getfolder = {
            from: 0,
            size: 100,
            category: experimentFolderName.EXPERIMENTS_BY_FOLDERID,
            folderId: folder.FolderID,
            searchText: EMPTY,
            collaborationGroupId: 0,
            sort: { fieldToSort: "CreatedOn", sortOrder: "DESC" },
        };
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.componentSubscriptions.add(
            this.experimentApiService.getExperimentByFolderId(getfolder).subscribe({
                next: (result) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (!result?.Experiments?.ExperimentDetail?.length) {
                        this.searchValue.disable();
                    }
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to clear folder name and folderid when click on close icon
     * @return {void}
     * @memberof ExperimentsSearchComponent
     */
    public clearFolderField(): void {
        if (this.selectedExpFolderName) {
            this.selectedExpFolderName = EMPTY;
            this.activeExpFolderId = EMPTY;
        }
    }

    /**
     * Method to update search term based on selected category
     * @return {void}
     * @memberof ExperimentsSearchComponent
     */
    public updateSearchTerm(): void {
        if (this.searchCategoryValue === EXP_SEARCH_CATEGORIES.All_MY_EXPERIMENTS) {
            this.searchValue.patchValue(this.appStateService.getCurrentUser().initials);
            this.onEnterSearch();
        } else {
            this.searchValue.reset();
        }
    }

    /**
     * Method to open menu and refresh grid
     *
     * @memberof ExperimentsSearchComponent
     */
    public onMenuOpened(): void {
        this.experimentFolderSelectorComponent.refreshGrid();
    }

    /**
     * Method to get user collaboration groups
     * @param {InsertSearchFilterModel} experiment
     * @memberof ExperimentsSearchComponent
     */
    public getCollaborationsGroup(experiment: InsertSearchFilterModel): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.componentSubscriptions.add(
            this.experimentApiService.getCollaborationsGroup().subscribe({
                next: (result) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.userCollaborationGroupList = result;
                    if (this.userCollaborationGroupList?.length === 0) {
                        this.searchValue.disable();
                        return;
                    }
                    this.searchCollaborationValue = experiment?.collaboration ?? this.userCollaborationGroupList[0].CollaborationGroupID;
                    this.onChangeCollaborationGroup();
                    if (experiment?.searchText) {
                        this.searchValue.patchValue(experiment.searchText?.toUpperCase());
                    }
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to reset pagination fields
     *
     * @memberof ExperimentsSearchComponent
     */
    public resetOffsetLimit(): void {
        this.end = 0;
        this.start = 0;
        this.searchCriteria.offset = 0;
        this.dataSource = [];
        this.selectedRowIndex = -1;
        this.totalCount = 0;
        this.noDataFound = false;
        this.focusExperimentSearch();
    }

    /**
     * Method to change user collaboration groups
     *
     * @memberof ExperimentsSearchComponent
     */
    public onChangeCollaborationGroup(): void {
        this.noExpFoundInCollaborationGroup = false;
        this.resetOffsetLimit();
        if (this.searchValue.disabled) this.searchValue.enable();
        this.componentSubscriptions.add(
            this.getSearchExperiments().subscribe((result) => {
                if (result && (!result.count || result.count === 0)) {
                    this.dataSource = [];
                    this.isLoading = false;
                    if (this.spaceTrim.transform(this.searchValue.value)?.length > 0) {
                        this.noExpFoundInCollaborationGroup = false;
                        this.noDataFound = true;
                    } else {
                        this.selectedRowIndex = -1;
                        this.noExpFoundInCollaborationGroup = true;
                        this.noDataFound = false;
                        this.searchValue.disable();
                    }
                } else if (result?.count) {
                    this.isLoading = false;
                }
            }),
        );
    }

    /**
     * Method focus Experiment SearchBox
     *
     * @memberof ExperimentsSearchComponent
     */
    private focusExperimentSearch(): void {
        delay(() => {
            this.searchTextBox.nativeElement.blur();
            this.searchTextBox.nativeElement.focus();
        }, 100);
    }

    /**
     * Sub method of onSelectCategories
     * @param {InsertSearchFilterModel} experiment
     * @memberof ExperimentsSearchComponent
     */
    public onSelectCategoriesSub(experiment: InsertSearchFilterModel): void {
        this.noExpFoundInCollaborationGroup = false;
        this.resetOffsetLimit();
        if (this.searchValue.disabled) this.searchValue.enable();
        if (this.searchCategoryValue === this.expSearchCategoryList.COLLABORATION_GROUP) {
            this.searchCollaborationValue = experiment?.collaboration;
            this.searchCriteria.searchCategory = this.searchCategoryValue;
            this.getCollaborationsGroup(experiment);
        } else {
            this.searchCollaborationValue = undefined;
            this.searchCriteria.searchCategory = undefined;
            if (experiment?.searchText) {
                this.searchValue.patchValue(experiment.searchText?.toUpperCase());
            }
        }

        if (experiment?.folder || this.searchCategoryValue === this.expSearchCategoryList.MY_FOLDER) {
            if (this.isExpFoldersLoaded) {
                this.validateFolderName(experiment);
            } else {
                this.experimentFolderSelectorComponent.configAgGrid();
                this.isExpFoldersLoaded = true;
                this.experimentFolderSelectorComponent.foldersFetchSub$.subscribe((areFoldersFetched: boolean) => {
                    // eslint-disable-next-line no-unused-expressions
                    areFoldersFetched && delay(() => this.validateFolderName(experiment), 0);
                });
            }
        } else if (!this.searchCollaborationValue && !this.selectedExpFolderName && (experiment?.folder || experiment?.collaboration)) {
            [this.searchCategoryValue] = EXPERIMENTS_SEARCH_CATEGORIES;
        }
    }

    /**
     * Method to get selected Checkbox list
     * @returns {Array<string>}
     * @memberof ExperimentsSearchComponent
     */
    public getSelectedCheckboxList(): Array<string> {
        return this.searchCheckBoxList?.filter((list) => list.checked).map((data) => toLower(data.searchCriteria));
    }

    /**
     * Method to store the search filter in session
     * @returns {void}
     * @memberof ExperimentsSearchComponent
     */
    public storeExperimentSearchFilter(): void {
        this.currentWorkspace = this.tabHelper.getActiveTab();
        this.currentWorkspace.SearchFilters.Experiment = {
            category: this.searchCategoryValue,
            usingOption: this.selectedQuery,
            searchText: this.searchValue.value,
            folder: this.activeExpFolderId,
            collaboration: this.searchCollaborationValue,
            // eslint-disable-next-line unicorn/no-useless-spread
            checkBox: [...this.searchCheckBoxList.filter((checkBox) => checkBox.checked).map((checkBox) => checkBox.searchCriteria)],
        };
        this.appCacheHelper.storeWorspaceBomSearch([this.currentWorkspace]);
    }

    /**
     * Method to get the search filter values from session and bind
     * @returns {void}
     * @memberof ExperimentsSearchComponent
     */
    public getExperimentSearchFilter(): void {
        if (this.isOpenproduct) {
            return;
        }
        if (this.searchFilterData && this.searchFilterData?.Experiment) {
            const experiment = this.searchFilterData.Experiment;
            const isCategoryExist = this.searchCategories.includes(experiment.category);
            this.searchCategoryValue = isCategoryExist ? experiment.category : this.searchCategoryValue;
            this.selectedQuery = experiment.usingOption;
            this.searchValue.setValue(experiment.searchText);
            this.searchCheckBoxList.forEach((searchCheckBox) => {
                const checkBox = searchCheckBox;
                checkBox.checked = experiment.checkBox.includes(checkBox.searchCriteria);
            });
            this.onSelectCategories(this.searchCategoryValue, experiment);
        }
    }

    /**
     * Method to validate the folder name and bind in folder field
     * @param experiment
     * @returns {void}
     * @memberof ExperimentsSearchComponent
     */
    public validateFolderName(experiment: InsertSearchFilterModel): void {
        if (!experiment?.folder) {
            this.selectedExpFolderName = this.appStateService.getCurrentUser().globaluserid;
            const userDefaultFolder = AppStateService.getExpFolderList().find(
                (folderDetails) => folderDetails.FolderName === this.selectedExpFolderName,
            );
            this.activeExpFolderId = userDefaultFolder?.FolderID ?? EMPTY;
            return;
        }
        const selectedFolder = this.experimentFolderSelectorComponent.verifySelectedFolder(experiment.folder);
        this.selectedExpFolderName = selectedFolder?.FolderName ?? this.appStateService.getCurrentUser().globaluserid;
        this.activeExpFolderId = selectedFolder?.FolderID ?? EMPTY;
    }

    /**
     * Method to detect value changes applied on search value and filter data
     * @returns {void}
     * @memberof ExperimentsSearchComponent
     */
    private detectValueChangesAndFilter(): void {
        this.componentSubscriptions.add(
            this.searchValue.valueChanges
                .pipe(
                    filter((selectedValue: string) => {
                        this.totalCount = 0;
                        this.noDataFound = false;
                        this.isLoading =
                            selectedValue?.length >= MIN_SEARCH_VALUE_LENGTH &&
                            this.searchValue.dirty &&
                            this.searchCategoryValue !== this.expSearchCategoryList.ALL_OTHER_EXPERIMENTS &&
                            !this.isAllUnChecked &&
                            (this.searchCategoryValue !== this.expSearchCategoryList.MY_FOLDER ||
                                (this.searchCategoryValue === this.expSearchCategoryList.MY_FOLDER &&
                                    this.selectedExpFolderName !== EMPTY)) &&
                            this.searchCategoryValue !== this.expSearchCategoryList.ALL_SHARED_EXPERIMENTS;
                        this.dataSource = [];
                        this.selectedRowIndex = -1;
                        return this.isLoading;
                    }),
                    debounceTime(SEARCH_DEBOUNCE_TIME),
                    tap(() => {
                        this.selectSearchCriteria();
                    }),
                    switchMap((): any => {
                        return this.getSearchExperiments();
                    }),
                )
                .subscribe({
                    next: (result: any) => {
                        this.isLoading = false;
                        this.combineDatasource(result);
                    },
                    error: (error) => {
                        this.errorHandler(error);
                    },
                }),
        );
    }
}
