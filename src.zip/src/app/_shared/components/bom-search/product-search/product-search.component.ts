/* eslint-disable max-lines */
/* eslint-disable lines-between-class-members */
/* eslint-disable no-param-reassign */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { SelectionModel } from "@angular/cdk/collections";
import {
    Component,
    ElementRef,
    EventEmitter,
    HostListener,
    Input,
    OnInit,
    Output,
    QueryList,
    ViewChild,
    ViewChildren,
} from "@angular/core";
import { UntypedFormControl, Validators } from "@angular/forms";
import { MatAutocompleteSelectedEvent, MatAutocompleteTrigger } from "@angular/material/autocomplete";
import { MatDialog } from "@angular/material/dialog";
import { MatTable } from "@angular/material/table";
import { cloneDeep, delay, each, find, forEach, includes, lowerCase, toLower, uniq, isEqual, sortBy } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { Observable, Subscription } from "rxjs";
import { map, startWith } from "rxjs/operators";
import { ExperimentEditorHelper } from "@te-experiment-editor/helpers/experiment-editor.helper";
import { CreativeReviewHelper } from "src/app/creative-review/helpers/creative-review-helper";
import { DialogHelper } from "@te-shared/helpers/dialog-helper";
import { PayloadHelper } from "@te-shared/helpers/payload-helper";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { ExportToExcelHelper } from "@te-shared/helpers/export-to-excel.helper";
import { RestrictedAccessLabelPipe } from "@te-shared/pipes/restricted-access-label.pipe";
import { EditionSuggesstColumnLayoutHelper } from "../../../../experiment-editor/helpers/edition-suggesst-column-layout.helper";
import {
    DisplayValueModel,
    EditionSuggestionProductRow,
    ExpTrusteeModel,
} from "../../../../experiment-editor/models/experiment-editor.model";
import { EditionSuggesstionHelper } from "../../../../experiment-editor/helpers/edition-suggesstion.helper";
import { GridApiService } from "../../../../experiment-editor/helpers/grid-api-service";
import { TabHelper } from "../../../helpers/tab-helper";
import { TasteEditorUtilClass } from "../../../helpers/taste-editor-utils";
import { AuditValidationPipe } from "../../../pipes/audit-validation.pipe";
import { FlashpointConversionPipe } from "../../../pipes/flashpoint-conversion.pipe";
import { MiniEditorSuggestionHelper } from "../../../helpers/mini-editor-suggestion.helper";
import { EDITION_SUGGESTION, EMPTY, LOADING, TOOLTIP_VISIBLE_LENGTH } from "../../../../app.constant";
import { FLEX_COMPLIANCE_STATUS, ZERO_WITH_DECIMAL } from "../../../../creative-review/creative-review.constant";
import {
    FLAG_COLUMN_VALUE,
    RECENTLY_USED_POPUP_ERROR,
    YES_OPTION,
    NO_OPTION,
    CBW_FLAG_COLUMN_VALUE,
} from "../../../../experiment-editor/constants/experiment-editor.constant";
import { ExperimentEditorService } from "../../../../experiment-editor/helpers/experiment-editor.service";
import { RecentlyUsedActionModel, RecentlyUsedParametersModel } from "../../../../experiment-editor/models/recently-used.model";
import { SalesProductSearchComponent } from "../../../../experiment-editor/quick-search/sales-product-search/sales-product-search.component";
import { AppBroadCastService, AppStateService, ErrorFormatService, MatomoService } from "../../../../_services";
import {
    ADD_TO_CART,
    ALREADY_ADDED_IN_CART,
    ALREADY_OPEN,
    BOM_TYPE,
    CANT_OPEN_MORE_EXPERIMENTS,
    CATEGORY,
    COLUMN_ATTRIBUTE_DISPLAY_LIST,
    COLUMN_LAYOUT_ADDED_PAGE,
    COLUMN_LAYOUT_SUCCESS,
    COMMON_DIALOG_SALES_PRODUCT,
    DEFAULT_SPEC_FLASHPOINT,
    EDITION_SUGGESTION_ACTION_IN,
    EXPERIMENTS_SEARCH,
    IPC,
    LOCKED_BY_STATUS,
    PANEL_CLASS,
    PRODUCTS_SEARCH,
    PRODUCTS_SEARCH_CATEGORIES,
    PRODUCTS_SEARCH_SEARCHBY,
    PRODUCT_SEARCH_CONSTANTS,
    PROJECT_NUMBER_ERROR,
    RECENTLY_USED_ACCESS_LIST,
    REFERENCE_ERRORS,
    SEARCH_AUDIT_STATUS,
    STORE_HEADER_WIDTH_FOR,
    MAX_EXPORPRO_OPEN_LENGTH,
    COLUMN_LAYOUTS_CRITERIA,
    COLUMN_LAYOUT_DEFAULT,
    PASS_AUDIT_RESTRICTED_FLAGS,
    UPDATED_TAB,
    DATA_TYPE,
    NO_PRODUCT_TYPE_MSG,
    DIRECT_SORT_COLUMN_WITHKEY,
    IPC_SELECTION_DIALOG,
    IPC_SELECTION,
} from "../../../constants";
import { PRODUCT } from "../../../constants/context-menu.constant";
import { MARK_FOR_UNDELETE_FLAG } from "../../../constants/experiment.constant";
import { MatomoAction, MatomoCategory, MatomoLabel, SUBTypes } from "../../../enums";
import { BomSearchHelper } from "../../../helpers/bom-search.helper";
import { ExperimentApiService } from "../../../helpers/experiment-api.service";
import { SearchDrawerHelper } from "../../../helpers/search-drawer.helper";
import { ProductSearchList, SortEventModel } from "../../../models/experiments.model";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { BaseColumnHelper } from "../../base-column-layout/helper/base-column-helper";
import { ConfirmationDialogComponent } from "../../confirmation-dialog/confirmation-dialog.component";
import { ProductDataCostHelper } from "../../product-data/product-data-cost/product-data-cost.helper";
import { ProductSearchResponse } from "../../../../master-data/models/ipc-selection-model";
import { IpcSelectionPopupComponent } from "../../../../master-data/ipc-selection-popup/ipc-selection-popup.component";

@Component({
    selector: "app-product-search",
    templateUrl: "./product-search.component.html",
})
export class ProductSearchComponent implements OnInit {
    public categoryHeading = CATEGORY;
    public editionSuggestion = EDITION_SUGGESTION;
    public displayedColumns: string[] = PRODUCT_SEARCH_CONSTANTS.PRODUCT_GRID_COLUMN_LIST;
    public dataSource = [];
    public recentlyViewed = PRODUCTS_SEARCH_CATEGORIES[0];
    public selectedIPC = PRODUCT_SEARCH_CONSTANTS.DEFAULT_IPC_SELECTION;
    public selectedProductCategory;
    public selectedTemplateData = [];
    public searchValue: UntypedFormControl = new UntypedFormControl("", [Validators.required, Validators.minLength(3)]);
    // eslint-disable-next-line unicorn/no-null
    public Category: UntypedFormControl = new UntypedFormControl(null, [Validators.required]);
    public searchResultList: any = [];
    public ipcSelectionList: any;
    public searchCriteria: any;
    public isLoading = false;
    public searchCheckBoxList = cloneDeep(PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_CHECKBOX_LIST);
    public specsCheckboxList = PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_SPECS_CHECKBOX_LIST;
    public searchFilterCheckboxList = [
        ...PRODUCT_SEARCH_CONSTANTS.DEFAULT_PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE_DETAILS,
        ...PRODUCT_SEARCH_CONSTANTS.DEFAULT_CHECKBOX_SELECTION,
    ];
    public searchByFieldsCheckbox = [];
    public searchBySpecCheckbox = [];
    public dynamicColumns = [];
    public selectedQuery = PRODUCT_SEARCH_CONSTANTS.DEFAULT_PRODUCT_QUERY;
    public start = PRODUCT_SEARCH_CONSTANTS.START_FROM;
    public limit = PRODUCT_SEARCH_CONSTANTS.LIMIT;
    public productSearchLimit = PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_LIMIT;
    public end = this.limit + this.start;
    public totalCount = 0;
    public selectedRowIndex = -1;
    public noDataFound = false;
    public isLayoutChanged = false;
    public auditStatus = SEARCH_AUDIT_STATUS;
    public addToCart = ADD_TO_CART;
    public toolTipVisibleLength = TOOLTIP_VISIBLE_LENGTH;
    public showPassAuditToggle = false;
    public disableExcludePlantToggle = false;
    public columnDisplayList = COLUMN_ATTRIBUTE_DISPLAY_LIST;
    public columnLayoutPage = COLUMN_LAYOUT_ADDED_PAGE;
    public isCompliance = false;
    public complianceStatues = FLEX_COMPLIANCE_STATUS;
    public projectNumber: number;
    public selection: SelectionModel<any> = new SelectionModel();
    public productSearchConstant = PRODUCT_SEARCH_CONSTANTS;
    private componentSubscriptions: Subscription = new Subscription();
    @Input() public productSearchCategoryID: number;
    @Input() public deFaultLayoutSelection: any[] = [];
    @Input() public facility: any;
    @Input() public plantId: any;
    @Input() public isIpcView: boolean;
    @Input() public isIpcPick: boolean;
    @Input() public criteriaData: any;
    @Input() public isOpenproduct: boolean;
    @Input() public openedExperimentOrProduct;
    @Input() public cartLists;
    @Input() public selectedCartItemIndex;
    @Input() public gridData;
    @Input() public searchFilterData;
    @Input() public activeExpSource: string;
    @Input() public expCode: string;
    @Input() public isInsertproduct: boolean;
    @Output()
    public emitCartData = new EventEmitter();
    @Output()
    public focusCartData = new EventEmitter();
    @Output()
    public emitProductSearchCategory = new EventEmitter<number>();
    @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;
    @ViewChild(MatTable, { read: ElementRef }) private matTableRef: ElementRef;
    @ViewChild("searchTextBox") searchTextBox: ElementRef;
    @ViewChild("productDataTableContainer") productDataTableContainer: ElementRef;
    @ViewChildren("productDataTable") productDataTable: QueryList<ElementRef>;
    public projectNumberError: string;
    public advanceSearchActive = true;
    public flagYesValue = YES_OPTION;
    public flagColumn = FLAG_COLUMN_VALUE;
    public cbwFlagColumn = CBW_FLAG_COLUMN_VALUE;
    public flashPoint = DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME;
    public flagNoValue = NO_OPTION;
    private maxWSOpenExpLength = MAX_EXPORPRO_OPEN_LENGTH;
    public columnLayouts = COLUMN_LAYOUTS_CRITERIA;
    public pageSize = PRODUCT_SEARCH_CONSTANTS.START_FROM;
    public isScrollVisible: boolean;
    public applicationPermissions = APPLICATION_PERMISSIONS;
    public isOpenProductDataAccessible = true;

    constructor(
        private readonly toastrService: ToastrService,
        private readonly logger: NGXLogger,
        private readonly dialog: MatDialog,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly productDataCostHelper: ProductDataCostHelper,
        private readonly tabHelper: TabHelper,
        private readonly spaceTrim: SpaceTrimPipe,
        private readonly experimentApiService: ExperimentApiService,
        private readonly gridApiService: GridApiService,
        private readonly baseColumnHelper: BaseColumnHelper,
        private readonly experimentEditorService: ExperimentEditorService,
        private readonly editionSuggesstColumnLayoutHelper: EditionSuggesstColumnLayoutHelper,
        private readonly errorFormatService: ErrorFormatService,
        private readonly miniEditorSuggestionHelper: MiniEditorSuggestionHelper,
        private readonly flashpointConversion: FlashpointConversionPipe,
        private readonly auditValidation: AuditValidationPipe,
        private readonly bomSearchHelper: BomSearchHelper,
        private readonly creativeReviewHelper: CreativeReviewHelper,
        private readonly dialogHelper: DialogHelper,
        private readonly payloadHelper: PayloadHelper,
        private readonly securityHelper: SecurityHelper,
        private readonly matomoService: MatomoService,
        private readonly exportToExcelHelper: ExportToExcelHelper,
        private readonly restrictedAccessLabelPipe: RestrictedAccessLabelPipe,
    ) {}

    public ngOnInit(): void {
        this.getProductSearchCriteria();
        this.columnLayoutSelection();
        this.bindAttributesControl();
        this.setColumnLayout();
        this.isOpenProductDataAccessible = this.securityHelper.hasPermission(this.applicationPermissions.PRODUCT_DATA);
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_SEARCH, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    public ngOnDestroy(): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY)
        this.componentSubscriptions.unsubscribe();
    }

    public exportToExcel(): void {
        if (this.dataSource.length === this.totalCount || this.dataSource.length === this.productSearchLimit) {
            this.formatExcelJsonObject(this.dataSource, this.dynamicColumns);
        }
        if (this.dataSource.length < this.totalCount && this.dataSource.length < this.productSearchLimit) {
            this.updateIndex(true);
            this.searchProduct(true);
        }
    }

    /**
     * Method to check load more is need or not
     *
     * @memberof ProductSearchComponent
     */
    @HostListener("window:resize", ["$event"])
    public loadWorkspaceMenu(): void {
        this.updateIsScrollVisible();
    }

    /**
     * Method to get the list of the ipc selection
     *
     * @memberof ProductSearchComponent
     */
    public getProductSearchCriteria(): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.componentSubscriptions.add(
            this.experimentApiService.getProductSearchCriteria().subscribe({
                next: (result) => {
                    if (result) {
                        const defaultCategories = [
                            {
                                ProductSearchID: -1,
                                SearchName: this.recentlyViewed,
                            },
                            PRODUCT_SEARCH_CONSTANTS.DEFAULT_PRODUCT_CATEGORY,
                        ];
                        result.unshift(...defaultCategories);
                        this.ipcSelectionList = result;
                        this.setDefaultProductCategory();
                        this.getProductSearchFilters();
                        this.onSelectIPCSelection();
                        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    }
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.toastrService.error(REFERENCE_ERRORS.PRODUCT_SEARCH_ERROR);
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to update the isScrollVisible flag
     *
     * @memberof ProductSearchComponent
     */
    public updateIsScrollVisible(): void {
        delay(() => {
            this.isScrollVisible =
                this.productDataTableContainer.nativeElement.scrollHeight > this.productDataTableContainer.nativeElement.clientHeight;
        }, 0);
    }

    /**
     * Method to validate that we can show the load more button
     *
     * @return {*}
     * @memberof ProductSearchComponent
     */
    public canShowLoadMoreButton(): boolean {
        return this.totalCount > 0 && this.dataSource.length < this.totalCount && this.pageSize < this.totalCount;
    }

    /**
     * Method to set the default product category
     *
     * @private
     * @memberof ProductSearchComponent
     */
    private setDefaultProductCategory(): void {
        const productSearchCategory: ProductSearchResponse =
            this.productSearchCategoryID ||
            this.productSearchCategoryID === PRODUCT_SEARCH_CONSTANTS.DEFAULT_PRODUCT_CATEGORY.ProductSearchID
                ? this.ipcSelectionList.find((ipc) => {
                      return ipc.ProductSearchID === this.productSearchCategoryID;
                  })
                : this.productCategoryBasedOnUserPreference();
        this.Category.patchValue(productSearchCategory);
        this.selectedProductCategory = productSearchCategory;
        this.selectedIPC = productSearchCategory?.SearchName;
    }

    /**
     * Method to set the default product category based on user preference
     *
     * @private
     * @returns {ProductSearchResponse} ProductSearchResponse
     * @memberof ProductSearchComponent
     */
    private productCategoryBasedOnUserPreference(): ProductSearchResponse {
        const hasDefaultUserPreference = ExperimentEditorHelper.getDefaultUserPreference();
        if (hasDefaultUserPreference.defaultProductCategory) {
            return this.ipcSelectionList.find((ipc) => {
                return ipc.ProductSearchID === hasDefaultUserPreference?.defaultProductCategory;
            });
        }
        return this.ipcSelectionList.find((ipc) => {
            return ipc.ProductSearchID === PRODUCT_SEARCH_CONSTANTS.DEFAULT_PRODUCT_CATEGORY.ProductSearchID;
        });
    }

    /**
     * Method to bind the valueChanges functions for component forms
     *
     * @param {number} index
     * @memberof BaseColumnLayoutComponent
     */
    public bindAttributesControl(): void {
        this.searchResultList = this.Category.valueChanges.pipe(
            startWith(""),
            map((value) => BomSearchHelper.filterCategoryValues(this.ipcSelectionList, "SearchName", value?.SearchName ?? value)),
        );
    }

    /**
     * Method to shift focus to cart from search results table
     *
     * @param {KeyboardEvent} event
     * @memberof ProductSearchComponent
     */
    public shiftFocusToCart(event: KeyboardEvent): void {
        event.stopPropagation();
        event.preventDefault();
        this.autocomplete.closePanel();
        this.focusCartData.emit();
    }

    /**
     * Method to validate and add product to mini-editor
     *
     * @param {KeyboardEvent} event
     * @memberof ProductSearchComponent
     */
    public validateAndAddProduct(event: KeyboardEvent) {
        event.preventDefault();
        const productData = this.selection.selected[0];
        const isInValid = this.isOpenproduct
            ? !productData.otherdetails.bomright || !productData.otherdetails.isbom
            : this.auditValidation.transform(productData.audit?.status, true);
        // eslint-disable-next-line no-unused-expressions
        !isInValid && this.addValidProductToCart(productData);
    }

    /**
     * Method to switch page focus to first data row
     *
     * @memberof ProductSearchComponent
     */
    public focusOnFirstDataRow(event?: KeyboardEvent): void {
        this.autocomplete.closePanel();
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        if (this.dataSource?.length > 0) {
            this.selectedRowIndex = 0;
            this.selection.select(this.dataSource[this.selectedRowIndex]);

            BomSearchHelper.focusSelectedRowInTable(this.productDataTable, this.selectedRowIndex);
        }
    }

    /**
     * Method to switch page focus to search text box
     *
     * @memberof ProductSearchComponent
     */
    public focusSearchTextBox(shouldSelect = false): void {
        BomSearchHelper.focusOrSelectTextbox(this.searchTextBox, shouldSelect);
    }

    /**
     * Method to get the selected IPC search
     *
     * @param {*} selectedIPC
     * @returns {*}
     * @memberof ProductSearchComponent
     */
    public getIPCSelctionQuery(criteria: any): any {
        if (criteria === PRODUCT_SEARCH_CONSTANTS.DEFAULT_IPC_SELECTION) {
            return { filter: {} };
        }
        const query = find(this.ipcSelectionList, (list) => {
            return list.SearchName === criteria;
        });
        return query && query.Criteria ? JSON.parse(query.Criteria) : {};
    }

    /**
     * Method to set the search criteria
     *
     * @param {*} selectedIPC
     * @returns {*}
     * @memberof ProductSearchComponent
     */
    // eslint-disable-next-line sonarjs/cognitive-complexity, max-lines-per-function
    public onSelectIPCSelection(selectedIPC?: MatAutocompleteSelectedEvent): void {
        const isSearchValidatorExist = this.searchValue.hasValidator(Validators.required);
        if (selectedIPC) {
            this.selectedIPC = selectedIPC?.option?.value?.SearchName;
            this.selectedProductCategory = selectedIPC?.option?.value;
            this.productSearchCategoryID = this.selectedProductCategory?.ProductSearchID;
            this.Category.setValue(this.selectedProductCategory);
            this.tabHelper.updateTab(
                UPDATED_TAB,
                this.tabHelper.getActiveTab().UserTabID,
                [],
                EMPTY,
                this.selectedProductCategory?.ProductSearchID,
            );
        }
        if (this.selectedIPC === this.recentlyViewed && isSearchValidatorExist) {
            this.searchValue.clearValidators();
            this.searchValue.updateValueAndValidity();
        } else if (this.selectedIPC !== this.recentlyViewed && !isSearchValidatorExist) {
            this.searchValue.setValidators([Validators.required, Validators.minLength(3)]);
            this.searchValue.updateValueAndValidity();
        }
        this.searchByFieldsCheckbox = [];
        this.searchBySpecCheckbox = [];
        if (this.searchFilterCheckboxList) {
            forEach(this.searchFilterCheckboxList, (checkboxDetails) => {
                if (PRODUCT_SEARCH_CONSTANTS.DEFAULT_CHECKBOX_SELECTION.includes(checkboxDetails)) {
                    this.searchByFieldsCheckbox.push(checkboxDetails);
                    return;
                }
                this.searchBySpecCheckbox.push(checkboxDetails);
            });
        }
        delay(() => {
            this.focusSearchTextBox();
        }, 0);

        this.resetAttributes();
        if (this.selectedIPC === this.recentlyViewed) {
            this.getSearchProducts();
            return;
        }
        this.searchCriteria = this.isIpcView ? this.criteriaData : this.getIPCSelctionQuery(this.selectedIPC);
        const pageDataDetails = {
            from: PRODUCT_SEARCH_CONSTANTS.START_FROM,
            recordcount: this.isInsertproduct || this.isOpenproduct ? this.productSearchLimit : PRODUCT_SEARCH_CONSTANTS.LIMIT,
        };
        const auditQueries = {
            checkrestricted: true,
            plantId: this.plantId !== EMPTY && !this.isOpenproduct ? this.plantId : EMPTY,
            activeExpSource: this.activeExpSource !== EMPTY && !this.isOpenproduct ? this.activeExpSource : EMPTY,
            expCode: this.expCode !== EMPTY && !this.isOpenproduct ? this.expCode : EMPTY,
        };

        if (!this.isIpcView) {
            if (
                (this.searchByFieldsCheckbox.includes(PRODUCT_SEARCH_CONSTANTS.DEFAULT_CHECKBOX_SELECTION[0]) ||
                    this.searchByFieldsCheckbox.includes(PRODUCT_SEARCH_CONSTANTS.DEFAULT_CHECKBOX_SELECTION[1])) &&
                this.searchValue.value
            ) {
                if (this.searchCriteria?.filter) {
                    this.searchCriteria.filter.byfields = [];
                } else {
                    this.searchCriteria.filter = {
                        byfields: [],
                    };
                }
                each(this.searchByFieldsCheckbox, (item: string) => {
                    this.searchCriteria.filter.byfields.push({
                        name: [item],
                        value: this.spaceTrim.transform(this.searchValue.value),
                        operator: this.selectedQuery,
                    });
                });
            }
            if (this.searchBySpecCheckbox.length > 0 && this.searchValue.value) {
                this.searchCriteria.filter.specOR = this.searchCriteria.filter.specOR ?? [];
                each(this.searchBySpecCheckbox, (specs: string) => {
                    if (
                        this.searchCriteria.filter?.specOR.map((spec) => spec[EXPERIMENTS_SEARCH.EXP_CODE]).includes(specs) &&
                        PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE_DETAILS.includes(specs)
                    ) {
                        forEach(this.searchCriteria.filter.specOR, (spec, index) => {
                            if (spec.code === specs) {
                                this.searchCriteria.filter.specOR[index] = {
                                    code: spec.code,
                                    value: this.spaceTrim.transform(this.searchValue.value),
                                    operator: this.selectedQuery,
                                };
                            }
                        });
                    } else {
                        this.searchCriteria.filter.specOR.push({
                            code: specs,
                            value: this.spaceTrim.transform(this.searchValue.value),
                            operator: this.selectedQuery,
                        });
                    }
                });
            }

            this.searchCriteria.filter.sortby = {
                ipc: {
                    order: PRODUCT_SEARCH_CONSTANTS.SORT_ORDER,
                },
            };
        }

        if (this.plantId !== "" && this.showPassAuditToggle && !this.isOpenproduct) {
            if (this.searchCriteria?.filter?.flagswithinheritedmustnot?.length > 0) {
                this.searchCriteria.filter.flagswithinheritedmustnot.push(...PASS_AUDIT_RESTRICTED_FLAGS);
            } else {
                this.searchCriteria.filter.flagswithinheritedmustnot = PASS_AUDIT_RESTRICTED_FLAGS;
            }
            const plantAppend = [
                {
                    value: this.plantId,
                    operator: "equalsto",
                },
            ];
            if (this.searchCriteria && this.searchCriteria.query) {
                this.searchCriteria.query.prodallocationcode = plantAppend;
            } else {
                this.searchCriteria = {
                    ...this.searchCriteria,
                    query: {
                        prodallocationcode: plantAppend,
                    },
                };
            }
        }

        this.searchCriteria.filter.sortby = {
            ipc: {
                order: PRODUCT_SEARCH_CONSTANTS.SORT_ORDER,
            },
        };
        this.searchCriteria = { ...this.searchCriteria, ...pageDataDetails, ...auditQueries };

        if (this.isIpcView) {
            this.searchProduct();
        }
    }

    /**
     * Method to display the search name of product category
     *
     * @param {{ ProductSearchID: number; SearchName: string; ColumnValue: string } | string} category
     * @returns {string}
     * @memberof ProductSearchComponent
     */
    // eslint-disable-next-line class-methods-use-this
    public displayProductCategory(category: ProductSearchResponse): string {
        if (
            (category as unknown as string) === PRODUCT_SEARCH_CONSTANTS.DEFAULT_IPC_SELECTION ||
            (category as unknown as string) === PRODUCTS_SEARCH_CATEGORIES[0]
        ) {
            return category as unknown as string;
        }
        // eslint-disable-next-line no-nested-ternary
        return category ? (typeof category === DATA_TYPE.STRING ? (category as unknown as string) : category?.SearchName) : EMPTY;
    }

    /**
     * Method to reset the values
     *
     * @memberof ProductSearchComponent
     */
    public resetAttributes(): void {
        this.dataSource = [];
        this.selectedRowIndex = -1;
        this.totalCount = 0;
        this.start = PRODUCT_SEARCH_CONSTANTS.START_FROM;
        this.limit =
            this.isInsertproduct || this.isOpenproduct ? PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_LIMIT : PRODUCT_SEARCH_CONSTANTS.LIMIT;
        this.end = this.limit + this.start;
        this.noDataFound = false;
        this.isLoading = false;
        this.pageSize = PRODUCT_SEARCH_CONSTANTS.START_FROM;
    }

    /**
     * Method to subscribe the services
     *
     * @memberof ProductSearchComponent
     */
    public columnLayoutSelection(): void {
        this.componentSubscriptions.add(
            this.appBroadCastService.editLayouts.subscribe((results) => {
                this.isLayoutChanged = true;
                const dynamicColumns = this.editionSuggesstColumnLayoutHelper.getDynamicColumnsForColumLayout(results, this.facility);
                const currentDynamicColumns = this.dynamicColumns?.map((col) => col.value);
                const newDynamicColumns = dynamicColumns?.dynamicColumns?.map((col) => col.value);
                if (isEqual(currentDynamicColumns, newDynamicColumns)) {
                    return;
                }
                this.dynamicColumns = dynamicColumns?.dynamicColumns ?? this.dynamicColumns;
                this.selectedTemplateData = dynamicColumns.selectedTemplateData;
                this.formDynamicColumns();
                if (results.eventType) {
                    this.toastrService.success(COLUMN_LAYOUT_SUCCESS.APPLIED_COLUMN_LAYOUT);
                }
                this.getSearchColumnHeaderWidth("productSearch");
            }),
        );
    }

    /**
     * Method to form dynamic product columns
     * @returns {void}
     * @memberof ProductSearchComponent
     */
    public formDynamicColumns(): void {
        const columns = this.dynamicColumns.map((column) => column.value);
        this.displayedColumns = uniq([...PRODUCT_SEARCH_CONSTANTS.PRODUCT_GRID_COLUMN_LIST, ...columns]);
        if (this.dataSource.length > 0) {
            this.searchProduct();
        }
    }

    /**
     * Method to convert the cost of product based on currency
     *
     * @param {*} productData
     * @param {DisplayValueModel} column
     * @return {*}  {string}
     * @memberof ProductSearchComponent
     */
    // eslint-disable-next-line class-methods-use-this ,@typescript-eslint/explicit-module-boundary-types
    public costConversionByCurrency(productData: any, column: DisplayValueModel, isTooltip = false): string {
        if (isTooltip && (column?.columns === this.columnLayouts.TRUSTEE || column?.columns === this.columnLayouts.CC_INDICATOR)) return;
        if (productData[column?.value] && column?.isCost) {
            // eslint-disable-next-line consistent-return
            return ProductDataCostHelper.costConversionByCurrency(productData[column?.value]);
        }
        // eslint-disable-next-line consistent-return
        return column.columns === this.columnLayouts.TRUSTEE ? this.getTrusteeDisplayName(productData) : productData[column?.value];
    }

    /**
     * Method to construct search Payload with layout details
     *
     * @memberof ProductSearchComponent
     */
    public searchProductWithSelectedTemplate() {
        const esPayload = {
            esDetails: this.searchCriteria?.esDetails ?? this.searchCriteria,
            layoutDetails: this.selectedTemplateData ?? [],
        };
        this.searchCriteria = esPayload;
        if (this.isCompliance) {
            this.searchCriteria.complicanceDetails = {
                projectNumber: this.projectNumber,
            };
        }
    }

    /**
     * Method to trigger edition suggestion popup on clicking bulb icon
     *
     *
     * @return {void}
     * @memberof ProductSearchComponent
     */
    public editionSuggestionOfProductSearch(productData: any): void {
        const editionSuggestionData: EditionSuggestionProductRow = {
            ExpFormulaID: EMPTY,
            IsDelete: 0,
            Parts: 0,
            SUBCode: productData?.ipc,
            SUBType: BOM_TYPE.PRODUCT,
            otherdetails: productData?.otherdetails,
            isSolution: productData?.isSolution,
            isFema: productData?.isFema,
            isEnum: productData?.isEnum,
            isVariant: productData?.isVariant,
        };
        this.miniEditorSuggestionHelper.triggerEditSuggestPopup(
            editionSuggestionData,
            this.gridData,
            this.selectedCartItemIndex,
            EDITION_SUGGESTION_ACTION_IN.PRODUCT_SEARCH,
            this.cartLists,
        );
    }

    /**
     * Method to search the product
     *
     * @memberof ProductSearchComponent
     */
    public searchProduct(isExport = false) {
        this.isLoading = true;
        this.searchProductWithSelectedTemplate();
        this.searchCriteria.isOpenproduct = this.isOpenproduct;
        this.searchCriteria.isInsertproduct = this.isInsertproduct;
        this.searchCriteria.plantInfo =
            this.dynamicColumns?.length > 0 ? this.payloadHelper.getStockPlantInfo(this.dynamicColumns, this.facility) : [];
        if (isExport) this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.componentSubscriptions.add(
            this.getSearchProducts().subscribe({
                next: (result: any) => {
                    if (this.showPassAuditToggle && this.Category?.value?.SearchName !== this.recentlyViewed) {
                        const passAuditsOnly = result?.searchresults?.filter(
                            (product) =>
                                product?.audit.status === SEARCH_AUDIT_STATUS.STATUS_INFO ||
                                product?.audit.status === SEARCH_AUDIT_STATUS.STATUS_PASS,
                        );
                        const productResults = {
                            searchresults: passAuditsOnly,
                            total: result?.total,
                        };
                        this.combineDatasource(productResults, isExport);
                    } else {
                        this.combineDatasource(result, isExport);
                    }
                    this.isLayoutChanged = false;
                    this.updateIsScrollVisible();
                },
                error: (error) => {
                    this.isLoading = false;
                    this.errorHandler(error);
                    if (isExport) this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                },
            }),
        );
    }

    /**
     * Method to return product search observable based on the category selection
     *
     * @return {*}  {Observable<ProductSearchList>}
     * @memberof ProductSearchComponent
     */
    public getSearchProducts(): Observable<ProductSearchList> {
        if (this.selectedIPC !== this.recentlyViewed) {
            this.searchCriteria.isAllCategorySelected =
                this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION) === false
                    ? this.selectedIPC !== PRODUCT_SEARCH_CONSTANTS.DEFAULT_IPC_SELECTION
                    : false;
            return this.gridApiService.searchIpc(this.searchCriteria);
        }
        const payload = {
            limit: PRODUCTS_SEARCH.LIMIT,
            offset: PRODUCTS_SEARCH.OFFSET,
            searchType: this.selectedQuery,
            searchText: this.searchValue.value ?? "",
            searchBy: [],
            isOpenproduct: this.isOpenproduct,
            isInsertproduct: this.isInsertproduct,
            esPayload: {
                esDetails: {
                    activeExpSource: this.activeExpSource,
                    checkrestricted: true,
                    expCode: this.expCode,
                    plantId: this.plantId,
                    from: PRODUCTS_SEARCH.OFFSET,
                    recordcount: PRODUCTS_SEARCH.LIMIT,
                },
                layoutDetails: this.selectedTemplateData?.length ? this.selectedTemplateData : [],
                plantInfo: this.dynamicColumns?.length > 0 ? this.payloadHelper.getStockPlantInfo(this.dynamicColumns, this.facility) : [],
                complicanceDetails: this.searchCriteria?.complicanceDetails,
            },
        };
        each(this.searchByFieldsCheckbox, (item: string) => {
            if (PRODUCTS_SEARCH_SEARCHBY[item]) payload.searchBy.push(PRODUCTS_SEARCH_SEARCHBY[item]);
        });
        return this.experimentApiService.getRecentlyUsed(SUBTypes.PRODUCT, payload) as unknown as Observable<ProductSearchList>;
    }

    /**
     * Method to prepare the datasource
     *
     * @memberof ProductSearchComponent
     */
    public combineDatasource(data: any, isExport = false): void {
        if ((this.isIpcView && data?.total) || (!this.isIpcView && data?.searchresults?.length > 0)) {
            forEach(data?.searchresults, (product) => {
                product.isSolution = EditionSuggesstionHelper.doesSolutionExist(product?.otherdetails);
                product.isFema = EditionSuggesstionHelper.doesFemaExist(product?.otherdetails);
                product.isEnum = EditionSuggesstionHelper.doesENumExist(product?.otherdetails);
                product.isVariant = EditionSuggesstionHelper.doesVariantExist(product?.otherdetails);
            });
            if (this.isLayoutChanged) {
                this.dataSource = [];
                this.selectedRowIndex = -1;
            }
            // eslint-disable-next-line unicorn/prefer-spread
            const productList = TasteEditorUtilClass.getUniqueListBy(this.dataSource.concat(data.searchresults), IPC);
            this.dataSource = sortBy(productList, (product) => product?.audit?.priority);
            this.flagSelection(this.dataSource);
            this.technologySelection(this.dataSource);
            if (this.displayedColumns.includes(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME)) {
                this.dataSource = this.flashpointConversion.transform(this.dataSource);
            }
            if (!this.totalCount) {
                this.totalCount = data.total;
                this.noDataFound = false;
            }
            this.isLoading = false;
            if (isExport) {
                this.exportToExcel();
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            }
        } else {
            this.noDataFound = true;
            this.isLoading = false;
            if (isExport) this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
        }
    }
    /**
     * Method to display technology
     * @param {*} technology
     * @memberof ProductSearchComponent
     */
    public technologySelection(technology): void {
        const columns = this.dynamicColumns.map((column) => ({ value: column.value, columnName: column.columns }));
        forEach(technology, (product) => {
            const techList = product?.otherdetails?.technology;
            if (!techList || !product?.otherdetails?.isbom) {
                return;
            }
            forEach(columns, (column) => {
                const attribute = find(techList, (item) => item.tag === column.columnName);
                if (attribute) {
                    const columnData =
                        attribute === undefined ? NO_PRODUCT_TYPE_MSG : `${attribute.technologydescription} (${attribute.technologyid})`;

                    Object.assign(product, {
                        [column.value]: columnData,
                    });
                }
            });
        });
    }
    /**
     * Method to display flag %
     * @param {*} flagDetail
     * @memberof ProductSearchComponent
     */
    public flagSelection(flagDetail): void {
        const columns = this.dynamicColumns.map((column) => ({ value: column.value, columnName: column.columns }));
        forEach(flagDetail, (product) => {
            const flagList = product?.otherdetails?.flags;
            if (!flagList) {
                return;
            }
            forEach(columns, (column) => {
                const attribute = find(
                    flagList,
                    (item) =>
                        item.flagcode === column.value &&
                        (column.columnName === this.flagColumn || column.columnName === this.cbwFlagColumn),
                );
                if (attribute) {
                    const columnData =
                        attribute === undefined
                            ? NO_OPTION
                            : `${
                                  attribute?.inheritedflag
                                      ? `${YES_OPTION} (${Number((Number(attribute?.inheritedcontent) * 100).toFixed(3))}%)`
                                      : YES_OPTION
                              }`;
                    Object.assign(product, {
                        [column.value]: columnData,
                    });
                }
            });
        });
    }

    /**
     * Method to enter the search button
     *
     * @memberof ProductSearchComponent
     */
    public onEnterSearch(): void {
        if (!this.Category.valid) return;
        if (
            (!this.searchValue.valid || this.searchValue?.value?.trim().length < 3) &&
            this.Category?.value?.SearchName !== this.recentlyViewed
        ) {
            if (this.dataSource?.length > PRODUCT_SEARCH_CONSTANTS.EMPTY_SEARCH_RESULT_COUNT) {
                this.dataSource = [];
                this.totalCount = PRODUCT_SEARCH_CONSTANTS.EMPTY_SEARCH_RESULT_COUNT;
            }
            this.searchValue.markAsDirty();
            return;
        }
        this.Category.setValue(this.selectedProductCategory);
        this.emitProductSearchCategory.emit(this.productSearchCategoryID);
        this.dataSource = [];
        this.selectedRowIndex = -1;
        if (
            (!this.isCompliance || (this.isCompliance && this.projectNumber)) &&
            !this.isLoading &&
            this.searchFilterCheckboxList.length > 0
        ) {
            this.projectNumberError = "";
            this.onSelectIPCSelection();
            this.isLoading = true;
            this.searchProduct();
        }
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_SEARCH, MatomoAction.CLICK, MatomoLabel.ON_ENTER_SEARCH);
    }

    /**
     * Method to invoke when scrolling the table
     *
     * @param {*} event
     * @returns {*}
     * @memberof ProductSearchComponent
     */
    public onTableScroll(event: any): any {
        if (!this.isOpenproduct && !this.isInsertproduct) {
            const tableViewHeight = event.target.offsetHeight;
            const tableScrollHeight = event.target.scrollHeight;
            const scrollLocation = event.target.scrollTop;

            // If the user has scrolled within 200px of the bottom, add more data
            const buffer = 200;
            const limit = tableScrollHeight - tableViewHeight - buffer;
            if (scrollLocation > limit && !this.isLoading && this.dataSource.length < this.totalCount && this.pageSize < this.totalCount) {
                this.isLoading = true;
                this.updateIndex();
                this.searchProduct();
            }
        }
    }

    /**
     * Method to invoke the process of data fetching when the text field search or table scroll happen
     *
     * @memberof ProductSearchComponent
     */
    public onLoadMore(): void {
        if (
            !this.isLoading &&
            this.dataSource.length < this.totalCount &&
            this.pageSize < this.totalCount &&
            !this.isInsertproduct &&
            !this.isOpenproduct
        ) {
            this.isLoading = true;
            this.updateIndex();
            this.searchProduct();
        }
    }

    /**
     * Method to update the count of start and limit
     *
     * @memberof ProductSearchComponent
     */
    public updateIndex(isExport = false) {
        this.pageSize += this.isInsertproduct || this.isOpenproduct ? this.productSearchLimit : PRODUCTS_SEARCH.LIMIT;
        if (isExport) {
            this.searchCriteria.esDetails.recordcount = this.productSearchLimit - this.pageSize;
            this.pageSize += this.productSearchLimit - this.pageSize;
        }
        this.start = this.end;
        this.end = this.limit + this.start;
        this.searchCriteria.esDetails.from = this.start;
    }

    /**
     * Method to select the checkbox
     *
     * @param {*} event
     * @param {string} value
     * @returns {*}
     * @memberof ProductSearchComponent
     */
    // eslint-disable-next-line consistent-return
    public onSelectionList(event: any, value: string): any {
        this.searchCheckBoxList.forEach((checkBox) => {
            if (value === checkBox.searchCriteria) checkBox.checked = event.checked;
        });
        const lowerCaseValue = toLower(value);
        const hasDefaultSpecsCheckboxValues = includes(this.specsCheckboxList, value);
        const hasCheckboxValues = this.searchFilterCheckboxList.find((checkBoxValue) => {
            return checkBoxValue === value || checkBoxValue === lowerCaseValue;
        });
        if (!hasCheckboxValues && event.checked && !hasDefaultSpecsCheckboxValues) {
            this.searchFilterCheckboxList.push(lowerCaseValue);
            return;
        }
        if (!hasCheckboxValues && event.checked && hasDefaultSpecsCheckboxValues) {
            this.searchFilterCheckboxList.push(PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE[value]);
            return;
        }
        if (hasDefaultSpecsCheckboxValues) {
            const index = this.searchFilterCheckboxList.indexOf(PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE[value]);
            this.searchFilterCheckboxList.splice(index, 1);
        } else {
            const index = this.searchFilterCheckboxList.indexOf(lowerCaseValue);
            this.searchFilterCheckboxList.splice(index, 1);
        }
    }

    /**
     * Method to handle errors
     *
     * @memberof ProductSearchComponent
     */
    public errorHandler(error: any) {
        this.toastrService.error(REFERENCE_ERRORS.PRODUCT_SEARCH_ERROR);
        this.logger.error(error);
    }

    /**
     * Method to add the product to cart
     * @param {any} cartData
     * @memberof ProductSearchComponent
     */
    public onAddProductToCart(cartData): void {
        if (this.isOpenproduct && this.validateOpenProduct(cartData)) {
            this.formatCartData(cartData);
        } else if (!this.isOpenproduct) {
            this.addValidProductToCart(cartData);
        }
    }

    /**
     * Method to format cart data to open as experiment
     * @param {any} cartData
     * @memberof ProductSearchComponent
     */
    public formatCartData(cartData) {
        const cartProductData = {
            SUBCode: cartData.ipc,
            SUBType: BOM_TYPE.PRODUCT,
            ExpName: cartData?.otherdetails?.description,
            ExpCode: cartData.ipc,
            // eslint-disable-next-line unicorn/no-null
            ExpID: null,
            IPC: cartData.ipc,
            IsLocked: LOCKED_BY_STATUS.LOCKED,
            otherdetails: cartData.otherdetails,
            Type: PRODUCT,
        };
        this.emitCartData.emit(cartProductData);
    }

    /**
     * Method to add the product to cart
     * @param {any} cartData
     * @memberof ProductSearchComponent
     */
    public addValidProductToCart(cartData) {
        this.selectedRowIndex = -1;
        const cartProductData = {
            ExpFormulaID: EMPTY,
            SUBCode: cartData.ipc,
            description: cartData.description,
            Instruction: undefined,
            otherdetails: cartData.otherdetails,
            code: cartData.ipc,
            SUBType: BOM_TYPE.PRODUCT,
            Parts: ZERO_WITH_DECIMAL,
            IsDelete: MARK_FOR_UNDELETE_FLAG,
        };
        this.emitCartData.emit(cartProductData);
    }

    /**
     * Method to display IPC information when IPC number is clicked
     * @param {string} ipc
     * @memberof ProductSearchComponent
     */
    public onIpcTextClick(ipc: string): void {
        if (this.isOpenProductDataAccessible) {
            this.dialogHelper.onOpenViewProductDialog(ipc);
            this.matomoService.trackEvent(MatomoCategory.PRODUCT_SEARCH, MatomoAction.CLICK, MatomoLabel.ON_IPC_TEXT_CLICK);
        }
    }

    /**
     * Method to add product to the cart
     *
     * @param {any} product
     * @memberof ProductSearchComponent
     */
    // eslint-disable-next-line max-lines-per-function
    public validateOpenProduct(productData): boolean {
        productData.IPC = productData.ipc;
        productData.Type = PRODUCT;
        if (this.openedExperimentOrProduct?.length >= 0) {
            const isMaxExpExceeds = SearchDrawerHelper.isMaxExpExceeds(this.openedExperimentOrProduct, this.cartLists);
            if (isMaxExpExceeds) {
                const dialogMessage = CANT_OPEN_MORE_EXPERIMENTS;
                // eslint-disable-next-line prettier/prettier
                dialogMessage.subMesssage = `Cannot add ${
                    this.cartLists.length + 1
                } BOM items to compare since it exceeds maximum capacity of ${
                    this.maxWSOpenExpLength
                } BOMs that can be opened in the Experiment BOM. You can open ${
                    this.maxWSOpenExpLength - this.openedExperimentOrProduct.length
                } BOMs to compare.`;
                this.dialog.open(ConfirmationDialogComponent, {
                    panelClass: PANEL_CLASS,
                    width: "540px",
                    disableClose: true,
                    data: dialogMessage,
                });
                return false;
            }
            const isAlreadyOpened = SearchDrawerHelper.isAlreadyOpened(productData, this.openedExperimentOrProduct);
            if (isAlreadyOpened) {
                const dialogMessage = ALREADY_OPEN;
                dialogMessage.subMesssage = `${productData.ipc} is already open in the current tab of the Experiment BOM screen.`;
                dialogMessage.message = `Product already open `;
                this.dialog.open(ConfirmationDialogComponent, {
                    panelClass: PANEL_CLASS,
                    width: "540px",
                    disableClose: true,
                    data: ALREADY_OPEN,
                });
                return false;
            }
            const isAddedInCart = SearchDrawerHelper.isAddedInCart(productData, this.cartLists);
            if (isAddedInCart) {
                const dialogMessage = ALREADY_ADDED_IN_CART;
                dialogMessage.subMesssage = `${productData.ipc} is already added in the cart`;
                dialogMessage.message = `Product already in cart `;
                this.dialog.open(ConfirmationDialogComponent, {
                    panelClass: PANEL_CLASS,
                    width: "540px",
                    disableClose: true,
                    data: ALREADY_ADDED_IN_CART,
                });
                return false;
            }
        }
        return true;
    }

    /**
     * Method to set layout in grid
     * @returns {void}
     * @memberof ProductSearchComponent
     */
    public setColumnLayout(): void {
        let lastUsedLayout = AppStateService.getLastUsedLColumnLayout() ?? [];
        if (lastUsedLayout?.length === 0 && this.gridData.fromLandingPage) {
            this.baseColumnHelper.getSavedColumnLayout().subscribe({
                next: (columnLayoutList) => {
                    if (columnLayoutList) {
                        this.baseColumnHelper.formatColumnLayoutData(columnLayoutList);
                        const savedColumnLayout = AppStateService.getSavedColumnLayoutList();
                        lastUsedLayout = savedColumnLayout?.filter(
                            (columnLayout) => columnLayout.IsDefault === COLUMN_LAYOUT_DEFAULT.IS_DEFAULT,
                        );
                    }
                    if (lastUsedLayout?.length === 0) {
                        lastUsedLayout.push(BaseColumnHelper.setDefaultAtrributes());
                    }
                    this.baseColumnHelper.formatColumnLayoutInfo(lastUsedLayout);
                },
                error: (error) => {
                    this.logger.error(error);
                },
            });
        } else {
            this.baseColumnHelper.setColumnLayout();
        }
    }

    /**
     * Method to open the recently used popup and get the list
     *
     * @memberof ProductSearchComponent
     */
    public onOpenRecentUsedPopup(): void {
        const selectedDataParameters: RecentlyUsedParametersModel = {
            type: RECENTLY_USED_ACCESS_LIST.OPEN_PRODUCT,
        };
        this.componentSubscriptions.add(
            this.experimentEditorService.handleRecentlyUsedPopup(undefined, selectedDataParameters).subscribe({
                next: (result: RecentlyUsedActionModel) => {
                    if (result && result.subType === SUBTypes.PRODUCT && this.searchValue.value !== result.product?.ipc) {
                        this.searchValue.setValue(result.product?.ipc);
                        this.onEnterSearch();
                    }
                },
                error: (error) => {
                    this.errorFormatService.logFormattedError(RECENTLY_USED_POPUP_ERROR, error);
                },
            }),
        );
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_SEARCH, MatomoAction.CLICK, MatomoLabel.OPEN_RECENTLY_USED_POPUP);
    }

    /**
     * Method to open the popup to search product by sales number
     *
     * @memberof ProductSearchComponent
     */
    public onOpenSalesNumber(): void {
        const salesInfo = COMMON_DIALOG_SALES_PRODUCT;
        salesInfo.data = {
            type: RECENTLY_USED_ACCESS_LIST.OPEN_PRODUCT,
        };
        const dialogReference = this.dialog.open(SalesProductSearchComponent, salesInfo);
        this.componentSubscriptions.add(
            dialogReference.afterClosed().subscribe((product) => {
                if (product && this.searchValue.value !== product?.ipc) {
                    this.searchValue.setValue(product?.ipc);
                    this.onEnterSearch();
                }
            }),
        );
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_SEARCH, MatomoAction.CLICK, MatomoLabel.OPEN_SALES_NUMBER);
    }

    /**
     * Method to sort product search columns
     * @param {SortEventModel} sortEvent
     * @returns {void}
     * @memberof ProductSearchComponent
     */
    public sortProductSearch(sortEvent: SortEventModel): void {
        if (this.selectedIPC === this.recentlyViewed) {
            this.sortRecentlyProduct(sortEvent);
            return;
            // eslint-disable-next-line no-else-return
        } else if (this.searchCriteria.esDetails) {
            this.searchCriteria.esDetails.filter.sortby = BomSearchHelper.sortProductSearch(sortEvent, this.dynamicColumns);
        } else {
            this.searchCriteria.filter.sortby = BomSearchHelper.sortProductSearch(sortEvent, this.dynamicColumns);
        }
        this.dataSource = [];
        this.selectedRowIndex = -1;
        this.searchProduct();
    }

    /**
     * Method to refresh table and remove project numver value if compliance is false
     * @returns {void}
     * @memberof ProductSearchComponent
     */
    public onComplianceChange(): void {
        if (this.isCompliance) return;
        this.projectNumber = undefined;
        this.dataSource = [];
        this.selectedRowIndex = -1;
    }

    /**
     * Method to store the search filter value in session
     * @returns {void}
     * @memberof ProductSearchComponent
     */
    public storeProductSearchFilters(): void {
        const currentWorkspace = this.tabHelper.getActiveTab();
        currentWorkspace.SearchFilters.Product = {
            category: this.selectedIPC,
            usingOption: this.selectedQuery,
            searchText: this.searchValue.value,
            ProjectNumber: this.projectNumber,
            advanceSearch: this.advanceSearchActive,
            showCompatible: this.showPassAuditToggle,
            compliance: this.isCompliance,
            // eslint-disable-next-line unicorn/no-useless-spread
            checkBox: [...this.searchCheckBoxList.filter((checkBox) => checkBox.checked).map((checkBox) => checkBox.searchCriteria)],
        };
    }

    /**
     * Method to get the search filter values from session and bind
     *
     * @memberof ProductSearchComponent
     */
    public getProductSearchFilters(): void {
        if (this.isOpenproduct) {
            this.getDefaultValue();
            return;
        }
        if (this.searchFilterData && this.searchFilterData?.Product) {
            this.searchFilterCheckboxList = [];
            const product = this.searchFilterData.Product;
            this.searchCheckBoxList.forEach((searchCheckBox) => {
                const checkBox = searchCheckBox;
                checkBox.checked = checkBox.checked ?? product.checkBox.includes(checkBox.searchCriteria);
                if (checkBox.checked && PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_SPECS_CHECKBOX_LIST.includes(checkBox.searchCriteria)) {
                    this.searchFilterCheckboxList.push(
                        PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE[checkBox.searchCriteria],
                    );
                } else if (
                    checkBox.checked &&
                    !PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_SPECS_CHECKBOX_LIST.includes(checkBox.searchCriteria)
                ) {
                    this.searchFilterCheckboxList.push(lowerCase(checkBox.searchCriteria));
                }
            });
            const isCategoryExist = this.ipcSelectionList.find((ipcSelection) => ipcSelection.SearchName === product.category);
            this.selectedIPC = isCategoryExist ? product.category : this.selectedIPC;
            this.selectedQuery = product.usingOption;
            this.projectNumber = product.ProjectNumber;
            this.advanceSearchActive = product.advanceSearch;
            this.showPassAuditToggle = product.showCompatible;
            this.isCompliance = product.compliance;
            this.searchValue.setValue(product.searchText);
            this.Category.setValue(isCategoryExist ?? this.selectedProductCategory);
            BomSearchHelper.selectAutocompleteOption(this.autocomplete);
        } else {
            this.getDefaultValue();
        }
    }

    /**
     * Method to store column header width in ngrx store for product search column layout
     * @return {void}
     * @memberof ProductSearchComponent
     */
    public storeSearchColumnHeaderWidth(): void {
        this.bomSearchHelper.storeColumnLayoutWidth(this.matTableRef, STORE_HEADER_WIDTH_FOR.PRODUCT_SEARCH);
    }

    /**
     * Method to get column header width from ngrx store for product search column layout
     *  @param {string} actionFor
     * @return {void}
     * @memberof ProductSearchComponent
     */
    public getSearchColumnHeaderWidth(actionFor: string): void {
        this.bomSearchHelper.getColumnHeaderWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to get the default values
     * @return {void}
     * @memberof ProductSearchComponent
     */
    public getDefaultValue(): void {
        this.searchCheckBoxList.forEach((checkBox) => {
            checkBox.checked = checkBox.checked !== false;
        });
        this.showPassAuditToggle = !this.isOpenproduct && this.plantId !== EMPTY;
        this.disableExcludePlantToggle = !this.isOpenproduct && this.plantId === EMPTY;
    }

    /**
     * Method to fetch trustee name
     * @param {ExpTrusteeModel} row
     * @returns {string}
     * @memberof ProductSearchComponent
     */
    // eslint-disable-next-line class-methods-use-this
    public getTrusteeDisplayName(row: ExpTrusteeModel): string {
        return BomSearchHelper.getTrusteeDisplayName(row);
    }

    /**
     * Method to validate project number
     *
     * @memberof ProductSearchComponent
     */
    public validateProjectNumber(): void {
        if (this.isCompliance && !this.projectNumber) {
            this.projectNumberError = PROJECT_NUMBER_ERROR;
            return;
        }
        if (this.isCompliance && this.projectNumber) {
            this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
            this.creativeReviewHelper.projectNumberValidation(this.projectNumber.toString()).subscribe(
                (projectDetails) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (projectDetails && projectDetails.error) {
                        this.projectNumberError = projectDetails.message;
                        this.projectNumber = undefined;
                        this.dataSource = [];
                        return;
                    }
                    if (projectDetails && !projectDetails.error) {
                        this.onEnterSearch();
                    }
                },
                (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            );
        }
    }

    /**
     * Method triggered on clearing search text
     * @param event
     * @return {void}
     * @memberof ProductSearchComponent
     */
    public onClearSearchText(event): void {
        this.searchValue.setValue("");
        this.totalCount = 0;
        this.dataSource = [];
        event.stopPropagation();
    }

    /**
     * Method to sort recently Used Product search response
     * @param {SortEventModel} sortEvent
     * @return {void}
     * @memberof ProductSearchComponent
     */
    public sortRecentlyProduct(sortEvent: SortEventModel): void {
        const gridData = cloneDeep(this.dataSource);
        this.dataSource = [];
        if (sortEvent.direction === EMPTY) {
            this.dataSource = sortBy(gridData, (product) => product?.audit?.priority);
        } else {
            this.recentlyUsedProductCustomSort(sortEvent, gridData);
        }
    }

    /**
     * Method for recently Used Product Custom Sort
     * @param sortEvent {SortEventModel}
     * @param gridData {any[]}
     * @memberof ProductSearchComponent
     */
    private recentlyUsedProductCustomSort(sortEvent: SortEventModel, gridData: any[]) {
        const isDirectColumns = PRODUCT_SEARCH_CONSTANTS.PRODUCT_GRID_COLUMN_LIST.find(
            (directColumns) => directColumns === sortEvent.active,
        );
        const activeSortKey = isDirectColumns ? DIRECT_SORT_COLUMN_WITHKEY[sortEvent.active] : sortEvent.active;
        gridData.sort((value1, value2) => {
            const aValue = value1[activeSortKey];
            const bValue = value2[activeSortKey];

            if (aValue < bValue) {
                return sortEvent.direction === PRODUCT_SEARCH_CONSTANTS.SORT_ORDER ? -1 : 1;
            }
            if (aValue > bValue) {
                return sortEvent.direction === PRODUCT_SEARCH_CONSTANTS.SORT_ORDER ? 1 : -1;
            }
            return 0;
        });
        this.dataSource = gridData;
    }

    /**
     * Method called on ipc selection click
     * @returns {void}
     * @memberof ProductSearchComponent
     */
    public onIpcSelectionClick(): void {
        const slidePanel = IPC_SELECTION_DIALOG;
        slidePanel.data = {
            selectedIpcSelectionID: this.selectedProductCategory?.ProductSearchID,
        };
        const dialogReference = this.dialog.open(IpcSelectionPopupComponent, slidePanel);
        this.componentSubscriptions.add(
            dialogReference.afterClosed().subscribe((searchCriteria) => {
                this.productSearchCategoryID =
                    searchCriteria?.length === 1
                        ? searchCriteria[0].ProductSearchID
                        : PRODUCT_SEARCH_CONSTANTS.DEFAULT_PRODUCT_CATEGORY.ProductSearchID;
                this.getProductSearchCriteria();
            }),
        );
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_SEARCH, MatomoAction.CLICK, MatomoLabel.ON_IPC_SELECTION_CLICK);
    }

    /**
     * Methos to format ipc selection excel json object
     * @param dataSource
     * @param dynamicColumns
     * @returns {void}
     * @memberof ProductSearchComponent
     */
    public formatExcelJsonObject(dataSource, dynamicColumns,isTestCase=false): void {
        const formattedResponse = [];
        forEach(dataSource, (productData) => {
            const result = {};
            Object.assign(result, {
                IPC: productData.ipc,
                Description: productData.description,
            });
            forEach(dynamicColumns, (column) => {
                if (!column?.isCost) {
                    const objectKey =
                        column.value === DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME
                            ? `${column.value} ${TasteEditorUtilClass.getUserDefaultFlashpoint()}`
                            : column?.value;
                    if (column.columns === this.columnLayouts.TRUSTEE) {
                        result[objectKey] = this.getTrusteeDisplayName(productData);
                    } else if (column.columns === this.flagColumn || column.columns === this.cbwFlagColumn) {
                        result[objectKey] =
                            productData[column.value] === this.flagNoValue
                                ? EMPTY
                                : this.restrictedAccessLabelPipe.transform(productData[column.value], productData, column);
                                if(result[objectKey] !=''){
                                    const flagNotes = find(productData?.otherdetails?.flags, (flag) => flag.flagcode === column?.value);
                                    const flagNotesColumn = flagNotes?.flagcode + "-Note";
                                    if(result["IPC"] === flagNotes?.ipc) {
                                        result[flagNotesColumn] = flagNotes?.comment;
                                    }
                                }
                    } else {
                        result[objectKey] = productData[column?.value];
                    }
                }
            });
            formattedResponse.push(result);
        });
        const fileName = this.gridData?.criteriaName ?? IPC_SELECTION;
        if(!isTestCase){
            this.exportToExcelHelper.exportToExcel(formattedResponse, fileName, IPC_SELECTION);
        }
    }
}
