/* eslint-disable max-classes-per-file */
/* eslint-disable max-lines */
/* eslint-disable import/no-unresolved */
/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { HttpClient, HttpHandler } from "@angular/common/http";
import { OAuthService, UrlHelperService, OAuthLogger } from "angular-oauth2-oidc";
import { ToastrService } from "ngx-toastr";
import { NGXLogger } from "ngx-logger";
import { MatDialog, MatDialogModule } from "@angular/material/dialog";
import { CommonModule, DatePipe } from "@angular/common";
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from "@angular/forms";
import { ExperimentApiService } from "@te-shared/helpers/experiment-api.service";
import { BaseColumnHelper } from "@te-shared/components/base-column-layout/helper/base-column-helper";
import { EditionSuggesstionHelper } from "@te-experiment-editor/helpers/edition-suggesstion.helper";
import { of, throwError } from "rxjs";
import { ExperimentEditorService } from "@te-experiment-editor/helpers/experiment-editor.service";
import { MockExperimentEditorService } from "@te-testing/mock-experiment-editor.service";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { MockGridapiService } from "@te-testing/mock-gridapi.service";
import { MiniEditorSuggestionHelper } from "@te-shared/helpers/mini-editor-suggestion.helper";
import { SearchDrawerHelper } from "@te-shared/helpers/search-drawer.helper";
import { Store } from "@ngrx/store";
import { EditionSuggesstColumnLayoutHelper } from "@te-experiment-editor/helpers/edition-suggesst-column-layout.helper";
import { AppCacheHelper } from "@te-shared/helpers/app-cache.service";
import { MockAppcacheHelper } from "@te-testing/mock-app-cache-helper";
import { mockProductSearchFilter, MOCK_WORKSPACES } from "@te-testing/mock-tabhelper-data";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { MockTabHelperService } from "@te-testing/mock-tabhelper.service";
import { cloneDeep } from "lodash";
import { CUSTOM_ELEMENTS_SCHEMA, ElementRef, NO_ERRORS_SCHEMA, QueryList } from "@angular/core";
import { FlashpointConversionPipe } from "@te-shared/pipes/flashpoint-conversion.pipe";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { AuditValidationPipe } from "@te-shared/pipes/audit-validation.pipe";
import { MatAutocomplete, MatAutocompleteModule, MatAutocompleteTrigger } from "@angular/material/autocomplete";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { DialogHelper } from "@te-shared/helpers/dialog-helper";
import { PayloadHelper } from "@te-shared/helpers/payload-helper";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { RestrictedAccessLabelPipe } from "@te-shared/pipes/restricted-access-label.pipe";
import { ExportToExcelHelper } from "@te-shared/helpers/export-to-excel.helper";
import { CreativeReviewHelper } from "src/app/creative-review/helpers/creative-review-helper";
import { MockCreativereview } from "@te-testing/mock-creativereview-helper";
import { EMPTY } from "src/app/app.constant";
import { SortEventModel } from "@te-shared/models/experiments.model";
import { ExpTrusteeModel } from "@te-experiment-editor/models/experiment-editor.model";
import { EDIT_SUGGEST_VARIANT_DISPLAY_COLUMNS } from "@te-experiment-editor/constants/experiment-editor.constant";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { AttributeColumnHelper } from "@te-experiment-editor/helpers/attribute-column-helper";
import { PRODUCTS_SEARCH_CATEGORIES, PRODUCT_SEARCH_CONSTANTS, PROJECT_NUMBER_ERROR } from "../../../constants";
import { RecentlyUsedActionModel } from "../../../../experiment-editor/models/recently-used.model";
import { SUBTypes } from "../../../enums";
import { ProductDataCostHelper } from "../../product-data/product-data-cost/product-data-cost.helper";
import { MockProductDataCostHelper } from "../../../../testing/mock-product-data-cost-helper";
import { AppStateService } from "../../../../_services/app-state/app.state.service";
import { AppBroadCastService, AppDataService, MatomoService, WindowReferenceService } from "../../../../_services";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";
import { MockToastrService } from "../../../../testing/mock-toastr.service";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { ProductSearchComponent } from "./product-search.component";
import { MockAppDataService } from "../../../../testing/mock-app.data.service";
import { SpaceTrimPipe } from "../../../pipes/space-trim/space-trim.pipe";
import { mockSortEventData } from "../../../../testing/mock-experiment-editor.helper";
import { MatSelectModule } from "@angular/material/select";
import { BrowserModule } from "@angular/platform-browser";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatTableModule } from "@angular/material/table";
import { MatInputModule } from "@angular/material/input";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { MatMenuModule } from "@angular/material/menu";
import { DisableSortPipe } from "@te-shared/pipes/disable-sort.pipe";
import { MatTabsModule } from "@angular/material/tabs";

describe("ProductSearchComponent", () => {
    const flashpointConversionKey = "flashpointConversion";
    let component: ProductSearchComponent;
    let fixture: ComponentFixture<ProductSearchComponent>;

    let getProductSearchCriteriaSpy;
    let setColumnLayoutSpy;
    let ipcValue;
    const event = {
        target: {
            offsetHeight: 400,
            scrollHeight: 500,
            scrollTop: 1000,
        },
    };

    class StoreMock {
        select = jasmine.createSpy().and.returnValue(of({}));

        dispatch = jasmine.createSpy();

        pipe = jasmine.createSpy().and.returnValue(of("success"));
    }

    const data = {
        total: 10,
        searchresults: [{ ipc: 12, isSolution: false, isFema: false, otherdetails: { solutions: [{}], specs: [] } }],
    };

    const dialogReferenceStub = {
        afterClosed() {
            const product = {
                ipc: "1RR04333",
            };
            return of(product); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    class MockSecurityHelper {
        hasPermission = () => {
            return true;
        };
    }

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ProductSearchComponent,FlashpointConversionPipe,DisableSortPipe],
            providers: [
                DatePipe,
                HttpClient,
                HttpHandler,
                AppBroadCastService,
                SpaceTrimPipe,
                WindowReferenceService,
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                BaseColumnHelper,
                ExperimentApiService,
                EditionSuggesstionHelper,
                MiniEditorSuggestionHelper,
                SearchDrawerHelper,
                EditionSuggesstColumnLayoutHelper,
                AuditValidationPipe,
                FlashpointConversionPipe,
                BomSearchHelper,
                {
                    provide: Store,
                    useClass: StoreMock,
                },
                { provide: CreativeReviewHelper, useClass: MockCreativereview },
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: AppDataService, useClass: MockAppDataService },
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: ProductDataCostHelper, useClass: MockProductDataCostHelper },
                { provide: AppCacheHelper, useClass: MockAppcacheHelper },
                { provide: TabHelper, useClass: MockTabHelperService },
                { provide: ToastrService, useClass: MockToastrService },
                { provide: NGXLogger, useClass: MockLoggerService },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                { provide: ExperimentEditorService, useClass: MockExperimentEditorService },
                DialogHelper,
                PayloadHelper,
                {
                    provide: SecurityHelper,
                    useClass: MockSecurityHelper,
                },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
                RestrictedAccessLabelPipe,
                ExportToExcelHelper,
                AttributeColumnHelper,
            ],
            imports: [
                MatFormFieldModule,
                MatSelectModule,
                MatTabsModule,
                MatInputModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule,
                MatAutocompleteModule,
                MatButtonModule,
                MatCheckboxModule,
                MatSlideToggleModule,
                MatIconModule,
                MatDialogModule,
                MatMenuModule,
                MatTableModule,
                CommonModule,
            ],
            schemas: [NO_ERRORS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ProductSearchComponent);

        component = fixture.componentInstance;
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        setColumnLayoutSpy = spyOn(component, "setColumnLayout").and.returnValue();
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("F");
        ipcValue = spyOn(component, "onSelectIPCSelection").and.returnValue();
        component.selectedIPC = "1234";
        component.ipcSelectionList = [
            {
                CreatedBy: 1,
                CreatedOn: "2020-08-19T09:46:01.000Z",
                Criteria: '{   "filter": {      "flags": ["AMETI BANK"]    }\r\n }',
                IsPrivate: "0",
                ProductSearchID: 226,
                SearchName: "AMETI BANK",
                UpdatedBy: 1,
                UpdatedOn: "2020-08-19T09:46:01.000Z",
                UserID: undefined,
            },
            {
                CreatedBy: 1,
                CreatedOn: "2020-12-07T09:51:38.000Z",
                Criteria: '{   "filter": {   "flagsmustnot": ["NO NEW USE"]   } }',
                IsPrivate: "0",
                ProductSearchID: 230,
                SearchName: "ALL TASTE PRODUCT",
                UpdatedBy: 1,
                UpdatedOn: "2020-12-07T09:51:38.000Z",
                UserID: undefined,
            },
        ];
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: {
                    ipc: "asc",
                },
            },
            esDetails: {
                filter: {
                    sortby: "asc",
                },
                from: 0,
            },
            from: 0,
        };
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call ngOnDestroy", () => {
        const spy = spyOn(component, "ngOnDestroy").and.callThrough();
        component.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });
    it("should call loadWorkspaceMenu", () => {
        const spy = spyOn(component, "loadWorkspaceMenu").and.callThrough();
        component.loadWorkspaceMenu();
        expect(spy).toHaveBeenCalled();
    });
    it("should call canShowLoadMoreButton", () => {
        const spy = spyOn(component, "canShowLoadMoreButton").and.callThrough();
        component.canShowLoadMoreButton();
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for onAddProductToCart() if condition", () => {
        component.isOpenproduct = true;
        const product = { ipc: "00010047", description: "test" };
        const spy = spyOn(component, "onAddProductToCart").and.callThrough();
        component.onAddProductToCart(product);
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for onAddExpToCart() else condition", () => {
        component.isOpenproduct = false;
        const product = { ipc: "00010047", description: "test" };
        const spy = spyOn(component, "onAddProductToCart").and.callThrough();
        component.onAddProductToCart(product);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for editionSuggestionOfProductSearch() else condition", () => {
        component.isOpenproduct = false;
        component.gridData = {
            ExpID: undefined,
        };
        component.selectedCartItemIndex = 1;
        const product = { ipc: "00010047", description: "test", otherdetails: {} };
        const spy = spyOn(component, "editionSuggestionOfProductSearch").and.callThrough();
        const newService: MiniEditorSuggestionHelper = TestBed.inject(MiniEditorSuggestionHelper);
        spyOn(newService, "triggerEditSuggestPopup").and.returnValue();
        component.editionSuggestionOfProductSearch(product);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for addValidProductToCart()", () => {
        const product = { ipc: "00010047", description: "test" };
        const spy = spyOn(component, "addValidProductToCart").and.callThrough();
        component.addValidProductToCart(product);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for validateOpenProduct() if condition is satisfied", () => {
        component.openedExperimentOrProduct = [{ ExpCode: "NXD00006AA", ExpID: 63_353_206, ExpName: "openproduct" }];
        component.cartLists = [{ subCode: "00010047" }];
        const product = { ipc: "00010047", description: "test", IPC: "" };
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const isMaxExpExceedsSPY = spyOn<any>(SearchDrawerHelper, "isMaxExpExceeds").and.returnValue(true);
        const spy = spyOn(component, "validateOpenProduct").and.callThrough();
        component.validateOpenProduct(product);
        isMaxExpExceedsSPY.and.returnValue(false);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const isAlreadyOpenedSPY = spyOn<any>(SearchDrawerHelper, "isAlreadyOpened").and.returnValue(true);
        component.validateOpenProduct(product);
        isMaxExpExceedsSPY.and.returnValue(false);
        isAlreadyOpenedSPY.and.returnValue(false);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(SearchDrawerHelper, "isAddedInCart").and.returnValue(true);
        component.validateOpenProduct(product);
        expect(spy).toHaveBeenCalled();
    });
    it("should call formDynamicColumns()", () => {
        const spy = spyOn(component, "formDynamicColumns").and.callThrough();
        component.formDynamicColumns();
        expect(spy).toHaveBeenCalled();
    });
    it("should call formDynamicColumns() when datasource length is greater than 0", () => {
        component.dataSource = [{ ipc: "00010047", description: "test", IPC: "" }];
        const spy = spyOn(component, "formDynamicColumns").and.callThrough();
        component.formDynamicColumns();
        expect(spy).toHaveBeenCalled();
    });
    it("should call costConversionByCurrency() ", () => {
        const productData = {};
        const column = EDIT_SUGGEST_VARIANT_DISPLAY_COLUMNS[0];
        const spy = spyOn(component, "costConversionByCurrency").and.callThrough();
        component.costConversionByCurrency(productData, column, true);
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve costConversionByCurrency() when isCost is true and product data has column value ", () => {
        const productData = { cost: "123.34" };
        const column = { columns: "ipcvariant", isCost: true, value: "cost", gridHeaderType: "cost" };
        const spy = spyOn(component, "costConversionByCurrency").and.callThrough();
        component.costConversionByCurrency(productData, column, true);
        expect(spy).toHaveBeenCalled();
    });
    it("should call  onTableScroll()", () => {
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for onTableScroll() when if condition is satisfied", () => {
        component.isLoading = false;
        component.totalCount = 100;
        component.searchCriteria = { from: 0 };
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
            esDetails: {
                filter: {
                    sortby: "asc",
                },
                from: 0,
            },
            from: 0,
        };
        spyOn(component, "searchProduct").and.returnValue();
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTableScroll() when false condition is satisfied", () => {
        component.isLoading = true;
        component.totalCount = 0;
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for searchProductWithSelectedTemplate() when isCompliance is true", () => {
        component.isCompliance = true;
        component.projectNumber = 124;
        const spy = spyOn(component, "searchProductWithSelectedTemplate").and.callThrough();
        component.searchProductWithSelectedTemplate();
        expect(spy).toHaveBeenCalled();
        expect(component.searchCriteria.complicanceDetails.projectNumber).toEqual(component.projectNumber);
    });
    it("should call onSelectionList()", () => {
        const spy = spyOn(component, "onSelectionList").and.callThrough();
        component.onSelectionList({ checked: true }, "test");
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for onSelectionList() when checked is true and value is included", () => {
        component.searchFilterCheckboxList = ["test"];
        component.searchCheckBoxList = [{ searchCriteria: "test", checked: true }];
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        const spy = spyOn(component, "onSelectionList").and.callThrough();
        component.onSelectionList({ checked: true }, "test");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSelectionList() when checked is true and value is not included", () => {
        component.searchFilterCheckboxList = ["testcheckbox"];
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        const spy = spyOn(component, "onSelectionList").and.callThrough();
        component.onSelectionList({ checked: true }, "test");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSelectionList() when checked is false and value is included", () => {
        component.searchFilterCheckboxList = ["test"];

        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        const spy = spyOn(component, "onSelectionList").and.callThrough();
        component.onSelectionList({ checked: false }, "test");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getSearchProducts() ", () => {
        // eslint-disable-next-line prefer-destructuring
        component.selectedIPC = PRODUCTS_SEARCH_CATEGORIES[0];
        component.isIpcView = false;
        component.searchByFieldsCheckbox = ["description", "code"];
        component.selectedQuery = "contains";
        component.searchValue = {
            value: "sxt00465",
        } as UntypedFormControl;
        component.searchCriteria = {
            filter: {
                byfields: {},
                sortBy: {},
            },
        };
        const spy = spyOn(component, "getSearchProducts").and.callThrough();
        const service: AppDataService = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of());
        component.getSearchProducts();
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for onEnterSearch() when isLoading is true", () => {
        component.dataSource = ["Taste1"];

        const spy = spyOn(component, "onEnterSearch").and.callThrough();
        ipcValue.and.returnValue();
        spyOn(component, "searchProduct").and.returnValue();
        component.onEnterSearch();
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for onEnterSearch() when isLoading is true", () => {
        component.isLoading = true;
        component.searchFilterCheckboxList = [
            ...PRODUCT_SEARCH_CONSTANTS.PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE_DETAILS,
            ...PRODUCT_SEARCH_CONSTANTS.DEFAULT_CHECKBOX_SELECTION,
        ];
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        const spy = spyOn(component, "onEnterSearch").and.callThrough();
        ipcValue.and.returnValue();
        spyOn(component, "searchProduct").and.returnValue();
        component.onEnterSearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getIPCSelctionQuery() ", () => {
        component.ipcSelectionList = [{ SearchName: "test" }];
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        const spy = spyOn(component, "getIPCSelctionQuery").and.callThrough();
        component.getIPCSelctionQuery("test");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getIPCSelctionQuery() when select all option in dropdown ", () => {
        const spy = spyOn(component, "getIPCSelctionQuery").and.callThrough();
        component.getIPCSelctionQuery("All");
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for displayProductCategory() when select all option in dropdown ", () => {
        const category = PRODUCT_SEARCH_CONSTANTS.DEFAULT_PRODUCT_CATEGORY;
        const spy = spyOn(component, "displayProductCategory").and.callThrough();
        component.displayProductCategory(category);
        expect(spy).toHaveBeenCalled();
    });
    it("should call  resetAttributes() ", () => {
        const spy = spyOn(component, "resetAttributes").and.callThrough();
        component.resetAttributes();
        expect(spy).toHaveBeenCalled();
    });
    it("should call  columnLayoutSelection() ", () => {
        const spy = spyOn(component, "columnLayoutSelection").and.callThrough();
        component.columnLayoutSelection();
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for combineDatasource() when data is not empty and totalCount is 0", () => {
        component.totalCount = 0;
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        // component.displayedColumns.push(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(TasteEditorUtilClass, "getUniqueListBy").and.returnValue([]);
        spyOn(component[flashpointConversionKey], "transform").and.returnValue([]);
        component.combineDatasource(data);
        expect(component.noDataFound).toBeFalsy();
    });

    it("should resolve for combineDatasource() when data is not empty and totalCount is 10", () => {
        component.totalCount = 10;
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        // component.displayedColumns.push(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(TasteEditorUtilClass, "getUniqueListBy").and.returnValue([]);
        spyOn(component[flashpointConversionKey], "transform").and.returnValue([]);
        component.combineDatasource(data);
        expect(component.noDataFound).toBeFalsy();
    });

    it("should resolve for combineDatasource() when data is empty", () => {
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource({ total: "" });
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for combineDatasource() when isLayoutChanged is true", () => {
        component.totalCount = 10;
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        component.isLayoutChanged = true;
        const spy = spyOn(component, "combineDatasource").and.callThrough();
        component.combineDatasource(data);
        expect(spy).toHaveBeenCalled();
    });
    it("should getProductSearchCriteria", () => {
        component.plantId = "";
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
        };
        ipcValue.and.returnValue();

        getProductSearchCriteriaSpy = spyOn(component, "getProductSearchCriteria").and.returnValue();
        getProductSearchCriteriaSpy.and.callThrough();
        component.getProductSearchCriteria();
        component.plantId = "BAG";
        const service: AppDataService = TestBed.inject(AppDataService);
        spyOn(service, "get").and.returnValue(throwError(() => ""));
        component.getProductSearchCriteria();
        expect(getProductSearchCriteriaSpy).toHaveBeenCalled();
    });

    it("should formatCartData", () => {
        const product = { ipc: "00010047", description: "test" };
        const spy = spyOn(component, "formatCartData").and.callThrough();
        component.formatCartData(product);
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke onOpenRecentUsedPopup", () => {
        const spy = spyOn(component, "onOpenRecentUsedPopup").and.callThrough();
        const product: RecentlyUsedActionModel = {
            subType: SUBTypes.PRODUCT,
            product: {
                ipc: "50010011",
            },
        } as RecentlyUsedActionModel;
        const service = TestBed.inject(ExperimentEditorService);
        spyOn(service, "handleRecentlyUsedPopup").and.returnValue(of(product));
        component.onOpenRecentUsedPopup();
        expect(spy).toHaveBeenCalled();
    });
    it("should invoke onOpenSalesNumber", () => {
        spyOn(component, "onOpenSalesNumber").and.callThrough();
        component.searchValue.setValue("11R04332");
        component.onOpenSalesNumber();
        expect(component.searchValue.value).toMatch("1RR04333");
    });

    it("should invoke onOpenSalesNumber same ipc selected", () => {
        spyOn(component, "onOpenSalesNumber").and.callThrough();
        component.searchValue.setValue("1RR04333");
        component.onOpenSalesNumber();
        expect(component.searchValue.value).toBe("1RR04333");
    });
    it("should invoke sortProductSearch if selectedIPC is recentlyViewed", () => {
        component.recentlyViewed = "1234";
        component.selectedIPC = "1234";
        spyOn(component, "sortProductSearch").and.callThrough();
        component.sortProductSearch(mockSortEventData);
        expect(component.sortProductSearch).toHaveBeenCalled();
    });
    it("should invoke sortProductSearch if esDetails is in searchCriteria", () => {
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
            esDetails: {
                filter: {
                    sortby: "asc",
                },
                from: 0,
            },
            from: 0,
        };
        spyOn(component, "sortProductSearch").and.callThrough();
        component.sortProductSearch(mockSortEventData);
        expect(component.sortProductSearch).toHaveBeenCalled();
    });

    it("should invoke sortProductSearch if esDetails is not in searchCriteria", () => {
        component.searchCriteria = {
            filter: {
                byfields: {
                    name: "XXXX",
                    value: "xxxx",
                    operator: 12,
                },
                sortby: "asc",
            },
            esDetails: undefined,
            from: 0,
        };
        spyOn(component, "sortProductSearch").and.callThrough();
        component.sortProductSearch(mockSortEventData);
        expect(component.sortProductSearch).toHaveBeenCalled();
    });

    it("should resolve for shiftFocusToCart()", () => {
        const spy = spyOn(component, "shiftFocusToCart").and.callThrough();
        const mockEvent = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        const childComponents = { closePanel: () => of({}) };
        component.autocomplete = childComponents as unknown as MatAutocompleteTrigger;
        component.shiftFocusToCart(mockEvent as unknown as KeyboardEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for shiftFocusToCart() when event is defined", () => {
        component.selectedRowIndex = 5;
        const mockEvent1 = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        const mockEvent2 = {
            focus() {
                return true;
            },
            scrollIntoViewIfNeeded() {
                return true;
            },
        };
        const mockDataTable = { first: { _elementRef: { nativeElement: { tBodies: [{ rows: [mockEvent2] }] } } } };
        component.productDataTable = mockDataTable as unknown as QueryList<ElementRef>;
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { closePanel: () => {} };
        component.autocomplete = childComponents as unknown as MatAutocompleteTrigger;
        component.totalCount = 10;
        component.combineDatasource(data);
        component.focusOnFirstDataRow(mockEvent1 as unknown as KeyboardEvent);
        expect(component.selectedRowIndex).toBe(0);
    });

    it("should resolve for errorHandler()", () => {
        const spy = spyOn(component, "errorHandler").and.callThrough();
        component.errorHandler(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for focusSearchTextBox()", () => {
        const spy = spyOn(component, "focusSearchTextBox").and.callThrough();
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        const childComponents = { nativeElement: { focus: () => {} } };
        component.searchTextBox = childComponents;
        component.focusSearchTextBox();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for validateAndAddProduct()", () => {
        const mockEvent = {
            stopPropagation() {
                return true;
            },
            preventDefault() {
                return true;
            },
        };
        const productData = {
            ipc: "00010350",
            description: "ARABIC GUM SPRDR VERY LOW BACTERIA",
            fema: {},
            cas: {},
            audit: {
                status: "PASS",
                results: [],
            },
            otherdetails: {},
        };
        component.selection.select(productData);
        component.isOpenproduct = false;
        const spy = spyOn(component, "validateAndAddProduct").and.callThrough();
        component.validateAndAddProduct(mockEvent as unknown as KeyboardEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onComplianceChange()", () => {
        component.onComplianceChange();
        expect(component.selectedRowIndex).toBe(-1);
    });
    it("should return when isCompliance is true for onComplianceChange()", () => {
        component.isCompliance = true;
        const spy = spyOn(component, "onComplianceChange").and.callThrough();
        component.onComplianceChange();
        expect(spy).toHaveBeenCalled();
    });

    it("should call setColumnLayout", () => {
        setColumnLayoutSpy.and.callThrough();
        component.gridData = {
            ExpID: undefined,
            fromLandingPage: true,
        };
        const service: BaseColumnHelper = TestBed.inject(BaseColumnHelper);
        const servicespyOn = spyOn(service, "formatColumnLayoutInfo");
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const spy = spyOn<any>(AppStateService, "getLastUsedLColumnLayout");
        spy.and.returnValue([{}]);
        servicespyOn.and.returnValue();
        component.setColumnLayout();
        spy.and.returnValue([]);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(BaseColumnHelper, "setDefaultAtrributes").and.returnValue({});
        servicespyOn.and.returnValue();
        component.setColumnLayout();
        expect(setColumnLayoutSpy).toHaveBeenCalled();
    });

    it("should resolve for storeProductSearchFilters", () => {
        const tabService: TabHelper = TestBed.inject(TabHelper);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(tabService, "getActiveTab").and.returnValue(MOCK_WORKSPACES[0]);
        component.storeProductSearchFilters();
        expect(component.selectedQuery).toEqual(PRODUCT_SEARCH_CONSTANTS.DEFAULT_PRODUCT_QUERY);
    });
    it("should resolve isOpenproduct is true for getProductSearchFilters", () => {
        component.isOpenproduct = true;
        const spy = spyOn(component, "getDefaultValue").and.callThrough();
        component.getProductSearchFilters();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getProductSearchFilters", () => {
        const mockData = cloneDeep(mockProductSearchFilter);
        component.isOpenproduct = false;
        component.searchFilterData = mockData.SearchFilters;
        component.searchCheckBoxList = [{ searchCriteria: "Description", checked: true }];
        component.getProductSearchFilters();
        expect(component.searchValue.value).toEqual("Lemon");
    });
    it("should call onLoadMore()", () => {
        const spy = spyOn(component, "onLoadMore").and.callThrough();
        component.onLoadMore();
        expect(spy).toHaveBeenCalled();
    });
    it("should reolve for loading onLoadMore()", async () => {
        const spy = spyOn(component, "onLoadMore").and.callThrough();
        component.isLoading = false;
        component.dataSource = ["Taste1"];
        component.totalCount = 2;
        component.pageSize = 1;
        component.isInsertproduct = false;
        component.isOpenproduct = false;
        component.onLoadMore();
        expect(spy).toHaveBeenCalled();
    });
    it("should call onIpcTextClick()", () => {
        const spy = spyOn(component, "onIpcTextClick").and.callThrough();
        component.onIpcTextClick("Taste editor");
        expect(spy).toHaveBeenCalled();
    });
    it("should call storeSearchColumnHeaderWidth()", () => {
        const spy = spyOn(component, "storeSearchColumnHeaderWidth").and.callThrough();
        component.storeSearchColumnHeaderWidth();
        expect(spy).toHaveBeenCalled();
    });
    it("should call getSearchColumnHeaderWidth()", () => {
        const spy = spyOn(component, "getSearchColumnHeaderWidth").and.callThrough();
        const actionFor: string = "Column Name";
        component.getSearchColumnHeaderWidth(actionFor);
        expect(spy).toHaveBeenCalled();
    });
    it("should call getTrusteeDisplayName()", () => {
        const spy = spyOn(component, "getTrusteeDisplayName").and.callThrough();
        const row: ExpTrusteeModel = { otherdetails: data.searchresults["otherdetails"] };
        component.getTrusteeDisplayName(row);
        expect(spy).toHaveBeenCalled();
    });
    it("should call validateProjectNumber()", () => {
        const spy = spyOn(component, "validateProjectNumber").and.callThrough();
        component.validateProjectNumber();
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve when project number is not defined and isCompliance is true validateProjectNumber()", () => {
        component.isCompliance = true;
        component.validateProjectNumber();
        expect(component.projectNumberError).toEqual(PROJECT_NUMBER_ERROR);
    });
    it("should resolve when project number is defined and isCompliance is true validateProjectNumber()", () => {
        component.isCompliance = true;
        component.projectNumber = 123;
        const service = TestBed.inject(AppBroadCastService);
        const spy = spyOn(service, "onUpdateAppSpinnerPrompt").and.callThrough();
        component.validateProjectNumber();
        expect(spy).toHaveBeenCalled();
    });
    it("should call onClearSearchText()", () => {
        const spy = spyOn(component, "onClearSearchText").and.callThrough();
        const event = { stopPropagation: jasmine.createSpy("stopPropagation") };
        component.onClearSearchText(event);
        expect(spy).toHaveBeenCalled();
    });
    it("should call sortRecentlyProduct()", () => {
        const spy = spyOn(component, "sortRecentlyProduct").and.callThrough();
        const sortEvent: SortEventModel = {
            active: "ColumnName",
            direction: "Ascending",
        };
        component.sortRecentlyProduct(sortEvent);
        expect(spy).toHaveBeenCalled();
    });
    it("should call sortRecentlyProduct()", () => {
        const spy = spyOn(component, "sortRecentlyProduct").and.callThrough();
        const sortEvent: SortEventModel = {
            active: "ColumnName",
            direction: EMPTY,
        };
        component.sortRecentlyProduct(sortEvent);
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve onIpcSelectionClick()", () => {
        const spy = spyOn(component, "onIpcSelectionClick").and.callThrough();
        component.onIpcSelectionClick();
        expect(spy).toHaveBeenCalled();
    });
    it("should call formatExcelJsonObject() when user try to download as excel", () => {
        component.dataSource = [{
            ipc: "00011977",
            description: "ALOE VERA 8X8MM CUBE IN LIGHT SYRUP",
            fema: {},
            cas: {},
            audit: {
                status: "PASS",
                results: [],
            },
            otherdetails: {
                flags:[{
                    cbwflag: 0,
                    comment: "For Protons Lab",
                    createdby: "Unknown",
                    createdon: "2002-12-16T16:28:23.090Z",
                    displaycolour: "RED",
                    flagcode: "RESTRICTED USE",
                    htmlcolourcode: "#FF0000",
                    inheritedcontent: 1,
                    inheritedflag: false,
                    ipc : "00011977",
                    isbom: false,
                    sortcode:  "A",
                    tag: "flags",
                    updatedby: null,
                    updatedon: null
                }],
                ipc: "00011977"
            },
        }];
        component.dynamicColumns = [{
            columns: "CostPerKg", gridHeaderType : "attribute",isCost: true, value:"SBFL/Kg"
        },
        {
            columns: "Spec", gridHeaderType : "attribute",isCost: false, value:"LEGAL-FDA"
        },
        {
            columns: "Flag", gridHeaderType : "attribute",isCost: false, value:"RESTRICTED USE"
        },
        {
            columns: "prodtypecode", gridHeaderType : "attribute",isCost: true, value:"Product Type"
        },
        {
            columns: "FlagCBW", gridHeaderType : "attribute",isCost: false, value:"TRU2FRESH"
        },
        {
            columns: "Flag", gridHeaderType : "attribute",isCost: false, value:"DO NOT USE"
        },
    ];
        const spy = spyOn(component, "formatExcelJsonObject").and.callThrough();
        component.formatExcelJsonObject( component.dataSource, component.dynamicColumns,true);
        expect(spy).toHaveBeenCalled();
    });

    it("should call formatExcelJsonObject() and throw error when param is empty", () => {
        const spy = spyOn(component, "formatExcelJsonObject").and.callThrough();
        const param1=[];
        const param2=[]
        try {
            component.formatExcelJsonObject( param1, param2,true);
            expect(spy).toThrowError(); 
         } catch (error) {
            expect(error).toBe('Error')
         }
    });
});
