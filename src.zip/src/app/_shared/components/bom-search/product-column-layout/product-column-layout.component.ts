/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, Output, EventEmitter, ViewChild, SimpleChanges, OnChanges, OnDestroy } from "@angular/core";
import { MatTabGroup } from "@angular/material/tabs";
import { UntypedFormGroup } from "@angular/forms";
import { delay, find, sortBy } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { Subscription } from "rxjs";
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { VALUE } from "@te-shared/components/base-ipc-layout/base-ipc-layout-constant";
import { MatomoCategory, MatomoAction, MatomoLabel } from "@te-shared/enums";
import { CustomLayoutSaveComponent } from "../custom-layout-save/custom-layout-save.component";
import { BaseColumnHelper } from "../../base-column-layout/helper/base-column-helper";
import { AppBroadCastService, AppStateService, MatomoService } from "../../../../_services";
import { BaseColumnLayoutComponent } from "../../base-column-layout/base-column-layout.component";
import {
    COLUMN_LAYOUT_ADDED_PAGE,
    COLUMN_LAYOUT_ERROR,
    COLUMN_LAYOUT_SUCCESS,
    COLUMN_LAYOUT_TYPES,
    DEFAULT_COLUMN_LAYOUT,
    COLUMN_LAYOUT_TAB_INDEX,
    COMMON_DIALOG_OLD,
} from "../../../constants";
import { ColumnLayoutHelper } from "../../../../master-data/helpers/column.layout.helper";
import { CREATE_COLUMN_LAYOUT, EMPTY, LOADING } from "../../../../app.constant";
import { ExperimentHelper } from "../../../helpers/experiment-helper";
import { LastUsedColumnLayoutModel } from "../../../../experiment-editor/models/experiment-editor.model";
import { ColumnLayoutResponse, ColumnLayouTypePayload } from "../../../../master-data/models/column-layout.model";

@Component({
    selector: "app-product-column-layout",
    templateUrl: "./product-column-layout.component.html",
    host: { class: "product-column-layout-component" },
})
export class ProductColumnLayoutComponent implements OnChanges, OnDestroy {
    public dialogRef: MatDialogRef<CustomLayoutSaveComponent>;

    public userColumnLayoutFormData: any[] = [];

    public columnLayoutFormData: any;

    public isDefaultLayout: any;

    public defaultLayoutDetails: any;

    public isTitle = false;

    public isSavedTemplateTab: boolean;

    public defaultLayoutName;

    public selectedIndex = 1;

    public selectedLayout;

    public columnLayoutPage = COLUMN_LAYOUT_ADDED_PAGE;

    public savedColumnList;

    public screenClick = false;

    @Input() public lastUsedColumnLayout: any[] = [];

    @Input() public currentPage: string;

    @Output()
    public onEmitSelectedColumns = new EventEmitter();

    @Output()
    public isCloseDrawer = new EventEmitter();

    @Output()
    public onCancelColumnLayout = new EventEmitter();

    @ViewChild("columnLayoutTab") columnLayoutTab: MatTabGroup;

    @ViewChild("columnLayoutSection") columnLayoutSection: BaseColumnLayoutComponent;

    public lastUsedColumLayout;

    public copiedColumnsToCustom = [];

    public disableSavedTab = false;

    public resetDefaultColumns = false;

    public checkCreateColumnValidation = false;

    public customSaveLayout = false;

    private componentSubscriptions: Subscription = new Subscription();

    constructor(
        private readonly baseColumnHelper: BaseColumnHelper,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly columnLayoutHelper: ColumnLayoutHelper,
        private readonly dialogReference: MatDialog,
        private readonly logger: NGXLogger,
        private readonly toastrService: ToastrService,
        private readonly appStateService: AppStateService,
        private readonly matomoService: MatomoService,
    ) {}

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.lastUsedColumnLayout?.currentValue?.length > 0) {
            // eslint-disable-next-line prefer-destructuring
            this.lastUsedColumLayout = changes.lastUsedColumnLayout.currentValue[0];
            this.updateLastUsedColumnLayout(changes.lastUsedColumnLayout.currentValue[0]);
        }
        const savedList = AppStateService.getSavedColumnLayoutList();
        this.disableSavedTab = savedList?.length === 0;
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_COLUMN_LAYOUT, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    public ngOnDestroy(): void {
        this.componentSubscriptions.unsubscribe();
    }

    /**
     * Method to update last used column layout in prod search and exp bom
     * @param {*} lastUsedColumnLayout
     * @memberof ProductColumnLayoutComponent
     */
    public updateLastUsedColumnLayout(lastUsedColumnLayout: LastUsedColumnLayoutModel): void {
        let lastUsedColumns;
        if (
            lastUsedColumnLayout?.columnLayoutType?.LayoutType === COLUMN_LAYOUT_TYPES.EDIT_BOM_CUSTOM ||
            lastUsedColumnLayout.columnLayoutType.LayoutType === COLUMN_LAYOUT_TYPES.PRODUCT_SEARCH_CUSTOM
        ) {
            lastUsedColumns = lastUsedColumnLayout;
        } else {
            this.savedColumnList = AppStateService.getSavedColumnLayoutList();
            lastUsedColumns =
                lastUsedColumnLayout && lastUsedColumnLayout.columnLayoutTypeID
                    ? lastUsedColumnLayout
                    : BaseColumnHelper.getDefaultColumnFromSavedLayouts();
        }
        this.isDefaultLayout = lastUsedColumns && lastUsedColumns.columnLayoutType ? lastUsedColumns.columnLayoutType : lastUsedColumns;
        this.selectedIndex =
            this.isDefaultLayout.LayoutType === COLUMN_LAYOUT_TYPES.EDIT_BOM_CUSTOM ||
            this.isDefaultLayout.LayoutType === COLUMN_LAYOUT_TYPES.PRODUCT_SEARCH_CUSTOM
                ? 0
                : 1;
        this.isSavedTemplateTab = this.selectedIndex !== 0;
        this.getDefaultlayout();
    }

    /**
     * Method to emit last used layout in custom/saved section
     * @memberof ProductColumnLayoutComponent
     */
    public getDefaultlayout() {
        if (this.isDefaultLayout) {
            const layouts = this.baseColumnHelper.formatColumnLayoutFormData(
                this.isDefaultLayout.UserColumnLayout,
                this.isDefaultLayout.ColumnLayoutTypeID,
            );
            if (
                this.isDefaultLayout.LayoutType === COLUMN_LAYOUT_TYPES.EDIT_PROD_SAVED ||
                this.isDefaultLayout.LayoutType === COLUMN_LAYOUT_TYPES.EDIT_BOM_SAVED
            ) {
                this.userColumnLayoutFormData = layouts;
            } else {
                this.copiedColumnsToCustom = layouts;
            }
            this.onEmitSelectedColumns.emit(layouts);
            const defaultLayout = {
                Columns:
                    this.isDefaultLayout.LayoutType === COLUMN_LAYOUT_TYPES.EDIT_BOM_CUSTOM ||
                    this.isDefaultLayout.LayoutType === COLUMN_LAYOUT_TYPES.PRODUCT_SEARCH_CUSTOM
                        ? this.copiedColumnsToCustom
                        : this.userColumnLayoutFormData,
            };
            this.defaultLayoutDetails = defaultLayout;
            this.defaultLayoutName = this.isDefaultLayout ? this.isDefaultLayout.LayoutName : "";
            this.selectedLayout = this.isDefaultLayout;
        }
    }

    /**
     * Method to select the column layout from the list
     *
     * @param {*} selectedLayout
     * @memberof ProductColumnLayoutComponent
     */
    public onSelectColumnLayout(selectedLayout: any): void {
        this.selectedLayout = selectedLayout;
        this.defaultLayoutName = selectedLayout.LayoutName;
        this.userColumnLayoutFormData = this.baseColumnHelper.formatColumnLayoutFormData(
            selectedLayout.UserColumnLayout,
            selectedLayout.ColumnLayoutTypeID,
        );
        this.onEmitSelectedColumns.emit(this.userColumnLayoutFormData);
    }

    /**
     * Mehod to get column form values
     *
     * @param {*} columnFormData
     * @memberof ProductColumnLayoutComponent
     */
    public getColumnFormValues(columnFormData: UntypedFormGroup): void {
        this.columnLayoutFormData = columnFormData;
        const checkSelectedColumn = find(this.columnLayoutFormData.get("Columns").value, (value) => value.Columns);
        if (!checkSelectedColumn) {
            this.checkCreateColumnValidation = true;
            return;
        }
        this.checkCreateColumnValidation = false;
    }

    /**
     * Method to apply the selected layout
     *
     * @memberof ProductColumnLayoutComponent
     */
    public onApplyTemplate(): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        const defaultColumnInfo = this.formatColumnLayoutInfo({ Columns: this.columnLayoutFormData.get("Columns").value });
        defaultColumnInfo.eventType = true;
        delay(() => {
            const defaultLayoutDetails = this.columnLayoutHelper.columnLayoutDetails(this.lastUsedColumLayout.columnLayoutType);
            const colLayoutDetails = {
                colLayoutDetail: defaultColumnInfo,
                userTabID: defaultColumnInfo.type === this.columnLayoutPage.BOM ? this.lastUsedColumLayout.userTabID : 0,
                IsColumnFieldsUpdated: defaultLayoutDetails
                    ? JSON.stringify(defaultColumnInfo.data.Columns) === JSON.stringify(defaultLayoutDetails)
                    : false,
                IsLayoutUpdated: defaultColumnInfo.columnLayoutTypeID
                    ? this.lastUsedColumLayout.columnLayoutType.ColumnLayoutTypeID === defaultColumnInfo.columnLayoutTypeID
                    : true,
                isSavedTemplateTab: this.isSavedTemplateTab,
                layoutName: this.defaultLayoutName,
            };
            const layoutType = ExperimentHelper.getLayoutTypeBasedOnID(this.savedColumnList, this.lastUsedColumLayout.columnLayoutTypeID);
            if (defaultColumnInfo.type === this.columnLayoutPage.BOM) {
                if (!colLayoutDetails.IsColumnFieldsUpdated || !colLayoutDetails.IsLayoutUpdated) {
                    this.columnLayoutHelper.updateColumnLayoutModification(colLayoutDetails, layoutType);
                } else {
                    this.onCancelTemplate();
                }
            } else {
                this.columnLayoutHelper.updateColumnLayoutModification(colLayoutDetails, layoutType);
            }
        }, 0);
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_COLUMN_LAYOUT, MatomoAction.CLICK, MatomoLabel.APPLY_TEMPLATE);
    }

    /**
     * Method to cancel the changed column layouts
     *
     * @memberof ProductColumnLayoutComponent
     */
    public onCancelTemplate(): void {
        this.resetDefaultColumns = false;
        this.onCancelColumnLayout.emit();
        if (this.isDefaultLayout) {
            this.onSelectColumnLayout(this.isDefaultLayout);
        }
        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_COLUMN_LAYOUT, MatomoAction.CLICK, MatomoLabel.ON_CANCEL_TEMPLATE);
    }

    /**
     * Method called after clicked the tab
     *
     * @memberof ProductColumnLayoutComponent
     */
    public onTabChange(): void {
        if (this.columnLayoutTab && this.columnLayoutTab.selectedIndex === 0) {
            this.isSavedTemplateTab = false;
            if (!this.resetDefaultColumns) {
                if (
                    this.lastUsedColumLayout.columnLayoutType.LayoutType !== COLUMN_LAYOUT_TYPES.EDIT_BOM_CUSTOM &&
                    this.lastUsedColumLayout.columnLayoutType.LayoutType !== COLUMN_LAYOUT_TYPES.PRODUCT_SEARCH_CUSTOM
                ) {
                    this.resetSelectedValues();
                } else {
                    this.columnLayoutFormData[VALUE].Columns = this.copiedColumnsToCustom;
                }
            }
            return;
        }
        this.isSavedTemplateTab = true;
        this.resetDefaultColumns = false;
        if (!this.customSaveLayout) {
            this.setDefaultColumnInSavedSection();
        }
        this.matomoService.trackEvent(MatomoCategory.PRODUCT_COLUMN_LAYOUT, MatomoAction.TAB_SWITCH, MatomoLabel.ON_TAB_CHANGE);
    }

    /**
     * Method to set deafult column in saved section on tab change
     * @returns{void}
     * @memberof ProductColumnLayoutComponent
     */
    public setDefaultColumnInSavedSection(): void {
        if (
            this.lastUsedColumLayout.columnLayoutType.LayoutType === COLUMN_LAYOUT_TYPES.EDIT_BOM_CUSTOM ||
            this.lastUsedColumLayout.columnLayoutType.LayoutType === COLUMN_LAYOUT_TYPES.PRODUCT_SEARCH_CUSTOM
        ) {
            this.savedColumnList = AppStateService.getSavedColumnLayoutList();
            const isDefaultLayout = BaseColumnHelper.getDefaultColumnFromSavedLayouts();
            this.selectedLayout = isDefaultLayout;
            if (isDefaultLayout) {
                const layouts = this.baseColumnHelper.formatColumnLayoutFormData(
                    isDefaultLayout.UserColumnLayout,
                    isDefaultLayout.ColumnLayoutTypeID,
                );
                this.defaultLayoutName = isDefaultLayout.LayoutName;
                this.userColumnLayoutFormData = layouts;
            }
        }
    }

    /**
     * Method to reset the column selecion in the layout
     *
     * @memberof ProductColumnLayoutComponent
     */
    public resetSelectedValues(): void {
        this.columnLayoutSection.resetColumnLayout();
    }

    /**
     * Method to call apply the default layout details
     *
     * @memberof ProductColumnLayoutComponent
     */
    public applyDefaultLayoutAfterClose(): void {
        if (this.defaultLayoutDetails) {
            const defaultColumnInfo = this.formatColumnLayoutInfo(this.defaultLayoutDetails);
            this.appBroadCastService.onLayoutChange(defaultColumnInfo);
        }
    }

    /**
     * Method to get column layout info
     *
     * @param {*} columnLayoutInfo
     * @returns {*}
     * @memberof ProductColumnLayoutComponent
     */
    private formatColumnLayoutInfo(columnLayoutInfo: any): any {
        return {
            data: columnLayoutInfo,
            type: this.currentPage,
            eventType: false,
            columnLayoutTypeID: this.selectedLayout && this.selectedLayout.ColumnLayoutTypeID ? this.selectedLayout.ColumnLayoutTypeID : "",
        };
    }

    /**
     * Method to copy saved column list from saved section to custom section
     * @returns {*}
     * @memberof ProductColumnLayoutComponent
     */
    public onCopyLayoutsToCustomSection(): void {
        this.resetDefaultColumns = true;
        this.selectedIndex = 0;
        this.copiedColumnsToCustom = [...this.userColumnLayoutFormData];
        this.matomoService.trackEvent(
            MatomoCategory.PRODUCT_COLUMN_LAYOUT,
            MatomoAction.CLICK,
            MatomoLabel.ON_COPY_LAYOUTS_TO_CUSTOM_SECTION,
        );
    }

    /**
     * Method to open save custom layout screen
     * @returns {*}
     * @memberof ProductColumnLayoutComponent
     */
    public openSaveCustomLayout(): void {
        this.isCloseDrawer.emit(true);
        this.dialogRef = this.dialogReference.open(CustomLayoutSaveComponent, COMMON_DIALOG_OLD);
        this.componentSubscriptions.add(
            this.dialogRef.afterClosed().subscribe((result) => {
                this.isCloseDrawer.emit(false);
                if (result) {
                    this.createColumnLayoutPayload(result.formData.LayoutName);
                    this.matomoService.trackEvent(
                        MatomoCategory.PRODUCT_COLUMN_LAYOUT,
                        MatomoAction.CLICK,
                        MatomoLabel.OPEN_SAVE_CUSTOM_LAYOUT,
                    );
                }
            }),
        );
    }

    /**
     * Method to create custom layout payload
     * @returns {void}
     * @param {string} layoutName
     * @memberof ProductColumnLayoutComponent
     */
    public createColumnLayoutPayload(layoutName: string): void {
        const columnLayoutValues: any = {};
        const defaultColumnInfo = this.formatColumnLayoutInfo(this.columnLayoutFormData.value);
        columnLayoutValues.LayoutName = layoutName;
        columnLayoutValues.LayoutType = COLUMN_LAYOUT_TYPES.EDIT_PROD_SAVED;
        columnLayoutValues.IsDefault = DEFAULT_COLUMN_LAYOUT;
        columnLayoutValues.UserColumnLayout = this.columnLayoutHelper.createColumnLayoutPayload(defaultColumnInfo.data.Columns);
        this.postCreateColumnLayout(columnLayoutValues);
    }

    /**
     * Method is used to add custom layout as saved column layout
     * @returns {void}
     * @param {ColumnLayouTypePayload} payLoad
     * @memberof ProductColumnLayoutComponent
     */
    public postCreateColumnLayout(payLoad: ColumnLayouTypePayload): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(CREATE_COLUMN_LAYOUT);
        this.componentSubscriptions.add(
            this.columnLayoutHelper.createColumnLayout(payLoad).subscribe({
                next: (response: ColumnLayoutResponse) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (!response) {
                        return;
                    }
                    this.selectedIndex = COLUMN_LAYOUT_TAB_INDEX;
                    // eslint-disable-next-line unicorn/prefer-spread
                    const layoutList = AppStateService.getSavedColumnLayoutList().concat(response);
                    this.appStateService.setSavedColumnLayoutList(layoutList);
                    this.savedColumnList = sortBy(layoutList, (list) => {
                        return list.LayoutName;
                    });
                    this.defaultLayoutName = response?.LayoutName;
                    this.selectedLayout.columnLayoutTypeID = response?.ColumnLayoutTypeID;
                    this.selectedLayout = response;
                    const layouts = this.baseColumnHelper.formatColumnLayoutFormData(
                        response?.UserColumnLayout,
                        response?.ColumnLayoutTypeID,
                    );
                    this.userColumnLayoutFormData = layouts;
                    this.toastrService.success(COLUMN_LAYOUT_SUCCESS.CREATE_COLUMN_LAYOUT_SUCCESS);
                },
                error: (error) => {
                    this.logger.error(error);
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.toastrService.error(COLUMN_LAYOUT_ERROR.CREATE_COLUMN_LAYOUT_ERROR);
                },
            }),
        );
    }
}
