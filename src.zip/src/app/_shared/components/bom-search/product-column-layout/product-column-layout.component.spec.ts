/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-empty-function */
/* eslint-disable class-methods-use-this */
/* eslint-disable max-lines-per-function */
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChange } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
// eslint-disable-next-line import/no-unresolved
import { ColumnLayoutHelper } from "src/app/master-data/helpers/column.layout.helper";
import { MatTabGroup } from "@angular/material/tabs";
import { UntypedFormControl, UntypedFormGroup } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";
import { of, throwError } from "rxjs";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { ColumnLayoutResponse, ColumnLayouTypePayload } from "../../../../master-data/models/column-layout.model";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { MockAppDataService } from "../../../../testing/mock-app.data.service";
import { AppBroadCastService, AppDataService, AppStateService, MatomoService } from "../../../../_services";
import { BaseColumnHelper } from "../../base-column-layout/helper/base-column-helper";
import { ExperimentHelper } from "../../../helpers/experiment-helper";
import { ProductColumnLayoutComponent } from "./product-column-layout.component";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";
import { MockToastrService } from "../../../../testing/mock-toastr.service";

describe("ProductColumnLayoutComponent", () => {
    let component: ProductColumnLayoutComponent;
    let fixture: ComponentFixture<ProductColumnLayoutComponent>;
    let element;
    const columnLayoutTab: MatTabGroup = {
        selectedIndex: 1,
    } as MatTabGroup;
    const dialogReferenceStub = {
        afterClosed() {
            return of({ screenActive: true, formData: { LayoutName: "test" } }); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    const dialogStub = { open: () => dialogReferenceStub };
    const layoutList = [
        {
            ColumnLayoutTypeID: 945,
            LayoutName: "test",
            IsDefault: true,
            UserColumnLayout: [
                {
                    ColumnHeader: "TEFL",
                    ColumnLayoutID: 17_090,
                    ColumnLayoutTypeID: 931,
                    ColumnName: "Stock",
                    ColumnSelectedValue: "TEFL",
                    Sequence: 1,
                },
            ],
            isUpdateLayouts: true,
        },
        {
            ColumnLayoutTypeID: 946,
            LayoutName: "LayoutName",
            IsDefault: true,
            UserColumnLayout: [
                {
                    ColumnHeader: "TEFL",
                    ColumnLayoutID: 17_090,
                    ColumnLayoutTypeID: 931,
                    ColumnName: "Stock",
                    ColumnSelectedValue: "TEFL",
                    Sequence: 1,
                },
            ],
            isUpdateLayouts: true,
        },
    ];
    class MockBaseColumnHelper {
        formatColumnLayoutInfo() {}

        formatColumnLayoutFormData() {}

        // eslint-disable-next-line class-methods-use-this
        updateLastUsedColumnLayout() {
            return [{ IsDefault: "1", LayoutName: "test", columnLayoutType: { LayoutType: "EX " } }];
        }

        getDefaultColumnFromSavedLayouts() {}

        columnLayoutDetails() {}

        updateColumnLayoutModification() {}

        createColumnLayoutPayload() {}

        createColumnLayout() {
            return of({});
        }

        getColumnLayouts() {}
    }

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ProductColumnLayoutComponent],
            providers: [
                { provide: BaseColumnHelper, useClass: MockBaseColumnHelper },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                AppBroadCastService,
                { provide: ColumnLayoutHelper, useClass: MockBaseColumnHelper },
                ExperimentHelper,
                { provide: AppStateService, useClass: MockAppStateService },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: dialogStub,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ProductColumnLayoutComponent);
        component = fixture.componentInstance;
        element = fixture.nativeElement;
        component.lastUsedColumLayout = [{ IsDefault: "1", LayoutName: "test", columnLayoutType: { LayoutType: "EX " } }];
        component.selectedLayout = {};
        component.savedColumnList = layoutList;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for onCancelTemplate()", () => {
        component.isDefaultLayout = { UserColumnLayout: "" };
        spyOn(component, "onSelectColumnLayout").and.callThrough();
        const spy = spyOn(component, "onCancelTemplate").and.callThrough();
        component.onCancelTemplate();
        expect(spy).toHaveBeenCalled();
    });

    xit("should resolve for onApplyTemplate()", () => {
        component.columnLayoutFormData = { value: "TEST" };
        const spy = spyOn(component, "onApplyTemplate").and.callThrough();
        component.onApplyTemplate();
        expect(spy).toHaveBeenCalled();
    });

    it("should render savedColumnList", () => {
        spyOn(component, "updateLastUsedColumnLayout").and.returnValue();
        component.savedColumnList = [{ columnLayoutTypeID: 945, IsDefault: "1", LayoutName: "test", UserColumnLayout: [] }];
        component.ngOnChanges({
            savedColumnList: new SimpleChange(component.savedColumnList, component.savedColumnList, false),
        });
        fixture.detectChanges();
        expect(element.querySelector("mat-option").textContent).toBe("test");
    });

    it("should render savedColumnList", () => {
        component.savedColumnList = [];
        component.isDefaultLayout = {};
        component.ngOnChanges({
            savedColumnList: new SimpleChange(component.savedColumnList, component.savedColumnList, false),
        });
        fixture.detectChanges();
        expect(element.querySelector("mat-select").textContent).toBe("");
    });

    it("should resolve for onCopyLayoutsToCustomSection()", () => {
        component.columnLayoutFormData = { value: "TEST" };
        const spy = spyOn(component, "onCopyLayoutsToCustomSection").and.callThrough();
        component.onCopyLayoutsToCustomSection();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for applyDefaultLayoutAfterClose()", () => {
        const spy = spyOn(component, "applyDefaultLayoutAfterClose").and.callThrough();
        component.applyDefaultLayoutAfterClose();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for applyDefaultLayoutAfterClose()", () => {
        component.defaultLayoutDetails = true;
        const spy = spyOn(component, "applyDefaultLayoutAfterClose").and.callThrough();
        component.applyDefaultLayoutAfterClose();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTabChange()", () => {
        component.columnLayoutTab = columnLayoutTab;
        component.lastUsedColumLayout = {
            columnLayoutTypeID: 945,
            IsDefault: "1",
            LayoutName: "test",
            columnLayoutType: { LayoutType: "EX " },
        };
        const spy = spyOn(component, "onTabChange").and.callThrough();
        component.onTabChange();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTabChange()", () => {
        component.columnLayoutTab = columnLayoutTab;
        component.lastUsedColumLayout = { IsDefault: "1", LayoutName: "test", columnLayoutType: { LayoutType: "EX " } };
        const spy = spyOn(component, "onTabChange").and.callThrough();
        component.onTabChange();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onCancelTemplate()", () => {
        component.isDefaultLayout = false;
        const spy = spyOn(component, "onCancelTemplate").and.callThrough();
        component.onCancelTemplate();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getColumnFormValues()", () => {
        const formData = new UntypedFormGroup({
            Columns: new UntypedFormControl("test"),
            Attributes: new UntypedFormControl("test"),
            ColumnHeader: new UntypedFormControl("test"),
        });
        const spy = spyOn(component, "getColumnFormValues").and.callThrough();
        component.getColumnFormValues(formData);
        expect(spy).toHaveBeenCalled();
    });

    xit("should resolve for updateLastUsedColumnLayout()", () => {
        component.savedColumnList = [
            { LayoutType: "EXS", IsDefault: "1", LayoutName: "test", UserColumnLayout: [], columnLayoutType: { LayoutType: "EXS" } },
        ];
        // eslint-disable-next-line prefer-destructuring
        component.isDefaultLayout = component.savedColumnList[0];
        const spy = spyOn(component, "updateLastUsedColumnLayout").and.callThrough();
        component.updateLastUsedColumnLayout(component.savedColumnList[0]);
        expect(spy).toHaveBeenCalled();
    });

    it("should render lastUsedColumnLayout ", () => {
        component.savedColumnList = [{ columnLayoutTypeID: 945, IsDefault: "0", LayoutName: "test", UserColumnLayout: [] }];
        component.lastUsedColumnLayout = [{ IsDefault: "0", LayoutName: "test", columnLayoutType: { LayoutType: "EXC" } }];
        component.ngOnChanges({
            lastUsedColumnLayout: new SimpleChange(component.lastUsedColumnLayout, component.lastUsedColumnLayout, false),
        });
        fixture.detectChanges();
        expect(element.querySelector("mat-select").textContent).toBe("test");
    });
    it("should resolve for openSaveCustomLayout()", () => {
        spyOn(component, "createColumnLayoutPayload").and.returnValue();
        const spy = spyOn(component, "openSaveCustomLayout").and.callThrough();
        component.openSaveCustomLayout();
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for createColumnLayoutPayload()", () => {
        component.columnLayoutFormData = { value: "" };
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(component, "formatColumnLayoutInfo").and.returnValue({ data: { Columns: {} } });
        spyOn(component, "postCreateColumnLayout").and.returnValue();
        const spy = spyOn(component, "createColumnLayoutPayload").and.callThrough();
        component.createColumnLayoutPayload("");
        expect(spy).toHaveBeenCalled();
    });
    // it("should resolve for postCreateColumnLayout()", () => {
    //     const service: ColumnLayoutHelper = TestBed.inject(ColumnLayoutHelper);
    //     spyOn(service, "getColumnLayouts").and.returnValue();
    //     const spy = spyOn(component, "postCreateColumnLayout").and.callThrough();
    //     component.postCreateColumnLayout({} as ColumnLayouTypePayload);
    //     expect(spy).toHaveBeenCalled();
    // });
    it("should call for error postCreateColumnLayout()", () => {
        const broadService: AppBroadCastService = TestBed.inject(AppBroadCastService);
        broadService.columnLayoutSavedData.next(layoutList);
        component.selectedLayout = {};
        const service: ColumnLayoutHelper = TestBed.inject(ColumnLayoutHelper);
        spyOn(service, "createColumnLayout").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "postCreateColumnLayout").and.callThrough();
        component.postCreateColumnLayout({} as ColumnLayouTypePayload);
        expect(spy).toHaveBeenCalled();
    });
    it("should call for response postCreateColumnLayout()", () => {
        // const broadService: AppBroadCastService = TestBed.inject(AppBroadCastService);
        const stateService: AppStateService = TestBed.inject(AppStateService);
        // broadService.columnLayoutSavedData.next(layoutList);
        component.selectedLayout = {};
        const service: ColumnLayoutHelper = TestBed.inject(ColumnLayoutHelper);
        spyOn(service, "createColumnLayout").and.returnValue(of(layoutList[0] as unknown as ColumnLayoutResponse));
        spyOn(AppStateService, "getSavedColumnLayoutList").and.returnValue([layoutList[0] as unknown as ColumnLayoutResponse]);
        spyOn(stateService, "setSavedColumnLayoutList").and.returnValue();
        const spy = spyOn(component, "postCreateColumnLayout").and.callThrough();
        component.postCreateColumnLayout({} as ColumnLayouTypePayload);
        expect(spy).toHaveBeenCalled();
    });
});
