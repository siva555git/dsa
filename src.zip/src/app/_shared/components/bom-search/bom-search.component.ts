/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { Component, ElementRef, Inject, OnInit, QueryList, ViewChild, ViewChildren } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MatTabGroup } from "@angular/material/tabs";
import { cloneDeep, delay, every, filter, forEach, remove, slice } from "lodash";
import { Subscription } from "rxjs";
import { filter as rxFilter } from "rxjs/operators";
import { DialogHelper } from "@te-shared/helpers/dialog-helper";
import { ExperimentFormulaModel } from "@te-shared/models/experiment-bom.model";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { PRODUCT } from "../../constants/context-menu.constant";
import { ColumnLayoutHelper } from "../../../master-data/helpers/column.layout.helper";
import { TabHelper } from "../../helpers/tab-helper";
import { EMPTY, DRAG_AND_DROP_TOOLTIP, TOOLTIP_VISIBLE_LENGTH, EDITION_SUGGESTION } from "../../../app.constant";
import { ZERO_WITH_DECIMAL } from "../../../creative-review/creative-review.constant";
import { DEFAULT_COST, EDIT_SUGGEST_ACTIONS, IS_DELETE } from "../../../experiment-editor/constants/experiment-editor.constant";
import { ExperimentUtil } from "../../../experiment-editor/helpers/experiment.util";
import {
    CartItemModel,
    EditionSuggestionProductRow,
    LastUsedColumnLayoutModel,
    SearchType,
} from "../../../experiment-editor/models/experiment-editor.model";
import { ColumnLayoutResponse } from "../../../master-data/models/column-layout.model";
import { AppBroadCastService, AppStateService, MatomoService } from "../../../_services";
import {
    APPLY,
    BOM_MENU,
    BOM_TYPE,
    CANCEL,
    CART_WARNING_INFO,
    COLUMN_LAYOUT_ADDED_PAGE,
    COMMON_DIALOG_OLD,
    DISPLAY_DECIMALS,
    EDITION_SUGGESTION_ACTION_IN,
    KEYBOARD_KEYS,
    MAX_INSTRUCTION_LENGTH,
    NUMRIC_LIMITS,
    PARTS,
    SEARCH_DEBOUNCE_TIME,
    SEARCH_DRAWER_HEADING,
} from "../../constants/common.constant";
import { EDIT_SUGGEST_TABS, MARK_FOR_DELETE_FLAG, MARK_FOR_UNDELETE_FLAG } from "../../constants/experiment.constant";
import { MatomoAction, MatomoCategory, MatomoLabel, SUBTypes } from "../../enums";
import { BomSearchHelper } from "../../helpers/bom-search.helper";
import { ExperimentBomUtil } from "../../helpers/experiment-bom.util";
import { MiniEditorSuggestionHelper } from "../../helpers/mini-editor-suggestion.helper";
import { TasteEditorUtilClass } from "../../helpers/taste-editor-utils";
import { BomSearchModel, CartItemsModel } from "../../models/bom-search.model";
import { BomSearchDialogDataModel } from "../../models/dialog.model";
import { SearchButtonPipe } from "../../pipes/search-button.pipe";
import { ProductDataCostHelper } from "../product-data/product-data-cost/product-data-cost.helper";
import { ExperimentsSearchComponent } from "./experiments-search/experiments-search.component";
import { InstructionSearchComponent } from "./instruction-search/instruction-search.component";
import { ProductColumnLayoutComponent } from "./product-column-layout/product-column-layout.component";
import { ProductSearchComponent } from "./product-search/product-search.component";
import { UnapprovedSearchComponent } from "./unapproved-search/unapproved-search.component";
import { KeyboardShortcutsInfoComponent } from "./keyboard-shortcuts-info/keyboard-shortcuts-info.component";
import { EditionSuggesstionHelper } from "../../../experiment-editor/helpers/edition-suggesstion.helper";
import { VALUE } from "../base-ipc-layout/base-ipc-layout-constant";

@Component({
    selector: "app-bom-search",
    templateUrl: "./bom-search.component.html",
})
export class BomSearchComponent implements OnInit {
    public cartTypes = BOM_TYPE;

    public cartListCopy = [];

    public cartLists: CartItemModel[] = [];

    public highLightCartItem = false;

    public showSideDrawer = false;

    public showInstruction: boolean[] = [];

    public textMaxLength = MAX_INSTRUCTION_LENGTH;

    public drapAndDropTooltip = DRAG_AND_DROP_TOOLTIP;

    public toolTipVisibleLength = TOOLTIP_VISIBLE_LENGTH;

    public bomMenuList = BOM_MENU;

    public currentListItem = BOM_MENU.BOM_CART;

    public savedColumnList: ColumnLayoutResponse;

    public deFaultLayoutSelection: any[] = [];

    public disableBomMenu = false;

    public expandProductSidebar = true;

    public cartWarningInfo = CART_WARNING_INFO;

    public columnLayoutPage = COLUMN_LAYOUT_ADDED_PAGE;

    public plantID: any;

    public activeExpSource: string;

    public expCode: string;

    public searchHeading = "";

    public selectedCartItemIndex = 0;

    public deletedItems = [];

    public softDeletedItems = [];

    public unDeletedCartItems = [];

    public cartListSubscriptions: Subscription[] = [];

    public numricLimits = NUMRIC_LIMITS;

    public totalParts;

    public lastUsedColumnLayout: LastUsedColumnLayoutModel[];

    public saveBtnName = APPLY;

    public cancelBtnName = CANCEL;

    public experimentDetails;

    public searchType = SearchType;

    public isProductadded = false;

    private previousValue: string;

    public isOpenProductDataAccessible = true;

    @ViewChild("productSearchComp") productSearchComp: ProductSearchComponent;

    @ViewChild("instructionSearchComp") instructionSearchComp: InstructionSearchComponent;

    @ViewChild("unapprovedSearchComp") unapprovedSearchComp: UnapprovedSearchComponent;

    @ViewChild("experimentSearchComp") experimentSearchComp: ExperimentsSearchComponent;

    @ViewChild("productColumnLayout") private productColumnLayout: ProductColumnLayoutComponent;

    @ViewChild("tabGroup") tabGroup: MatTabGroup;

    @ViewChildren("cartListItemInput") cartListInputs: QueryList<ElementRef>;

    @ViewChildren("cartListItems") cartListItems: QueryList<ElementRef>;

    public applicationPermissions = APPLICATION_PERMISSIONS;

    public bomSearchModel: BomSearchModel;

    public disableBtn = true;

    public isOpenProductExperiment = false;

    public editionSuggestion = EDITION_SUGGESTION;

    public selectedTabIndex = 0;

    public searchFilterData;

    public selectedMiniEditorInst: string;

    constructor(
        private readonly myElement: ElementRef,
        private readonly dialogReference: MatDialogRef<BomSearchComponent>,
        private readonly searchButton: SearchButtonPipe,
        private readonly miniEditorSuggestionHelper: MiniEditorSuggestionHelper,
        @Inject(MAT_DIALOG_DATA) public data: BomSearchDialogDataModel,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly productDataCostHelper: ProductDataCostHelper,
        private readonly tabHelper: TabHelper,
        private readonly dialog: MatDialog,
        private readonly dialogHelper: DialogHelper,
        private readonly securityHelper: SecurityHelper,
        private readonly matomoService: MatomoService,
    ) {}

    ngOnInit() {
        this.isOpenProductDataAccessible = this.securityHelper.hasPermission(this.applicationPermissions.PRODUCT_DATA);
        this.currentListItem = (this.data.type === this.searchType.ipcView || this.data.type === this.searchType.pickIpc) ? BOM_MENU.BOM_LAYOUT : BOM_MENU.BOM_CART;
        this.searchHeading = SEARCH_DRAWER_HEADING[this.data.type];
        if (this.data.type === this.searchType.ipcView || this.data.type === this.searchType.pickIpc) {
            this.expandProductSidebar = false;
        } else if (this.data.type === this.searchType.openProductOrExperiment) {
            this.saveBtnName = "OPEN";
            this.cancelBtnName = "CLOSE";
            this.isOpenProductExperiment = true;
        } else {
            this.searchFilterData = this.data.workSpace?.SearchFilters;
            this.selectedTabIndex = this.data.workSpace ? this.data.workSpace.SearchFilters?.activeTab : 0;
            this.cartLists = this.getCartDataFromGrid();
            this.removeDeletedItem();
        }
        this.cartListSubscriptions.push(
            this.dialogReference.keydownEvents().subscribe((event) => {
                    if (event.key === KEYBOARD_KEYS.ESCAPE) {
                        this.onCancelDrawer();
                    }
                }),
        );

        this.plantID = this.data.activeExperiment?.PlantID ?? EMPTY;
        this.activeExpSource = this.data.activeExperiment?.SourceFlagCodeID ?? EMPTY;
        this.expCode = this.data.activeExperiment?.ExpCode ?? EMPTY;
        if (this.data.activeExperiment) {
            this.experimentDetails = this.data.activeExperiment;
        }

        this.bomSearchModel = {
            searchType: this.data.type,
            softDeletedItems: this.softDeletedItems,
            deletedItems: this.deletedItems,
            data: this.data,
            cartListCopy: this.cartListCopy,
        };
        this.listenSuggestionChanges();
        this.getSearchColumnHeaderWidth();
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    public ngOnDestroy(): void {
        if (this.cartListSubscriptions !== undefined) {
            TasteEditorUtilClass.removeSubscriptions(this.cartListSubscriptions);
        }
    }

    /**
     * Method to get grid data in cart format
     *
     * @memberof BomSearchComponent
     */
    public getCartDataFromGrid(): CartItemModel[] {
        const cartData: CartItemModel[] = [];
        let isCartItemIndex = true;
        forEach(this.data.bomDetails, (bom, index) => {
            const cartObject: CartItemModel = {
                ExpFormulaID: bom[ExperimentBomUtil.getFormulaIdKey(this.data.activeExperiment.ExpCode)],
                Instruction: bom.Instruction,
                SUBType: bom.SUBType,
                IsDelete: bom.IsDelete,
            };
            // eslint-disable-next-line unicorn/prefer-switch
            if (bom.SUBType === BOM_TYPE.PRODUCT || bom.SUBType === BOM_TYPE.UNAPPROVED) {
                const cartProductData = {
                    SUBCode: bom.ipc,
                    description: bom.ingredientName,
                    Parts: ExperimentUtil.parseFloatWithGivenDecimals(bom[this.data.activeExperiment.ExpCode], DISPLAY_DECIMALS),
                    isSolution: bom.isSolution ?? false,
                    isFema: bom.isFema ?? false,
                    isEnum: bom.isEnum ?? false,
                    isVariant: bom.isVariant ?? false,
                };
                Object.assign(cartObject, cartProductData);
            } else if (bom.SUBType === BOM_TYPE.EXPERIMENT) {
                const cartExperimentData = {
                    IPC: bom.ipc,
                    SUBCode: bom.SUBCode,
                    ExpCode: bom.ipc ?? bom.SUBCode,
                    ExpName: bom.ingredientName,
                    Parts: ExperimentUtil.parseFloatWithGivenDecimals(bom[this.data.activeExperiment.ExpCode], DISPLAY_DECIMALS),
                    IsSolution: bom.isSolution,
                    IsFema: bom.isFema,
                    IsEnum: bom.isEnum,
                    isVariant: bom.isVariant,
                };
                Object.assign(cartObject, cartExperimentData);
            } else if (bom.SUBType === BOM_TYPE.INSTRUCTION) {
                const cartInstrucationData = {
                    Parts: DEFAULT_COST,
                };
                Object.assign(cartObject, cartInstrucationData);
            }
            cartData.push(cartObject);
            if (bom.IsDelete === MARK_FOR_UNDELETE_FLAG && isCartItemIndex) {
                this.selectedCartItemIndex = +index;
                isCartItemIndex = false;
            }
        });
        this.setInitialCartItemIndex(cartData);
        this.cartListCopy = cloneDeep(cartData);
        return cartData;
    }

    /**
     * Method to set Initial CartItemIndex
     * @param {CartItemModel[]} cartData
     * @returns {void}
     * @memberof BomSearchComponent
     */
    public setInitialCartItemIndex(cartData: CartItemModel[]): void {
        if (this.data.lastSelectedExperiment?.length > 0 && cartData?.length > 0) {
            const selectedExperimentFormulaID =
                this.data.lastSelectedExperiment[0].data[ExperimentBomUtil.getFormulaIdKey(this.data.activeExperiment.ExpCode)];
            const selectedExpIndexInCart = cartData.findIndex((data) => data.ExpFormulaID === selectedExperimentFormulaID);
            if (selectedExpIndexInCart !== -1) {
                this.selectedCartItemIndex = selectedExpIndexInCart;
            }
            this.focusOnSelectedCartItem();
        } else if (cartData?.length > 0) {
            this.selectedCartItemIndex = cartData.length - 1;
            this.focusOnSelectedCartItem();
        }
    }

    /**
     * Method to close the drawer
     *
     * @memberof BomSearchComponent
     */
    public onCancelDrawer(): void {
        this.dialogReference.close();
        if (!this.isOpenProductExperiment) this.storeTabDetails();
        if (this.productSearchComp) {
            this.productSearchComp.storeSearchColumnHeaderWidth();
        }
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.CLICK, MatomoLabel.ON_CANCEL_DRAWER);
    }

    /**
     * Method to close the drawer
     *
     * @memberof BomSearchComponent
     */
    public onInsertToBom(): void {
        let cartItems;
        if (this.data.type === this.searchType.openProductOrExperiment) {
            cartItems = this.cartLists;
        } else {
            const { softDeletedItems, deletedItems, cartLists, cartListCopy } = this;
            const { addedItems, updatedItems } = BomSearchHelper.getNewAndUpdatedBomItems(cartLists, this.data, cartListCopy);
            const data: CartItemsModel = {
                addedItems,
                updatedItems,
                softDeletedItems,
                deletedItems,
                cartLists,
                cartListCopy,
            };
            if (BomSearchHelper.isBOMChanged(data)) {
                cartItems = { cartList: cartLists, addedItems, updatedItems, softDeletedItems, deletedItems };
            }
        }
        this.dialogReference.close(cartItems);
        if (!this.isOpenProductExperiment) this.storeTabDetails();
        this.cartLists = [];
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.CLICK, MatomoLabel.ON_INSERT_TO_BOM);
    }

    /**
     * Method to add item to the cart
     *
     * @param {*} cartItem
     * @param {*} [suggestionData]
     * @memberof BomSearchComponent
     */
    public onAddToCart(cartItem: CartItemModel, suggestionData?): void {   
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.CLICK, MatomoLabel.ON_ADD_TO_CART);
        const item = cartItem;
        item.isNewlyAddedItem = true;
        if(this.data.type == this.searchType.pickIpc){        
            this.dialogReference.close(item);
            return;
        }
        const exceptCurrentExp = filter(
            this.data.gridSelectedExpCodes,
            (selectExpCode) => selectExpCode !== this.data.activeExperiment.ExpCode,
        );
        if (exceptCurrentExp?.length > 0) {
            item.showAvailabiltyWarning = ExperimentBomUtil.getItemAvailabityFromGrid(
                this.data.filteredGridDataSource,
                exceptCurrentExp,
                item,
            );
        }
        if (item.SUBType === SUBTypes.PRODUCT) {
            MiniEditorSuggestionHelper.doesSolutionAndFemaExist(item);
        }
        this.cartLists.splice(this.selectedCartItemIndex + 1, 0, item);
        if (this.cartLists.length > 1) {
            this.selectedCartItemIndex += 1;
        }
        this.highLightCartItem = true;
        this.disableBtn = this.searchButton.transform(this.cartLists, this.bomSearchModel);

        // To hard delete the new ipc if it is replaced
        if (suggestionData?.action === EDIT_SUGGEST_ACTIONS.REPLACE && suggestionData.suggestedBom.ExpFormulaID === "") {
            this.cartLists.splice(this.selectedCartItemIndex - 1, 1);
            this.selectedCartItemIndex -= 1;
        }
        this.focusOnSelectedCartItem();
        delay(() => {
            this.removeDeletedItem();
        }, 10);
    }

    /**
     * Method to remove item from the cart
     *
     * @param {*} item
     * @param {number} cartItemIndex
     * @returns {void}
     * @memberof BomSearchComponent
     */
    public onRemoveCartItem(item: any, cartItemIndex: number): void {
        this.selectedCartItemIndex = cartItemIndex;
        const cartItem = item;
        if (item?.isNewlyAddedItem) {
            const index = this.cartLists.indexOf(cartItem);
            this.cartLists.splice(index, 1);
            delay(() => {
                this.selectedCartItemIndex -= 1;
                this.updateCartItemsAfterDelete();
            }, 10);
        } else {
            cartItem.Parts = cartItem.Parts || this.previousValue;
            cartItem.IsDelete = MARK_FOR_DELETE_FLAG;
            this.updateCartItemsAfterDelete();
        }
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.CLICK, MatomoLabel.REMOVE_CART_ITEM);
    }

    /**
     * Method to update cart items after delete
     *
     * @returns {void}
     * @memberof BomSearchComponent
     */
    private updateCartItemsAfterDelete(): void {
        this.totalParts = ExperimentUtil.calculateTotalParts(this.cartLists as unknown as ExperimentFormulaModel[], PARTS);
        this.disableBtn = this.searchButton.transform(this.cartLists, this.bomSearchModel);
        this.removeDeletedItem();
        this.isDeletedItem(true);
    }

    /**
     * Method to handle the drag and drop
     *
     * @param {CdkDragDrop<string[]>} event
     * @memberof BomSearchComponent
     */
    public drop(event: CdkDragDrop<string[]>): void {
        this.selectedCartItemIndex = event.currentIndex;
        moveItemInArray(this.cartLists, event.previousIndex, event.currentIndex);
        this.disableBtn = this.searchButton.transform(this.cartLists, this.bomSearchModel);
    }

    /**
     * Method to focus on selected cart item
     *
     * @memberof BomSearchComponent
     */
    public focusOnSelectedCartItem(): void {
        delay(() => {
            const element = this.myElement.nativeElement.querySelector(".selected-cart-item");
            if (element) {
                element.scrollIntoViewIfNeeded();
            }
            this.selectInput(this.selectedCartItemIndex);
        }, 200);
    }

    /**
     * Method to select text box value on first click
     *
     * @memberof BomSearchComponent
     */
    public onClickParts(selectedRow, event) {
        event.target.select();
        if (selectedRow !== this.selectedCartItemIndex) {
            event.target.select();
        }
    }

    /**
     * Method to update parts in cartList item if text box value is defaulted to previous value
     *
     * @param {number} index
     * @returns {void}
     * @memberof BomSearchComponent
     */
    public onFocusOutParts(index: number): void {
        const newValue = this.cartLists[index].Parts;
        if (!newValue || Number.isNaN(Number(newValue))) {
            this.cartLists[index].Parts = this.previousValue;
        } else if (newValue !== this.previousValue) {
            this.disableBtn = this.searchButton.transform(this.cartLists, this.bomSearchModel);
        }
        this.removeDeletedItem();
    }

    /**
     * Method to update parts in cartList item if text box value is defaulted to previous value
     *
     * @param {FocusEvent} event
     * @memberof BomSearchComponent
     */
    public onFocusParts = (event: FocusEvent): void => {
        this.previousValue = event.target[VALUE];
    };

    /**
     * Method to navigate between tabs on key press
     *
     * @param {KeyboardEvent} event
     * @param {boolean} [goToPreviousTab=false]
     * @memberof BomSearchComponent
     */
    public changeTab(event: KeyboardEvent, goToPreviousTab = false): void {
        event.stopPropagation();
        event.preventDefault();

        const currentTabIndex = this.tabGroup.selectedIndex;
        if (goToPreviousTab) {
            this.tabGroup.selectedIndex = currentTabIndex - 1 < 0 ? currentTabIndex : currentTabIndex - 1;
        } else {
            // eslint-disable-next-line no-underscore-dangle
            this.tabGroup.selectedIndex = currentTabIndex + 1 === this.tabGroup._tabs.length ? currentTabIndex : currentTabIndex + 1;
        }
        this.onTabChange();
    }

    /**
     * Method to set focus in searchbox based on tab change
     * @memberof BomSearchComponent
     */
    public onTabChange(): void {
        if (!this.tabGroup) return;
        this.disableBomMenu = this.tabGroup.selectedIndex !== 0;
        if (this.tabGroup.selectedIndex > 0 && this.currentListItem === BOM_MENU.BOM_LAYOUT) {
            this.switchToCart(true);
        }
        this.focusSearchTextBox(false);
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.TAB_SWITCH, MatomoLabel.CHANGE_TAB);
    }

    /**
     * Method to shift focus to Search text box
     *
     * @memberof BomSearchComponent
     */
    public focusSearchTextBox(shouldSelect: boolean, instructionInputFocus = false): void {
        const focusTextBoxes =
            this.data.type === this.searchType.openProductOrExperiment
                ? [this.productSearchComp.searchTextBox.nativeElement, this.experimentSearchComp.searchTextBox.nativeElement]
                : [
                      this.productSearchComp.searchTextBox.nativeElement,
                      instructionInputFocus
                          ? this.instructionSearchComp?.instructionInput.nativeElement
                          : this.instructionSearchComp?.searchTextBox.nativeElement,
                      this.experimentSearchComp.searchTextBox.nativeElement,
                      this.unapprovedSearchComp?.searchTextBox.nativeElement,
                  ];
        delay(() => {
            if (focusTextBoxes) {
                if (shouldSelect) focusTextBoxes[this.tabGroup.selectedIndex].select();
                else focusTextBoxes[this.tabGroup.selectedIndex].focus();
            }
            if (!instructionInputFocus) {
                this.instructionSearchComp?.instruction?.setValue(EMPTY);
            }
        }, SEARCH_DEBOUNCE_TIME);
    }

    /**
     * Method to switch to cart
     *
     * @memberof BomSearchComponent
     */
    public switchToCart(isCloseDialog = false): void {
        this.currentListItem = (this.data.type === this.searchType.ipcView || this.data.type === this.searchType.pickIpc) ? BOM_MENU.BOM_LAYOUT : BOM_MENU.BOM_CART;
        if (!isCloseDialog)  { 
            this.dialogReference.close();
        } else {
            this.onClickExpandCollapse()
        }
    }

    /**
     * Method to switch focus to 1st row of search results
     *
     * @memberof BomSearchComponent
     */
    public focusOnSearchResults() {
        const searchResultList =
            this.data.type === this.searchType.openProductOrExperiment
                ? [this.productSearchComp, this.experimentSearchComp]
                : [this.productSearchComp, this.instructionSearchComp, this.experimentSearchComp, this.unapprovedSearchComp];
        searchResultList[this.tabGroup.selectedIndex].focusOnFirstDataRow();
    }

    /**
     * Method to expand column layout and insert items
     *
     * @memberof BomSearchComponent
     */
    public layoutExpandCollapse(item: string): void {
        this.expandProductSidebar = true;
        if (item === this.bomMenuList.BOM_CART) {
            this.currentListItem = this.bomMenuList.BOM_CART;
        } else if (this.data.type !== this.searchType.openProductOrExperiment) {
            this.currentListItem = this.bomMenuList.BOM_LAYOUT;
            delay(() => {
                this.lastUsedColumnLayout =
                    (this.data.type === this.searchType.ipcView || this.data.type === this.searchType.pickIpc)
                        ? BomSearchHelper.getLastUsedColumnLayout()
                        : ColumnLayoutHelper.updateLastUsedColumnLayout(AppStateService.getUserTabDetails());
            }, 0);
        }
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.CLICK, MatomoLabel.LAYOUT_EXPAND_COLLAPSE);
    }

    /**
     * Method to check if an index is the last index of the available elements in an array.
     * @param {any[]} array The array of objects to check
     * @param {number} index The index to check
     * @return {*} {boolean} A boolean value indicating whether the index is the last index of the available elements
     * @memberof BomSearchComponent
     */
    public isLastIndex(array, index) {
        // Check if the index is valid and the element at that index is not deleted
        if (index >= 0 && index < array.length && array[index].IsDelete === 0) {
            // Use the every function to check if all the elements after the given index are deleted
            return every(slice(array, index + 1), { IsDelete: 1 });
        }
        // If the index is invalid or the element at that index is deleted, return false
        return false;
    }

    /**
     * Method to navigate list by keyboard events
     *
     * @param {KeyboardEvent} event
     * @return {*}  {boolean}
     * @memberof BomSearchComponent
     */
    public onKeydownEvents(event: KeyboardEvent): boolean {
        if (event.key === KEYBOARD_KEYS.ENTER) {
            const isLastIndex = this.isLastIndex(this.cartLists, this.selectedCartItemIndex);
            if (isLastIndex === true) {
                this.focusSearchTextBox(true, true);
            }
        }
        if (
            (event.key === KEYBOARD_KEYS.DOWN_ARROW || event.key === KEYBOARD_KEYS.ENTER) &&
            this.cartLists.length - this.selectedCartItemIndex > 1
        ) {
            this.isDeletedItem(true);
            return false;
        }
        if (event.key === KEYBOARD_KEYS.UP_ARROW && this.selectedCartItemIndex > 0) {
            this.isDeletedItem(false);
            return false;
        }
        return true;
    }

    /**
     * Method to check deleted item while navigation
     * @param {boolean} isKeyDown
     *
     * @return {void}
     * @memberof BomSearchComponent
     */
    public isDeletedItem(isKeyDown: boolean): void {
        let isDeletedItem;
        if (isKeyDown) {
            this.selectedCartItemIndex += 1;
            isDeletedItem = this.selectInput(this.selectedCartItemIndex - 1);
        } else {
            this.selectedCartItemIndex -= 1;
            isDeletedItem = this.selectInput(this.selectedCartItemIndex + 1);
        }

        if (isDeletedItem) {
            this.isDeletedItem(isKeyDown);
        }
    }

    /**
     * Method to set focus and select values in input
     *
     * @memberof BomSearchComponent
     */
    private selectInput(previousIndex: number): boolean {
        const inputElement = this.getNativeElement(this.selectedCartItemIndex);
        if (inputElement?.nativeElement) {
            inputElement.nativeElement.focus();
            inputElement.nativeElement.select();
        } else {
            const previousInputElement = this.getNativeElement(previousIndex);
            if (previousInputElement && previousInputElement.nativeElement) {
                previousInputElement.nativeElement.blur();
            }
            // eslint-disable-next-line id-length
            const currentCartItem = this.cartListItems.find((_, index) => index === this.selectedCartItemIndex);
            if (currentCartItem) {
                currentCartItem.nativeElement.focus();
                return currentCartItem.nativeElement.className.includes("hide-list");
            }
        }
        return false;
    }

    /**
     * Method to get native element
     *
     * @private
     * @param {number} index
     * @return {*}  {ElementRef}
     * @memberof BomSearchComponent
     */
    private getNativeElement(index: number): ElementRef {
        return this.cartListInputs.find((input) => input.nativeElement.id - 1 === index);
    }

    /**
     * Method to selectCartItem
     *
     * @memberof BomSearchComponent
     */
    public onSelectCartItem(index: number, cart: CartItemModel): void {
        const previousIndex = cloneDeep(this.selectedCartItemIndex);
        this.selectedCartItemIndex = index;
        this.selectInput(previousIndex);
        this.selectedMiniEditorInst = cart?.SUBType === BOM_TYPE.INSTRUCTION ? cart?.Instruction : EMPTY;
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.CLICK, MatomoLabel.ON_SELECT_CART_ITEM);
    }

    /**
     * Method to get column layout on clicking expand/collapse icon
     *
     * @memberof BomSearchComponent
     */
    public onClickExpandCollapse(): void {
        this.expandProductSidebar = !this.expandProductSidebar;
        if (this.data.type === this.searchType.ipcView || this.data.type === this.searchType.pickIpc) {
            this.currentListItem = this.bomMenuList.BOM_LAYOUT;
        }
        if (this.currentListItem === this.bomMenuList.BOM_LAYOUT && this.expandProductSidebar) {
            this.layoutExpandCollapse(this.currentListItem);
        }
    }

    /**
     * Method to remove deleted item from cart list
     *
     * @return {void}
     * @memberof BomSearchComponent
     */
    public removeDeletedItem(): void {
        this.unDeletedCartItems = cloneDeep(this.cartLists);
        remove(this.unDeletedCartItems, (cartList) => cartList[IS_DELETE] === MARK_FOR_DELETE_FLAG);
        this.totalParts = ExperimentUtil.calculateTotalParts(this.unDeletedCartItems, PARTS);
    }

    /**
     * Method to trigger edition suggestion popup on clicking bulb icon
     * @param {EditionSuggestionProductRow} cartItem
     *
     * @return {void}
     * @memberof BomSearchComponent
     */
    public triggerEditSuggestPopup(cartItem: EditionSuggestionProductRow): void {
        this.miniEditorSuggestionHelper.triggerEditSuggestPopup(
            cartItem,
            this.data,
            this.selectedCartItemIndex,
            EDITION_SUGGESTION_ACTION_IN.MINI_EDITIOR,
            this.cartLists,
        );
    }

    /**
     * Method to listen suggestion changes
     *
     * @return {void}
     * @memberof BomSearchComponent
     */
    public listenSuggestionChanges(): void {
        this.cartListSubscriptions.push(
            this.appBroadCastService.editSuggestSubject.subscribe((suggestionData) => {
                const input = this.getNativeElement(this.selectedCartItemIndex);

                if (suggestionData.action === EDIT_SUGGEST_ACTIONS.REPLACE) {
                    this.cartLists.forEach((cartList) => {
                        const list = cartList;
                        if (list.ExpFormulaID === suggestionData.suggestedBom.ExpFormulaID && list.ExpFormulaID !== "") {
                            list.IsDelete = MARK_FOR_DELETE_FLAG;
                        }
                    });
                }
                let parts;
                if (suggestionData?.action === EDIT_SUGGEST_ACTIONS.ADD) {
                    parts = ZERO_WITH_DECIMAL;
                } else {
                    parts =
                        suggestionData.suggestionType === EDIT_SUGGEST_TABS.SOLUTION
                            ? EditionSuggesstionHelper.calculateParts(input?.nativeElement?.value ?? ZERO_WITH_DECIMAL, suggestionData)
                            : input?.nativeElement?.value ?? ZERO_WITH_DECIMAL;
                }
                const replacingBom = {
                    ExpFormulaID: EMPTY,
                    // eslint-disable-next-line unicorn/no-null
                    ExpID: this.data.type === this.searchType.openProductOrExperiment ? null : this.data.activeExperiment.ExpID,
                    FormulaSeq: suggestionData.suggestedBom.FormulaSeq,
                    IsDelete: MARK_FOR_UNDELETE_FLAG,
                    Parts: parts,
                    SUBCode: suggestionData.suggestionItem.SUBCode,
                    SUBType: suggestionData.suggestionItem.SUBType,
                    otherdetails: suggestionData.suggestionItem.otherdetails,
                    description: suggestionData.suggestionItem?.description,
                    Instruction: undefined,
                    Type: PRODUCT,
                    IPC: suggestionData.suggestionItem.SUBCode,
                    ExpCode: suggestionData.suggestionItem.SUBCode,
                };
                this.onAddToCart(replacingBom, suggestionData);
            }),
        );
    }

    /**
     * Method to display IPC information when IPC number is clicked
     * @param {string} ipc
     * @returns {void}
     * @memberof BomSearchComponent
     */
    public onIpcTextClick(ipc: string): void {
        this.dialogHelper.onOpenViewProductDialog(ipc);
    }

    /**
     * Method to store tab details in session
     * @returns {void}
     * @memberof BomSearchComponent
     */
    public storeTabDetails(): void {
        const currentWorkspace = this.tabHelper.getActiveTab();
        if (!currentWorkspace) return;
        currentWorkspace.SearchFilters = {
            activeTab: this.tabGroup.selectedIndex,
        };
        if (this.productSearchComp) this.productSearchComp.storeProductSearchFilters();
        if (this.instructionSearchComp) this.instructionSearchComp.storeInstructionsSearchFilter();
        if (this.unapprovedSearchComp) this.unapprovedSearchComp.storeUnApprovedSearchFilters();
        if (this.experimentSearchComp) this.experimentSearchComp.storeExperimentSearchFilter();
        this.appBroadCastService.getWorkSpaceBomSearchFromCache(this.data.ProductSearchID);
    }

    /**
     * Method to get last used width for product search column header from store
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public getSearchColumnHeaderWidth(): void {
        delay(() => {
            this.productSearchComp.getSearchColumnHeaderWidth("productSearch");
        }, 10);
    }

    /**
     * Method to trigger the keyboard shortcuts info popup
     *
     * @memberof BomSearchComponent
     */
    public keyboardShortcuts(): void {
        this.dialog.open(KeyboardShortcutsInfoComponent, COMMON_DIALOG_OLD);
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.CLICK, MatomoLabel.KEYBOARD_SHORTCUTS);
    }

    /**
     * Method to listen product category change
     *
     * @param {number} productCategoryID
     * @memberof BomSearchComponent
     */
    public listenProductCategoryChange(productCategoryID: number) {
        this.data.ProductSearchID = productCategoryID;
    }

    /**
     * Method to remove previously selected instruction
     *
     * @memberof BomSearchComponent
     */
    public removeSelectedInst(): void {
        this.selectedMiniEditorInst = EMPTY;
        this.matomoService.trackEvent(MatomoCategory.OPEN_PRODUCT, MatomoAction.CLICK, MatomoLabel.REMOVE_SELECTED_INST);
    }
}
