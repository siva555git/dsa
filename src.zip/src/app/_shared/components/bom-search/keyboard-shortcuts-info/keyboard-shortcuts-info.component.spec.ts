import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialogModule, MatDialogRef } from "@angular/material/dialog";

import { MatomoService } from "@te-services/app-common";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { EventEmitter } from "@angular/core";
import { KeyboardShortcutsInfoComponent } from "./keyboard-shortcuts-info.component";

describe("KeyboardShortcutsInfoComponent", () => {
    let component: KeyboardShortcutsInfoComponent;
    let fixture: ComponentFixture<KeyboardShortcutsInfoComponent>;
    let dialogReferenceSpy: jasmine.SpyObj<MatDialogRef<KeyboardShortcutsInfoComponent>>;

    beforeEach(waitForAsync(() => {
        dialogReferenceSpy = jasmine.createSpyObj("MatDialogRef", ["keydownEvents", "close"]);
        TestBed.configureTestingModule({
            declarations: [KeyboardShortcutsInfoComponent],
            providers: [
                { provide: MatDialogRef, useValue: dialogReferenceSpy },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
            imports: [
                MatDialogModule
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(KeyboardShortcutsInfoComponent);
        component = fixture.componentInstance;
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
    it("should close the dialog on ESCAPE keydown", () => {
        const eventEmitter = new EventEmitter<KeyboardEvent>();
        dialogReferenceSpy.keydownEvents.and.returnValue(eventEmitter.asObservable());
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
        fixture.detectChanges();
        eventEmitter.emit(new KeyboardEvent("keydown", { key: "Escape" }));
        expect(dialogReferenceSpy.close).toHaveBeenCalled();
    });
});
