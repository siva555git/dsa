import { Component, OnInit } from "@angular/core";
import { MatDialogRef } from "@angular/material/dialog";
import { KEYBOARD_KEYS } from "@te-shared/constants";
import { filter } from "rxjs/operators";
import { Subscription } from "rxjs";
import { MatomoService } from "@te-services/app-common/matomo/matomo.service";
import { MatomoCategory, MatomoAction, MatomoLabel } from "@te-shared/enums";

@Component({
    selector: "app-keyboard-shortcuts-info",
    templateUrl: "./keyboard-shortcuts-info.component.html",
})
export class KeyboardShortcutsInfoComponent implements OnInit {
    private componentSubscriptions: Subscription = new Subscription();

    constructor(
        private readonly dialogReference: MatDialogRef<KeyboardShortcutsInfoComponent>,
        private readonly matomoService: MatomoService,
    ) {}

    ngOnInit(): void {
        this.componentSubscriptions.add(
            this.dialogReference
                .keydownEvents()
                .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.dialogReference.close();
                }),
        );
        this.matomoService.trackEvent(MatomoCategory.KEYBOARD_SHORTCUTS_INFO, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    public ngOnDestroy(): void {
        this.componentSubscriptions.unsubscribe();
    }
}
