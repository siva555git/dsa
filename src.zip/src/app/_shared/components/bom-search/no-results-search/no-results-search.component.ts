import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-no-results-search",
    templateUrl: "./no-results-search.component.html",
})
export class NoResultsSearchComponent implements OnInit {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() {}

    // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
    ngOnInit(): void {}
}
