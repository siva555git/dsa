import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { PAGE_NOT_FOUND } from "../../constants/common.constant";

@Component({
    selector: "app-page-not-found",
    templateUrl: "./page-not-found.component.html",
    styleUrls: ["./page-not-found.component.scss"],
})
export class PageNotFoundComponent {
    public pageNotFoundInfo = PAGE_NOT_FOUND;

    constructor(private router: Router) {}

    /**
     * Method to redirect the page to Home Page
     * @returns {void}
     * @memberof PageNotFoundComponent
     */
    public redirectToHomePage(): void {
        this.router.navigate(["/"]);
    }
}
