/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder } from "@angular/forms";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { of, throwError } from "rxjs";
import { HttpClient, HttpHandler } from "@angular/common/http";
import { RecostProductComponent } from "./recost-product.component";
import { UserPreferencesHelper } from "../../../user-settings/user-settings-components/helper/user-perferences-helper";
import { SpaceTrimPipe } from "../../pipes/space-trim/space-trim.pipe";
import { ExperimentApiService } from "../../helpers/experiment-api.service";
import { ExperimentHelper } from "../../helpers/experiment-helper";
import { TasteEditorUtilClass } from "../../helpers/taste-editor-utils";
import { MockExperimentHelper } from "../../../testing/mock-experiment.helper";
import { MockUserPreferenceHelper } from "../../../testing/mock-user-preference-helper.spec";
import { MockDialogReference } from "../../../testing/mock-dialog.reference";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { MockToastrService } from "../../../testing/mock-toastr.service";
import { mockActiveExperiment, mockFacilities } from "../../../testing/mock-ag-grid-data";
import { mockBatchSizeData, mockDefaultUserPreference } from "../../../testing/mock-experiment-editor.helper";
import { mockPlantAndSource } from "../../../testing/mock-user-setting-data";
import { AppDataService } from "../../../_services/app-data/app.data.service";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { FORM_CONTROL_NAME, PLANT_PRODUCT_COMBINATION_ERROR } from "../../../experiment/experiment.constant";
import { BatchSizeResponse } from "../../models/create-experiment.model";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatSelectModule } from "@angular/material/select";

describe("RecostProductComponent", () => {
    let component: RecostProductComponent;
    let fixture: ComponentFixture<RecostProductComponent>;
    const dialogData = {
        dialogData: [
            {
                facilities: mockFacilities,
                activeExperiment: mockActiveExperiment,
                productTypes: [],
            },
        ],
    };

    class MockExperimentApiService {
        // eslint-disable-next-line class-methods-use-this
        public getBatchSize() {
            return of([{}]);
        }
    }

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [RecostProductComponent],
            imports: [MatAutocompleteModule,
                MatFormFieldModule,
                MatInputModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule,
                MatSelectModule
            ],
            providers: [
                UserPreferencesHelper,
                SpaceTrimPipe,
                TasteEditorUtilClass,
                { provide: MAT_DIALOG_DATA, useValue: dialogData },
                UntypedFormBuilder,
                { provide: ExperimentHelper, useClass: MockExperimentHelper },
                {
                    provide: ExperimentApiService,
                    useClass: MockExperimentApiService,
                },
                { provide: UserPreferencesHelper, useClass: MockUserPreferenceHelper },
                { provide: MatDialogRef, useClass: MockDialogReference },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                { provide: AppDataService, useClass: MockAppDataService },
                HttpClient,
                HttpHandler,
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RecostProductComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call createRecostProductForm", () => {
        const spy = spyOn(component, "createRecostProductForm").and.callThrough();
        component.createRecostProductForm();
        expect(spy).toHaveBeenCalled();
    });

    it("should call setDialogData", () => {
        component.data = {
            dialogData: [
                {
                    facilities: mockFacilities,
                    activeExperiment: mockActiveExperiment,
                    productTypes: [{ prodtypecode: undefined, PTtechnologyID: 1098 }],
                    plantsAndSources: [mockPlantAndSource],
                },
            ],
        };
        const spy = spyOn(component, "setDialogData").and.callThrough();
        component.setDialogData();
        expect(spy).toHaveBeenCalled();
    });

    it("should call getUserPreference", () => {
        const spy = spyOn(component, "getUserPreference").and.callThrough();
        component.getUserPreference();
        expect(spy).toHaveBeenCalled();
    });

    it("should call getUserPreference error", () => {
        const service = TestBed.inject(UserPreferencesHelper);
        spyOn(service, "getDefaultUserPreferences").and.returnValue(throwError(() => "Test error"));
        spyOn(component, "getUserPreference").and.callThrough();
        component.getUserPreference();
        expect(component.getUserPreference).toHaveBeenCalled();
    });

    it("should call getUserPreference on result is empty", () => {
        const service = TestBed.inject(UserPreferencesHelper);
        spyOn(service, "getDefaultUserPreferences").and.returnValue(of());
        spyOn(component, "getUserPreference").and.callThrough();
        component.getUserPreference();
        expect(component.getUserPreference).toHaveBeenCalled();
    });

    it("should call loadSourceByDefault", () => {
        const spy = spyOn(component, "loadSourceByDefault").and.callThrough();
        component.loadSourceByDefault(mockDefaultUserPreference);
        expect(spy).toHaveBeenCalled();
    });

    it("should call loadSourceByDefault with default plant", () => {
        component.plantsAndSources = [mockPlantAndSource];
        component.plantsAndSources[0].plantCode = "BAFL";
        const spy = spyOn(component, "loadSourceByDefault").and.callThrough();
        component.loadSourceByDefault(mockDefaultUserPreference);
        expect(spy).toHaveBeenCalled();
    });

    it("should call loadSourceByDefault with no default plant", () => {
        component.plantsAndSources = [mockPlantAndSource];
        component.plantsAndSources[0].plantCode = "SBFL";
        const spy = spyOn(component, "loadSourceByDefault").and.callThrough();
        component.loadSourceByDefault(mockDefaultUserPreference);
        expect(spy).toHaveBeenCalled();
    });

    it("should call getBatchSize", () => {
        const spy = spyOn(component, "getBatchSize").and.callThrough();
        component.getBatchSize(mockBatchSizeData);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onRecost", () => {
        component.selectedPlant = mockPlantAndSource;
        const spy = spyOn(component, "onRecost").and.callThrough();
        component.onRecost();
        expect(spy).toHaveBeenCalled();
    });

    it("should call onRecost if batchSize is less than zero", () => {
        component.recostProductForm.get(FORM_CONTROL_NAME.BATCH_SIZE).patchValue(-1);
        spyOn(component, "onRecost").and.callThrough();
        const response = component.onRecost();
        expect(response).toBeFalsy();
    });

    it("should call onRecost if batchSize is greater than zero", () => {
        component.selectedPlant = mockPlantAndSource;
        component.recostProductForm.get(FORM_CONTROL_NAME.BATCH_SIZE).patchValue(10);
        const spy = spyOn(component, "onRecost").and.callThrough();
        component.onRecost();
        expect(spy).toHaveBeenCalled();
    });

    it("should call loadBatchSizeByPlant", () => {
        const spy = spyOn(component, "loadBatchSizeByPlant").and.callThrough();
        component.loadBatchSizeByPlant(mockPlantAndSource);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getBatchSize which no default values", () => {
        const batchSizePayload = { plant: "0938", technologyid: 620 };
        const mockData = { batch: 1000, facilitycode: "0938", isdefault: false, isminimum: false };
        const service = TestBed.inject(ExperimentApiService);
        spyOn(service, "getBatchSize").and.returnValue(of([mockData as BatchSizeResponse]));
        spyOn(component, "getBatchSize").and.callThrough();
        component.getBatchSize(batchSizePayload);
        expect(component.recostProductForm.value.BatchSize).toEqual("");
    });

    it("should call on getBatchSize with default values", () => {
        const batchSizePayload = { plant: "0938", technologyid: 620 };
        const mockData = { batch: 1000, facilitycode: "0938", isdefault: true, isminimum: false };
        const service = TestBed.inject(ExperimentApiService);
        spyOn(service, "getBatchSize").and.returnValue(of([mockData as BatchSizeResponse]));
        spyOn(component, "getBatchSize").and.callThrough();
        component.getBatchSize(batchSizePayload);
        expect(component.recostProductForm.value.BatchSize).toEqual(1000);
    });

    it("should call on getBatchSize with batch size response is empty", () => {
        const batchSizePayload = { plant: "0938", technologyid: 620 };
        const service = TestBed.inject(ExperimentApiService);
        spyOn(service, "getBatchSize").and.returnValue(of([]));
        spyOn(component, "getBatchSize").and.callThrough();
        component.getBatchSize(batchSizePayload);
        expect(component.batchSizeError).toEqual(PLANT_PRODUCT_COMBINATION_ERROR);
    });

    it("should call on getBatchSize", () => {
        const batchSizePayload = { plant: "0938", technologyid: 620 };
        spyOn(component, "getBatchSize").and.callThrough();
        component.getBatchSize(batchSizePayload);
        expect(component.recostProductForm.value.BatchSize).toEqual("");
    });

    it("should call on getBatchSize error", () => {
        const batchSizePayload = { plant: "0938", technologyid: 620 };
        const service = TestBed.inject(ExperimentApiService);
        spyOn(service, "getBatchSize").and.returnValue(throwError(() => "Test error"));
        spyOn(component, "getBatchSize").and.callThrough();
        component.getBatchSize(batchSizePayload);
        expect(component.getBatchSize).toHaveBeenCalled();
    });
});
