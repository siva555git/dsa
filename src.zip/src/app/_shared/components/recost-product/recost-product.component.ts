/* eslint-disable lines-between-class-members */
import { Component, Inject, OnDestroy, OnInit } from "@angular/core";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { NGXLogger } from "ngx-logger";
import { Subscription } from "rxjs";
import { find } from "lodash";
import { filter } from "rxjs/operators";
import { KEYBOARD_KEYS, USERPREFERENCE_DEFAULT_PLANT_CODE } from "../../constants/common.constant";
import { ExperimentApiService } from "../../helpers/experiment-api.service";
import { ExperimentHelper } from "../../helpers/experiment-helper";
import { TasteEditorUtilClass } from "../../helpers/taste-editor-utils";
import { ExperimentsModel } from "../../models/experiment-bom.model";
import { UserPreferenceModel } from "../../models/experiments.model";
import { SpaceTrimPipe } from "../../pipes/space-trim/space-trim.pipe";
import { UserPreferencesHelper } from "../../../user-settings/user-settings-components/helper/user-perferences-helper";
import { PlantAndSourceModel } from "../../models/plant-and-source.model";
import { FacilitiesModel } from "../../models/facilities-model";
import { BatchSizePayload, BatchSizeResponse } from "../../models/create-experiment.model";
import { ProductTypesModel } from "../../models/product-types.model";
import {
    BATCHSIZE_VALIDATION,
    BATCH_SIZE_VALIDATION,
    FORM_CONTROL_NAME,
    NO_PLANT_ALLOCATION_MSG,
    PLANT_PRODUCT_COMBINATION_ERROR,
    RECOST_PRODUCT,
} from "../../../experiment/experiment.constant";
import { AppDataService } from "../../../_services/app-data/app.data.service";

@Component({
    selector: "app-recost-product",
    templateUrl: "./recost-product.component.html",
})
export class RecostProductComponent implements OnInit, OnDestroy {
    public title: string;
    public cancelText: string;
    public confirmText: string;
    public plantsAndSources: PlantAndSourceModel[];
    public facilities: FacilitiesModel[];
    public recostProductForm: UntypedFormGroup = new UntypedFormGroup({});
    public filteredPlants: PlantAndSourceModel[];
    public batchSizeData: BatchSizeResponse[];
    public selectedPlant: PlantAndSourceModel;
    public defaultPlant: PlantAndSourceModel;
    public recostSubscriptions: Subscription[] = [];
    public activeExperiment: ExperimentsModel;
    public productTypeID: number;
    public productTypes: ProductTypesModel[];
    public batchSizeError: string;
    public emptyPlantValidation: string;
    public inInValidBatchSizeMsg = BATCHSIZE_VALIDATION;

    constructor(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        @Inject(MAT_DIALOG_DATA) public data: any,
        public formBuilder: UntypedFormBuilder,
        public spaceTrim: SpaceTrimPipe,
        public experimentHelper: ExperimentHelper,
        private experimentApiService: ExperimentApiService,
        private userPreferencesHelper: UserPreferencesHelper,
        private readonly dialogReference: MatDialogRef<RecostProductComponent>,
        private readonly logger: NGXLogger,
        private appDataService: AppDataService,
    ) {}

    ngOnInit(): void {
        this.recostProductForm = this.createRecostProductForm();
        this.setDialogData();
        this.dialogReference
            .keydownEvents()
            .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
            .subscribe(() => {
                this.dialogReference.close();
            });
    }

    public ngOnDestroy(): void {
        // to un subscribe all the subscriptions done in this component
        TasteEditorUtilClass.removeSubscriptions(this.recostSubscriptions);
    }

    /**
     * Method to create the scale parts form
     * @memberof RecostProductComponent
     */
    public createRecostProductForm = (): UntypedFormGroup => {
        return this.formBuilder.group({
            PlantID: new UntypedFormControl("", [Validators.required]),
            BatchSize: new UntypedFormControl("", [Validators.required, this.experimentHelper.batchSizeValidation]),
        });
    };

    /**
     * Method to set the dialog data to populate to the view with title, button texts and the experiment lists
     * @returns {void}
     * @memberof RecostProductComponent
     */
    setDialogData(): void {
        this.title = this.data.title;
        this.cancelText = this.data.cancelText;
        this.confirmText = this.data.confirmText;
        this.facilities = this.data.dialogData[0].facilities;
        this.activeExperiment = this.data.dialogData[0].activeExperiment;
        this.productTypes = this.data.dialogData[0].productTypes;
        this.plantsAndSources = this.experimentHelper.filterFacilityForPlants(this.data.dialogData[0].plantsAndSources, this.facilities);
        if (this.plantsAndSources.length > 0) {
            this.filteredPlants = TasteEditorUtilClass.getUniqueListBy(this.plantsAndSources, FORM_CONTROL_NAME.PLANT);
            this.getUserPreference();
        } else {
            this.emptyPlantValidation = `${NO_PLANT_ALLOCATION_MSG.replace(
                "<<functionName>>",
                RECOST_PRODUCT,
            )} ${this.appDataService.getUserId()}`;
        }
        this.productTypeID = this.productTypes.find(
            (productType) => productType.prodtypecode === this.activeExperiment.ProductTypeID,
        )?.PTtechnologyID;
    }

    /**
     * Method to get the user preferences
     * @returns {void}
     * @memberof RecostProductComponent
     */
    public getUserPreference(): void {
        this.recostSubscriptions.push(
            this.userPreferencesHelper.getDefaultUserPreferences().subscribe({
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                next: (result: any) => {
                    if (result) {
                        this.loadSourceByDefault(result);
                    }
                },
                error: (error) => {
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to load source based on user pref plant value
     * @param {UserPreferenceModel[]} result
     * @returns {void}
     * @memberof RecostProductComponent
     */
    public loadSourceByDefault(result: UserPreferenceModel[]): void {
        const defaultPlant = find(result, (userPref) => {
            return userPref.ReferenceUserPreferenceType?.PrefTypeCode === USERPREFERENCE_DEFAULT_PLANT_CODE;
        });
        this.defaultPlant = find(this.plantsAndSources, (plant) => plant.plantCode === defaultPlant?.ColumnValue);
        this.recostProductForm.patchValue({
            // eslint-disable-next-line unicorn/no-null
            PlantID: this.defaultPlant ?? null,
        });
        if (this.defaultPlant) {
            const batchDetails = {
                plant: this.defaultPlant?.PlantID,
                technologyid: this.productTypeID,
            };
            this.getBatchSize(batchDetails);
        }
    }

    /**
     * Method to load batch size based on user pref plant value and product's product type
     * @param {BatchSizePayload} batchDetails
     * @returns {void}
     * @memberof RecostProductComponent
     */
    public getBatchSize(batchDetails: BatchSizePayload): void {
        this.recostSubscriptions.push(
            this.experimentApiService.getBatchSize(batchDetails).subscribe({
                next: (response) => {
                    this.batchSizeError = "";
                    this.batchSizeData = response;
                    const defaultBatchSize = find(this.batchSizeData, (batch) => {
                        return batch.isdefault;
                    });
                    if (defaultBatchSize?.batch) {
                        // eslint-disable-next-line unicorn/no-null
                        this.recostProductForm.patchValue({ BatchSize: defaultBatchSize.batch ?? null });
                    }
                    if (this.batchSizeData.length === 0) {
                        this.batchSizeError = PLANT_PRODUCT_COMBINATION_ERROR;
                    }
                },
                error: (error) => {
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to create payload for recost product
     * @returns {void}
     * @memberof RecostProductComponent
     */
    public onRecost(): void {
        const batchSize = this.recostProductForm.get(FORM_CONTROL_NAME.BATCH_SIZE).value;
        if (batchSize > 0) {
            const recostPayload = {
                PlantID: this.selectedPlant?.plantCode ?? this.defaultPlant?.plantCode,
                BatchSize: this.recostProductForm.get(FORM_CONTROL_NAME.BATCH_SIZE).value,
            };
            this.dialogReference.close(recostPayload);
        } else {
            this.batchSizeError = BATCH_SIZE_VALIDATION;
        }
    }

    /**
     * Method to load batch size by selected plant
     * @memberof RecostProductComponent
     */
    public loadBatchSizeByPlant(selectedPlant: PlantAndSourceModel): void {
        this.selectedPlant = selectedPlant;
        const batchDetails = {
            plant: this.selectedPlant.PlantID,
            technologyid: this.productTypeID,
        };
        // eslint-disable-next-line unicorn/no-null
        this.recostProductForm.patchValue({ BatchSize: null });
        this.getBatchSize(batchDetails);
    }
}
