import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";

@Component({
    selector: "app-notification-audio",
    templateUrl: "./notification-audio.component.html",
})
export class NotificationAudioComponent implements OnInit {
    @ViewChild("audioOption") audioPlayerRef: ElementRef;

    constructor(public appBroadCastService: AppBroadCastService) {}

    public ngOnInit(): void {
        this.listenSubscriptions();
    }

    /**
     * Method to listen events
     *
     * @memberof NotificationDrawerComponent
     */
    public listenSubscriptions(): void {
        this.appBroadCastService.pushNotificationToneSubject.subscribe(() => {
            this.onAudioPlay();
        });
    }

    /**
     * Method to play the notification audio from view
     * @memberof NotificationAudioComponent
     */
    onAudioPlay(): void {
        this.audioPlayerRef.nativeElement.play();
    }
}
