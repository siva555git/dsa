import { ElementRef } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { MockElementRef as MockElementReference } from "../../../testing/mock-elementRef.service";
import { NotificationAudioComponent } from "./notification-audio.component";

describe("NotificationAudioComponent", () => {
    let component: NotificationAudioComponent;
    let fixture: ComponentFixture<NotificationAudioComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [NotificationAudioComponent],
            providers: [AppBroadCastService, { provide: ElementRef, useClass: MockElementReference }],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NotificationAudioComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call listenSubscriptions", () => {
        const spy = spyOn(component, "listenSubscriptions").and.callThrough();
        component.listenSubscriptions();
        expect(spy).toHaveBeenCalled();
    });

    it("should call onAudioPlay", () => {
        component.audioPlayerRef = {
            nativeElement: {
                // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
                play: () => {},
            },
        };
        const spy = spyOn(component, "onAudioPlay").and.callThrough();
        component.onAudioPlay();
        expect(spy).toHaveBeenCalled();
    });
});
