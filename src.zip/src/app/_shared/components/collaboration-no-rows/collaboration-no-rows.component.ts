import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
    selector: "app-collaboration-no-rows",
    templateUrl: "./collaboration-no-rows.component.html",
})
export class CollaborationNoRowsComponent {
    @Input() noGroupFound: boolean;

    @Input() noExpFound: boolean;

    @Input() isLandingPage: boolean;

    @Output() public onCreateClick = new EventEmitter();

    /**
     * Method to open create collaboration drawer
     * @memberof CollaborationNoRowsComponent
     */
    public onOpenCreateCollaborationgroupDrawer(): void {
        this.onCreateClick.emit();
    }
}
