import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";

import { CollaborationNoRowsComponent } from "./collaboration-no-rows.component";

describe("CollaborationNoRowsComponent", () => {
    let component: CollaborationNoRowsComponent;
    let fixture: ComponentFixture<CollaborationNoRowsComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CollaborationNoRowsComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CollaborationNoRowsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should emit on create collaboration drawer", () => {
        spyOn(component.onCreateClick, "emit");
        component.onOpenCreateCollaborationgroupDrawer();
        expect(component.onCreateClick.emit).toHaveBeenCalled();
    });
});
