import { Component, Input } from "@angular/core";
import { AppDataService } from "../../../_services";
import { UserProfileModel } from "../../master-data/models/profile-picture.model";

@Component({
    selector: "app-profile-picture",
    templateUrl: "./profile-picture.component.html",
})
export class ProfilePictureComponent {
    public userDetails: UserProfileModel;

    @Input() public picWidth: number;

    @Input() public picHeigth: number;

    @Input() public displayName: boolean;

    @Input() public isdisplayDetail: boolean;

    @Input() public restrictedUserDetails: boolean;

    constructor(public appDataService: AppDataService) {}

    @Input() set userProfile(profile: UserProfileModel) {
        const user = profile;
        if (profile) {
            const globalUserId = profile.globalUserId || profile.GlobalUserID || profile.globalUserID || profile.globaluserid;
            if (!profile.photoUrl && globalUserId) {
                user.photoUrl = this.appDataService.getImageUrl(this.appDataService.url.userPhoto, [globalUserId]);
            }
        }
        this.userDetails = user;
    }
}
