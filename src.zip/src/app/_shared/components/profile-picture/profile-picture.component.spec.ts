/* eslint-disable   no-use-before-define */

import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { Component, ViewChild, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { ProfilePictureComponent } from "./profile-picture.component";
// import { SecureImagePipe } from '../../pipes';
import { mockPipe } from "../../../testing/mock-secure-image.pipe";
// import { By } from '@angular/platform-browser';

describe("ProfilePictureComponent", () => {
    let component: ProfilePictureHostComponent;
    let fixture: ComponentFixture<ProfilePictureHostComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ProfilePictureHostComponent, mockPipe({ name: "secureImage" })],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            providers:[
                { provide: AppDataService, useClass: MockAppDataService }]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ProfilePictureHostComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    // it("should reflect input from host component", () => {
    //     // expect(profilePicture).not.toBeNull();
    //     const profilePicture = fixture.debugElement.children[0].componentInstance;
    //     // component.profilePictureComponent.userProfile = userProfileInfo;
    //     fixture.detectChanges();
    //     const profilePicture1 = fixture.debugElement.query(By.directive(ProfilePictureComponent));
    //     const imageElt = fixture.debugElement.query(By.css("img"));
    //     // expect(component.profilePictureComponent.userProfile.name).toBe(component.userProfileInfo.name);
    //     expect(imageElt).toBeTruthy();
    // });
});

@Component({
    selector: "profile-picture-host",
    template: '<app-profile-picture [userProfile]="userProfileInfo"></app-profile-picture>',
})
class ProfilePictureHostComponent {
    userProfileInfo = {
        name: "Test User",
        photoUrl: "assets/images/axb1234/photo.png",
    };

    @ViewChild(ProfilePictureComponent)
    public profilePictureComponent!: ProfilePictureComponent;
}

import {  AppDataService } from "../../../_services/index";
import { MockAppDataService } from "@te-testing/mock-app.data.service";
import { SecureImagePipe } from "@te-shared/pipes";
import { HttpClientTestingModule } from "@angular/common/http/testing";

describe("ProfilePictureComponent", () => {
    let component: ProfilePictureComponent;
    let fixture: ComponentFixture<ProfilePictureComponent>;
        let appDataService : AppDataService;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            declarations: [ProfilePictureComponent,SecureImagePipe],
            providers: [              
                { provide: AppDataService, useClass: MockAppDataService },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(ProfilePictureComponent);
        component = fixture.componentInstance;
        appDataService = TestBed.inject(AppDataService);
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should set the userProfile", () => {
      const userProfileInfo = {
            name: "Test User",
            photoUrl: "assets/images/axb1234/photo.png",
        };
        component.userProfile = userProfileInfo;
        expect(component.userDetails.name).toEqual(userProfileInfo.name);
        expect(component.userDetails.photoUrl).toEqual(userProfileInfo.photoUrl);
    });
});
