import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ExperimentEditorComponent } from "@te-experiment-editor/experiment-editor.component";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import {
    FLASHPOINT_ERROR,
    FLASHPOINT_MESSAGE,
    FLASHPOINT_SUCCESS,
    HEAT_UNIT,
    KEYBOARD_KEYS,
    NO_DATA_FOR_TEMPERATURE,
    USER_PREFERENCES_TYPES,
} from "@te-shared/constants";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { ExperimentsModel, FlashPointPrediction } from "@te-shared/models/experiment-bom.model";
import { FMPDialogData } from "@te-shared/models/experiments.model";
import { filter } from "rxjs/operators";
import { NGXLogger } from "ngx-logger";
import { Subscription } from "rxjs";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { EMPTY, LOADING } from "../../../app.constant";

@Component({
    selector: "app-flash-point",
    templateUrl: "./flash-point.component.html",
})
export class FlashPointComponent implements OnInit {
    public activeExperiment: ExperimentsModel;

    public defaultFlashPoint: string;

    public temperature: string;

    public isFlammable: boolean;

    public isPredictionFetchSuccess: boolean;

    public displayError: string;

    public confidenceScore: string;

    public ipcList: Array<{ ipc: string; description: string }>;

    public flashPointMessages = FLASHPOINT_MESSAGE;

    public celsius = HEAT_UNIT.Celcius;

    private subscriptionList: Subscription[] = [];

    constructor(
        private readonly dialogReference: MatDialogRef<ExperimentEditorComponent>,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly logger: NGXLogger,
        private readonly experimentHelper: ExperimentHelper,
        @Inject(MAT_DIALOG_DATA) public data: FMPDialogData,
    ) {}

    ngOnInit(): void {
        this.activeExperiment = this.data?.experiment;
        this.subscriptionList.push(
            this.dialogReference
                .keydownEvents()
                .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.dialogReference.close();
                }),
        );
        this.fetchingFlashPointPrediction();
    }

    ngOnDestroy(): void {
        TasteEditorUtilClass.removeSubscriptions(this.subscriptionList);
    }

    /**
     * Method to get the default the flash point type
     *
     * @return {*}  {string}
     * @memberof FlashPointComponent
     */
    public getDefaultFlashPoint(): string {
        const userDefaultPreference = AppStateService.getUserDefaultPreferenceType();
        return userDefaultPreference?.find((userSetting) => userSetting.PrefTypeCode === USER_PREFERENCES_TYPES.FLASHPOINT_CODE)
            ?.ColumnValue;
    }

    /**
     * Method to update the farenheit or celcius values
     *
     * @param {FlashPointPrediction[]} response
     * @memberof FlashPointComponent
     */
    public onShowingPredictionTemperature(response: FlashPointPrediction[]): void {
        this.defaultFlashPoint = this.getDefaultFlashPoint();
        this.temperature = NO_DATA_FOR_TEMPERATURE;
        const temperature = response[0]?.predictedFlashpoint?.split("/");
        if (temperature?.length > 0) {
            const [celsius, farenheat] = temperature;
            const celiusValue = celsius.trim().split(" ")[0];
            this.isFlammable = Number(celiusValue) < 100;
            if (this.defaultFlashPoint && this.defaultFlashPoint === HEAT_UNIT.Farenheit) {
                // eslint-disable-next-line prefer-destructuring
                this.temperature = farenheat.trim().split(" ")[0];
            } else {
                this.temperature = celiusValue;
                this.defaultFlashPoint = this.defaultFlashPoint ?? this.celsius;
            }
        }
    }

    /**
     * Method to fetch the max predication value
     *
     * @return {*}
     * @memberof FmpReviewComponent
     */
        public fetchingFlashPointPrediction() {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        const payload = { ExpCode: this.activeExperiment?.ExpCode };
        this.ipcList = [];
        this.displayError = EMPTY;
        this.subscriptionList.push(
            this.experimentHelper.getFlashPointPrediction(payload).subscribe({
                next: (response) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (response && response?.status && response?.status === FLASHPOINT_SUCCESS) {
                        if (response?.flashpointData && response?.flashpointData.length > 0) {
                            this.isPredictionFetchSuccess = true;
                            this.confidenceScore = response.flashpointData[0]?.confidenceScore;
                            this.onShowingPredictionTemperature(response?.flashpointData);
                        } else {
                            this.isPredictionFetchSuccess = false;
                            this.displayError =
                                response?.flashpointData && response?.flashpointData?.length === 0
                                    ? this.flashPointMessages.unpredictabale
                                    : this.flashPointMessages.ErrorMessage;
                        }
                    } else if (response && response.status && response?.status === FLASHPOINT_ERROR) {
                        this.isPredictionFetchSuccess = false;
                        this.displayError = this.flashPointMessages.ErrorMessage;
                    }

                    if (response && response?.ipcWithNoChemical && response?.ipcWithNoChemical.length > 0) {
                        this.ipcList = response?.ipcWithNoChemical;
                    }
                },
                error: (error) => {
                    this.isPredictionFetchSuccess = false;
                    this.displayError = this.flashPointMessages.ErrorMessage;
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            }),
        );
    }
}
