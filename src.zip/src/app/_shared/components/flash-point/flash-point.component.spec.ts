import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { cloneDeep } from "lodash";
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule, MatDialogRef } from "@angular/material/dialog";
import { MockDialogReference } from "@te-testing/mock-dialog.reference";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { NGXLogger } from "ngx-logger";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { ToastrService } from "ngx-toastr";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { AppDataService } from "@te-services/app-data/app.data.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { AppStateService } from "@te-services/index";
import { OAuthService } from "angular-oauth2-oidc";
import { MockOAuthService } from "@te-testing/mock-oauth.service";
import { DialogHelper } from "@te-shared/helpers/dialog-helper";
import { of } from "rxjs";
import { CreativeReviewHelper } from "src/app/creative-review/helpers/creative-review-helper";
import { MockCreativereview } from "@te-testing/mock-creativereview-helper";
import { ExperimentApiService } from "@te-shared/helpers/experiment-api.service";
import { FlashPointComponent } from "./flash-point.component";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";

// eslint-disable-next-line max-lines-per-function
describe("FlashPointComponent", () => {
    let component: FlashPointComponent;
    let fixture: ComponentFixture<FlashPointComponent>;
    const mockBomDetail = {
        BatchSize: undefined,
        CountryCode: undefined,
        CreatedBy: 47_442,
        CreatedOn: new Date("2022-02-05T09:49:23.000Z"),
        ExpCode: "AXA00002AA",
        ExpID: 12_348_048,
        ExpName: undefined,
        Yield: 544_656,
        ExperimentFormula: [
            {
                CreatedBy: 47_442,
                ExpFormulaID: "50481",
                ExpID: 12_348_048,
                FormulaSeq: 40,
                Instruction: undefined,
                IsDelete: 0,
                Parts: 1,
                SUBCode: "00010000",
                SUBType: "I",
            },
            {
                CreatedBy: 47_442,
                ExpFormulaID: "50487",
                ExpID: 12_348_048,
                FormulaSeq: 100,
                Instruction: undefined,
                IsDelete: 0,
                Parts: 2,
                SUBCode: "00010339",
                SUBType: "I",
            },
            {
                CreatedBy: 47_552,
                ExpFormulaID: "50488",
                ExpID: 12_348_048,
                FormulaSeq: 60,
                Instruction: undefined,
                IsDelete: 0,
                Parts: 2,
                SUBCode: "00020000",
                SUBType: "I",
            },
        ],
        ExperimentStaff: [],
        IPC: undefined,
        IsArchived: "0",
        IsDeleted: "0",
        IsLocked: "0",
        IsPublic: false,
        Level: 0,
        LockedBy: undefined,
        ProductTypeID: undefined,
        BOMType: "E",
        Type: "Experiment",
        UpdatedBy: 123,
        UpdatedOn: new Date("2022-02-10T08:43:29.791Z"),
        UoMID: 1234,
        MappedFolderID: 5656,
    };

    const mockDialogData = {
        experiment: {
            ExpID: 63_482_130,
            ExpCode: "SXT51265AA",
            ExpName: "Flashpoint",
            ProductTypeID: "AGGLOMERATES",
            CountryCode: "",
            IPC: null,
            TaskID: null,
            SourceFlagCodeID: "SOURCE FA GB MANNINGTREE",
            PlantID: "HHFL",
            Yield: 100,
            BatchSize: 500,
            UoMID: 1,
            UseLevel: null,
            ExpSource: "S",
            IsLocked: "0",
            LockedBy: null,
            LockedOn: null,
            IsArchived: "0",
            ArchivedOn: null,
            IsDeleted: "0",
            IsPublic: true,
            DeletedOn: null,
            CreatedBy: 47_442,
            Trustee: 47_442,
            UpdatedBy: 47_442,
            Comment: "test for comments",
            CreatedOn: "2024-01-23T06:26:09.852Z",
            UpdatedOn: "2024-01-29T06:54:56.208Z",
            Type: "Experiment",
            ExperimentTaste: [],
            ExperimentCost: null,
            ExperimentVariant: null,
            ExperimentNote: [],
            ExperimentStaffDetails: [],
            IsOtherExp: false,
            IsAppliedNaturalOrder: true,
            IsViewindicator: false,
            isSort: true,
        },
    };

    const mockResponse = {
        status: "success",
        ipcWithNoChemical: [
            {
                description: "LACTIC ACID USP 88/92",
                isbom: true,
                ipc: "00120162",
            },
            {
                description: "H2O DEMINERALIZED WATER",
                isbom: true,
                ipc: "00230200",
            },
            {
                description: "H2O TAP WATER",
                isbom: true,
                ipc: "00230195",
            },
            {
                description: "ETH ALC TAX PAID 95 PCT",
                isbom: true,
                ipc: "00058604",
            },
            {
                description: "ETH BUTY",
                isbom: true,
                ipc: "00058803",
            },
            {
                description: "VALERIAN F.E. NF VIII 61-68% ETOH",
                isbom: true,
                ipc: "00220315",
            },
        ],
        ipcs: ["00220315", "00058803", "00058604", "00230195", "00230200", "00120162"],
        flashpointData: [
            {
                formula: "0G00001037AA",
                predictedFlashpoint: "115 C/ 239 F",
                heatmapImage: "0G00001037AA.png",
                confidenceScore: "99.0%",
            },
        ],
    };

    const dialogReferenceStub = {
        afterClosed() {
            return of(); // this can be whatever, esp handy if you actually care about the value returned
        },
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [FlashPointComponent],
            imports: [HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
                AppBroadCastService,
                ExperimentHelper,
                AppDataService,
                SecurityHelper,
                AppStateService,
                DialogHelper,
                ExperimentApiService,
                {
                    provide: CreativeReviewHelper,
                    useClass: MockCreativereview,
                },
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
                { provide: MAT_DIALOG_DATA, useValue: mockDialogData },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: NGXLogger, useClass: MockLoggerService },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(FlashPointComponent);
        component = fixture.componentInstance;
        const mockExp = cloneDeep(mockBomDetail);
        mockExp.CreatedOn = new Date();
        component.activeExperiment = mockExp;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("expect ngOnInit to be called", () => {
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    it("expect getDefaultFlashPoint to be called", () => {
        const spy = spyOn(component, "getDefaultFlashPoint").and.callThrough();
        component.getDefaultFlashPoint();
        expect(spy).toHaveBeenCalled();
    });

    it("expect updateTemperature to be called", () => {
        spyOn(AppStateService, "getUserDefaultPreferenceType").and.returnValue([
            {
                ColumnValue: "C",
                PrefTypeCode: "DefaultFlashPoint",
                UserID: 47_442,
                UserPrefID: 3094,
                UserPrefTypeID: 23,
            },
        ]);
        const spy = spyOn(component, "onShowingPredictionTemperature").and.callThrough();
        component.onShowingPredictionTemperature([
            {
                formula: "0G00001037AA",
                predictedFlashpoint: "115 C/ 239 F",
                heatmapImage: "0G00001037AA.png",
                confidenceScore: "99.0%"
            },
        ]);
        expect(spy).toHaveBeenCalled();
    });

    it("expect fetchingFlashPointPrediction to be called", () => {
        const experimentHelper = TestBed.inject(ExperimentHelper);
        spyOn(experimentHelper, "getFlashPointPrediction").and.returnValue(of(mockResponse));
        const spy = spyOn(component, "fetchingFlashPointPrediction").and.callThrough();
        component.fetchingFlashPointPrediction();
        expect(spy).toHaveBeenCalled();
    });
});
