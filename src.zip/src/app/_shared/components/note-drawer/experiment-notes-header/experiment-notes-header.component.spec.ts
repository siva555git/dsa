/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from "@angular/core";
import { NotesFilterPipe } from "../../../pipes/notes-filter/notes-filter.pipe";
import { mockExperimentNoteList } from "../../../../testing/mock-ag-grid-data";
import { MockNotesHelper } from "../../../../testing/mock-notes-helper";
import { NotesHelper } from "../../../helpers/notes.helper";
import { ExperimentNotesHeaderComponent } from "./experiment-notes-header.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatSelectModule } from "@angular/material/select";

describe("ExperimentNotesHeaderComponent", () => {
    let component: ExperimentNotesHeaderComponent;
    let fixture: ComponentFixture<ExperimentNotesHeaderComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ExperimentNotesHeaderComponent],
            providers: [
                NotesFilterPipe,
                {
                    provide: NotesHelper,
                    useClass: MockNotesHelper,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule,
                MatFormFieldModule,
                MatInputModule,
                MatSelectModule
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExperimentNotesHeaderComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for onCancelDrawer", () => {
        const spy = spyOn(component, "onCancelDrawer").and.callThrough();
        component.experimentNotes = mockExperimentNoteList;
        component.dateRangByDefault = "last7Days";
        component.searchText = "search";
        component.onCancelDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSearchText", () => {
        const spy = spyOn(component, "onSearchText").and.callThrough();
        component.experimentNotes = mockExperimentNoteList;
        component.dateRangByDefault = "last7Days";
        component.searchText = "search";
        component.onSearchText();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onChangeDateRange", () => {
        const spy = spyOn(component, "onChangeDateRange").and.callThrough();
        component.experimentNotes = mockExperimentNoteList;
        component.dateRangByDefault = "last7Days";
        component.searchText = "search";
        component.onChangeDateRange();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onCancelDrawer when searchNote is false", () => {
        const spy = spyOn(component, "onCancelDrawer").and.callThrough();
        component.experimentNotes = mockExperimentNoteList;
        component.dateRangByDefault = "last7Days";
        component.searchText = "search";
        component.searchNote = "";
        component.onCancelDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke ngOnChanges", () => {
        const changes = {
            searchNote: {
                currentValue: true,
            },
        } as unknown as SimpleChanges;
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });
});
