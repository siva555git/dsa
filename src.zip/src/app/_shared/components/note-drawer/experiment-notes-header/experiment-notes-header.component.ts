import { Component, Input, EventEmitter, Output, HostListener, OnChanges, SimpleChanges } from "@angular/core";
import { EMPTY } from "../../../../app.constant";
import { NotesHelper } from "../../../helpers/notes.helper";
import { DATE_RANGE_DROPDOWN_NOTES } from "../../../constants/common.constant";
import { NotesFilterPipe } from "../../../pipes/notes-filter/notes-filter.pipe";
import { ClearSearchModel } from "../../../models/notes.model";

@Component({
    selector: "app-experiment-notes-header",
    templateUrl: "./experiment-notes-header.component.html",
})
export class ExperimentNotesHeaderComponent implements OnChanges {
    @Input() experimentNotes;

    @Output()
    public noteToggle = new EventEmitter();

    @Output()
    public filteredNotes = new EventEmitter();

    public searchText: string;

    public datesRangeDropDown = DATE_RANGE_DROPDOWN_NOTES;

    public dateRangByDefault = DATE_RANGE_DROPDOWN_NOTES[2].allTime;

    public listNotes;

    @Input() public experimentCode: string;

    @HostListener("document:keydown.escape", ["$event"]) onKeydownHandler(): void {
        this.onCancelDrawer();
    }

    @Input() public searchNote: string;

    constructor(private readonly notesFilterPipe: NotesFilterPipe, private notesHelper: NotesHelper) {
        this.notesHelper.clearSearchSub$.subscribe((result: ClearSearchModel) => {
            if (result.searchText || result.defaultFilterValue) {
                this.searchText = result.searchText;
                this.dateRangByDefault = result.defaultFilterValue;
            }
        });
    }

    /**
     * Method to close notes drawer
     *
     * @memberof ExperimentNotesHeaderComponent
     */
    onCancelDrawer(): void {
        if (!this.searchNote && this.searchNote === EMPTY) {
            this.searchText = EMPTY;
        }
        this.dateRangByDefault = DATE_RANGE_DROPDOWN_NOTES[2].allTime;
        this.noteToggle.emit();
    }

    /**
     * Method to filter notes results
     * @param {stirng} event
     * @returns {void}
     * @memberof ExperimentNotesHeaderComponent
     */
    public onSearchText(): void {
        this.filteredNotes.emit(this.notesFilterPipe.transform(this.experimentNotes, this.searchText, this.dateRangByDefault));
    }

    /**
     * Method to get date value from drop down
     *
     * @returns {void}
     * @memberof ExperimentNotesHeaderComponent
     */
    public onChangeDateRange(): void {
        this.filteredNotes.emit(this.notesFilterPipe.transform(this.experimentNotes, this.searchText, this.dateRangByDefault));
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes?.searchNote && changes?.searchNote?.currentValue) {
            this.searchText = changes?.searchNote?.currentValue;
            this.onSearchText();
        }
    }
}
