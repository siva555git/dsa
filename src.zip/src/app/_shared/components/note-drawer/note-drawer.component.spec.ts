/* eslint-disable dot-notation */
/* eslint-disable no-empty-function */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable max-lines-per-function */
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from "@angular/core";
import { ExperimentsModel } from "@te-shared/models/experiment-bom.model";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { BehaviorSubject } from "rxjs";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { AppDataService } from "@te-services/app-data/app.data.service";
import { HttpClient, HttpHandler } from "@angular/common/http";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { OAuthService } from "angular-oauth2-oidc";
import { ExperimentApiService } from "@te-shared/helpers/experiment-api.service";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { MatDialog } from "@angular/material/dialog";
import { MockOAuthService } from "../../../testing/mock-oauth.service";
import { NoteDrawerComponent } from "./note-drawer.component";
import { ExperimentNotesListComponent } from "./experiment-notes-list/experiment-notes-list.component";
import { NotesHelper } from "../../helpers/notes.helper";
import { MockToastrService } from "../../../testing/mock-toastr.service";
import { MockNotesHelper, notesResponse, productNotes } from "../../../testing/mock-notes-helper";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { mockExperimentNoteList } from "../../../testing/mock-ag-grid-data";

describe("NoteDrawerComponent", () => {
    let component: NoteDrawerComponent;
    let fixture: ComponentFixture<NoteDrawerComponent>;

    const childComponents = {
        clearControls: () => {},
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [NoteDrawerComponent],
            providers: [
                HttpClient,
                HttpHandler,
                AppBroadCastService,
                AppDataService,
                AppStateService,
                SecurityHelper,
                ExperimentApiService,
                ExperimentAccessHelper,
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => {}, closeAll: () => {} },
                },
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: ExperimentHelper,
                    useClass: MockExperimentHelper,
                },
                {
                    provide: NotesHelper,
                    useClass: MockNotesHelper,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NoteDrawerComponent);
        component = fixture.componentInstance;
        const activeExp = notesResponse;
        activeExp["ExperimentNote"] = productNotes;
        component.activeExperiment = activeExp as unknown as ExperimentsModel;
        fixture.detectChanges();
        component["experimentNotesList"] = childComponents as unknown as ExperimentNotesListComponent;
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on ngOnInit", () => {
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnInit with experiment type", () => {
        const expMockData = {
            ProductNote: [{ User: 1212 }],
            Type: "Experiment",
            ExpID: "12121",
        };
        const noteHelper = new MockNotesHelper();
        noteHelper.expNoteSub$ = new BehaviorSubject(expMockData);
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for ngOnChanges ", () => {
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        const changes = {
            experimentCode: {
                previousValue: 12_121,
            },
            expCreator: {
                currentValue: 1212,
            },
            expCreatedUser: {
                currentValue: 123_456,
            },
        } as unknown as SimpleChanges;
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getupdatedLimit", () => {
        const spy = spyOn(component, "getupdatedLimit").and.callThrough();
        component.getupdatedLimit(12);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on closeDrawer", () => {
        const spy = spyOn(component, "closeDrawer").and.callThrough();
        component.closeDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getExperimentNotesByExpId", () => {
        const spy = spyOn(component, "getExperimentNotesByExpId").and.callThrough();
        component.getExperimentNotesByExpId("1234");
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getFilteredNotes", () => {
        const spy = spyOn(component, "getFilteredNotes").and.callThrough();
        component.getFilteredNotes([]);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on saveUpdateNotes", () => {
        const spy = spyOn(component, "saveNotes").and.callThrough();
        const data = { noteDesc: "new save check", noteId: "17746" };
        component.experimentNotes = mockExperimentNoteList;
        component.saveNotes(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on saveNewNotes", () => {
        const spy = spyOn(component, "saveNotes").and.callThrough();
        const data = { noteDesc: "Welcome back", noteId: "" };
        component.experimentNotes = mockExperimentNoteList;
        component.saveNotes(data);
        expect(spy).toHaveBeenCalled();
    });

    xit("should call on closeDrawer", () => {
        const spy = spyOn(component, "closeDrawer").and.callThrough();
        component.closeDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getNotes", () => {
        const spy = spyOn(component, "getNotes").and.callThrough();
        component.getNotes([]);
        expect(spy).toHaveBeenCalled();
    });
});
