/* eslint-disable max-lines-per-function */
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialog } from "@angular/material/dialog";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { of } from "rxjs";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { MockAppDataService } from "@te-testing/mock-app.data.service";
import { ExperimentApiService } from "@te-shared/helpers/experiment-api.service";
import { MockExperimentApiService } from "@te-testing/mock-experiment-api.service";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";
import { mockExperimentNoteList } from "../../../../testing/mock-ag-grid-data";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { MockNotesHelper, notesResponse } from "../../../../testing/mock-notes-helper";
import { MockToastrService } from "../../../../testing/mock-toastr.service";
import { AppBroadCastService, AppDataService, AppStateService } from "../../../../_services";
import { NotesHelper } from "../../../helpers/notes.helper";
import { ExperimentNotesListComponent } from "./experiment-notes-list.component";
import { NotesResponse } from "@te-shared/models/notes.model";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatListModule } from "@angular/material/list";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

describe("ExperimentNotesListComponent", () => {
    let component: ExperimentNotesListComponent;
    let fixture: ComponentFixture<ExperimentNotesListComponent>;

    const dialogReferenceStub = {
        afterClosed() {
            return of("result"); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    const dialogStub = { open: () => dialogReferenceStub };
    // const dialogMessage = {
    //     cancelText: "Cancel",
    //     message: "Are you sure you want to delete the selected notes?",
    //     subMesssage: "This action cannot be undone",
    //     submitBtnClass: "red-button fill-button",
    //     submitText: "Delete",
    //     title: "Delete Experiment Notes",
    // };
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ExperimentNotesListComponent],
            imports: [
                MatFormFieldModule,
                MatInputModule,
                MatListModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule
            ],
            providers: [
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                ExperimentAccessHelper,
                SecurityHelper,
                {
                    provide: ExperimentHelper,
                    useClass: MockExperimentHelper,
                },
                { provide: ExperimentApiService, useClass: MockExperimentApiService },
                AppBroadCastService,
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: NotesHelper,
                    useClass: MockNotesHelper,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: MatDialog,
                    useValue: dialogStub,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExperimentNotesListComponent);
        component = fixture.componentInstance;
        component.sampId = 47_442;
        fixture.detectChanges();
    });

    it("should create", () => {
        component.sampId = 47_442;
        expect(component).toBeTruthy();
    });

    it("should resolve for ngOnChanges ", () => {
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        const changes = {
            totalCount: {
                currentValue: 3,
            },
        } as unknown as SimpleChanges;
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for saveEnteredNotes ", () => {
        const spy = spyOn(component, "saveEnteredNotes").and.callThrough();
        component.saveEnteredNotes();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for togglePublic ", () => {
        const spy = spyOn(component, "togglePublic").and.callThrough();
        component.togglePublic(mockExperimentNoteList[0]);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onDeleteNotes ", () => {
        const spy = spyOn(component, "onDeleteNotes").and.callThrough();
        const notes = notesResponse as unknown as NotesResponse
        component.onDeleteNotes(notes);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEditNotes ", () => {
        const spy = spyOn(component, "onEditNotes").and.callThrough();
        component.onEditNotes("12");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onTableScroll ", () => {
        const spy = spyOn(component, "onTableScroll").and.callThrough();
        const event = {
            target: {
                offsetHeight: 429,
                scrollHeight: 450,
                scrollLocation: 0.775_193_810_462_951_7,
            },
        };
        component.onTableScroll(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for updateIndex ", () => {
        const spy = spyOn(component, "updateIndex").and.callThrough();
        component.updateIndex();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for clearControls ", () => {
        const spy = spyOn(component, "clearControls").and.callThrough();
        component.clearControls();
        expect(spy).toHaveBeenCalled();
    });
});
