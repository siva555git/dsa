/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, EventEmitter, Output, OnInit, OnChanges, SimpleChanges, ViewChild, ElementRef } from "@angular/core";
import { ToastrService } from "ngx-toastr";
// eslint-disable-next-line import/no-unresolved
import { MatDialog } from "@angular/material/dialog";
import { delay } from "lodash";
import { ExperimentColumnHelper } from "@te-experiment-editor/helpers/experiment-column-helper";
import { NOTES_PRIVACY_UPDATE } from "../../../constants/notification.constant";
import {
    COMMON_DIALOG_OLD,
    HIGHLIGHT_TYPE,
    NOTES_CONFIRMATION_MESSAGE_PRIVATE,
    NOTES_CONFIRMATION_MESSAGE_PUBLIC,
    NOTES_PRIVACY,
    NOTES_TYPES,
    INVALID_USER,
    NO_USER_EXIST,
} from "../../../constants/common.constant";
import { ConfirmationDialogComponent } from "../../confirmation-dialog/confirmation-dialog.component";
import { AppStateService } from "../../../../_services/app-state/app.state.service";
import { AddNotes, DeletePayload, NotesObject, NotesResponse } from "../../../models/notes.model";
import { NotesHelper } from "../../../helpers/notes.helper";
import { ExperimentsModel } from "../../../models/experiment-bom.model";
import { PRODUCT } from "../../../constants/context-menu.constant";

@Component({
    selector: "app-experiment-notes-list",
    templateUrl: "./experiment-notes-list.component.html",
    styleUrls: ["./experiment-notes-list.component.scss"],
})
export class ExperimentNotesListComponent implements OnInit, OnChanges {
    @Input() public experimentNotes = [];

    @Input() public totalCount;

    @Input() public expCreater: number;

    @Output()
    public enteredNote = new EventEmitter();

    @Output()
    public deletedNotes = new EventEmitter();

    @Output()
    public updatedLimit = new EventEmitter();

    @Input("activeExperiment") activeExperiment: ExperimentsModel;

    public sampId: number;

    public notesPrivacy = NOTES_PRIVACY;

    public start = 0;

    public limit = 50;

    public end = this.limit + this.start;

    public isLoading: any;

    public applyDisable = false;

    public notes: AddNotes;

    public isEdited = false;

    public userName = INVALID_USER;

    public notesType = NOTES_TYPES;

    public noteData: NotesObject = {
        noteDesc: "",
        noteId: "",
    };

    public showDescription: boolean[] = [];

    public isOtherUserExp = false;

    public product = PRODUCT;

    public noUserExist = NO_USER_EXIST;

    @Input() public searchNote: string;

    public highlightType = HIGHLIGHT_TYPE;

    @Input() public allExperimentNotes = [];

    @ViewChild("inputnotes") inputnotes: ElementRef;

    @Input("isOpen") public isOpen: boolean;

    constructor(
        private readonly appStateService: AppStateService,
        private readonly toastrService: ToastrService,
        public readonly dialog: MatDialog,
        private readonly notesHelper: NotesHelper,
        public readonly experimentColumnHelper: ExperimentColumnHelper,
    ) {
        this.notesHelper.updateLoadingSub$.subscribe((result) => {
            this.isLoading = result;
        });
        this.notesHelper.updateLimitSub$.subscribe(() => {
            this.end = this.limit + 0;
        });
    }

    public ngOnInit(): void {
        this.sampId = Number(this.appStateService.getCurrentUserSapEmpId());
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.isOpen?.currentValue) {
            this.focusNotesField();
        }

        if (changes.totalCount !== undefined) {
            this.totalCount = changes.totalCount.currentValue;
        }
        if (changes.expCreater?.currentValue) {
            this.isOtherUserExp = this.expCreater !== Number(this.appStateService.getCurrentUserSapEmpId());
        }
        this.noteData = {
            noteDesc: "",
            noteId: "",
        };
    }

    /**
     * Method to focus the notes when opening the drawer
     *
     * @param {string} formType
     * @memberof ExperimentNotesListComponent
     */
    public focusNotesField(): void {
        delay(() => {
            this.inputnotes.nativeElement.focus();
        }, 100);
    }

    /**
     * Method to emit entered notes
     *
     * @memberof ExperimentNotesListComponent
     */
    public saveEnteredNotes(): void {
        this.enteredNote.emit(this.noteData);
        this.clearControls();
    }

    /**
     * Method to toggle the privacy update
     * @param {AddNotes} notes
     * @memberof ExperimentNotesListComponent
     */
    public togglePublic(notes: AddNotes): void {
        this.notes = notes;
        const notesToggleMessage =
            this.notes.IsPrivate === this.notesPrivacy.private ? NOTES_CONFIRMATION_MESSAGE_PUBLIC : NOTES_CONFIRMATION_MESSAGE_PRIVATE;
        this.openConfirmationDialog(this.onUpdatetoggle.bind(this), notesToggleMessage);
    }

    /**
     * Method to update privacy
     *
     * @memberof ExperimentNotesListComponent
     */
    public onUpdatetoggle(): void {
        this.notes.IsPrivate = this.notes.IsPrivate === this.notesPrivacy.private ? this.notesPrivacy.public : this.notesPrivacy.private;
        this.notesHelper.updateNotes(this.notes).subscribe({
            next: () => {
                this.toastrService.success(NOTES_PRIVACY_UPDATE.PRIVACY_UPDATE_SUCCESS);
                this.noteData = {
                    noteDesc: "",
                    noteId: "",
                };
            },
            error: (error) => {
                this.notes.IsPrivate =
                    this.notes.IsPrivate === this.notesPrivacy.private ? this.notesPrivacy.public : this.notesPrivacy.private;
                this.toastrService.error(error);
            },
        });
    }

    /**
     * Method to open dialog
     * @param {*} callBack
     * @param {*} dialogMessage
     * @memberof ExperimentNotesListComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types, @typescript-eslint/no-explicit-any
    public openConfirmationDialog(callBack: any, dialogMessage: any): void {
        const dialogOptions = COMMON_DIALOG_OLD;
        dialogOptions.data = dialogMessage;
        const dialogReference = this.dialog.open(ConfirmationDialogComponent, dialogOptions);
        dialogReference.afterClosed().subscribe((dialogResult) => {
            if (dialogResult) {
                callBack();
            }
        });
    }

    /**
     * Method to subscribe delete api call and remove deleted notes
     * @param {DeletePayload} notesId
     * @returns {void}
     * @memberof ExperimentNotesListComponent
     */
    public onDeleteNotes(expNotes: NotesResponse): void {
        const payload: DeletePayload = {
            ExpNoteId: Number(expNotes.ExpNoteID),
            ExpID: expNotes.ExpID,
        };
        this.notesHelper.deleteNotes(payload).subscribe({
            next: (result) => {
                if (payload.ExpNoteId === +this.noteData.noteId) this.clearControls();
                this.experimentNotes = this.notesHelper.getUnDeletedExprimentNotes(expNotes, this.experimentNotes);
                this.allExperimentNotes = this.notesHelper.getUnDeletedExprimentNotes(expNotes, this.allExperimentNotes);
                this.deletedNotes.emit(this.allExperimentNotes);
                this.experimentColumnHelper.handleToasterForExperimentResend(result?.iffManResponse, NOTES_PRIVACY_UPDATE.DELETE_NOTES);
            },
            error: (error) => {
                this.toastrService.error(error);
            },
        });
    }

    /**
     * Method to subscribe edit api call and bind description
     *
     * @param {string} notesId
     * @memberof ExperimentNotesListComponent
     */
    public onEditNotes(notesId: string): void {
        this.notesHelper.getExperimentNotesById(notesId).subscribe({
            next: (result) => {
                this.noteData = {
                    noteDesc: result.Description,
                    noteId: result.ExpNoteID,
                };
                this.isEdited = true;
                this.focusNotesField();
            },
            error: (error) => {
                this.toastrService.error(error);
            },
        });
    }

    /**
     * Method to invoke when scrolling the table
     *
     * @param {*} event
     * @returns {*}
     * @memberof ExperimentNotesListComponent
     */
    public onTableScroll(event: any): any {
        const tableViewHeight = event.target.offsetHeight;
        const tableScrollHeight = event.target.scrollHeight;
        const scrollLocation = event.target.scrollTop;

        // If the user has scrolled within 200px of the bottom, add more data
        const buffer = 200;
        const limit = tableScrollHeight - tableViewHeight - buffer;
        if (scrollLocation > limit && !this.isLoading && this.experimentNotes.length < this.totalCount) {
            this.notesHelper.clearSearch();
            this.isLoading = true;
            this.updateIndex();
            this.notesHelper.publishExpId(this.activeExperiment);
        }
    }

    /**
     * Method to update the count of start and limit
     *
     * @memberof ExperimentNotesListComponent
     */
    public updateIndex(): void {
        this.start = this.end;
        this.end = this.limit + this.start;
        this.updatedLimit.emit(this.end);
    }

    /**
     * Method to clear the controls on clide the drawer
     *
     * @memberof ExperimentNotesListComponent
     */
    public clearControls(): void {
        this.noteData = {
            noteDesc: "",
            noteId: "",
        };
        this.isEdited = false;
    }
}
