/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, OnChanges, EventEmitter, Output, ViewChild, SimpleChanges } from "@angular/core";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { ExperimentColumnHelper } from "@te-experiment-editor/helpers/experiment-column-helper";
import { PRODUCT } from "../../constants/context-menu.constant";
import { ExperimentsModel } from "../../models/experiment-bom.model";
import { NotesHelper } from "../../helpers/notes.helper";
import { AddNotes, NotesResponse, GetExperimentNotesByIdPayload } from "../../models/notes.model";
import { ExperimentNotesListComponent } from "./experiment-notes-list/experiment-notes-list.component";
import { ES_RESPONSE } from "../../constants";

@Component({
    selector: "app-note-drawer",
    templateUrl: "./note-drawer.component.html",
})
export class NoteDrawerComponent implements OnChanges {
    @Input() expId;

    @Input("isOpen") public isOpen: boolean;

    @Output()
    public noteDrawerToggle = new EventEmitter();

    public experimentNotes;

    public limitToScroll: any = 50;

    public offsetToScroll: any = 0;

    public totalCount = 0;

    public filteredResults;

    public expCreatedUser: number;

    @Input() experimentCode: string;

    @Input() expCreator: number;

    @ViewChild("experimentNotesList") private experimentNotesList: ExperimentNotesListComponent;

    public activeExperiment: ExperimentsModel;

    @Input() public searchNote: string;

    constructor(
        private readonly toastrService: ToastrService,
        private readonly notesHelper: NotesHelper,
        private readonly logger: NGXLogger,
        private readonly experimentColumnHelper: ExperimentColumnHelper,
    ) {}

    ngOnChanges(changes: SimpleChanges): void {
        this.notesHelper.updateLimitSub$.subscribe((result) => {
            if (changes.experimentCode?.previousValue) {
                this.experimentNotes = [];
                this.filteredResults = [];
            }
            this.limitToScroll = result;
        });

        if (changes.expCreator?.currentValue) {
            this.expCreatedUser = this.expCreator;
        }
    }

    ngOnInit(): void {
        this.notesHelper.expNoteSub$.subscribe((result) => {
            this.activeExperiment = result;
            if (result.Type === PRODUCT) {
                const productNotes = result.ProductNote;
                this.filteredResults = productNotes;
                this.experimentNotes = this.filteredResults;
                this.notesHelper.updateLoading(false);
            } else {
                this.expId = result.ExpID ?? result;
                if (this.activeExperiment.ExperimentNote) {
                    this.filteredResults = this.activeExperiment.ExperimentNote;
                    this.experimentNotes = this.filteredResults;
                    this.notesHelper.updateLoading(false);
                } else {
                    this.getExperimentNotesByExpId(this.expId);
                }
            }
        });
    }

    /**
     * Method to get updated limit
     * @param {number} limit
     * @memberof NoteDrawerComponent
     */
    public getupdatedLimit(limit: number): void {
        this.limitToScroll = limit;
    }

    /**
     * Method to call api for get experiment
     * @param {string} expId
     * @memberof NoteDrawerComponent
     */

    public getExperimentNotesByExpId(expId: string): void {
        const payload: GetExperimentNotesByIdPayload = {
            limit: this.limitToScroll,
            ExpId: expId,
            offset: this.offsetToScroll,
            filter: this.searchNote,
        };
        this.notesHelper.getExperimentNotesByExpId(payload).subscribe({
            next: (result: any) => {
                if (result) {
                    this.notesHelper.updateLoading(false);
                    this.totalCount = result.count;
                    this.experimentNotes = result.rows;
                    this.filteredResults = result.rows;
                } else {
                    this.notesHelper.updateLoading(false);
                    this.experimentNotes = [];
                    this.filteredResults = [];
                }
            },
            error: (error) => {
                this.toastrService.error(error);
            },
        });
    }

    /**
     * Method to call api for get experiment
     * @param {NotesResponse} notesList
     * @memberof NoteDrawerComponent
     */
    public getFilteredNotes(notesList: Array<NotesResponse>): void {
        this.filteredResults = notesList;
    }

    /**
     * Method to save notes
     * @param {string} noteDesc
     * @param {string} noteId
     * @returns {void}
     * @memberof NoteDrawerComponent
     */
    public saveNotes(noteValue: { noteDesc: string; noteId: string }): void {
        this.notesHelper.clearSearch();
        const addNotePayload: AddNotes = this.notesHelper.createPayloadNote(noteValue.noteDesc, this.expId, true);
        if (noteValue.noteId) {
            this.saveNotesWhenNoteIdExists(addNotePayload, noteValue);
        } else {
            this.experimentNotes.unshift(addNotePayload);
            this.notesHelper.saveNotes(addNotePayload).subscribe({
                next: (result) => {
                    if (result) {
                        this.experimentNotes.shift();
                        this.experimentNotes.unshift(result);
                        this.filteredResults = this.experimentNotes;
                        this.notesHelper.updateAddedNotes(this.experimentNotes);
                        this.experimentColumnHelper.handleToasterForExperimentResend(
                            result?.iffManResponse,
                            undefined,
                            result?.isESResponseFlag ? undefined : ES_RESPONSE.NOTES_MSG,
                        );
                    }
                },
                error: (error) => {
                    this.logger.error(error);
                },
            });
        }
    }

    private saveNotesWhenNoteIdExists(addNotePayload: AddNotes, noteValue: { noteDesc: string; noteId: string }) {
        addNotePayload.ExpNoteID = noteValue.noteId;
        this.notesHelper.updateNotes(addNotePayload).subscribe({
            next: (result) => {
                if (result) {
                    this.experimentNotes = this.experimentNotes.filter((item) => item.ExpNoteID !== noteValue.noteId);
                    this.experimentNotes.unshift(result);
                    this.filteredResults = this.experimentNotes;
                    if (this.activeExperiment?.ExperimentNote) {
                        this.activeExperiment.ExperimentNote = this.filteredResults;
                    }
                }
                this.experimentColumnHelper.handleToasterForExperimentResend(
                    result?.iffManResponse,
                    undefined,
                    result?.isESResponseFlag ? undefined : ES_RESPONSE.NOTES_MSG,
                );
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to close notes drawer
     *
     * @memberof NoteDrawerComponent
     */
    public closeDrawer(): void {
        this.experimentNotesList.clearControls();
        this.noteDrawerToggle.emit();
    }

    /**
     * Method to get notes after deleting
     *
     * @param {NotesResponse[]} notes
     * @returns {void}
     * @memberof NoteDrawerComponent
     */
    public getNotes(notes: NotesResponse[]): void {
        this.experimentNotes = notes;
        this.notesHelper.updateAddedNotes(this.experimentNotes);
        if (this.activeExperiment?.ExperimentNote) {
            this.activeExperiment.ExperimentNote = notes;
        }
    }
}
