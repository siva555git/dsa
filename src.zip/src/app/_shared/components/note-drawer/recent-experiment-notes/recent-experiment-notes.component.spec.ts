/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { MatMenuModule } from "@angular/material/menu";
import { MockNotesHelper } from "../../../../testing/mock-notes-helper";
import { MockToastrService } from "../../../../testing/mock-toastr.service";
import { NotesHelper } from "../../../helpers/notes.helper";
import { MockLoggerService } from "../../../../testing/mock-logger.service";

import { RecentExperimentNotesComponent } from "./recent-experiment-notes.component";

describe("RecentExperimentNotesComponent", () => {
    let component: RecentExperimentNotesComponent;
    let fixture: ComponentFixture<RecentExperimentNotesComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [RecentExperimentNotesComponent],
            imports: [BrowserAnimationsModule, MatMenuModule],
            providers: [
                {
                    provide: NotesHelper,
                    useClass: MockNotesHelper,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RecentExperimentNotesComponent);
        component = fixture.componentInstance;
        component.experimentData = {
            data: {
                ExpCode: "NXC00121AA",
                ExpID: "1234567",
            },
            value: 0,
            colDef: {
                context: {
                    notesToggle: {
                        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
                        emit: () => {},
                    },
                },
            },
        };
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for closeExperimentNotes", () => {
        jasmine.clock().install();
        const spy = spyOn(component, "closeExperimentNotes").and.callThrough();
        component.closeExperimentNotes();
        jasmine.clock().tick(10);
        expect(spy).toHaveBeenCalled();
        jasmine.clock().uninstall();
    });

    xit("should resolve for getExperimentNotesByExpId", () => {
        const spy = spyOn(component, "getExperimentNotesByExpId").and.callThrough();
        component.getExperimentNotesByExpId("1234567");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for viewAllExperimentNotes", () => {
        const spy = spyOn(component, "viewAllExperimentNotes").and.callThrough();
        component.viewAllExperimentNotes();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for showExperimentNotes", () => {
        const spy = spyOn(component, "showExperimentNotes").and.callThrough();
        component.showExperimentNotes(component.experimentData);
        expect(spy).toHaveBeenCalled();
    });
});
