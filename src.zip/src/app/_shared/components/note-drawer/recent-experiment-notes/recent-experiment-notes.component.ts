import { Component, ViewChild } from "@angular/core";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { delay } from "lodash";
import { ICellRendererParams } from "@ag-grid-community/core";
import { MatMenuTrigger } from "@angular/material/menu";
import { HIGHLIGHT_TYPE, NOTES_TYPES, INVALID_USER } from "../../../constants/common.constant";
import { GetExperimentNotesByIdPayload, NotesResponse } from "../../../models/notes.model";
import { NotesHelper } from "../../../helpers/notes.helper";

@Component({
    selector: "app-recent-experiment-notes",
    templateUrl: "./recent-experiment-notes.component.html",
})
export class RecentExperimentNotesComponent {
    public notesType = NOTES_TYPES;

    public maxLength = "57";

    public expCode: string;

    public userName = INVALID_USER;

    public experimentNotes: NotesResponse[];

    public showDescription: boolean[] = [];

    @ViewChild("notesMenu", { static: false }) notesMenuTrigger: MatMenuTrigger;

    public openNotes = false;

    public experimentId: number;

    public showLoader = true;

    public experimentData;

    public searchNote: string;

    public highlightType = HIGHLIGHT_TYPE;

    public isSearchNoteApplied = false;

    public experimentNotesCount = 0;

    public isShowNotesPopup = false;

    constructor(
        private readonly notesHelper: NotesHelper,
        private readonly logger: NGXLogger,
        private readonly toastrService: ToastrService,
    ) {}

    /**
     * Method to show experiment notes in landing page
     * @param experimentData
     * @returns {void}
     * @memberof RecentExperimentNotesComponent
     */
    public showExperimentNotes(experimentData: ICellRendererParams): void {
        this.showLoader = true;
        this.experimentNotes = [];
        this.experimentNotesCount = 0;
        this.experimentData = experimentData;
        this.expCode = experimentData.data.ExpCode;
        this.getExperimentNotesByExpId(experimentData.data.ExpID);
        this.searchNote = this.experimentData?.context?.componentParent?.noteSearchInfo?.searchText;
        this.isSearchNoteApplied = !!this.searchNote;
        delay(() => {
            this.notesMenuTrigger.openMenu();
            this.isShowNotesPopup = true;
        }, 0);
    }

    /**
     * Method to close experiment notes in landing page when close icon click
     * @returns {void}
     * @memberof RecentExperimentNotesComponent
     */
    public closeExperimentNotes(): void {
        delay(() => {
            this.notesMenuTrigger.closeMenu();
            this.isShowNotesPopup = false;
        }, 0);
    }

    /**
     * Method to get experiment notes from api
     * @param {string} expId
     * @returns {void}
     * @memberof RecentExperimentNotesComponent
     */
    public getExperimentNotesByExpId(expId: string): void {
        const payload: GetExperimentNotesByIdPayload = {
            limit: 5,
            ExpId: expId,
            offset: 0,
            filter: this.experimentData?.context?.componentParent?.noteSearchInfo?.searchText,
        };
        this.notesHelper.getExperimentNotesByExpId(payload).subscribe({
            next: (result) => {
                this.showLoader = false;
                if (result) {
                    // eslint-disable-next-line dot-notation
                    this.experimentNotesCount = result["count"];
                    // eslint-disable-next-line dot-notation
                    this.experimentNotes = result["rows"];
                }
            },
            error: (error) => {
                this.showLoader = false;
                this.toastrService.error(error);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to open notes drawer when click on view all notes button
     * @returns {void}
     * @memberof RecentExperimentNotesComponent
     */
    public viewAllExperimentNotes(): void {
        this.closeExperimentNotes();
        this.experimentData.colDef.context.notesToggle.emit(this.experimentData.data.ExpID);
    }

    /**
     * Method to handle escape keyup event
     * @return {void}
     */
    public hideNotesOnEscape(): void {
        if (this.isShowNotesPopup) {
            this.closeExperimentNotes();
        }
    }
}
