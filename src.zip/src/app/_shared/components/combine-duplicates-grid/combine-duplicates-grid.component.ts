import { SelectionModel } from "@angular/cdk/collections";
import { Component, EventEmitter, Input, Output, SimpleChanges, ViewChild } from "@angular/core";
import { MatCheckboxChange } from "@angular/material/checkbox";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { map } from "lodash";
import { ExplodeBomItemModel } from "../../../experiment-editor/models/experiment-editor.model";
import { COLUMN_ID } from "../display-grid-data/display-grid-data-constants";
import { DisplayGridColumnModel } from "../display-grid-data/display.grid.model";

@Component({
    selector: "app-combine-duplicates-grid",
    templateUrl: "./combine-duplicates-grid.component.html",
})
export class CombineDuplicatesGridComponent {
    public displayColumns;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public selection = new SelectionModel<any>(true, []);

    @Input()
    public displayGridColumns: DisplayGridColumnModel[];

    @Input()
    public displayGridDataSource = new MatTableDataSource();

    @Output() public selectedData = new EventEmitter<ExplodeBomItemModel[]>();

    @ViewChild(MatSort) sort: MatSort;

    public ngAfterViewInit(): void {
        if (this.displayGridDataSource) {
            this.displayGridDataSource.sort = this.sort;
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (
            (changes.displayGridColumns && changes.displayGridColumns.currentValue) ||
            (changes.displayGridDataSource && changes.displayGridDataSource.currentValue)
        ) {
            if (changes.displayGridColumns) {
                this.displayColumns = map(changes.displayGridColumns.currentValue, COLUMN_ID);
            }
            this.displayGridDataSource = new MatTableDataSource(changes.displayGridDataSource.currentValue);
            this.displayGridDataSource.sort = this.sort;
            this.selectAllOnLoad(true);
        }
    }

    /**
     * Method to check whether all rows are selected
     * @returns {boolean}
     * @memberof DisplayGridDataComponent
     */
    public isAllSelected(): boolean {
        const numberSelected = this.selection.selected.length;
        const numberRows = this.displayGridDataSource.data.length;
        return numberSelected === numberRows;
    }

    /**
     * Method to get selected data from combine modal
     * @param {MatCheckboxChange} event
     * @returns {void}
     * @memberof DisplayGridDataComponent
     */
    public masterToggle(event: MatCheckboxChange): void {
        // eslint-disable-next-line no-unused-expressions
        this.isAllSelected() ? this.selection.clear() : this.selectAllOnLoad(event.checked);
        if (!event.checked) this.selectedData.emit([]);
    }

    /**
     * Method to select all the grid row data
     * @param {boolean} isChecked
     * @returns {void}
     * @memberof DisplayGridDataComponent
     */
    public selectAllOnLoad(isChecked: boolean): void {
        if (this.displayGridDataSource?.data.length > 0) {
            this.displayGridDataSource.data.forEach((row) => this.selection.select(row));
            if (isChecked) this.selectedData.emit(this.selection.selected);
        }
    }

    /**
     * Method to get selected data from combine modal
     * @param {ExplodeBomItemModel} row
     * @returns {void}
     * @memberof DisplayGridDataComponent
     */
    public emitSelectedData(row: ExplodeBomItemModel): void {
        this.selection.toggle(row);
        this.selectedData.emit(this.selection.selected);
    }
}
