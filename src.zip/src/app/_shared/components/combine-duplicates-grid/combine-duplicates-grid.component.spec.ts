/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChange } from "@angular/core";
import { MatCheckboxChange, MatCheckboxModule } from "@angular/material/checkbox";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource, MatTableModule } from "@angular/material/table";
import { DISPLAY_GRID_DATA, explodeBomItemData } from "../../../testing/mock-display-grid.helper";

import { CombineDuplicatesGridComponent } from "./combine-duplicates-grid.component";
import { ChecboxCheckedPipe } from "@te-shared/pipes/checbox-checked.pipe";

describe("CombineDuplicatesGridComponent", () => {
    let component: CombineDuplicatesGridComponent;
    let fixture: ComponentFixture<CombineDuplicatesGridComponent>;
    let sort: MatSort;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CombineDuplicatesGridComponent, ChecboxCheckedPipe],
            providers: [
                ChecboxCheckedPipe
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                MatTableModule,
                MatCheckboxModule
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CombineDuplicatesGridComponent);
        component = fixture.componentInstance;
        component.displayGridColumns = DISPLAY_GRID_DATA.DISPLAY_GRID_COLUMNS;
        component.displayGridDataSource = new MatTableDataSource(DISPLAY_GRID_DATA.DISPLAY_GRID);
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should match the display columns count", () => {
        // component.displayGridDataSource = DISPLAY_GRID_DATA.DISPLAY_GRID;
        component.displayGridColumns = DISPLAY_GRID_DATA.DISPLAY_GRID_COLUMNS;
        component.ngOnChanges({
            displayGridDataSource: new SimpleChange(component.displayGridDataSource, component.displayGridDataSource, false),
            displayGridColumns: new SimpleChange(component.displayGridColumns, component.displayGridColumns, false),
        });
        fixture.detectChanges();
        expect(component.displayColumns.length).toBe(5);
    });

    it("should set sort after the view initialization", () => {
        component.ngAfterViewInit();
        expect(component.displayGridDataSource.sort).toBe(sort);
    });

    it("should call isAllSelected", () => {
        const spy = spyOn(component, "isAllSelected").and.callThrough();
        component.isAllSelected();
        expect(spy).toHaveBeenCalled();
    });

    it("should call masterToggle", () => {
        const spy = spyOn(component, "masterToggle").and.callThrough();
        component.masterToggle({ checked: true } as MatCheckboxChange);
        expect(spy).toHaveBeenCalled();
    });

    it("should call emitSelectedData", () => {
        const spy = spyOn(component, "emitSelectedData").and.callThrough();
        component.emitSelectedData(explodeBomItemData[0]);
        expect(spy).toHaveBeenCalled();
    });

    it("should call selectAllOnLoad when checked is true", () => {
        const spy = spyOn(component, "selectAllOnLoad").and.callThrough();
        component.selectAllOnLoad(true);
        expect(spy).toHaveBeenCalled();
    });

    it("should call selectAllOnLoad when checked is false", () => {
        const spy = spyOn(component, "selectAllOnLoad").and.callThrough();
        component.selectAllOnLoad(false);
        expect(spy).toHaveBeenCalled();
    });
});
