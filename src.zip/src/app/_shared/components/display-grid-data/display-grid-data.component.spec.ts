/* eslint-disable max-lines-per-function */
import { NO_ERRORS_SCHEMA, SimpleChange } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource, MatTableModule } from "@angular/material/table";
import { DISPLAY_GRID_DATA } from "../../../testing/mock-display-grid.helper";

import { DisplayGridDataComponent } from "./display.grid.data.component";

describe("DisplayGridDataComponent", () => {
    let component: DisplayGridDataComponent;
    let fixture: ComponentFixture<DisplayGridDataComponent>;
    let sort: MatSort;
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [DisplayGridDataComponent],
            imports: [MatTableModule],
            schemas: [NO_ERRORS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DisplayGridDataComponent);
        component = fixture.componentInstance;
        component.displayGridColumns = DISPLAY_GRID_DATA.DISPLAY_GRID_COLUMNS;
        component.displayGridDataSource = new MatTableDataSource(DISPLAY_GRID_DATA.DISPLAY_GRID);
        fixture.detectChanges();
    });

    it("should match the display columns count", () => {
        // component.displayGridDataSource = DISPLAY_GRID_DATA.DISPLAY_GRID;
        component.displayGridColumns = DISPLAY_GRID_DATA.DISPLAY_GRID_COLUMNS;
        component.ngOnChanges({
            displayGridDataSource: new SimpleChange(component.displayGridDataSource, component.displayGridDataSource, false),
            displayGridColumns: new SimpleChange(component.displayGridColumns, component.displayGridColumns, false),
        });
        fixture.detectChanges();
        expect(component.displayColumns.length).toBe(5);
    });

    it("should set sort after the view initialization", () => {
        component.ngAfterViewInit();
        expect(component.displayGridDataSource.sort).toBe(sort);
    });
});
