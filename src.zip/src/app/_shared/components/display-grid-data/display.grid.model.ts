/**
 * DisplayGridColumnModel Model
 *
 * @export
 * @interface DisplayGridColumnModel
 */
export interface DisplayGridColumnModel {
    /**
     * rowIndex
     *
     * @type {string}
     * @memberof DisplayGridColumnModel
     */
    columndID: string;

    /**
     * displayColumnName
     *
     * @type {string}
     * @memberof DisplayGridColumnModel
     */
    displayColumnName: string;
}
