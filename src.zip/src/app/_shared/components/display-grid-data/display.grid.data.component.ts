import { Component, Input, SimpleChanges, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { map } from "lodash";
import { NO_ROW_DISPLAY_MSG } from "@te-shared/constants/common.constant";
import {
    COMBINE_NAME,
    COMBINE_INDEX,
    COMBINE_PARTS,
    INACTIVE_BOM_FLAG,
} from "../../../experiment-editor/constants/experiment-editor.constant";
import { COLUMN_ID } from "./display-grid-data-constants";
import { DisplayGridColumnModel } from "./display.grid.model";

@Component({
    selector: "app-display-grid-data",
    templateUrl: "./display-grid-data.component.html",
})
export class DisplayGridDataComponent {
    @Input()
    public displayGridColumns: DisplayGridColumnModel[];

    @Input()
    public displayGridDataSource = new MatTableDataSource();

    @Input() public title: string;

    @Input() public isCombineExp: boolean;

    @Input() public isProductData: boolean;

    @Input() public noRowDisplayMsg: string;

    @Input() public isViewDuplicatePour = false;

    public displayColumns;

    public subName = COMBINE_NAME;

    public showInstruction: boolean[] = [];

    public parts = COMBINE_PARTS;

    public isSoftDeleted = INACTIVE_BOM_FLAG;

    public columnId = COMBINE_INDEX;

    public defaultNoRowDisplayMsg = NO_ROW_DISPLAY_MSG;

    @ViewChild(MatSort) sort: MatSort;

    public ngAfterViewInit(): void {
        if (this.displayGridDataSource) {
            this.displayGridDataSource.sort = this.sort;
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (
            (changes.displayGridColumns && changes.displayGridColumns.currentValue) ||
            (changes.displayGridDataSource && changes.displayGridDataSource.currentValue)
        ) {
            if (changes.displayGridColumns) {
                this.displayColumns = map(changes.displayGridColumns.currentValue, COLUMN_ID);
            }
            this.displayGridDataSource = new MatTableDataSource(changes.displayGridDataSource.currentValue);
            this.displayGridDataSource.sort = this.sort;
        }
    }
}
