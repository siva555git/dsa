/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { NGXLogger } from "ngx-logger";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { of, throwError } from "rxjs";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from "@angular/core";
import { MatSelectModule } from "@angular/material/select";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { PERMISSION_CATEGORY_CONSTANT } from "@te-shared/constants";
import { MockExperimentEditorService } from "@te-testing/mock-experiment-editor.service";
import { MatomoService, WindowReferenceService } from "@te-services/app-common";
import { ExperimentEditorService } from "@te-experiment-editor/helpers/experiment-editor.service";
import { ToastrService } from "ngx-toastr";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { CreativeReviewHelper } from "src/app/creative-review/helpers/creative-review-helper";
import { MockCreativereview } from "@te-testing/mock-creativereview-helper";
import { MockExperimentAccessHelper } from "@te-testing/mock-experiment-access.helper";
import { QzTrayService } from "@te-services/app-qz-tray/qz-tray.service";
import pdfMake from "pdfmake/build/pdfmake";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { MockPrintService } from "@te-testing/mock-print-service";
import { KEY_BOARD_EVENTS } from "@te-experiment/experiment.constant";
import { SAMPLE_CONST, TEMPLATE_DETAILS } from "@te-shared/constants/print-sample.constant";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { MockExperimentApiService } from "../../../testing/mock-experiment-api.service";
import { MockDialogReference } from "../../../testing/mock-dialog.reference";
import { ExperimentApiService } from "../../helpers/experiment-api.service";
import { AppStateService } from "../../../_services/app-state/app.state.service";
import { MockAppStateService } from "../../../testing/mock-app.state.service";
import { CreateSampleComponent } from "./create-sample.component";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { BatchSheetHelper } from "../../helpers/batch-sheet.helper";
import { BatchSheetReturn, CreateSampleModel, FORM_CONTROL_NAME } from "../../../experiment-editor/models/batch-sheet.model";
import { AppDataService } from "../../../_services/app-data/app.data.service";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { AppCacheHelper } from "../../helpers/app-cache.service";
import { MockAppcacheHelper } from "../../../testing/mock-app-cache-helper";
import { GridApiService } from "../../../experiment-editor/helpers/grid-api-service";
import { MockGridapiService } from "../../../testing/mock-gridapi.service";
import { batchSheetModel } from "../../../testing/mock-create-sample-helper";
import { MasterDataHelper } from "../../master-data/helpers/master-data.helper";
import { EMPTY } from "../../../app.constant";
import { MockMasterDataHelper } from "../../../testing/mock-master-data-helper";

describe("CreateSampleComponent", () => {
    let component: CreateSampleComponent;
    let fixture: ComponentFixture<CreateSampleComponent>;
    const dialogData = {
        expId: 63_399_886,
    };
    const dialogReferenceStub = {
        afterClosed() {
            return of("result"); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    class MockMasterData {
        checkAndFetchDefaultData = () => {
            return of([]);
        };
    }
    const dialogStub = { open: () => dialogReferenceStub };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            imports: [
                ReactiveFormsModule,
                FormsModule,
                BrowserModule,
                BrowserAnimationsModule,
                MatSelectModule,
                MatInputModule,
                MatFormFieldModule,
            ],
            declarations: [CreateSampleComponent],
            providers: [
                { provide: ExperimentApiService, useClass: MockExperimentApiService },
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: MAT_DIALOG_DATA, useValue: dialogData },
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: NGXLogger, useClass: MockLoggerService },
                { provide: MatDialog, useValue: dialogStub },
                { provide: AppDataService, useClass: MockAppDataService },
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: AppCacheHelper, useClass: MockAppcacheHelper },
                { provide: MasterDataHelper, useClass: MockMasterDataHelper },
                {
                    provide: BatchSheetHelper,
                    useValue: {
                        createBatchSheet: () => {
                            return of();
                        },
                        getSample: () => {
                            return of();
                        },
                        getLabelTemplate: () => {
                            return of();
                        },
                        generateLabelTemplate: () => {
                            return of();
                        },
                        validateSampleId: () => {
                            return of();
                        },
                    },
                },
                AppBroadCastService,
                UntypedFormBuilder,
                WindowReferenceService,
                { provide: MasterDataHelper, useClass: MockMasterData },
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                { provide: ExperimentEditorService, useClass: MockExperimentEditorService },
                { provide: ToastrService, useClass: MockToastrService },
                { provide: CreativeReviewHelper, useClass: MockCreativereview },
                { provide: QzTrayService, useClass: MockPrintService },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CreateSampleComponent);
        component = fixture.componentInstance;
        component.createSampleForm = new UntypedFormGroup({
            SampleID: new UntypedFormControl(12_345_678),
            ExperimentID: new UntypedFormControl(EMPTY),
            NumberOfSamples: new UntypedFormControl(1),
            RequiredSampleSize: new UntypedFormControl(1),
            TotalRequirement: new UntypedFormControl(EMPTY),
            Yield: new UntypedFormControl(100),
            YieldToggle: new UntypedFormControl(true),
            UOM: new UntypedFormControl(EMPTY),
            CustomNote: new UntypedFormControl(EMPTY),
            PrintSample: new UntypedFormGroup({
                PrintSampleCheckbox: new UntypedFormControl(true),
                NoOfPaperCopies: new UntypedFormControl(1),
                BomSortOrder: new UntypedFormControl(EMPTY),
                DecimalPrinter: new UntypedFormControl(3),
                PaperPrinter: new UntypedFormControl(EMPTY),
                ExperimentNotes: new UntypedFormControl(false),
            }),
            PrintLabel: new UntypedFormGroup({
                LabelCheckbox: new UntypedFormControl(true),
                NoOfLabelCopies: new UntypedFormControl(1),
                LabelTemplate: new UntypedFormControl(EMPTY),
                LabelPrinter: new UntypedFormControl(EMPTY),
                LabelOrientation: new UntypedFormControl(SAMPLE_CONST.LANDSCAPE),
            }),
        });
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on ngOnInit", () => {
        spyOn(component, "getPrinters");
        spyOn(component, "getSampleSheet");
        spyOn(component, "OnValidateExperiment");
        spyOn(component, "checkAndFetchDefaultData");
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onSelectionCriteria", () => {
        const spy = spyOn(component, "onSelectionCriteria").and.callThrough();
        component.onSelectionCriteria("Kg/g");
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ApplyYieldChange by passing false value", () => {
        const spy = spyOn(component, "onApplyYieldChange").and.callThrough();
        component.onApplyYieldChange(false);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ApplyYieldChange by passing true value", () => {
        const spy = spyOn(component, "onApplyYieldChange").and.callThrough();
        component.onApplyYieldChange(true);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on totalRequirement", () => {
        component.createSampleForm.get("NumberOfSamples").patchValue(1);
        component.createSampleForm.get("RequiredSampleSize").patchValue(10);
        const spy = spyOn(component, "totalRequirement").and.callThrough();
        component.totalRequirement();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onApplyFieldValue", () => {
        component.onApplyFieldValue("10", FORM_CONTROL_NAME.YIELD);
        expect(component.createSampleForm.controls.Yield.patchValue("10"));
    });

    it("should resolve for onSubmitSample", () => {
        const spy = spyOn(component, "onSubmitSample").and.callThrough();
        component.onSubmitSample();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSubmitSample when number of samples greater than or equal to 10", () => {
        component.createSampleForm.patchValue({ NumberOfSamples: 10 });
        const spy = spyOn(component, "onSubmitSample").and.callThrough();
        component.onSubmitSample();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onSubmitSample when number of samples greater than or equal to 10", () => {
        component.createSampleForm.patchValue({ NumberOfSamples: 10 });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn(component["dialog"], "open").and.returnValue({ afterClosed: () => of(false) } as MatDialogRef<any>);
        const spy = spyOn(component, "onSubmitSample").and.callThrough();
        component.onSubmitSample();
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke applyYieldKeyPress", () => {
        const keyBoadData = {
            event: { keyCode: 0 },
            target: { SELECTION_START: 0, SELECTION_END: 0, VALUE: 1 },
            stopPropagation() {
                return true;
            },
        };
        const spy = spyOn(component, "applyYieldKeyPress").and.callThrough();
        component.applyYieldKeyPress(keyBoadData as unknown as KeyboardEvent, FORM_CONTROL_NAME.YIELD);
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke sortOrderBasedonInput and sort by DEFAULT_SORT", () => {
        const sortType = "Sort by Natural Order (includes instructions)";
        const spy = spyOn(component, "sortOrderBasedonInput").and.callThrough();
        component.sortOrderBasedonInput(batchSheetModel as unknown as BatchSheetReturn, sortType);
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke sortOrderBasedonInput and sort by description", () => {
        const sortType = "Sort by Description (no instructions)";
        const spy = spyOn(component, "sortOrderBasedonInput").and.callThrough();
        component.printResult = batchSheetModel as unknown as BatchSheetReturn;
        component.sortOrderBasedonInput(batchSheetModel as unknown as BatchSheetReturn, sortType);
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke sortOrderBasedonInput and sort by ID", () => {
        const sortType = "Sort by IPC (no instructions)";
        const spy = spyOn(component, "sortOrderBasedonInput").and.callThrough();
        component.printResult = batchSheetModel as unknown as BatchSheetReturn;
        component.sortOrderBasedonInput(batchSheetModel as unknown as BatchSheetReturn, sortType);
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke sortOrderBasedonInput and sort by Parts", () => {
        const sortType = "Sort by Descending parts (no instructions)";
        const spy = spyOn(component, "sortOrderBasedonInput").and.callThrough();
        component.printResult = batchSheetModel as unknown as BatchSheetReturn;
        component.sortOrderBasedonInput(batchSheetModel as unknown as BatchSheetReturn, sortType);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on changeNumberFormat", () => {
        component.printResult = { Decimals: 4 } as BatchSheetReturn;
        const value = component.changeNumberFormat(1234);
        expect(value).toEqual("1,234.0000");
    });

    it("should call on getPrinters", () => {
        spyOn(component, "setCachePrinterValue").and.returnValue();
        component.sampleCacheValue = { PaperPrinter: "PDF" };
        component.getPrinters();
        expect(component.paperPrinters.length).toEqual(0);
    });

    it("should call on getPrinters on error", () => {
        spyOn(component.printerService, "getPrinters").and.returnValue(throwError(() => "error"));
        component.getPrinters();
    });

    it("should call on checkAndFetchDefaultData", () => {
        spyOn(component["masterData"], "checkAndFetchDefaultData").and.returnValue(of({ uomDetails: [{ uomtype: "W" }] }));
        component.checkAndFetchDefaultData();
        expect(component.uomData.length).toEqual(1);
    });

    it("should call on checkAndFetchDefaultData on error", () => {
        const spy = spyOn(component["masterData"], "checkAndFetchDefaultData").and.returnValue(throwError(() => "error"));
        component.checkAndFetchDefaultData();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on createSampleFromSampleForm", () => {
        component.createSampleFromSampleForm();
    });

    it("should call on totalRequirement when isArrow is true", () => {
        component.totalRequirement();
    });

    it("should call on totalRequirement when isArrow is false", () => {
        spyOn(component, "onApplyFieldValue").and.returnValue();
        component.createSampleForm = new UntypedFormGroup({
            RequiredSampleSize: new UntypedFormControl(""),
            TotalRequirement: new UntypedFormControl(10),
            NumberOfSamples: new UntypedFormControl(10),
        });
        component.totalRequirement();
        expect(component.createSampleForm.controls.TotalRequirement.value).toEqual("");
    });

    it("should call on onApplyFieldValue when empty", () => {
        component.onApplyFieldValue("", "");
    });

    it("should call on onApplyFieldValue when RequiredSampleSize is zero", () => {
        component.onApplyFieldValue("0", "RequiredSampleSize");
        expect(component.createSampleForm.controls.RequiredSampleSize.getError("zeroValue")).toBeTrue();
    });

    it("should call on onApplyFieldValue when TotalRequirement is zero", () => {
        component.onApplyFieldValue("0", "TotalRequirement");
        expect(component.createSampleForm.controls.TotalRequirement.getError("zeroValue")).toBeTrue();
    });

    it("should call on onApplyFieldValue when Yield is zero", () => {
        component.onApplyFieldValue("0", "Yield");
        expect(component.createSampleForm.controls.Yield.getError("zeroValue")).toBeTrue();
    });

    it("should call on createBatchSheet when ipc is cached", () => {
        const sampleFormValue = {
            ExperimentID: 63_400_261,
            NumberOfSamples: 1,
            RequiredSampleSize: 20,
            UOM: "L/kg",
            TotalRequirement: 200,
            Decimals: 1,
            Yield: 98,
        } as any;
        const spy = spyOn<any, any>(component, "printBatchSheet").and.returnValue("");
        spyOn(component["appCacheHelper"], "getAttributesFromCache").and.returnValue(of([{ ipc: "1RR04333" }] as any));
        spyOn(component["batchSheetHelper"], "createBatchSheet").and.returnValue(
            of({
                Experiment: {
                    ExperimentFormula: [
                        { SUBType: "I", SUBCode: "1RR04333" },
                        { SUBType: "E", SUBCode: "1RR04333" },
                    ],
                },
            } as any),
        );
        component.createBatchSheet(sampleFormValue);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on createBatchSheet when ipc is uncached", () => {
        const sampleFormValue = {
            ExperimentID: 63_400_261,
            NumberOfSamples: 1,
            RequiredSampleSize: 20,
            UOM: "L/kg",
            TotalRequirement: 200,
            Decimals: 1,
            Yield: 98,
        } as any;
        const spy = spyOn<any, any>(component, "printBatchSheet").and.returnValue("");
        spyOn(component["appCacheHelper"], "getAttributesFromCache").and.returnValue(of([{ ipc: "1RR04332" }] as any));
        spyOn(component["batchSheetHelper"], "createBatchSheet").and.returnValue(
            of({
                Experiment: {
                    ExperimentFormula: [
                        { SUBType: "I", SUBCode: "1RR04333" },
                        { SUBType: "E", SUBCode: "1RR04333" },
                    ],
                },
            } as any),
        );
        component.createBatchSheet(sampleFormValue);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on createBatchSheet when error", () => {
        const sampleFormValue = {
            ExperimentID: 63_400_261,
            NumberOfSamples: 1,
            RequiredSampleSize: 20,
            UOM: "L/kg",
            TotalRequirement: 200,
            Decimals: 1,
            Yield: 98,
        } as any;
        const spy = spyOn(component["batchSheetHelper"], "createBatchSheet").and.returnValue(throwError(() => "error") as any);
        component.createBatchSheet(sampleFormValue);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on printBatchSheet", () => {
        spyOn(component, "sortOrderBasedonInput").and.returnValue();
        spyOn(component, "generateLabelTemplate").and.returnValue();
        spyOn<any, any>(component, "doPrintSample").and.returnValue("");
        component["printBatchSheet"](
            { Experiment: { ExperimentFormula: [{ SUBCode: "1RR04333" }, { SUBCode: "1RR04332" }] } } as any,
            {} as any,
            [{ ipc: "1RR04333" }] as any,
            { PrintSample: { PrintSampleCheckbox: true }, PrintLabel: { LabelCheckbox: true } } as any,
        );
        expect(component.printResult.Experiment.ExperimentFormula.length).toEqual(2);
    });

    it("should call on printBatchSheet", () => {
        spyOn(component, "sortOrderBasedonInput").and.returnValue();
        spyOn(component, "generateLabelTemplate").and.returnValue();
        spyOn<any, any>(component, "doPrintSample").and.returnValue("");
        component.data = { type: "Make Sample" } as any;
        component["printBatchSheet"](
            { Experiment: { ExperimentFormula: [{ SUBCode: "1RR04333" }, { SUBCode: "1RR04332" }] } } as any,
            {} as any,
            [{ ipc: "1RR04333" }] as any,
            { PrintSample: { PrintSampleCheckbox: true }, PrintLabel: { LabelCheckbox: false } } as any,
        );
    });

    it("should call on doPrintSample", () => {
        jasmine.clock().install();
        spyOn<any, any>(component, "generateSampleDocumentAndPrint").and.returnValue("");
        component.printResult = { TaskDetails: { TaskID: "1234" } } as any;
        component.printElement = { nativeElement: { style: { display: "none" } } };
        component["doPrintSample"]();
        jasmine.clock().tick(110);
        expect(component.printElement.nativeElement.style.display).toEqual("block");
        jasmine.clock().uninstall();
    });

    it("should call on generateSampleDocumentAndPrint", () => {
        spyOn<any, any>(component, "getDocumentDefinition").and.returnValue("");
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(pdfMake, "createPdf").and.returnValue({ getBase64: () => "data", print: () => {} });
        component["generateSampleDocumentAndPrint"]();
        expect(component.printElement.nativeElement.style.display).toEqual("none");
    });

    xit("should call on doPrintLabel", () => {
        jasmine.clock().install();
        component.selectedLabelTemplate = { LabelName: TEMPLATE_DETAILS[0].name } as any;
        component["doPrintLabel"]({} as any);
        jasmine.clock().tick(60);
        expect(component.barcodeWidth).toBeDefined();
        jasmine.clock().uninstall();
    });

    it("should call on generateLabelTemplateAndPrint", () => {
        component.data = { type: "Make Sample" } as any;
        component.createSampleForm = new UntypedFormGroup({
            PrintLabel: new UntypedFormGroup({
                NoOfLabelCopies: new UntypedFormControl(1),
                LabelPrinter: new UntypedFormControl("Label"),
                LabelOrientation: new UntypedFormControl(EMPTY),
            }),
        });
        component.barcodeLabel = {
            bcElement: {
                nativeElement: {
                    innerHTML: "",
                },
            },
        } as any;
        component.qrcodeLabel = {
            qrcElement: {
                nativeElement: {
                    innerHTML: "",
                },
            },
        } as any;
        component["generateLabelTemplateAndPrint"]("", { width: 10, height: 10 }, "portrait");
    });

    it("should call on getDocumentDefinition", () => {
        spyOn<any, any>(component, "getHeaderSection").and.returnValue("");
        component.printBody = { nativeElement: { innerHTML: "" } };
        component.barcode = {
            bcElement: {
                nativeElement: {
                    innerHTML: "",
                    children: [{ src: "" }],
                },
            },
        } as any;
        component.qrcode = {
            qrcElement: {
                nativeElement: {
                    innerHTML: "",
                    children: [{ src: "" }],
                },
            },
        } as any;
        component["getDocumentDefinition"]();
    });

    it("should call on getHeaderSection", () => {
        component.printHeader4 = {
            nativeElement: {
                innerHTML: "",
            },
        };
        component.printHeader5 = {
            nativeElement: {
                innerHTML: "",
            },
        };
        component.printHeader6 = {
            nativeElement: {
                innerHTML: "",
            },
        };
        spyOn<any, any>(component, "getHeaderSection1").and.returnValue("");
        spyOn<any, any>(component, "getHeaderSection2").and.returnValue("");
        spyOn<any, any>(component, "getHeaderSection3").and.returnValue("");
        spyOn<any, any>(component, "getHeaderSection4").and.returnValue("");
        component["getHeaderSection"]("");
    });

    it("should call on getHeaderSection1", () => {
        component.printHeaderLabel2 = {
            nativeElement: {
                innerHTML: "",
            },
        };
        component.printHeaderLabel3 = {
            nativeElement: {
                innerHTML: "",
            },
        };
        component["getHeaderSection1"]("");
    });

    it("should call on getHeaderSection2", () => {
        component.printHeaderValue2 = {
            nativeElement: {
                innerHTML: "",
            },
        };
        component["getHeaderSection2"]();
    });

    it("should call on getHeaderSection3", () => {
        component.printHeader7 = {
            nativeElement: {
                innerHTML: "",
            },
        };
        component["getHeaderSection3"]();
    });

    it("should call on getHeaderSection4", () => {
        component.printHeader3 = {
            nativeElement: {
                innerHTML: "",
            },
        };
        component.entityHeader = {
            nativeElement: {
                innerHTML: "",
            },
        };
        component["getHeaderSection4"]();
    });

    it("should call on OnValidateExperiment", () => {
        component.createSampleForm = new UntypedFormGroup({
            ExperimentID: new UntypedFormControl(""),
        });
        component.OnValidateExperiment();
        component.createSampleForm.controls.ExperimentID.setValue("1RR04333");
    });

    it("should call on onValidateExperimentAccess", () => {
        component.createSampleForm = new UntypedFormGroup({
            ExperimentID: new UntypedFormControl(""),
        });
        component["onValidateExperimentAccess"]({ message: "Error" });
    });

    it("should call on onValidateExperimentAccess1", () => {
        spyOn(component["experimentAccessHelper"], "getExperimentAccessCheck").and.returnValue({ isPermitted: true } as any);
        component.createSampleForm = new UntypedFormGroup({
            ExperimentID: new UntypedFormControl(""),
        });
        component["onValidateExperimentAccess"]({ message1: "Error" });
    });

    it("should call on onValidateExperimentAccess2", () => {
        spyOn(component["experimentAccessHelper"], "getExperimentAccessCheck").and.returnValue({
            isPermitted: false,
            AccessDetail: [{ AccessList: PERMISSION_CATEGORY_CONSTANT.NOT_MEMBER }],
        } as any);
        component.createSampleForm = new UntypedFormGroup({
            ExperimentID: new UntypedFormControl(""),
        });
        component["onValidateExperimentAccess"]({ message1: "Error" });
    });

    it("should call on onValidateExperimentAccess3", () => {
        spyOn(component, "getBomdetails").and.returnValue();
        spyOn(component["experimentAccessHelper"], "getExperimentAccessCheck").and.returnValue({
            isPermitted: false,
            AccessDetail: [{ Lock: PERMISSION_CATEGORY_CONSTANT.UNLOCKED }],
        } as any);
        component.createSampleForm = new UntypedFormGroup({
            ExperimentID: new UntypedFormControl(""),
        });
        component["onValidateExperimentAccess"]({ message1: "Error" });
    });

    it("should call on openDialog", () => {
        spyOn(component, "setFormControlValue").and.returnValue();
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(component["dialog"], "open").and.returnValue({ afterClosed: () => of(false), close: () => {} } as any);
        component.openDialog("", FORM_CONTROL_NAME.NO_OF_PAPERCOPIES, "");
    });

    it("should call on onSelectCheckbox", () => {
        spyOn(component, "handleCheckboxClass").and.returnValue();
        component.createSampleForm = new UntypedFormGroup({
            PrintSample: new UntypedFormGroup({
                NoOfLabelCopies: new UntypedFormControl(1),
                LabelPrinter: new UntypedFormControl("Label"),
                PrintSampleCheckbox: new UntypedFormControl("Label"),
                ProductList: new UntypedFormControl("Label"),
            }),
        });
        component.bomDetails = [{}];
        component.onSelectCheckbox("PrintSample", "PrintSampleCheckbox");
        component.createSampleForm.controls.PrintSample["controls"].PrintSampleCheckbox.setValue("");
    });

    it("should call on onSelectCheckbox", () => {
        spyOn(component, "handleCheckboxClass").and.returnValue();
        component.createSampleForm = new UntypedFormGroup({
            PrintSample: new UntypedFormGroup({
                NoOfLabelCopies: new UntypedFormControl(1),
                LabelPrinter: new UntypedFormControl("Label"),
                PrintSampleCheckbox: new UntypedFormControl("Label"),
                ProductList: new UntypedFormControl("Label"),
            }),
        });
        component.bomDetails = [{}];
        component.onSelectCheckbox("PrintSample", "PrintSampleCheckbox");
        component.createSampleForm.controls.PrintSample["controls"].PrintSampleCheckbox.setValue("label2");
    });

    it("should call on showWarningDialog", () => {
        spyOn<any, any>(component, "validateRangeValues").and.returnValue("");
        component.createSampleForm = new UntypedFormGroup({
            PrintSample: new UntypedFormGroup({
                NoOfLabelCopies: new UntypedFormControl(1),
                LabelPrinter: new UntypedFormControl("Label"),
                PrintSampleCheckbox: new UntypedFormControl("Label"),
                ProductList: new UntypedFormControl("Label"),
            }),
        });
        component.bomDetails = [{}];
        component.showWarningDialog("", FORM_CONTROL_NAME.NO_OF_PAPERCOPIES, "PrintSample");
    });

    it("should call on showWarningDialog1", () => {
        spyOn<any, any>(component, "validateRangeValues").and.returnValue("");
        component.createSampleForm = new UntypedFormGroup({
            PrintSample: new UntypedFormGroup({
                NoOfLabelCopies: new UntypedFormControl(1),
                LabelPrinter: new UntypedFormControl("Label"),
                PrintSampleCheckbox: new UntypedFormControl("Label"),
                ProductList: new UntypedFormControl("Label"),
            }),
        });
        component.bomDetails = [{}];
        component.showWarningDialog("", FORM_CONTROL_NAME.DECIMAL_PRINTER, "PrintSample");
    });

    it("should call on showWarningDialog2", () => {
        spyOn<any, any>(component, "validateRangeValues").and.returnValue("");
        component.createSampleForm = new UntypedFormGroup({
            PrintSample: new UntypedFormGroup({
                NoOfLabelCopies: new UntypedFormControl(1),
                LabelPrinter: new UntypedFormControl("Label"),
                PrintSampleCheckbox: new UntypedFormControl("Label"),
                ProductList: new UntypedFormControl("Label"),
            }),
        });
        component.bomDetails = [{}];
        component.showWarningDialog("", FORM_CONTROL_NAME.NO_OF_LABEL_COPIES, "PrintSample");
    });

    it("should call on showWarningDialog3", () => {
        spyOn<any, any>(component, "validateRangeValues").and.returnValue("");
        component.createSampleForm = new UntypedFormGroup({
            PrintSample: new UntypedFormGroup({
                NoOfLabelCopies: new UntypedFormControl(1),
                LabelPrinter: new UntypedFormControl("Label"),
                PrintSampleCheckbox: new UntypedFormControl("Label"),
                ProductList: new UntypedFormControl("Label"),
            }),
        });
        component.bomDetails = [{}];
        component.showWarningDialog("lABEL2", FORM_CONTROL_NAME.NO_OF_LABEL_COPIES, "PrintSample");
    });

    it("should call on validateRangeValues4", () => {
        spyOn(component, "openDialog").and.returnValue();
        component["validateRangeValues"](10, FORM_CONTROL_NAME.NO_OF_SAMPLES, "", "PrintSample");
    });

    it("should call on validateRangeValues5", () => {
        spyOn(component, "openDialog").and.returnValue();
        component["validateRangeValues"](1001, FORM_CONTROL_NAME.REQUIRED_SAMPLESIZE, "", "PrintSample");
    });

    it("should call on validateRangeValues6", () => {
        spyOn(component, "openDialog").and.returnValue();
        component["validateRangeValues"](3001, FORM_CONTROL_NAME.TOTAL_REQUIREMENT, "", "PrintSample");
    });

    it("should call on validateRangeValues7", () => {
        spyOn(component, "openDialog").and.returnValue();
        component["validateRangeValues"](10, FORM_CONTROL_NAME.NO_OF_PAPERCOPIES, "", "PrintSample");
    });

    it("should call on validateRangeValues8", () => {
        spyOn(component, "openDialog").and.returnValue();
        component["validateRangeValues"](10, FORM_CONTROL_NAME.NO_OF_LABEL_COPIES, "", "PrintSample");
    });

    it("should call on tabFunction", () => {
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        component.experimentID = { nativeElement: { focus: () => {} } };
        component.tabFunction();
    });

    it("should call getBomdetails", () => {
        component.experiment = {
            ExpID: 1234,
        } as any;
        spyOn(component, "formatBomItems").and.returnValue();
        spyOn(component["appCacheHelper"], "getAttributesFromCache").and.returnValue(of([{ ipc: "1RR04333" }, { ipc: "1RR04332" }]) as any);
        spyOn(component["gridApiService"], "getBomDetails").and.returnValue(
            of({
                Experiments: [
                    {
                        ExpID: 1234,
                        ExperimentFormula: [
                            {
                                SUBType: "E",
                            },
                            {
                                SUBType: "I",
                                SUBCode: "1RR04333",
                            },
                            {
                                SUBType: "I",
                                SUBCode: "1RR04332",
                            },
                        ],
                    },
                ],
            }),
        );
        component.getBomdetails();
    });

    it("should call getBomdetails on error", () => {
        component.experiment = {
            ExpID: 1234,
        } as any;
        spyOn(component["gridApiService"], "getBomDetails").and.returnValue(throwError(() => "error") as any);
        component.getBomdetails();
    });

    it("should call formatBomItems", () => {
        component.experiment = {
            ExpID: 1234,
        } as any;
        component.bomDetails = [];
        component.formatBomItems({ Experiments: [{ ExperimentFormula: [{ SUBType: "U" }] }] }, []);
    });

    it("should call formatBomItems", () => {
        component.experiment = {
            ExpID: 1234,
        } as any;
        component.bomDetails = [];
        component.formatBomItems({ Experiments: [{ ExpID: 1234, ExperimentFormula: [{ SUBCode: 1234, SUBType: "E" }] }] }, []);
    });

    it("should call getSampleSheet on error", () => {
        spyOn(component["batchSheetHelper"], "getSample").and.returnValue(throwError(() => "error"));
        // eslint-disable-next-line unicorn/no-useless-undefined
        spyOn(AppStateService, "getRequestSampleRememberData").and.returnValue(undefined);
        component.getSampleSheet();
    });

    it("should call getSampleSheet", () => {
        spyOn(component["batchSheetHelper"], "getSample").and.returnValue(of({}));
        spyOn(component, "setCacheFormValue").and.returnValue();
        spyOn(component, "setCachePrinterValue").and.returnValue();
        // eslint-disable-next-line unicorn/no-useless-undefined
        spyOn(AppStateService, "getRequestSampleRememberData").and.returnValue(undefined);
        spyOn(AppStateService, "setRequestSampleRememberData").and.returnValue();
        component.getSampleSheet();
    });

    it("should call getSampleSheet", () => {
        spyOn(component["batchSheetHelper"], "getSample").and.returnValue(of({}));
        spyOn(component, "setCacheFormValue").and.returnValue();
        spyOn(component, "setCachePrinterValue").and.returnValue();
        spyOn(AppStateService, "getRequestSampleRememberData").and.returnValue({} as any);
        spyOn(AppStateService, "setRequestSampleRememberData").and.returnValue();
        component.getSampleSheet();
    });

    it("should call handleCheckboxClass", () => {
        component.handleCheckboxClass(FORM_CONTROL_NAME.SAMPLE_CHECKBOX, true);
        expect(component.isEnablePrintCheckBox).toBeTrue();
    });

    it("should call handleCheckboxClass1", () => {
        component.handleCheckboxClass(FORM_CONTROL_NAME.LABEL_CHECKBOX, true);
        expect(component.isEnableLabelCheckBox).toBeTrue();
    });

    it("should call handleCheckboxClass2", () => {
        component.handleCheckboxClass(FORM_CONTROL_NAME.SAP_PO_CHECKBOX, true);
        expect(component.isEnableSAPPOCheckBox).toBeTrue();
    });

    it("should call OnValidateNumberEntering", () => {
        component.OnValidateNumberEntering(
            {
                key: "0",
                target: {
                    [KEY_BOARD_EVENTS.SELECTION_START]: 0,
                },
                // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
                preventDefault: () => {},
            } as any,
            "",
        );
    });

    it("should call OnValidateNumberEntering1", () => {
        spyOn(component, "getFormControlValue").and.returnValue(12);
        spyOn(component, "isExceedRangeValidation").and.returnValue(true);
        component.OnValidateNumberEntering(
            {
                key: "*",
                target: {
                    [KEY_BOARD_EVENTS.SELECTION_START]: 0,
                },
                // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
                preventDefault: () => {},
            } as any,
            "Label",
        );
    });

    it("should call OnValidateNumberEntering2", () => {
        spyOn(component, "getFormControlValue").and.returnValue(12);
        spyOn(component, "isExceedRangeValidation").and.returnValue(true);
        component.OnValidateNumberEntering(
            {
                key: "*",
                target: {
                    [KEY_BOARD_EVENTS.SELECTION_START]: 0,
                },
                // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
                preventDefault: () => {},
            } as any,
            "Label",
        );
    });

    it("should call setFormControlValue", () => {
        spyOn(component, "getFormControlValue").and.returnValue(12);
        spyOn(component, "isExceedRangeValidation").and.returnValue(false);
        component.setFormControlValue("LabelCheckbox", "PrintLabel", 12);
    });

    it("should call setFormControlValue1", () => {
        spyOn(component, "getFormControlValue").and.returnValue(12);
        spyOn(component, "isExceedRangeValidation").and.returnValue(false);
        component.setFormControlValue("ExperimentID", "", 12);
    });

    it("should call setFormControlValue2", () => {
        spyOn(component, "getFormControlValue").and.returnValue(12);
        spyOn(component, "isExceedRangeValidation").and.returnValue(true);
        component.setFormControlValue("ExperimentID", "", 12);
    });

    it("should call getFormControlValue", () => {
        component.getFormControlValue("ExperimentID", "");
    });

    it("should call getFormControlValue", () => {
        component.getFormControlValue("LabelCheckbox", "PrintLabel");
    });

    it("should call setCacheFormValue", () => {
        spyOn(component, "totalRequirement").and.returnValue();
        component.experiment = {} as any;
        component.uomData = [{ uomdisplay: "Parts" }] as any;
        component.labelTemplates = [{ LabelName: "Label" }];
        component.sampleCacheValue = {
            BomSortOrder: true,
            UOM: "Parts",
            LabelTemplate: "Label",
        };
        component.setCacheFormValue();
    });

    it("should call setCacheFormValue", () => {
        spyOn(component, "totalRequirement").and.returnValue();
        component.experiment = {} as any;
        component.uomData = [{ uomdisplay: "Parts" }] as any;
        component.labelTemplates = [{ LabelName: "Label" }];
        component.sampleCacheValue = {
            BomSortOrder: true,
            UOM: "Parts",
            LabelTemplate: "Label",
        };
        component.setCacheFormValue();
    });

    it("should call setCachePrinterValue", () => {
        component.sampleCacheValue = {};
        component.setCachePrinterValue();
    });

    it("should call setCachePrinterValue1", () => {
        component.paperPrinters = [{ name: "Paper" }];
        component.labelPrinters = [{ name: "Paper" }];
        component.sampleCacheValue = {
            PaperPrinter: "Paper",
            LabelPrinter: "Paper",
        };
        component.setCachePrinterValue();
    });

    it("should call setCachePrinterValue2", () => {
        component.paperPrinters = [{ name: "Paper" }];
        component.labelPrinters = [{ name: "Paper" }];
        component.sampleCacheValue = {
            PaperPrinter: "Paper",
            LabelPrinter: "Paper",
        };
        component.setCachePrinterValue();
    });

    it("should call onLabelTemplateChange", () => {
        component.onLabelTemplateChange({} as any);
        expect(component.selectedLabelTemplate).toEqual({} as any);
    });

    it("should call isExceedRangeValidation", () => {
        const isValid = component.isExceedRangeValidation(FORM_CONTROL_NAME.NO_OF_SAMPLES, 22);
        expect(isValid).toEqual(true);
    });

    it("should call isExceedRangeValidation1", () => {
        const isValid = component.isExceedRangeValidation(FORM_CONTROL_NAME.NO_OF_PAPERCOPIES, 22);
        expect(isValid).toEqual(true);
    });

    it("should call isExceedRangeValidation2", () => {
        const isValid = component.isExceedRangeValidation(FORM_CONTROL_NAME.NO_OF_LABEL_COPIES, 22);
        expect(isValid).toEqual(true);
    });

    it("should call isExceedRangeValidation3", () => {
        const isValid = component.isExceedRangeValidation(FORM_CONTROL_NAME.DECIMAL_PRINTER, 22);
        expect(isValid).toEqual(true);
    });

    it("should call isExceedRangeValidation4", () => {
        const isValid = component.isExceedRangeValidation("", 22);
        expect(isValid).toEqual(false);
    });

    it("should call getLabelTemplate", () => {
        spyOn(component, "getSampleSheet").and.returnValue();
        spyOn(component["batchSheetHelper"], "getLabelTemplate").and.returnValue(of({}) as any);
        component.getLabelTemplate();
        expect(component.labelTemplates).toEqual({} as any);
    });

    it("should call getLabelTemplate on error", () => {
        spyOn(component["batchSheetHelper"], "getLabelTemplate").and.returnValue(throwError(() => "error"));
        component.getLabelTemplate();
    });

    it("should call generateLabelTemplate", () => {
        component.createSampleForm = new UntypedFormGroup({
            SampleID: new UntypedFormControl(EMPTY),
            CustomNote: new UntypedFormControl(EMPTY),
            NoOfLabelCopies: new UntypedFormControl(1),
            LabelTemplate: new UntypedFormControl(EMPTY),
            LabelPrinter: new UntypedFormControl(EMPTY),
            LabelOrientation: new UntypedFormControl(EMPTY),
        });
        component.data = {
            // eslint-disable-next-line sonarjs/no-duplicate-string
            type: "Reprint Label",
        } as unknown as CreateSampleModel;
        component.createSampleForm.controls.CustomNote.setValue("");
        component.createSampleForm.controls.LabelPrinter.setValue({});
        spyOn<any, any>(component, "doPrintLabel").and.returnValue({});
        spyOn(component["batchSheetHelper"], "generateLabelTemplate").and.returnValue(of({}) as any);
        component.generateLabelTemplate({});
    });

    it("should call generateLabelTemplate", () => {
        component.createSampleForm = new UntypedFormGroup({
            SampleID: new UntypedFormControl(EMPTY),
            CustomNote: new UntypedFormControl(EMPTY),
            NoOfLabelCopies: new UntypedFormControl(1),
            LabelTemplate: new UntypedFormControl(EMPTY),
            LabelPrinter: new UntypedFormControl(EMPTY),
        });
        component.data = {
            type: "Reprint Label",
        } as unknown as CreateSampleModel;
        component.createSampleForm.controls.CustomNote.setValue("");
        component.createSampleForm.controls.LabelPrinter.setValue({});
        spyOn<any, any>(component, "doPrintLabel").and.returnValue({});
        // eslint-disable-next-line unicorn/no-useless-undefined
        spyOn(component["batchSheetHelper"], "generateLabelTemplate").and.returnValue(of(undefined));
        component.generateLabelTemplate({});
    });

    it("should call generateLabelTemplate on error", () => {
        component.createSampleForm = new UntypedFormGroup({
            SampleID: new UntypedFormControl(EMPTY),
            CustomNote: new UntypedFormControl(EMPTY),
            NoOfLabelCopies: new UntypedFormControl(1),
            LabelTemplate: new UntypedFormControl(EMPTY),
            LabelPrinter: new UntypedFormControl(EMPTY),
            LabelOrientation: new UntypedFormControl(EMPTY),
        });
        component.data = {
            type: "Reprint Label",
        } as unknown as CreateSampleModel;
        component.createSampleForm.controls.CustomNote.setValue("");
        component.createSampleForm.controls.LabelPrinter.setValue({});
        spyOn<any, any>(component, "doPrintLabel").and.returnValue({});
        spyOn(component["batchSheetHelper"], "generateLabelTemplate").and.returnValue(throwError(() => "error") as any);
        component.generateLabelTemplate({});
    });

    it("should call validateSampleID", () => {
        component.validateSampleID();
    });

    it("should call validateSampleID1", () => {
        component.createSampleForm.controls.SampleID.setValue("1234567890");
        spyOn(component["batchSheetHelper"], "validateSampleId").and.returnValue(throwError(() => "error") as any);
        component.validateSampleID();
    });

    it("should call validateSampleID2", () => {
        component.createSampleForm.controls.SampleID.setValue("1234567890");
        // eslint-disable-next-line unicorn/no-useless-undefined
        spyOn(component["batchSheetHelper"], "validateSampleId").and.returnValue(of(undefined));
        component.validateSampleID();
    });

    it("should call validateSampleID3", () => {
        component.createSampleForm.controls.SampleID.setValue("1234567890");
        spyOn(component["batchSheetHelper"], "validateSampleId").and.returnValue(of({ message: "Message" }) as any);
        component.validateSampleID();
    });

    it("should call validateSampleID4", () => {
        component.createSampleForm.controls.SampleID.setValue("1234567890");
        spyOn(component["batchSheetHelper"], "validateSampleId").and.returnValue(of({}) as any);
        component.validateSampleID();
    });

    it("should call onSubmitReprintLabelForm", () => {
        spyOn(component, "generateLabelTemplate").and.returnValue();
        component.onSubmitReprintLabelForm();
    });

    it("should call prePopulateSampleInfo", () => {
        component.createSampleForm = new UntypedFormGroup({
            SampleID: new UntypedFormControl(EMPTY),
            CustomNote: new UntypedFormControl(EMPTY),
            NoOfLabelCopies: new UntypedFormControl(1),
            LabelTemplate: new UntypedFormControl(EMPTY),
            LabelPrinter: new UntypedFormControl(EMPTY),
            LabelOrientation: new UntypedFormControl(EMPTY),
        });
        component.createSampleForm.get("LabelOrientation").patchValue(SAMPLE_CONST.LANDSCAPE);
        const spy = spyOn(component, "prePopulateSampleInfo").and.callThrough();
        component.prePopulateSampleInfo({} as unknown);
        expect(spy).toHaveBeenCalled();
    });

    it("should set label orientation from cache", () => {
        // Arrange
        const mockSampleCacheValue = {
            LabelOrientation: "portrait",
        };
        const mockLabelOrientation = [{ orientationType: "portrait" }];

        component.sampleCacheValue = mockSampleCacheValue;
        component.labelOrientation = mockLabelOrientation;

        // Act
        component.setCacheFormValue();

        // Assert
        expect(component.createSampleForm.value.PrintLabel.LabelOrientation).toEqual(mockLabelOrientation[0].orientationType);
    });
});
