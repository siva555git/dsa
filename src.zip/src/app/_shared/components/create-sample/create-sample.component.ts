/* eslint-disable max-lines-per-function */
/* eslint-disable max-lines */
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, Inject, ViewChild } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormGroup, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { Subscription } from "rxjs";
import { debounceTime, filter as filterRxjs, switchMap, take } from "rxjs/operators";
import { NGXLogger } from "ngx-logger";
import { filter, inRange, orderBy, isEqual, map, uniq, delay, isNumber, forEach } from "lodash";
import htmlToPdfmake from "html-to-pdfmake";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { NgxBarcode6Component } from "ngx-barcode6";
import { QRCodeComponent } from "angularx-qrcode";
import { ToastrService } from "ngx-toastr";
import moment from "moment";
import { MatCheckboxChange } from "@angular/material/checkbox";
import { CurrentUser } from "../../models/user-collaboration-group.model";
import { EMPTY, LOADING, PLEASE_WAIT } from "../../../app.constant";
import { KEY_BOARD_EVENTS, REGEX_SAMPLE_VALIDATION, USE_LEVEL_VALIDATION } from "../../../experiment/experiment.constant";
import { AppBroadCastService, AppStateService, ErrorFormatService, MatomoService } from "../../../_services";
import {
    ALPHABETS_FORMAT,
    ASSIGNED_PRINT_WIDTH,
    BATCH_SHEET_VALUES,
    BOM_TYPE,
    CREATE_SAMPLE_SORT_OPTIONS,
    DECIMAL_LIMIT,
    DEFAULT_SORT,
    DEFAULT_YIELD_VALUE,
    EXPERIMENT_ACCESS,
    EXPERIMENT_FORMULA_ERRORS,
    FONT_STYLE,
    IPC_EXPCODE_LENGTH,
    KEYBOARD_KEYS,
    MASTER_DATAS,
    PARTS,
    PERMISSION_CATEGORY_CONSTANT,
    REQUIRED_SAMPLE_SIZE,
    SAMPLE_CONFIRMATION,
    SAMPLE_DEFAULT_VALUE,
    SORT_BY_DESCRIPTION,
    SORT_BY_ID,
    SORT_BY_NATURAL_ORDER_IN_BOLD,
    SPECIAL_CHARACTER_FORMAT,
    STATIC_HEADEAR_HEIGHT,
    STATIC_TASK_HEIGHT,
    STATIC_TEXT_HEIGHT,
    SUB_CODE,
    TOTAL_REQUIREMENT_SIZE,
    YIELD_VALUES,
} from "../../constants";
import { ConfirmationDialogComponent } from "../confirmation-dialog/confirmation-dialog.component";
import { BatchSheetHelper } from "../../helpers/batch-sheet.helper";
import {
    BatchSheetModel,
    BatchSheetReturn,
    CreateSampleModel,
    SampleResponse,
    FORM_CONTROL_NAME,
    LabelTemplatePayload,
    GenerateLabelResponse,
    LabelTemplateResponse,
} from "../../../experiment-editor/models/batch-sheet.model";
import { MasterDataHelper } from "../../master-data/helpers/master-data.helper";
import { UOMDetailsModel } from "../../master-data/models/uom-details.model";
import { AppCacheHelper } from "../../helpers/app-cache.service";
import { MatomoAction, MatomoCategory, MatomoLabel, SUBTypes } from "../../enums";
import { BomAttributes } from "../../models/attributes-model";
import { GridApiService } from "../../../experiment-editor/helpers/grid-api-service";
import { IPC_MAPPING } from "../../../experiment-editor/constants/experiment-editor.constant";
import { BOM_DETAILS_CONSTANTS } from "../../constants/experiment.constant";
import {
    DEFAULT_PAGE_SIZE,
    ERROR_MESSAGE,
    LABEL_ORIENTATION,
    PAGE_SIZE_DETAILS,
    SAMPLE_CONST,
    SAMPLE_TYPE,
    UOM_TYPE,
    LABEL_WITH_PRODUCT_TYPE,
    UOM_FOR_SAP_PO,
    UOM_VALIDATION_MESSAGE_FOR_SAP_PO,
} from "../../constants/print-sample.constant";
import { ExperimentAccessHelper } from "../../helpers/experiment-access.helper";
import { ExperimentEditorService } from "../../../experiment-editor/helpers/experiment-editor.service";
import { CreativeReviewHelper } from "../../../creative-review/helpers/creative-review-helper";
import { QzTrayService } from "../../../_services/app-qz-tray/qz-tray.service";
import { CreateSampleRememberData } from "../../models/experiment-list.model";
import { DATE_FORMAT } from "../../../master-data/constants/bom-view-report.constant";

pdfMake.vfs = pdfFonts.pdfMake.vfs;

pdfMake.fonts = {
    NunitoSans: {
        // eslint-disable-next-line angular/window-service
        normal: `${window.location.origin}/assets/fonts/NunitoSans/NunitoSans-Regular.ttf`,
        // eslint-disable-next-line angular/window-service
        bold: `${window.location.origin}/assets/fonts/NunitoSans/NunitoSans-Bold.ttf`,
        // eslint-disable-next-line angular/window-service
        italics: `${window.location.origin}/assets/fonts/NunitoSans/NunitoSans-Black.ttf`,
    },
};

@Component({
    selector: "app-create-sample",
    templateUrl: "./create-sample.component.html",
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateSampleComponent {
    public headerFields = FORM_CONTROL_NAME;

    public uomChangeValue = EMPTY;

    public sortOptions = CREATE_SAMPLE_SORT_OPTIONS;

    public uomData: UOMDetailsModel[];

    public bomType = BOM_TYPE;

    public printResult: BatchSheetReturn;

    public createSampleSubscriptions = new Subscription();

    public createSampleForm: UntypedFormGroup = new UntypedFormGroup({});

    public currentDateTime: Date;

    public userDetails: CurrentUser;

    public experiment: CreateSampleModel;

    public bomDetails = [];

    public paperPrinters: { name: string }[] = [];

    public labelPrinters: { name: string }[] = [];

    public sampleCacheValue;

    public isInstructionBold = false;

    public isEnablePrintCheckBox = true;

    public isEnableLabelCheckBox = true;

    public isEnableSAPPOCheckBox = false;

    public isChecked = true;

    public fontStyle = FONT_STYLE;

    public staticHeight = STATIC_TEXT_HEIGHT;

    public staticTaskHeight = STATIC_TASK_HEIGHT;

    public staticHeaderHeight = STATIC_HEADEAR_HEIGHT;

    public assignedPrintWidth = ASSIGNED_PRINT_WIDTH;

    public calcHeight: number;

    public canvasParamsWidth: number;

    public pageSize = PAGE_SIZE_DETAILS;

    public labelTemplates = [];

    public labelOrientation = LABEL_ORIENTATION;

    public selectedLabelTemplate: LabelTemplateResponse;

    public barcodeWidth: number;

    public barcodeHeight: number;

    public qrCodeWidth: number;

    public experimentDetail;

    public sampleDetails;

    public errorMessage: string;

    public type = SAMPLE_TYPE;

    public disableSAPPO = true;

    public sapPoPlants: string[] = [];

    public excludingRecoveredItems = SAMPLE_CONST.EXCLUDING_RECOVERED_ITEMS;

    @ViewChild("requiredSampleSize") requiredSampleSize: ElementRef;

    @ViewChild("experimentID") experimentID: ElementRef;

    @ViewChild("printElement") public printElement: ElementRef;

    @ViewChild("printHeader") public printHeader: ElementRef;

    @ViewChild("printHeaderLabel2") public printHeaderLabel2: ElementRef;

    @ViewChild("printHeaderValue2") public printHeaderValue2: ElementRef;

    @ViewChild("printHeaderLabel3") public printHeaderLabel3: ElementRef;

    @ViewChild("printHeader3") public printHeader3: ElementRef;

    @ViewChild("printHeader4") public printHeader4: ElementRef;

    @ViewChild("printHeader5") public printHeader5: ElementRef;

    @ViewChild("printHeader6") public printHeader6: ElementRef;

    @ViewChild("printHeader7") public printHeader7: ElementRef;

    @ViewChild("printBody") public printBody: ElementRef;

    @ViewChild("barcode") barcode: NgxBarcode6Component;

    @ViewChild("qrcode") qrcode: QRCodeComponent;

    @ViewChild("barcodeLabel") barcodeLabel: NgxBarcode6Component;

    @ViewChild("qrcodeLabel") qrcodeLabel: QRCodeComponent;

    @ViewChild("labelPrintElemet") public labelPrintElemet: ElementRef;

    @ViewChild("labelPrintHeader") public labelPrintHeader: ElementRef;

    @ViewChild("labelbarcode") labelbarcode: NgxBarcode6Component;

    @ViewChild("labelqrcode") labelqrcode: QRCodeComponent;

    @ViewChild("entityHeader") public entityHeader: ElementRef;

    @ViewChild("smallLabel") public smallLabel: ElementRef;

    @ViewChild("mediumLabel") public mediumLabel: ElementRef;

    @ViewChild("largeLabel") public largeLabel: ElementRef;

    @ViewChild("numberOfSamples") public numberOfSamples: ElementRef;

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: CreateSampleModel,
        private readonly dialogReference: MatDialogRef<CreateSampleComponent>,
        private readonly formBuilder: UntypedFormBuilder,
        private readonly dialog: MatDialog,
        private readonly batchSheetHelper: BatchSheetHelper,
        private readonly logger: NGXLogger,
        private readonly masterData: MasterDataHelper,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly appCacheHelper: AppCacheHelper,
        public readonly gridApiService: GridApiService,
        private readonly appStateService: AppStateService,
        private readonly experimentAccessHelper: ExperimentAccessHelper,
        private readonly experimentEditorService: ExperimentEditorService,
        private readonly errorFormatService: ErrorFormatService,
        private readonly toastrService: ToastrService,
        private readonly creativeReviewHelper: CreativeReviewHelper,
        public readonly printerService: QzTrayService,
        private cdReference: ChangeDetectorRef,
        private readonly matomoService: MatomoService,
    ) {
        this.printerService.connect().subscribe({
            next: () => {
                this.getPrinters();
            },
            error: (error) => {
                // eslint-disable-next-line no-console
                console.log(error);
                this.logger.error(error);
            },
        });
        this.createSampleForm =
            this.data?.type === this.type.MAKE_SAMPLE ? this.createSampleFromSampleForm() : this.createReprintLabelForm();
        this.createSampleSubscriptions.add(
            this.dialogReference
                .keydownEvents()
                .pipe(filterRxjs((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.dialogReference.close();
                }),
        );
    }

    ngOnInit(): void {
        this.userDetails = this.appStateService.getCurrentUser();
        const applicationSettings = this.appStateService.getApplicationSettings();
        this.sapPoPlants = applicationSettings.ApplicationSettings.filter((setting) => setting.ParameterCode === "SAP SAMPLING").map(
            (setting) => setting.ParameterInString,
        );
        this.currentDateTime = new Date();
        this.getLabelTemplate();
        this.checkAndFetchDefaultData();
        if (this.data?.type !== this.type.REPRINT_LABEL) {
            this.OnValidateExperiment();
        }
        delay(() => {
            if (this.data.expId) {
                this.experiment = this.data;
                if (this.numberOfSamples?.nativeElement) this.numberOfSamples.nativeElement.focus();
                this.getBomdetails();
            } else if (this.experimentID?.nativeElement) {
                this.experimentID.nativeElement.focus();
            }
        }, 500);
        this.matomoService.trackEvent(MatomoCategory.REPRINT_LABEL, MatomoAction.VIEW_PAGE, MatomoLabel.INITIALIZED);
    }

    ngOnDestroy(): void {
        this.printerService.disconnect();
        this.createSampleSubscriptions.unsubscribe();
    }

    ngAfterViewChecked(): void {
        this.cdReference.detectChanges();
    }

    /**
     * Method to get Printer list
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public getPrinters(): void {
        this.createSampleSubscriptions.add(
            this.printerService.getPrinters().subscribe({
                next: (data) => {
                    this.paperPrinters = data.paperPrinter;
                    this.labelPrinters = data.labelPrinter;
                    if (this.sampleCacheValue?.PaperPrinter || this.sampleCacheValue?.LabelPrinter) this.setCachePrinterValue();
                },
                error: (error) => {
                    this.logger.log(error);
                },
            }),
        );
    }

    /**
     * Method to check the default data are in store or not , if not fetch it from API
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public checkAndFetchDefaultData(): void {
        this.masterData.checkAndFetchDefaultData(MASTER_DATAS).subscribe({
            next: (response) => {
                this.uomData = response?.uomDetails?.filter((uom) => UOM_TYPE[uom.uomtype]);
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to create sample Form
     * @returns {UntypedFormGroup}
     * @memberof CreateSampleComponent
     */
    public createSampleFromSampleForm = (): UntypedFormGroup => {
        this.uomChangeValue = PARTS;
        return this.formBuilder.group({
            ExperimentID: new UntypedFormControl(this.data?.expCode, [Validators.required, Validators.maxLength(10)]),
            NumberOfSamples: new UntypedFormControl(SAMPLE_DEFAULT_VALUE.NO_OF_SAMPLE, [Validators.required]),
            RequiredSampleSize: new UntypedFormControl(EMPTY, [Validators.required]),
            TotalRequirement: new UntypedFormControl(EMPTY, [Validators.required]),
            UOM: new UntypedFormControl(PARTS, [Validators.required]),
            Yield: new UntypedFormControl(
                this.data?.yield
                    ? this.data.yield?.toFixed(YIELD_VALUES.DECIMAL_LENGTH)
                    : YIELD_VALUES.MAX.toFixed(YIELD_VALUES.DECIMAL_LENGTH),
                [Validators.required],
            ),
            YieldToggle: new UntypedFormControl(true),
            CustomNote: new UntypedFormControl(EMPTY, [Validators.maxLength(60)]),
            PrintSample: this.formBuilder.group({
                PrintSampleCheckbox: new UntypedFormControl(true),
                NoOfPaperCopies: new UntypedFormControl(SAMPLE_DEFAULT_VALUE.PAPER_COPIES, [Validators.required]),
                BomSortOrder: new UntypedFormControl(CREATE_SAMPLE_SORT_OPTIONS[0].displayValue, [Validators.required]),
                DecimalPrinter: new UntypedFormControl(SAMPLE_DEFAULT_VALUE.DECIMAL_PRINTER, [Validators.required]),
                PaperPrinter: new UntypedFormControl(EMPTY, [Validators.required]),
                PaperSize: new UntypedFormControl(SAMPLE_CONST.PAGE_LETTER, [Validators.required]),
                ExperimentNotes: new UntypedFormControl(false, [Validators.required]),
                IsDoubleSidePrint: new UntypedFormControl(false),
                SampleOrientation: new UntypedFormControl(SAMPLE_CONST.PORTRAIT, [Validators.required]),
            }),
            PrintLabel: this.formBuilder.group({
                LabelCheckbox: new UntypedFormControl(true),
                NoOfLabelCopies: new UntypedFormControl(SAMPLE_DEFAULT_VALUE.LABEL_COPIES, [Validators.required]),
                LabelTemplate: new UntypedFormControl(EMPTY, [Validators.required]),
                LabelPrinter: new UntypedFormControl(EMPTY, [Validators.required]),
                LabelOrientation: new UntypedFormControl(SAMPLE_CONST.LANDSCAPE, [Validators.required]),
            }),
            CreateSAPPO: this.formBuilder.group({
                SAPPOCheckbox: new UntypedFormControl({ value: false, disabled: this.disableSAPPO }),
                ProductList: new UntypedFormControl({ value: EMPTY, disabled: true }),
            }),
        });
    };

    /**
     * Method used to update the changed UOM
     * @param {string} uomValue
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public onSelectionCriteria = (uomValue: string): void => {
        this.uomChangeValue = uomValue;
    };

    /**
     * Method to set the apply yield values by changing
     * @param {boolean} event
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public onApplyYieldChange = (event: boolean): void => {
        if (event) {
            const yieldValue = this.experiment?.yield ?? DEFAULT_YIELD_VALUE;
            this.createSampleForm.get(FORM_CONTROL_NAME.YIELD).enable();
            this.createSampleForm.controls.Yield.patchValue(yieldValue?.toFixed(YIELD_VALUES.DECIMAL_LENGTH));
        } else {
            const yieldValue = DEFAULT_YIELD_VALUE;
            this.createSampleForm.controls.Yield.patchValue(yieldValue?.toFixed(YIELD_VALUES.DECIMAL_LENGTH));
            this.createSampleForm.get(FORM_CONTROL_NAME.YIELD).disable();
        }
    };

    /**
     * Method for use level validation
     * @param {KeyboardEvent}event
     * @param {string} formControl
     * @returns {boolean}
     * @memberof CreateSampleComponent
     */
    public applyYieldKeyPress = (event: KeyboardEvent, formControl: string): boolean => {
        const regex = formControl === FORM_CONTROL_NAME.YIELD ? USE_LEVEL_VALIDATION : REGEX_SAMPLE_VALIDATION[formControl];
        let textContent;
        if (
            event.target[KEY_BOARD_EVENTS.SELECTION_START] === 0 &&
            event.target[KEY_BOARD_EVENTS.SELECTION_END] === event.target[KEY_BOARD_EVENTS.VALUE].length
        ) {
            textContent = event.key;
        } else {
            const position = event.target[KEY_BOARD_EVENTS.SELECTION_START];
            const currentValue = event.target[KEY_BOARD_EVENTS.VALUE];
            textContent = [
                currentValue?.slice(0, position),
                event.key === DECIMAL_LIMIT.DECIMAL_KEY ? DECIMAL_LIMIT.DECIMAL_POINT : event.key,
                currentValue?.slice(position),
            ].join(EMPTY);
        }
        return regex.test(textContent);
    };

    /**
     * formula to calculate Total requirement %
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public totalRequirement = (): void => {
        const noofSample = this.createSampleForm.get(BATCH_SHEET_VALUES.NO_OF_SAMPLES).value;
        const requiredSampleSize = this.createSampleForm.get(BATCH_SHEET_VALUES.REQUIRED_SAMPLE_SIZE).value;
        if (requiredSampleSize === EMPTY) {
            this.createSampleForm.controls.RequiredSampleSize.patchValue(EMPTY);
        }
        if (noofSample && requiredSampleSize) {
            const value = (noofSample * requiredSampleSize).toFixed(TOTAL_REQUIREMENT_SIZE.DECIMAL_LENGTH);
            this.createSampleForm.controls.TotalRequirement.patchValue(value);
            this.onApplyFieldValue(value, FORM_CONTROL_NAME.TOTAL_REQUIREMENT);
        } else {
            this.createSampleForm.controls.TotalRequirement.patchValue(EMPTY);
        }
    };

    /**
     * Method to validate the decimals printed input arguments
     * @param {string} $event
     * @param {string} formControl
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public onApplyFieldValue($event: string, formControl: string): void {
        if ($event === EMPTY) {
            return;
        }
        if (
            formControl === FORM_CONTROL_NAME.REQUIRED_SAMPLESIZE &&
            !inRange(+$event, REQUIRED_SAMPLE_SIZE.MIN, REQUIRED_SAMPLE_SIZE.MAX + 1)
        ) {
            this.createSampleForm.controls[formControl].setErrors({ zeroValue: true });
            return;
        }
        if (
            formControl === FORM_CONTROL_NAME.TOTAL_REQUIREMENT &&
            !inRange(+$event, TOTAL_REQUIREMENT_SIZE.MIN, TOTAL_REQUIREMENT_SIZE.MAX + 1)
        ) {
            this.createSampleForm.controls[formControl].setErrors({ zeroValue: true });
            return;
        }
        if (formControl === FORM_CONTROL_NAME.YIELD && !inRange(+$event, YIELD_VALUES.MIN, YIELD_VALUES.MAX + 1)) {
            this.createSampleForm.controls[formControl].setErrors({ zeroValue: true });
            return;
        }
        const decimalValue = formControl === FORM_CONTROL_NAME.YIELD ? YIELD_VALUES.DECIMAL_LENGTH : REQUIRED_SAMPLE_SIZE.DECIMAL_LENGTH;
        const givenValue = Number($event)?.toFixed(decimalValue);
        this.createSampleForm.controls[formControl].patchValue(givenValue);
    }

    /**
     *  Method to store the experiment sample
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public onSubmitSample(): void {
        this.canvasWidth();
        const sampleFormValue = this.createSampleForm.getRawValue();
        const requestSampleData: CreateSampleRememberData = {
            SampleCount: Number(sampleFormValue.NumberOfSamples),
            SampleSize: Number(sampleFormValue.RequiredSampleSize),
            UOM: sampleFormValue.UOM,
            YieldToggle: !!sampleFormValue.YieldToggle,
            Decimals: Number(sampleFormValue.PrintSample?.DecimalPrinter),
            BomSortOrder: sampleFormValue.PrintSample?.BomSortOrder,
            PaperSize: sampleFormValue?.PrintSample?.PaperSize ?? undefined,
            PaperPrinter: sampleFormValue?.PrintSample?.PaperPrinter?.name ?? undefined,
            LabelTemplate: sampleFormValue?.PrintLabel?.LabelTemplate?.LabelName ?? undefined,
            LabelPrinter: sampleFormValue?.PrintLabel?.LabelPrinter?.name ?? undefined,
            LabelOrientation: sampleFormValue?.PrintLabel?.LabelOrientation ?? undefined,
            SampleOrientation: sampleFormValue?.PrintSample?.SampleOrientation ?? undefined,
            IsPrintSampleChecked: sampleFormValue?.PrintSample?.PrintSampleCheckbox ?? true,
            IsLabelChecked: sampleFormValue?.PrintLabel?.LabelCheckbox ?? true,
            IsDoubleSidePrint: sampleFormValue?.PrintSample?.IsDoubleSidePrint ?? false,
        };
        AppStateService.setRequestSampleRememberData(requestSampleData);
        this.createBatchSheet(sampleFormValue);
        this.matomoService.trackEvent(MatomoCategory.REPRINT_LABEL, MatomoAction.CLICK, MatomoLabel.ON_SUBMIT_SAMPLE);
    }

    /**
     * Method to create the BatchSheet based on the input
     * @param {BatchSheetModel} formValue
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    // eslint-disable-next-line max-lines-per-function, sonarjs/cognitive-complexity
    public createBatchSheet(formValue: BatchSheetModel): void {
        if (this.uomValidationSAPPO(formValue)) {
            return;
        }
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        const sampleFormValue = {
            ExperimentID: Number(this.experiment?.expId) || Number(this.experiment?.ExpID),
            RequiredSampleSize: Number(formValue.RequiredSampleSize),
            NumberOfSamples: Number(formValue.NumberOfSamples),
            Yield: Number(formValue.Yield) ?? YIELD_VALUES.MAX,
            YieldToggle: !!formValue.YieldToggle,
            TotalRequirement: Number(formValue.TotalRequirement),
            UOM: formValue.UOM,
            PrintCommentsNotes: formValue?.PrintSample?.ExperimentNotes,
            Decimals: formValue?.PrintSample?.DecimalPrinter,
            BomSortOrder: formValue?.PrintSample?.BomSortOrder,
            PaperSize: formValue?.PrintSample?.PaperSize ?? undefined,
            PaperPrinter: formValue?.PrintSample?.PaperPrinter?.name ?? undefined,
            LabelTemplate: formValue?.PrintLabel?.LabelTemplate?.LabelName ?? undefined,
            LabelOrientation: formValue?.PrintLabel?.LabelOrientation ?? undefined,
            LabelPrinter: formValue?.PrintLabel?.LabelPrinter?.name ?? undefined,
            SampleOrientation: formValue?.PrintSample?.SampleOrientation ?? undefined,
            IsPrintSampleChecked: formValue?.PrintSample?.PrintSampleCheckbox,
            IsLabelChecked: formValue?.PrintLabel?.LabelCheckbox,
            SAPPOCheckbox: formValue?.CreateSAPPO?.SAPPOCheckbox,
            IsDoubleSidePrint: formValue?.PrintSample?.IsDoubleSidePrint ?? false,
        };
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.batchSheetHelper.createBatchSheet(sampleFormValue).subscribe({
            next: (batchSheetResult: BatchSheetReturn) => {
                let ipcValues = batchSheetResult?.Experiment?.ExperimentFormula?.map((element) => {
                    if (element.SUBType === SUBTypes.PRODUCT) {
                        return element.SUBCode;
                    }
                    return EMPTY;
                });
                ipcValues = filter(uniq(ipcValues));
                this.appCacheHelper.getAttributesFromCache(ipcValues).subscribe((ipcResult) => {
                    let attributes = ipcResult;
                    const cachedIPCs = map(ipcResult, IPC_MAPPING);
                    if (isEqual(cachedIPCs, ipcValues)) {
                        this.printBatchSheet(batchSheetResult, sampleFormValue, attributes, formValue);
                    } else {
                        const apiPayload = this.createPayload(ipcValues, cachedIPCs);
                        this.gridApiService
                            .loadAttributesFromAPI(apiPayload)
                            .pipe(take(1))
                            .subscribe((attributesFromApi) => {
                                // eslint-disable-next-line unicorn/prefer-spread
                                attributes = attributes.concat(attributesFromApi);
                                this.printBatchSheet(batchSheetResult, sampleFormValue, attributes, formValue);
                            });
                    }
                });
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * uom Validation method for sappo
     *
     * @private
     * @param {*} formValue
     * @return {*}  {boolean}
     * @memberof CreateSampleComponent
     */
    private uomValidationSAPPO(formValue): boolean {
        if (formValue?.CreateSAPPO?.SAPPOCheckbox && formValue?.UOM && !UOM_FOR_SAP_PO.includes(formValue.UOM.toUpperCase())) {
            this.toastrService.error(UOM_VALIDATION_MESSAGE_FOR_SAP_PO);
            return true;
        }
        return false;
    }

    /**
     * Method to create payload
     *
     * @param {string[]} ipcValues
     * @param {string[]} cachedIPCs
     * @memberof CreateSampleComponent
     */
    private createPayload = (ipcValues: string[], cachedIPCs: string[]) => {
        const missingIPCs = ipcValues.filter((payloadIPC) => !cachedIPCs.includes(payloadIPC));
        const apiPayload = {
            payload: {
                filter: { ipcs: missingIPCs },
                from: 0,
                recordcount: 2000,
            },
            plantInfo: [],
            landingPageAudit: true,
        };
        return apiPayload;
    };

    /**
     * Method to print BatchSheet based on the input
     * @param {BatchSheetReturn} batchSheetResult
     * @param {BatchSheetModel} sampleFormValue
     * @param {BomAttributes[]} attributes
     * @param {*} formValue
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    // eslint-disable-next-line max-lines-per-function
    private printBatchSheet(
        batchSheetResult: BatchSheetReturn,
        sampleFormValue: BatchSheetModel,
        attributes: BomAttributes[],
        formValue: BatchSheetModel,
    ): void {
        if (formValue?.PrintSample?.PrintSampleCheckbox || formValue?.PrintLabel?.LabelCheckbox || formValue?.CreateSAPPO?.SAPPOCheckbox) {
            const batchSheetReturnResult = batchSheetResult;
            if (batchSheetReturnResult?.Experiment?.ExperimentFormula.length) {
                batchSheetReturnResult.Experiment.ExperimentFormula.forEach((formula) => {
                    // eslint-disable-next-line sonarjs/no-ignored-return
                    attributes.find((ipc) => {
                        const expFormula = formula;
                        if (ipc.ipc === formula.SUBCode) {
                            expFormula.Instruction = ipc.description;
                            return true;
                        }
                        return false;
                    });
                });
            }
            this.printResult = Object.assign(batchSheetReturnResult, sampleFormValue);
            if (formValue?.PrintSample?.PrintSampleCheckbox) {
                this.sortOrderBasedonInput(this.printResult, this.createSampleForm?.value?.PrintSample?.BomSortOrder);
                this.doPrintSample();
            }
            if (formValue?.PrintLabel?.LabelCheckbox) {
                this.generateLabelTemplate(batchSheetResult);
            }
            if (formValue?.CreateSAPPO?.SAPPOCheckbox) {
                const payload = this.createSapPayload(batchSheetResult);
                this.batchSheetHelper
                    .generateSAPPO({
                        xmlPayload: payload,
                        PlantID: batchSheetResult.Experiment.PlantID,
                        ExpID: batchSheetResult.ExperimentID,
                        TotalParts: batchSheetResult.TotalRequirement.toFixed(batchSheetResult.Decimals),
                        UOM: batchSheetResult.UOM?.toUpperCase(),
                    })
                    .subscribe({
                        next: (response) => {
                            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                            this.toastrService.success(response.result);
                        },
                        error: (error) => {
                            this.toastrService.error("Something Went Wrong");
                            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                            this.logger.error(JSON.stringify(error));
                        },
                    });
            }
        }
    }

    // eslint-disable-next-line max-lines-per-function
    private createSapPayload(batchSheetResult: BatchSheetReturn): string {
        const ingredientTemplate = `<Ingredient><Material>IPC_CODE</Material><MaterialShortText>IPC_DESC</MaterialShortText><Sequence>SEQUENCE_NO</Sequence><MaterialQuantity>PARTS</MaterialQuantity></Ingredient>`;
        let ingredientsPayload = "";
        let count = 3;
        this.bomDetails.forEach((bom) => {
            const scaledBom = batchSheetResult.Experiment.ExperimentFormula.find((formula) => formula.ExpFormulaID === bom.ExpFormulaID);
            if (scaledBom) {
                bom.Parts = scaledBom.Parts;
                const ipc = bom.isSelected ? `${bom.SUBCode} FLAVORIST` : bom.SUBCode;
                let ingredientPayload = ingredientTemplate.replace("IPC_CODE", ipc);
                ingredientPayload = ingredientPayload.replace("IPC_DESC", bom.Description.replace("&", "_"));
                ingredientPayload = ingredientPayload.replace("SEQUENCE_NO", `00${count}`);
                ingredientPayload = ingredientPayload.replace("PARTS", `${Number(bom.Parts).toFixed(batchSheetResult.Decimals)}`);
                ingredientsPayload += ingredientPayload;
                count += 1;
            }
        });

        const processOrderTemplate = `<ProcessOrder><Material>E EXP_ID</Material><MaterialShortText>EXP_DESC</MaterialShortText>
                <ProcessOrder>PROCESS_ORDER</ProcessOrder><OrderQuantity>TOTAL_PARTS</OrderQuantity>
                <UnitOfMeasure>UOM</UnitOfMeasure><PlantFrom>PLANT_FROM</PlantFrom><PlantTo>PLANT_TO</PlantTo>
                <PerfumerName>FLAV_NAME</PerfumerName><PerfumerInitial>FLAV_INITIAL</PerfumerInitial>
                <Machine>PROD_TYPE</Machine></ProcessOrder>`;
        let processOrderPayload = processOrderTemplate.replace("EXP_ID", batchSheetResult.Experiment.ExpID.toString());
        processOrderPayload = processOrderPayload.replace("EXP_DESC", batchSheetResult.Experiment.ExpName);
        processOrderPayload = processOrderPayload.replace("TOTAL_PARTS", batchSheetResult.TotalRequirement.toString());
        processOrderPayload = processOrderPayload.replace("UOM", batchSheetResult.UOM?.toUpperCase());
        processOrderPayload = processOrderPayload.replace("PLANT_FROM", batchSheetResult.Experiment.PlantID);
        processOrderPayload = processOrderPayload.replace("PLANT_TO", batchSheetResult.Experiment.PlantID);
        processOrderPayload = processOrderPayload.replace("FLAV_NAME", this.userDetails.fullname);
        processOrderPayload = processOrderPayload.replace("FLAV_INITIAL", this.userDetails.initials);
        processOrderPayload = processOrderPayload.replace("PROD_TYPE", batchSheetResult.Experiment.ProductTypeID);
        let xmlPayload = `<?xml version="1.0" encoding="ISO-8859-1" standalone="no"?><SAMXML version="1.0"><SampleRequest>${processOrderPayload}${ingredientsPayload}</SampleRequest></SAMXML>`;
        xmlPayload = xmlPayload.replace(/</g, "&#60;");
        xmlPayload = xmlPayload.replace(/>/g, "&#62;");
        const payload = `
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pcs="http://usubwmd01.iff.com/PCSInbound">
            <soapenv:Header/>
            <soapenv:Body>
                <m:SampleMessage xmlns:m='http://usubwmd01.iff.com/PCSInbound' xmlns:A='http://schemas.xmlsoap.org/soap/encoding/' xmlns:E='http://schemas.xmlsoap.org/soap/envelope/' xmlns:s='http://www.w3.org/2001/XMLSchema-instance' xmlns:y='http://www.w3.org/2001/XMLSchema'>
                    <RequestCWB s:type='y:string'>${xmlPayload}</RequestCWB>
                </m:SampleMessage>
            </soapenv:Body>
        </soapenv:Envelope>`;
        return payload;
    }

    /**
     * Method to print BatchSheet based on the input
     *
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    private doPrintSample(): void {
        if (this.printResult.TaskDetails && this.printResult.TaskDetails.TaskID) {
            this.calcHeight =
                Math.ceil(this.canvasParamsWidth / this.assignedPrintWidth) * this.staticHeight +
                this.staticHeaderHeight +
                this.staticTaskHeight;
        }
        this.printElement.nativeElement.style.display = SAMPLE_CONST.BLOCK;
        delay(() => {
            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            this.generateSampleDocumentAndPrint();
        }, 100);
    }

    /**
     * Method to generate sample document and print
     *
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    // eslint-disable-next-line max-lines-per-function
    private generateSampleDocumentAndPrint(): void {
        const documentDefinition = this.getDocumentDefinition();
        const pdfDocumentGenerator = pdfMake.createPdf(documentDefinition, {
            mainLayout: {
                hLineWidth() {
                    return 1;
                },
                vLineWidth(index, node) {
                    return index === 0 || index === node.table.widths.length ? 1 : 0;
                },
                hLineColor() {
                    return SAMPLE_CONST.LIGHT_GRAY_1;
                },
                vLineColor() {
                    return SAMPLE_CONST.LIGHT_GRAY_1;
                },
            },
            totalLayout: {
                hLineWidth() {
                    return 0;
                },
                vLineWidth() {
                    return 0;
                },
            },
        });
        // pdfDocumentGenerator.print();
        pdfDocumentGenerator.getBase64((base64Data) => {
            const printPdfData = [
                {
                    type: "pixel",
                    format: "pdf",
                    flavor: "base64",
                    data: base64Data,
                },
            ];
            const printConfig = {
                size:
                    PAGE_SIZE_DETAILS.find(
                        (list) =>
                            list?.name ===
                            this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get(FORM_CONTROL_NAME.PAPER_SIZE).value,
                    )?.sizeCm ?? DEFAULT_PAGE_SIZE,
                units: "cm",
                scaleContent: true,
                printerTray: "Form-Source",
                copies: this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE].get("NoOfPaperCopies").value,
                // eslint-disable-next-line no-nested-ternary
                duplex: this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE].get(FORM_CONTROL_NAME.DOUBLE_SIDE_PRINT).value
                    ? this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get("SampleOrientation")?.value ===
                      SAMPLE_CONST.PORTRAIT
                        ? "long-edge"
                        : "short-edge"
                    : false,
            };
            const printResponse = this.printerService.printData(
                this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE].get(FORM_CONTROL_NAME.PAPER_PRINTER).value?.name,
                printPdfData,
                printConfig,
            );
            const sampleFormValue = this.createSampleForm.getRawValue();
            if (printResponse && !sampleFormValue?.PrintLabel?.LabelCheckbox) {
                delay(() => {
                    this.dialogReference.close();
                }, 1500);
            }
        });
        this.printElement.nativeElement.style.display = SAMPLE_CONST.NONE;
    }

    /**
     * Method to perform print label
     * @param labelResponse
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    private doPrintLabel(labelResponse: GenerateLabelResponse): void {
        const orientationType =
            this.data?.type === this.type.MAKE_SAMPLE
                ? this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_LABEL]?.get(FORM_CONTROL_NAME.LABEL_ORIENTATION)?.value
                : this.createSampleForm.get(FORM_CONTROL_NAME.LABEL_ORIENTATION).value;
        delay(() => {
            const parseData = JSON.parse(labelResponse?.Design);
            const data = parseData?.html;
            this.barcodeWidth = parseData?.barCodeWidth;
            this.barcodeHeight = parseData?.barCodeHeight;
            this.qrCodeWidth = parseData?.qrCodeWidth;
            const size = {
                width: orientationType === SAMPLE_CONST.PORTRAIT ? parseData?.size?.height : parseData?.size?.width,
                height: orientationType === SAMPLE_CONST.PORTRAIT ? parseData?.size?.width : parseData?.size?.height,
            };
            if (data) {
                delay(() => {
                    this.generateLabelTemplateAndPrint(data, size, orientationType);
                }, 500);
            }
        }, 50);
    }

    /**
     * Method to generate label template and print
     * @param {string} data
     * @param {{ width: number; height: number }} size
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    private generateLabelTemplateAndPrint(data: string, size: { width: number; height: number }, orientationType: string): void {
        let template = data;
        template = template.replace(SAMPLE_CONST.BAR_CODE_TEMPLATE, this.barcodeLabel.bcElement.nativeElement.innerHTML);
        template = template.replace(SAMPLE_CONST.QR_CODE_TEMPLATE, this.qrcodeLabel.qrcElement.nativeElement.innerHTML);
        const printLabelData = [
            {
                type: SAMPLE_CONST.PIXEL,
                format: SAMPLE_CONST.HTML,
                flavor: SAMPLE_CONST.PLAIN,
                data: template,
            },
        ];
        const labelCopies =
            this.data?.type === this.type?.MAKE_SAMPLE
                ? this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_LABEL].get(FORM_CONTROL_NAME.NO_OF_LABEL_COPIES).value
                : this.createSampleForm.controls[FORM_CONTROL_NAME.NO_OF_LABEL_COPIES].value;
        const labelPrinter =
            this.data?.type === this.type?.MAKE_SAMPLE
                ? this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_LABEL].get(FORM_CONTROL_NAME.LABEL_PRINTER).value?.name
                : this.createSampleForm.controls[FORM_CONTROL_NAME.LABEL_PRINTER].value?.name;
        const printConfig = {
            size,
            units: SAMPLE_CONST.UNIT_CM,
            scaleContent: true,
            printerTray: SAMPLE_CONST.FORM_SOURCE,
            orientation: orientationType,
            copies: labelCopies,
            colorType: "blackwhite",
        };
        const printResponse = this.printerService.printData(labelPrinter, printLabelData, printConfig);
        if (printResponse && this.data?.type === this.type?.MAKE_SAMPLE) {
            delay(() => {
                this.dialogReference.close();
            }, 1500);
        }
        this.appBroadCastService?.onUpdateAppSpinnerPrompt(EMPTY);
    }

    /**
     * Method to get document definition
     *
     * @memberof CreateSampleComponent
     */
    private getDocumentDefinition() {
        const paperType = this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get(FORM_CONTROL_NAME.PAPER_SIZE)?.value;
        const documentDefinition = {
            pageSize: paperType === SAMPLE_CONST.PAGE_A4 ? undefined : PAGE_SIZE_DETAILS.find((list) => list?.name === paperType)?.sizePx,
            pageOrientation: this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get("SampleOrientation")?.value,
            defaultStyle: {
                font: SAMPLE_CONST.NUNITO_SANS,
            },
            styles: this.getPrintStyles(),
            imagesByReference: true,
            pageMargins: [25, this.calcHeight || 5, 25, 40],
            content: htmlToPdfmake(this.printBody.nativeElement.innerHTML),
            images: {
                barCode: this.barcode.bcElement.nativeElement.children[0].src,
                qrCode: this.qrcode.qrcElement.nativeElement.children[0].src,
            },
            header: (currentPage) => {
                return this.getHeaderSection(currentPage);
            },
            footer: (currentPage, pageCount) => {
                return {
                    margin: [25, 5, 25, 10],
                    columns: [
                        {
                            text: SAMPLE_CONST.FOOTER,
                            width: 470,
                            style: SAMPLE_CONST.FOOTER_DESC,
                        },
                        {
                            text: `Page ${currentPage.toString()} of ${pageCount}`,
                            alignment: SAMPLE_CONST.RIGHT,
                            style: SAMPLE_CONST.FOOTER_COUNT,
                        },
                    ],
                };
            },
        };
        return documentDefinition;
    }

    /**
     * Method to get print styles
     *
     * @memberof CreateSampleComponent
     */
    // eslint-disable-next-line max-lines-per-function
    private getPrintStyles = () => {
        const isA4Paper =
            this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get(FORM_CONTROL_NAME.PAPER_SIZE)?.value ===
            SAMPLE_CONST.PAGE_A4;
        return {
            [SAMPLE_CONST.HTML_P]: {
                color: SAMPLE_CONST.GRAY,
                fontSize: 9,
                bold: true,
            },
            [SAMPLE_CONST.HTML_SPAN]: {
                color: SAMPLE_CONST.BLACK,
                fontSize: isA4Paper ? 11 : 14,
                bold: true,
            },
            expcodevalue: {
                color: SAMPLE_CONST.BLACK,
                fontSize: isA4Paper ? 15 : 18,
                bold: true,
            },
            barcodevalue: {
                width: 80,
                color: SAMPLE_CONST.BLACK,
                fontSize: 14,
                bold: true,
                alignment: "center",
            },
            headerdesc: {
                lineHeight: 1,
                marginBottom: 0,
                wordBreak: "break-word",
            },
            mainlayoutValueOne: {
                fontSize: isA4Paper ? 11 : 14,
                color: SAMPLE_CONST.DARK_GRAY,
                bold: false,
                marginLeft: 8,
                marginRight: 2,
            },
            mainlayoutValueNotInst: {
                fontSize: isA4Paper ? 11 : 14,
                color: SAMPLE_CONST.DARK_GRAY,
                bold: false,
            },
            mainlayoutValueInst: {
                fontSize: isA4Paper ? 11 : 14,
                color: SAMPLE_CONST.DARK_GRAY,
                bold: this.isInstructionBold,
            },
            mainlayoutValueThree: {
                fontSize: isA4Paper ? 11 : 14,
                color: SAMPLE_CONST.DARK_GRAY,
                bold: false,
                marginRight: 10,
            },
            totallayoutlabel: {
                lineHeight: 0,
                padding: [0, 0, 0, 0],
                marginTop: 0,
                marginBottom: 0,
            },
            totallayoutlabelHint: {
                fontSize: 10,
                lineHeight: 0,
                padding: [0, 0, 0, 0],
                marginTop: 0,
                marginBottom: 0,
            },
            totallayoutvalue: {
                color: SAMPLE_CONST.BLACK,
                lineHeight: 0.5,
                fontSize: 12,
                bold: true,
                padding: [0, 0, 0, 0],
                marginTop: 0,
                marginBottom: 0,
            },
            notessec: {
                padding: [5, 0, 5, 0],
            },
            notessectitle: {
                color: SAMPLE_CONST.GRAY,
                fontSize: 9,
                bold: true,
                marginBottom: 0.4,
            },
            notessecdesc: {
                color: SAMPLE_CONST.BLACK,
                fontSize: 10,
                bold: false,
                lineHeight: 1,
                marginBottom: 1,
            },
            notessectimeline: {
                color: SAMPLE_CONST.GRAY,
                fontSize: 9,
                bold: false,
                lineHeight: 1,
            },
            footerDesc: {
                color: SAMPLE_CONST.GRAY,
                fontSize: 8,
            },
            footerCount: {
                color: SAMPLE_CONST.LIGHT_GRAY,
                fontSize: 10,
                bold: true,
            },
        };
    };

    /**
     * Method to get header section
     *
     * @memberof CreateSampleComponent
     */
    private getHeaderSection(currentPage) {
        return [
            this.getHeaderSection1(currentPage),
            this.getHeaderSection2(),
            this.getHeaderSection3(),
            this.getHeaderSection4(),
            {
                margin: [25, 8, 25, 8],
                columnGap: 7,
                columns: [
                    {
                        text: htmlToPdfmake(this.printHeader4.nativeElement.innerHTML),
                        alignment: SAMPLE_CONST.LEFT,
                    },
                ],
            },
            {
                margin: [25, 0, 25, 0],
                columnGap: 7,
                columns: [
                    {
                        text: htmlToPdfmake(this.printHeader5.nativeElement.innerHTML),
                        alignment: SAMPLE_CONST.LEFT,
                    },
                ],
            },
            {
                margin: [25, -12, 25, 1],
                columnGap: 7,
                columns: [
                    {
                        text: htmlToPdfmake(this.printHeader6.nativeElement.innerHTML),
                        alignment: SAMPLE_CONST.RIGHT,
                        width: "100%",
                    },
                ],
            },
        ];
    }

    /**
     * Method to get header section
     *
     * @memberof CreateSampleComponent
     */
    private getHeaderSection1(currentPage) {
        const marginTop =
            currentPage % 2 === 0 &&
            this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get(FORM_CONTROL_NAME.PAPER_SIZE)?.value ===
                SAMPLE_CONST.PAGE_FS &&
            this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get(FORM_CONTROL_NAME.SAMPLE_ORIENTATION)?.value ===
                SAMPLE_CONST.PORTRAIT &&
            this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get(FORM_CONTROL_NAME.DOUBLE_SIDE_PRINT)?.value === true &&
            this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE]?.get(FORM_CONTROL_NAME.PAPER_PRINTER)?.value?.name !==
                SAMPLE_CONST.PDF
                ? 60
                : 15;
        return {
            margin: [25, marginTop, 25, 0],
            columnGap: 7,
            columns: [
                {
                    text: htmlToPdfmake(this.printHeaderLabel2.nativeElement.innerHTML),
                    width: 285,
                },
                {
                    text: "",
                    width: "*",
                },
                {
                    text: htmlToPdfmake(this.printHeaderLabel3.nativeElement.innerHTML),
                    width: 170,
                },
                {
                    text: "",
                    width: 70,
                },
            ],
        };
    }

    /**
     * Method to get header section
     *
     * @memberof CreateSampleComponent
     */
    private getHeaderSection2() {
        return {
            margin: [25, 1, 25, 0],
            columnGap: 7,
            columns: [
                {
                    text: htmlToPdfmake(this.printHeaderValue2.nativeElement.innerHTML),
                    width: 285,
                },
                {
                    text: "",
                    width: "*",
                },
                {
                    image: SAMPLE_CONST.BAR_CODE,
                    width: 170,
                    height: 42,
                    margin: [-4, -4, 0, 0],
                },
                {
                    image: SAMPLE_CONST.QR_CODE,
                    width: 70,
                    margin: [0, -18, 0, 0],
                },
            ],
        };
    }

    /**
     * Method to get header section
     *
     * @memberof CreateSampleComponent
     */
    private getHeaderSection3() {
        return {
            margin: [25, -23, 35, 0],
            columns: [
                {
                    text: "",
                    width: 285,
                },
                {
                    text: "",
                    width: "*",
                },
                {
                    text: htmlToPdfmake(this.printHeader7.nativeElement.innerHTML),
                    width: 170,
                    margin: [4, 2, 0, 0],
                },
                {
                    text: "",
                    width: 70,
                },
            ],
        };
    }

    /**
     * Method to get header section
     *
     * @memberof CreateSampleComponent
     */
    private getHeaderSection4() {
        return {
            margin: [25, -20, 35, 0],
            columns: [
                {
                    text: htmlToPdfmake(this.printHeader3.nativeElement.innerHTML),
                    width: 100,
                    margin: [0, -2, 0, 0],
                },
                {
                    text: htmlToPdfmake(this.entityHeader.nativeElement.innerHTML),
                    width: 360,
                    margin: [0, -2, 0, 0],
                },
            ],
        };
    }

    /**
     * Method to perform the sorting based on the input
     *
     * @param {string} sortType
     * @param {BatchSheetReturn} batchSheetValues
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public sortOrderBasedonInput(batchSheetValues: BatchSheetReturn, selectedBomSort: string): void {
        const sortType = CREATE_SAMPLE_SORT_OPTIONS.find((sort) => sort?.displayValue === selectedBomSort)?.value;
        let experimentFormula = batchSheetValues?.Experiment?.ExperimentFormula;
        const batchSheet = batchSheetValues;
        experimentFormula = experimentFormula?.filter((experiment) => {
            return experiment.SUBType !== BOM_TYPE.INSTRUCTION;
        });
        switch (sortType) {
            case DEFAULT_SORT:
            case SORT_BY_NATURAL_ORDER_IN_BOLD: {
                this.printResult = batchSheet;
                this.isInstructionBold = sortType === SORT_BY_NATURAL_ORDER_IN_BOLD;

                break;
            }
            case SORT_BY_DESCRIPTION: {
                const sortedexperimentFormula = orderBy(experimentFormula, [BOM_DETAILS_CONSTANTS.INSTRUCTION], ["asc"]);
                batchSheet.Experiment.ExperimentFormula = sortedexperimentFormula;
                this.printResult = Object.assign(this.printResult, batchSheet);

                break;
            }
            case SORT_BY_ID: {
                const sortedexperimentFormula = orderBy(experimentFormula, [SUB_CODE], ["asc"]);
                batchSheet.Experiment.ExperimentFormula = sortedexperimentFormula;
                this.printResult = Object.assign(this.printResult, batchSheet);

                break;
            }
            default: {
                const sortedexperimentFormula = orderBy(experimentFormula, [PARTS], ["desc"]);
                batchSheet.Experiment.ExperimentFormula = sortedexperimentFormula;
                this.printResult = Object.assign(this.printResult, batchSheet);
            }
        }
    }

    /**
     * To change number format with comma and decimals
     *
     * @param {number} value
     * @returns {string}
     * @memberof CreateSampleComponent
     */
    public changeNumberFormat = (value: number): string => {
        return (+value).toLocaleString("en", {
            minimumFractionDigits: this.printResult.Decimals,
            maximumFractionDigits: this.printResult.Decimals,
        });
    };

    /**
     * Method to Validate ExpCode or ID field
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public OnValidateExperiment = (): void => {
        let payload;
        this.createSampleForm.controls.ExperimentID.valueChanges
            .pipe(
                filterRxjs((value: string) => {
                    const expCodeOrId = value?.trim();
                    this.experiment = {} as CreateSampleModel;
                    if (
                        !expCodeOrId ||
                        this.experiment?.expID === expCodeOrId ||
                        this.experiment?.ExpID === expCodeOrId ||
                        this.experiment?.ExpCode === expCodeOrId
                    ) {
                        return false;
                    }
                    if (expCodeOrId.length === IPC_EXPCODE_LENGTH.EXP_CODE_LENGTH && !isNumber(value)) {
                        payload = { expCode: expCodeOrId };
                    } else if (expCodeOrId.length === IPC_EXPCODE_LENGTH.EXP_ID_LENGTH && isNumber(+value)) {
                        payload = { expID: +expCodeOrId };
                    }
                    if (!payload?.expCode && !payload?.expID && expCodeOrId !== EMPTY) {
                        this.createSampleForm.controls[this.headerFields.EXPERIMENT_ID].setErrors({ inValidCode: true });
                    }
                    return !!(payload?.expCode || payload?.expID);
                }),
                debounceTime(500),
                switchMap(() => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
                    return this.batchSheetHelper.validateExpCode(payload);
                }),
            )
            .subscribe({
                next: (result) => {
                    if (result) {
                        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                        this.onValidateExperimentAccess(result);
                    }
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            });
    };

    /**
     * Method to Validate Experiment access
     * @param result
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    private onValidateExperimentAccess(result) {
        if (result?.message) {
            this.createSampleForm.controls[this.headerFields.EXPERIMENT_ID].setErrors({ inValidCode: true });
            return;
        }
        this.experiment = result;
        const accessInfo = this.experimentAccessHelper.getExperimentAccessCheck(
            [this.experiment],
            Number(this.userDetails?.sapempid),
            EXPERIMENT_ACCESS.PRINT_SCREEN,
        );
        if (accessInfo.isPermitted) {
            if (accessInfo?.AccessDetail?.length > 0 && accessInfo.AccessDetail[0].Lock === PERMISSION_CATEGORY_CONSTANT.UNLOCKED) {
                this.createSampleForm.controls[this.headerFields.EXPERIMENT_ID].setErrors({ unLocked: true });
            } else {
                this.createSampleForm.controls[this.headerFields.EXPERIMENT_ID].setValidators([]);
            }
        } else if (!accessInfo?.isPermitted) {
            if (accessInfo?.AccessDetail?.length > 0 && accessInfo.AccessDetail[0].AccessList === PERMISSION_CATEGORY_CONSTANT.NOT_MEMBER) {
                this.createSampleForm.controls[this.headerFields.EXPERIMENT_ID].setErrors({ noAccess: true });
            } else if (accessInfo?.AccessDetail?.length > 0 && accessInfo.AccessDetail[0].Lock === PERMISSION_CATEGORY_CONSTANT.UNLOCKED) {
                this.createSampleForm.controls[this.headerFields.EXPERIMENT_ID].setErrors({ unLocked: true });
            }
        }
        this.getBomdetails();
    }

    /**
     * Method to open warning dialog
     * @param {string} message
     * @param {string} formControl
     * @param {string} formGroup
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public openDialog(message: string, formControl: string, formGroup?: string): void {
        SAMPLE_CONFIRMATION.data.message = message;
        const dialogReferenceForSamplePopup = this.dialog.open(ConfirmationDialogComponent, SAMPLE_CONFIRMATION);
        dialogReferenceForSamplePopup.afterClosed().subscribe((sampleConfirmation) => {
            if (!sampleConfirmation) {
                let value;
                if (formControl === FORM_CONTROL_NAME.NO_OF_PAPERCOPIES) {
                    value = SAMPLE_DEFAULT_VALUE.PAPER_COPIES;
                } else if (formControl === FORM_CONTROL_NAME.NO_OF_LABEL_COPIES) {
                    value = SAMPLE_DEFAULT_VALUE.LABEL_COPIES;
                }
                this.setFormControlValue(formControl, formGroup, value);
            }
            dialogReferenceForSamplePopup.close();
        });
    }

    /**
     * Method to enabel or disable fields based on checkbox selection
     *
     * @param {string} formGroup
     * @param {string} formControl
     * @param {MatCheckboxChange} [event]
     * @param {checkboxStatus} [boolean]
     * @memberof CreateSampleComponent
     */
    public onSelectCheckbox(formGroup: string, formControl: string, event?: MatCheckboxChange, checkboxStatus?: boolean): void {
        const isChecked = checkboxStatus || event?.checked;
        const form = this.createSampleForm.controls[formGroup];

        Object.keys((form as FormGroup).controls).forEach((controlName) => {
            if (controlName === FORM_CONTROL_NAME.PRODUCT_LIST) {
                this.bomDetails = this.bomDetails?.map((item) => {
                    const bomItem = item;
                    bomItem.Disabled = !isChecked;
                    return bomItem;
                });
            }
            if (!isChecked && controlName !== formControl) {
                form.get(controlName).disable();
                form.get(formControl).setValidators([]);
            }
            if (isChecked && controlName !== formControl) {
                form.get(controlName).enable();
                form.get(formControl).setValidators([Validators.required]);
            }
        });
        this.handleCheckboxClass(formControl, isChecked);
    }

    /**
     * Method to show warning dialog based on fields
     * @param value
     * @param {string} formControl
     * @param {string} formValue
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public showWarningDialog(value, formControl: string, formGroup?: string): void {
        let warningMessage;
        if (value === EMPTY && formControl === FORM_CONTROL_NAME.NO_OF_PAPERCOPIES) {
            this.createSampleForm.patchValue({ PrintSample: { NoOfPaperCopies: 1 } });
            return;
        }
        if (value === EMPTY && formControl === FORM_CONTROL_NAME.DECIMAL_PRINTER) {
            this.createSampleForm.patchValue({ PrintSample: { DecimalPrinter: 3 } });
            return;
        }
        if (value === EMPTY && formControl === FORM_CONTROL_NAME.NO_OF_LABEL_COPIES) {
            this.createSampleForm.patchValue({ PrintSample: { NoOfLabelCopies: 1 } });
            return;
        }
        this.validateRangeValues(value, formControl, warningMessage, formGroup);
    }

    /**
     * Method to validate range values
     * @param {number} number
     * @param {string} formControl
     * @param {string} message
     * @param {string} formGroup
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    private validateRangeValues(value, formControl: string, message: string, formGroup: string): void {
        let warningMessage = message;
        if (value > 3 && value <= 20 && formControl === FORM_CONTROL_NAME.NO_OF_SAMPLES) {
            warningMessage = SAMPLE_CONST.THREE_SAMPLES;
        } else if (value > 1000 && value <= 100_000 && formControl === FORM_CONTROL_NAME.REQUIRED_SAMPLESIZE) {
            warningMessage = `More than 1000 ${this.createSampleForm.controls.UOM.value} were requested.  Do you want to proceed ?`;
        } else if (value > 3000 && value <= 2_000_000 && formControl === FORM_CONTROL_NAME.TOTAL_REQUIREMENT) {
            warningMessage = `More than 3000 ${this.createSampleForm.controls.UOM.value} were requested.  Do you want to proceed ?`;
        } else if (value > 3 && value <= 10 && formControl === FORM_CONTROL_NAME.NO_OF_PAPERCOPIES) {
            warningMessage = `More than 3 copies of the sample sheet will be printed.  Do you want to proceed ?`;
        } else if (value > 3 && value <= 20 && formControl === FORM_CONTROL_NAME.NO_OF_LABEL_COPIES) {
            warningMessage = `More than 3 copies of the label will be printed.  Do you want to proceed ?`;
        }
        if (warningMessage) this.openDialog(warningMessage, formControl, formGroup);
    }

    /**
     * Method to handle tab focus after click last field
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public tabFunction(): void {
        this.experimentID.nativeElement.focus();
    }

    /**
     * Method to get the bom details
     * @returns {void}
     * @memberof CreateSampleComponent
     */
    public getBomdetails(): void {
        const expID = this.experiment?.ExpID || this.experiment?.expId;
        const payload = { expIds: [expID], ipcs: [] };
        this.gridApiService.getBomDetails(payload).subscribe({
            next: (result) => {
                const activeExperiment = result?.Experiments?.find((data) => data?.ExpID === expID);
                this.disableSAPPO = !this.sapPoPlants.includes(activeExperiment?.PlantID);
                if (
                    this.disableSAPPO &&
                    this.createSampleForm.controls[FORM_CONTROL_NAME.CREATE_SAP_PO]?.get(FORM_CONTROL_NAME.SAP_PO_CHECKBOX)?.value
                ) {
                    this.createSampleForm.controls[FORM_CONTROL_NAME.CREATE_SAP_PO].get(FORM_CONTROL_NAME.SAP_PO_CHECKBOX).setValue(false);
                }
                let ipcValues = activeExperiment?.ExperimentFormula?.map((element) => {
                    if (element.SUBType === SUBTypes.PRODUCT) {
                        return element.SUBCode;
                    }
                    return EMPTY;
                });
                ipcValues = filter(uniq(ipcValues));
                this.appCacheHelper.getAttributesFromCache(ipcValues).subscribe((ipcResult) => {
                    let attributes = ipcResult;
                    const cachedIPCs = map(ipcResult, IPC_MAPPING);
                    if (isEqual(cachedIPCs, ipcValues)) {
                        this.formatBomItems(result, attributes);
                    } else {
                        const apiPayload = this.createPayload(ipcValues, cachedIPCs);
                        this.gridApiService
                            .loadAttributesFromAPI(apiPayload)
                            .pipe(take(1))
                            .subscribe((attributesFromApi) => {
                                // eslint-disable-next-line unicorn/prefer-spread
                                attributes = attributes.concat(attributesFromApi);
                                this.formatBomItems(result, attributes);
                            });
                    }
                });
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.toastrService.error(EXPERIMENT_FORMULA_ERRORS.BOMDETAILS_FETCH_ISSUE);
                this.errorFormatService.logFormattedError(EXPERIMENT_FORMULA_ERRORS.BOMDETAILS_FETCH_ISSUE, error);
            },
        });
    }

    /**
     * Method to format the bom details
     * @param result
     * @param attributes
     * @memberof CreateSampleComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public formatBomItems(result, attributes): void {
        forEach(result.Experiments[0].ExperimentFormula, (data) => {
            // eslint-disable-next-line unicorn/prefer-switch
            if (data.SUBType === BOM_TYPE.EXPERIMENT) {
                const experiment = result.Experiments.find((item) => item.ExpID.toString() === data.SUBCode);
                this.bomDetails.push({
                    SUBCode: experiment?.ExpID.toString(),
                    ExpFormulaID: data.ExpFormulaID,
                    Description: experiment?.ExpName,
                    Disabled: true,
                });
            } else if (data.SUBType === BOM_TYPE.PRODUCT) {
                const product = attributes.find((item) => item?.ipc === data.SUBCode);
                this.bomDetails.push({
                    SUBCode: product?.ipc,
                    ExpFormulaID: data.ExpFormulaID,
                    Description: product?.description,
                    Disabled: true,
                });
            } else if (data.SUBType === BOM_TYPE.UNAPPROVED) {
                this.bomDetails.push({
                    SUBCode: data?.SUBCode,
                    ExpFormulaID: data.ExpFormulaID,
                    Description: data?.UnapprovedDescription,
                    Disabled: true,
                });
            }
        });
    }

    /**
     * To get the canvasWidth Experiment Discription and print header height
     * @returns {void}
     * @memberof CreateSampleComponent
     *
     */
    public canvasWidth(): void {
        // eslint-disable-next-line angular/document-service
        const context = document.createElement("canvas").getContext("2d");
        context.font = this.fontStyle;
        this.canvasParamsWidth = Math.ceil(context.measureText(this.data?.experimentName).width);
        this.calcHeight = Math.ceil(this.canvasParamsWidth / this.assignedPrintWidth) * this.staticHeight + this.staticHeaderHeight;
    }

    /**
     * Method to get sample sheet details
     * @returns {void}
     * @memberof CreateSampleComponent
     *
     */
    public getSampleSheet(): void {
        this.sampleCacheValue = AppStateService.getRequestSampleRememberData();
        if (this.sampleCacheValue) {
            this.setCacheFormValue();
            this.setCachePrinterValue();
        } else {
            this.batchSheetHelper.getSample().subscribe({
                next: (sampleSheetData: SampleResponse) => {
                    const requestSampleData: CreateSampleRememberData = {
                        SampleCount: sampleSheetData?.SampleCount,
                        SampleSize: sampleSheetData?.SampleSize,
                        UOM: sampleSheetData?.SampleUOMcode,
                        YieldToggle: sampleSheetData?.YieldToggle,
                        Decimals: sampleSheetData?.DecPlaces,
                        BomSortOrder: sampleSheetData?.BomSortOrder,
                        PaperSize: sampleSheetData?.PaperSize,
                        PaperPrinter: sampleSheetData?.PaperPrinter,
                        LabelTemplate: sampleSheetData?.LabelTemplate,
                        LabelPrinter: sampleSheetData?.LabelPrinter,
                        LabelOrientation: sampleSheetData?.LabelOrientation,
                        SampleOrientation: sampleSheetData?.SampleOrientation,
                        IsPrintSampleChecked: sampleSheetData?.IsPrintSampleChecked,
                        IsLabelChecked: sampleSheetData?.IsLabelChecked,
                        IsDoubleSidePrint: sampleSheetData?.IsDoubleSidePrint,
                    };
                    this.sampleCacheValue = requestSampleData;
                    this.setCacheFormValue();
                    this.setCachePrinterValue();
                    AppStateService.setRequestSampleRememberData(requestSampleData);
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            });
        }
    }

    /**
     * Method to handle checkbox class
     * @param {string} checkBoxName
     * @param {boolean} isEnable
     * @memberof CreateSampleComponent
     */
    public handleCheckboxClass(checkBoxName: string, isEnable: boolean): void {
        // eslint-disable-next-line default-case
        switch (checkBoxName) {
            case FORM_CONTROL_NAME.SAMPLE_CHECKBOX: {
                this.isEnablePrintCheckBox = isEnable;
                break;
            }
            case FORM_CONTROL_NAME.LABEL_CHECKBOX: {
                this.isEnableLabelCheckBox = isEnable;
                break;
            }
            case FORM_CONTROL_NAME.SAP_PO_CHECKBOX: {
                this.isEnableSAPPOCheckBox = isEnable;
                break;
            }
            // No default
        }
        this.isChecked = !(!this.isEnablePrintCheckBox && !this.isEnableLabelCheckBox && !this.isEnableSAPPOCheckBox);
    }

    /**
     * Method to validate number field
     * @param {KeyboardEvent} event
     * @memberof CreateSampleComponent
     */
    public OnValidateNumberEntering = (event: KeyboardEvent, formControl: string, formGroup?: string): void => {
        if (event.target[KEY_BOARD_EVENTS.SELECTION_START] === 0 && event.key === "0" && formControl !== FORM_CONTROL_NAME.SAMPLE_ID) {
            event.preventDefault();
        }
        if (SPECIAL_CHARACTER_FORMAT.test(event.key) || ALPHABETS_FORMAT.test(event.key) || event.key === " ") {
            event.preventDefault();
        }
        if (formControl) {
            const formValue = this.getFormControlValue(formControl, formGroup);
            // eslint-disable-next-line unicorn/prefer-spread
            const value = formValue ? formValue.toString().concat(event.key) : event.key;
            if (this.isExceedRangeValidation(formControl, Number(value?.trim()))) {
                event.preventDefault();
            }
        }
    };

    /**
     * Method to set the formControl values
     * @param {string} formControl
     * @param {string} formGroup
     * @param {number} string
     * @memberof CreateSampleComponent
     */
    public setFormControlValue(formControl: string, formGroup: string, value: number): void {
        if (this.isExceedRangeValidation(formControl, value)) return;
        if (formGroup) {
            this.createSampleForm.controls[formGroup].get(formControl).setValue(value);
        } else {
            this.createSampleForm.get(formControl).setValue(value);
        }
    }

    /**
     * Method to get the formControl values
     * @param {string} formControl
     * @param {string} formGroup
     * @memberof CreateSampleComponent
     */
    public getFormControlValue(formControl: string, formGroup: string): number {
        if (!formGroup) {
            return this.createSampleForm.get(formControl)?.value;
        }
        return this.createSampleForm.controls[formGroup].get(formControl)?.value;
    }

    /**
     * Method to set cache form value
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    public setCacheFormValue(): void {
        this.experiment = this.data;
        if (this.sampleCacheValue) {
            const formValue = {
                [FORM_CONTROL_NAME.NO_OF_SAMPLES]: this.sampleCacheValue?.SampleCount,
                [FORM_CONTROL_NAME.REQUIRED_SAMPLESIZE]: this.sampleCacheValue?.SampleSize?.toFixed(REQUIRED_SAMPLE_SIZE.DECIMAL_LENGTH),
                [FORM_CONTROL_NAME.YIELD_TOGGLE]: this.sampleCacheValue?.YieldToggle,
                PrintSample: {
                    [FORM_CONTROL_NAME.DECIMAL_PRINTER]: this.sampleCacheValue?.Decimals || SAMPLE_DEFAULT_VALUE.DECIMAL_PRINTER,
                    [FORM_CONTROL_NAME.BOM_SORT_ORDER]: this.sampleCacheValue?.BomSortOrder,
                    [FORM_CONTROL_NAME.SAMPLE_CHECKBOX]: this.sampleCacheValue?.IsPrintSampleChecked,
                    [FORM_CONTROL_NAME.PAPER_SIZE]: this.sampleCacheValue?.PaperSize || SAMPLE_CONST.PAGE_LETTER,
                    [FORM_CONTROL_NAME.DOUBLE_SIDE_PRINT]: this.sampleCacheValue?.IsDoubleSidePrint,
                    [FORM_CONTROL_NAME.SAMPLE_ORIENTATION]: this.sampleCacheValue?.SampleOrientation || SAMPLE_CONST.PORTRAIT,
                },
                [FORM_CONTROL_NAME.PRINT_LABEL]: {
                    [FORM_CONTROL_NAME.LABEL_CHECKBOX]: this.sampleCacheValue?.IsLabelChecked,
                },
            };
            // Check if LabelTemplate exists in labelTemplates array
            if (this.sampleCacheValue?.LabelTemplate) {
                const labelTemplate = this.labelTemplates?.find((label) => label.LabelName === this.sampleCacheValue?.LabelTemplate);
                if (labelTemplate) {
                    this.selectedLabelTemplate = labelTemplate;
                    formValue[FORM_CONTROL_NAME.PRINT_LABEL][FORM_CONTROL_NAME.LABEL_TEMPLATE] = labelTemplate;
                }
            }
            // Check if LabelOrientation exists in labelOrientation array
            if (this.sampleCacheValue?.LabelOrientation) {
                const labelOrientation = this.labelOrientation?.find(
                    (label) => label.orientationType === this.sampleCacheValue?.LabelOrientation,
                );
                if (labelOrientation) {
                    formValue[FORM_CONTROL_NAME.PRINT_LABEL][FORM_CONTROL_NAME.LABEL_ORIENTATION] = labelOrientation?.orientationType;
                }
            }
            this.createSampleForm.patchValue(formValue);
        }
        this.setUOM();
        this.setYield();
        this.validateAndDisableForm();
        this.totalRequirement();
    }

    /**
     * Method to validate IsLabelChecked and  IsPrintSampleChecked to DisableForm
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    private validateAndDisableForm() {
        if (this.sampleCacheValue?.IsLabelChecked !== undefined) {
            this.onSelectCheckbox(
                this.headerFields.PRINT_LABEL,
                this.headerFields.LABEL_CHECKBOX,
                undefined,
                this.sampleCacheValue?.IsLabelChecked,
            );
        }
        if (this.sampleCacheValue?.IsPrintSampleChecked !== undefined) {
            this.onSelectCheckbox(
                this.headerFields.PRINT_SAMPLE,
                this.headerFields.SAMPLE_CHECKBOX,
                undefined,
                this.sampleCacheValue?.IsPrintSampleChecked,
            );
        }
    }

    /**
     * Method to validate YieldToggle to  Disable YIELD toggle
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    private setYield() {
        if (!this.sampleCacheValue?.YieldToggle) {
            this.createSampleForm.controls.Yield.patchValue(DEFAULT_YIELD_VALUE?.toFixed(YIELD_VALUES.DECIMAL_LENGTH));
            this.createSampleForm.get(FORM_CONTROL_NAME.YIELD).disable();
        }
    }

    /**
     * Method to validate UOM
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    private setUOM() {
        if (this.sampleCacheValue?.UOM) {
            const uomValue = this.uomData?.find((uom) => uom.uomdisplay === this.sampleCacheValue?.UOM);
            if (uomValue) {
                this.uomChangeValue = this.sampleCacheValue?.UOM;
                this.createSampleForm.get(FORM_CONTROL_NAME.UOM).setValue(this.sampleCacheValue.UOM);
            }
        }
    }

    /**
     * Method to set cache value for paper and label printer
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    public setCachePrinterValue(): void {
        if (
            (!this.sampleCacheValue?.PaperPrinter && this.paperPrinters.length === 0) ||
            (!this.sampleCacheValue?.LabelPrinter && this.labelPrinters.length === 0)
        ) {
            return;
        }
        if (this.sampleCacheValue?.PaperPrinter) {
            const paperPrinter = this.paperPrinters?.find((printer) => printer.name === this.sampleCacheValue?.PaperPrinter);
            if (paperPrinter) {
                this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_SAMPLE].get(FORM_CONTROL_NAME.PAPER_PRINTER).setValue(paperPrinter);
            }
        }
        if (this.sampleCacheValue?.LabelPrinter) {
            const labelPrinter = this.labelPrinters?.find((printer) => printer.name === this.sampleCacheValue?.LabelPrinter);
            if (labelPrinter) {
                this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_LABEL].get(FORM_CONTROL_NAME.LABEL_PRINTER).setValue(labelPrinter);
            }
        }
    }

    /**
     * Method to select label template change
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    public onLabelTemplateChange(event: LabelTemplateResponse): void {
        this.selectedLabelTemplate = event;
    }

    /**
     * Method to check the validation if field value exceed their range
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    public isExceedRangeValidation = (formControl: string, value: number): boolean => {
        return !!(
            (formControl === FORM_CONTROL_NAME.NO_OF_SAMPLES && value > 20) ||
            (formControl === FORM_CONTROL_NAME.NO_OF_PAPERCOPIES && value > 10) ||
            (formControl === FORM_CONTROL_NAME.NO_OF_LABEL_COPIES && value > 20) ||
            (formControl === FORM_CONTROL_NAME.DECIMAL_PRINTER && value > 4)
        );
    };

    /**
     * Method to get Label templates
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    public getLabelTemplate(): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.batchSheetHelper.getLabelTemplate().subscribe({
            next: (response) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.labelTemplates = response;
                if (this.data?.type !== this.type.REPRINT_LABEL) {
                    this.getSampleSheet();
                }
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to generate Label template
     * @param {BatchSheetReturn} batchSheetResult
     * @return {void}
     * @memberof CreateSampleComponent
     *
     */
    public generateLabelTemplate(batchSheetResult: BatchSheetReturn): void {
        const labelNamePrintType =
            this.data.type === this.type.REPRINT_LABEL
                ? this.createSampleForm.get(FORM_CONTROL_NAME.LABEL_TEMPLATE).value?.LabelName
                : this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_LABEL].get(FORM_CONTROL_NAME.LABEL_TEMPLATE).value?.LabelName;
        const payload: LabelTemplatePayload = {
            ExpCode: batchSheetResult.Experiment?.ExpCode,
            ExpID: batchSheetResult.Experiment?.ExpID,
            ExpName: batchSheetResult.Experiment?.ExpName,
            LabelNote: this.createSampleForm.get(FORM_CONTROL_NAME.CUSTOM_NOTE).value,
            Manufacture: this.sampleDetails?.CreatedOn
                ? moment(new Date(this.sampleDetails.CreatedOn)).format(DATE_FORMAT.DISPLAY_FORMAT).toString()
                : moment(new Date()).format(DATE_FORMAT.DISPLAY_FORMAT).toString(),
            Expiry: this.sampleDetails?.CreatedOn
                ? moment(this.sampleDetails.CreatedOn).add(180, "days").format(DATE_FORMAT.DISPLAY_FORMAT).toString()
                : moment().add(180, "days").format(DATE_FORMAT.DISPLAY_FORMAT).toString(),
            LabelName: this.selectedLabelTemplate?.LabelName,
            LabelID: this.selectedLabelTemplate?.LabelID,
            SampleID: batchSheetResult.SampleID?.toString(),
            LabelPrinter:
                this.data.type === this.type.REPRINT_LABEL
                    ? this.createSampleForm.get(FORM_CONTROL_NAME.LABEL_PRINTER).value?.name
                    : this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_LABEL].get(FORM_CONTROL_NAME.LABEL_PRINTER).value?.name,
            LabelOrientation:
                this.data.type === this.type.REPRINT_LABEL
                    ? this.createSampleForm.get(FORM_CONTROL_NAME.LABEL_ORIENTATION)?.value
                    : this.createSampleForm.controls[FORM_CONTROL_NAME.PRINT_LABEL]?.get(FORM_CONTROL_NAME.LABEL_ORIENTATION)?.value,
            isReprint: this.data?.type !== this.type.MAKE_SAMPLE,
            ProductType:
                labelNamePrintType === LABEL_WITH_PRODUCT_TYPE && batchSheetResult.Experiment?.ProductTypeID
                    ? batchSheetResult.Experiment?.ProductTypeID
                    : undefined,
        };
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.batchSheetHelper.generateLabelTemplate(payload).subscribe({
            next: (response: GenerateLabelResponse) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                if (!response) {
                    return;
                }
                this.doPrintLabel(response);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to create Reprint Label form
     * @return {UntypedFormGroup}
     * @memberof CreateSampleComponent
     */
    public createReprintLabelForm = (): UntypedFormGroup => {
        return this.formBuilder.group({
            SampleID: new UntypedFormControl(EMPTY, [Validators.required, Validators.maxLength(10)]),
            CustomNote: new UntypedFormControl(EMPTY, [Validators.maxLength(60)]),
            NoOfLabelCopies: new UntypedFormControl(1),
            LabelTemplate: new UntypedFormControl(EMPTY, [Validators.required]),
            LabelPrinter: new UntypedFormControl(EMPTY, [Validators.required]),
            LabelOrientation: new UntypedFormControl(EMPTY, [Validators.required]),
        });
    };

    /**
     * Method to validate sample ID for Reprint Label
     * @return {void}
     * @memberof CreateSampleComponent
     */
    public validateSampleID(): void {
        const sampleId = this.createSampleForm.get(FORM_CONTROL_NAME.SAMPLE_ID).value;
        if (sampleId && this.printResult?.SampleID === sampleId) return;
        if (sampleId && sampleId?.toString()?.length < 9) {
            this.createSampleForm.controls[FORM_CONTROL_NAME.SAMPLE_ID].setErrors({ inValid: true });
            this.errorMessage = ERROR_MESSAGE.SAMPLE_NOT_EXIST;
            this.experimentDetail = undefined;
            return;
        }
        this.appBroadCastService.onUpdateAppSpinnerPrompt(PLEASE_WAIT);
        this.batchSheetHelper.validateSampleId(sampleId).subscribe({
            next: (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                if (!result) return;
                if (result?.message) {
                    this.createSampleForm.controls[FORM_CONTROL_NAME.SAMPLE_ID].setErrors({ inValid: true });
                    this.errorMessage = result?.message;
                    this.experimentDetail = undefined;
                    return;
                }
                this.sampleDetails = result;
                this.experimentDetail = result?.Experiment;
                this.prePopulateSampleInfo(this.sampleDetails);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to sumbit reprint Label form
     * @return {void}
     * @memberof CreateSampleComponent
     */
    public onSubmitReprintLabelForm(): void {
        const { value, controls } = this.createSampleForm;
        value.Experiment = this.experimentDetail;
        this.printResult = {
            SampleID: controls[FORM_CONTROL_NAME.SAMPLE_ID].value,
            Experiment: this.experimentDetail,
        };
        this.generateLabelTemplate(value);
        this.matomoService.trackEvent(MatomoCategory.REPRINT_LABEL, MatomoAction.CLICK, MatomoLabel.ON_SUBMIT_REPRINT_LABEL_FORM);
    }

    /**
     * Method to prePopulate Sample Info
     * @param sampleInfo
     * @memberof CreateSampleComponent
     */
    public prePopulateSampleInfo(sampleInfo): void {
        if (sampleInfo.LabelTemplate) {
            const templateInfo = this.labelTemplates.find((template) => template.LabelName === sampleInfo.LabelTemplate);
            this.onLabelTemplateChange(templateInfo);
            this.createSampleForm.controls.LabelTemplate.patchValue(templateInfo);
        }
        if (sampleInfo.LabelPrinter) {
            const printerInfo = this.labelPrinters.find((printer) => printer.name === sampleInfo.LabelPrinter);
            this.createSampleForm.controls.LabelPrinter.patchValue(printerInfo);
        }
        if (sampleInfo.LabelOrientation) {
            const orientationInfo = this.labelOrientation.find(
                (orientation) => orientation.orientationType === sampleInfo.LabelOrientation,
            );
            this.createSampleForm.controls.LabelOrientation.patchValue(orientationInfo.orientationType);
        } else {
            this.createSampleForm.controls.LabelOrientation?.patchValue(SAMPLE_CONST.LANDSCAPE);
        }
    }
}
