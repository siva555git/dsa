export const UPLOAD_IPC_LIST_VALIDATION = [
    {
        name: "Invalid IPC(S)",
        type: "isInvalid",
        values: [],
    },
    {
        name: "Duplicate IPC(S)",
        type: "isDuplicate",
        values: [],
    },
];
export const IPC = "ipc";

export const SUPPORTED_FILE_FORMAT = {
    XLSX: "xlsx",
    TXT: "txt",
};

export const DOT_CHARACTER = ".";

export const FILE_FORMAT_WARNING = "Only file formats .txt and .xlsx is allowed";

export const FILE_HEADER_COLUMN_FORMAT = "Uploaded file must have header as 'IPC'";

export const MAX_IPC_LIST_REACH = "Max. of 500 IPCs can be added";

export const MAX_ALLOWED_IPCS = 500;
