import { Component, Inject, ViewChild } from "@angular/core";
import { filter } from "rxjs/operators";
import { Subscription } from "rxjs";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { ADD_IPC_TYPE, KEYBOARD_KEYS } from "@te-shared/constants/common.constant";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { AddIpcListHelper } from "@te-shared/helpers/add-ipc-list.helper";
import { delay, forEach, map, split } from "lodash";
import { FileHelper } from "@te-shared/helpers/file.helper";
import { ToastrService } from "ngx-toastr";
import { MatAccordion } from "@angular/material/expansion";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { ExistingIpcListModel, IpcBasicAttributeInfo, NewIpcListModel } from "../add-ipc-list/models/add-ipc-list.model";
import {
    DOT_CHARACTER,
    FILE_FORMAT_WARNING,
    FILE_HEADER_COLUMN_FORMAT,
    IPC,
    MAX_ALLOWED_IPCS,
    MAX_IPC_LIST_REACH,
    SUPPORTED_FILE_FORMAT,
    UPLOAD_IPC_LIST_VALIDATION,
} from "./upload-ipc-list.constant";

@Component({
    selector: "app-upload-ipc-list",
    templateUrl: "./upload-ipc-list.component.html",
    styleUrls: ["./upload-ipc-list.component.scss"],
})
export class UploadIpcListComponent {
    public isLoading: boolean;

    public uploadedIpcList: NewIpcListModel[] = [];

    public invalidIPC: NewIpcListModel[] = [];

    public duplicateIpcValue: NewIpcListModel[] = [];

    public invalidOrDupRecords = UPLOAD_IPC_LIST_VALIDATION;

    public attributes: IpcBasicAttributeInfo[] = [];

    public uploadedIPCCount: number;

    public uploadSubcription: Subscription[] = [];

    public maxAllowedIpcCount = MAX_ALLOWED_IPCS;

    @ViewChild(MatAccordion) uploadAccordion: MatAccordion;

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: { uploadedFile: File[]; existingIpcListData: ExistingIpcListModel[] },
        private readonly dialogReference: MatDialogRef<UploadIpcListComponent>,
        private readonly appBroadCastService: AppBroadCastService,
        public readonly addIpcListHelper: AddIpcListHelper,
        private readonly fileHelper: FileHelper,
        private readonly toasterService: ToastrService,
    ) {}

    ngOnInit(): void {
        this.uploadSubcription.push(
            this.dialogReference
                .keydownEvents()
                .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.dialogReference.close(this.uploadedIpcList);
                }),
        );
        if (this.data?.uploadedFile && this.data?.uploadedFile?.length > 0) {
            this.isLoading = true;
            this.handleFileUpload(this.data?.uploadedFile);
        }
        this.listenIpcEdition();
        this.listenFileUploadEvents();
    }

    /**
     * Method to listen ipc edition
     * @returns {void}
     * @memberof UploadIpcListComponent
     */
    public listenIpcEdition(): void {
        this.uploadSubcription.push(
            this.appBroadCastService.addedIpcListInfo.subscribe((result) => {
                if (result.addType === ADD_IPC_TYPE.BULK_IPC_UPLOAD) {
                    this.isLoading = false;
                    this.attributes.push(...result.attributes);
                    this.uploadedIpcList = this.addIpcListHelper.checkForInvalidIpc(this.uploadedIpcList, this.attributes);
                    this.uploadedIPCCount = this.uploadedIpcList.filter((data) => !data.isDuplicate && !data.isInvalid)?.length;
                    forEach(this.invalidOrDupRecords, (dataValue) => {
                        dataValue.values = map(
                            this.uploadedIpcList.filter((data) => data[dataValue.type]),
                            IPC,
                        );
                    });
                    delay(() => {
                        this.uploadAccordion.openAll();
                    }, 500);
                }
            }),
        );
    }

    /**
     * Method to listen file upload
     * @returns {void}
     * @memberof UploadIpcListComponent
     */
    public listenFileUploadEvents(): void {
        this.uploadSubcription.push(
            this.appBroadCastService.uploadedExcelFileData.subscribe((fileData) => {
                if (this.checkForMaxLimit(fileData)) return;
                const ipcArray = [];
                const fileHeaders = Object.keys(fileData[0]);
                if (fileHeaders?.includes("ipc") || fileHeaders?.includes("IPC")) {
                    forEach(fileData, (item: { ipc?: string; IPC?: string }) => {
                        ipcArray.push(item?.ipc?.toString().toUpperCase() || item?.IPC?.toString().toUpperCase());
                    });
                    this.handleUplodedData(ipcArray);
                } else {
                    this.isLoading = false;
                    this.toasterService.info(FILE_HEADER_COLUMN_FORMAT);
                    this.dialogReference.close([]);
                }
            }),
            this.appBroadCastService.uploadedTextFileData.subscribe((fileData) => {
                const ipcArray = split(fileData.trim(), /[\s,]+/);
                if (this.checkForMaxLimit(ipcArray)) return;
                this.handleUplodedData(ipcArray);
            }),
        );
    }

    /**
     * Method to check for max limit
     * @returns {boolean}
     * @memberof UploadIpcListComponent
     */
    public checkForMaxLimit(fileData): boolean {
        if (
            fileData?.length > this.maxAllowedIpcCount ||
            this.data.existingIpcListData.length + fileData.length > this.maxAllowedIpcCount
        ) {
            this.isLoading = false;
            this.toasterService.info(MAX_IPC_LIST_REACH);
            this.dialogReference.close([]);
            return true;
        }
        return false;
    }

    /**
     * Method to handle uploaded file data
     * @param {Array<string>} uploadedIPCData
     * @returns {void}
     * @memberof UploadIpcListComponent
     */
    public handleUplodedData(uploadedIPCData: Array<string>): void {
        uploadedIPCData.forEach((data) => {
            this.uploadedIpcList.push({ ipc: data?.trim()?.toUpperCase() });
        });
        this.uploadedIpcList = this.addIpcListHelper.checkForDuplicateAndInvalidIpc(this.uploadedIpcList, this.data.existingIpcListData);
        const ipcList = this.addIpcListHelper.getValidIpcs(this.uploadedIpcList);
        if (ipcList?.length > 0) {
            this.addIpcListHelper.fetchIPCDetail([...new Set(ipcList)], ADD_IPC_TYPE.BULK_IPC_UPLOAD);
        } else {
            this.uploadedIPCCount = ipcList?.length;
            this.isLoading = false;
        }
    }

    /**
     * Method called on dialog close
     * @returns {void}
     * @memberof UploadIpcListComponent
     */
    public onDialogClose(): void {
        this.dialogReference.close(this.uploadedIpcList);
    }

    /**
     * Method called to read and handle uploaded file
     * @param {File[]} files
     * @returns {void}
     * @memberof UploadIpcListComponent
     */
    public handleFileUpload(files: File[]): void {
        const extension = files[0]?.name.split(DOT_CHARACTER).pop();
        if (extension?.toLowerCase() === SUPPORTED_FILE_FORMAT.XLSX) {
            this.fileHelper.readExcelFile(files[0]);
        } else if (extension?.toLowerCase() === SUPPORTED_FILE_FORMAT.TXT) {
            this.fileHelper.readTextFile(files[0]);
        } else {
            this.toasterService.info(FILE_FORMAT_WARNING);
        }
    }

    public ngOnDestroy(): void {
        TasteEditorUtilClass.removeSubscriptions(this.uploadSubcription);
    }
}
