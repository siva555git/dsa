/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ToastrService } from "ngx-toastr";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { AppBroadCastService } from "@te-services/index";
import { AddIpcListHelper } from "@te-shared/helpers/add-ipc-list.helper";
import { FileHelper } from "@te-shared/helpers/file.helper";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { MockDialogReference } from "@te-testing/mock-dialog.reference";
import { mockAttributeResponse, mockIpcListToBeAdded } from "@te-testing/mock-add-ipc-data";
import { cloneDeep } from "lodash";
import { MatAccordion } from "@angular/material/expansion";
import { UploadIpcListComponent } from "./upload-ipc-list.component";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

describe("UploadIpcListComponent", () => {
    let component: UploadIpcListComponent;
    let fixture: ComponentFixture<UploadIpcListComponent>;

    const dialogData = {
        uploadedFile: [],
        existingIpcListData: [],
    };

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [UploadIpcListComponent],
            providers: [
                AppBroadCastService,
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: AddIpcListHelper,
                    useValue: {
                        fetchIPCDetail: () => {
                            return [];
                        },
                        checkForInvalidIpc: () => {
                            return [];
                        },
                        checkForDuplicateAndInvalidIpc: () => {
                            return [];
                        },
                        getValidIpcs: () => {
                            return [];
                        },
                    },
                },
                {
                    provide: FileHelper,
                    useValue: {
                        readExcelFile: () => {
                            return [];
                        },
                        readTextFile: () => {
                            return [];
                        },
                    },
                },
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: MAT_DIALOG_DATA, useValue: dialogData },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        });
        fixture = TestBed.createComponent(UploadIpcListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on listenIpcEdition", () => {
        const addIpcListHelper: AddIpcListHelper = TestBed.inject(AddIpcListHelper);
        spyOn(addIpcListHelper, "checkForInvalidIpc").and.returnValue(mockIpcListToBeAdded);
        const mockData = cloneDeep(mockAttributeResponse);
        mockData.addType = "Bulk ipc upload";
        component.uploadAccordion = {
            // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
            openAll: () => {},
        } as MatAccordion;
        const appBoardCastService: AppBroadCastService = TestBed.inject(AppBroadCastService);
        appBoardCastService.addedIpcListSubject.next(mockData);
        component.listenIpcEdition();
        expect(component.uploadedIPCCount).toEqual(3);
    });

    it("should call on listenFileUploadEvents", () => {
        const spy = spyOn(component, "listenFileUploadEvents").and.callThrough();
        component.data.existingIpcListData = [];
        const appBoardCastService: AppBroadCastService = TestBed.inject(AppBroadCastService);
        appBoardCastService.excelFileData.next([{ item: { ipc: "1RR04333" } }]);
        const addIpcListHelper: AddIpcListHelper = TestBed.inject(AddIpcListHelper);
        spyOn(addIpcListHelper, "checkForDuplicateAndInvalidIpc").and.returnValue([
            { ipc: "1RR04333", isDuplicate: false, isInvalid: false },
        ]);
        spyOn(addIpcListHelper, "getValidIpcs").and.returnValue(["1RR04333"]);
        component.listenFileUploadEvents();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on listenFileUploadEvents 1", () => {
        const spy = spyOn(component, "listenFileUploadEvents").and.callThrough();
        component.data.existingIpcListData = [];
        const appBoardCastService: AppBroadCastService = TestBed.inject(AppBroadCastService);
        appBoardCastService.textFileData.next("1RR04333");
        const addIpcListHelper: AddIpcListHelper = TestBed.inject(AddIpcListHelper);
        spyOn(addIpcListHelper, "checkForDuplicateAndInvalidIpc").and.returnValue([
            { ipc: "1RR04333", isDuplicate: false, isInvalid: false },
        ]);
        spyOn(addIpcListHelper, "getValidIpcs").and.returnValue(["1RR04333"]);
        component.listenFileUploadEvents();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onDialogClose", () => {
        const spy = spyOn(component, "onDialogClose").and.callThrough();
        component.onDialogClose();
        expect(spy).toHaveBeenCalled();
    });
});
