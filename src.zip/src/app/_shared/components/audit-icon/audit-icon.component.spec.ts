import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { AuditIconPipe } from "../../pipes";

import { AuditIconComponent } from "./audit-icon.component";
import { TooltipDirective } from "@te-shared/custom-module/custom-tooltip/tooltip.directive";

describe("AuditIconComponent", () => {
    let component: AuditIconComponent;
    let fixture: ComponentFixture<AuditIconComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [AuditIconComponent, AuditIconPipe, TooltipDirective],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AuditIconComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
