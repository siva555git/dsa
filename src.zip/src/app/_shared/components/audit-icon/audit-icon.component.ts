import { Component, Input } from "@angular/core";
import { PRODUCT_FLAG_AUDIT, SEARCH_AUDIT_STATUS } from "../../constants";

@Component({
    selector: "app-audit-icon",
    templateUrl: "./audit-icon.component.html",
})
export class AuditIconComponent {
    @Input() public auditInfo;

    @Input() public auditTitle = "";

    public auditStatus = SEARCH_AUDIT_STATUS;

    public auditType = PRODUCT_FLAG_AUDIT;
}
