import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from "@angular/material/dialog";
import { LineageHelper } from "@te-experiment-editor/helpers/lineage.helper";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { AppDataService } from "@te-services/app-data/app.data.service";
import { MockAppDataService } from "@te-testing/mock-app.data.service";
import { MockDialogReference } from "@te-testing/mock-dialog.reference";
import { MockLineageHelper } from "@te-testing/mock-lineage-helper";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { NGXLogger } from "ngx-logger";
import { GridParameters } from "@te-shared/models";
import { accessDataValues, restrictedUseValues, viewAccessListResponse } from "@te-testing/mock-view-access-list-component";
import { ViewAccessListHelper } from "@te-shared/helpers/view-accesslist.helper";
import { ViewAccesslistComponent } from "./view-accesslist.component";
import { mockGridApiNew, mockGridColumnApiNew } from "../../../testing/mock-ag-grid-data";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

// eslint-disable-next-line max-lines-per-function
describe("ViewAccesslistComponent", () => {
    let component: ViewAccesslistComponent;
    let fixture: ComponentFixture<ViewAccesslistComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ViewAccesslistComponent],
            providers: [
                AppBroadCastService,
                ViewAccessListHelper,
                { provide: AppDataService, useClass: MockAppDataService },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                { provide: LineageHelper, useClass: MockLineageHelper },
                { provide: MAT_DIALOG_DATA, useValue: {} },
                { provide: MatDialogRef, useValue: {} },
                {
                    provide: MatDialogRef,
                    useClass: MockDialogReference,
                },
            ],
            imports: [
                MatFormFieldModule,
                MatInputModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule,
                MatDialogModule
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ViewAccesslistComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on viewAccesslist", () => {
        component.data = restrictedUseValues;
        component.accessData = accessDataValues;
        spyOn(component, "getAccessListUsers").and.returnValue([]);
        spyOn(component, "getSecurityGroupNames").and.returnValue([]);
        spyOn(component, "dataFormationForDirectUsers").and.returnValue();
        spyOn(component, "dataFormationForGroupUsers").and.returnValue();
        const spy = spyOn(component, "viewAccesslist").and.callThrough();
        component.viewAccesslist();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getSecurityGroupNames", () => {
        component.accessData = accessDataValues;
        const spy = spyOn(component, "getSecurityGroupNames").and.callThrough();
        component.getSecurityGroupNames();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getAccessListUsers", () => {
        component.accessData = accessDataValues;
        const spy = spyOn(component, "getAccessListUsers").and.callThrough();
        component.getAccessListUsers();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on dataFormationForGroupUsers", () => {
        component.accessData = accessDataValues;
        const accessList = viewAccessListResponse;
        spyOn(component, "createTreeStructure").and.returnValue();
        const spy = spyOn(component, "dataFormationForGroupUsers").and.callThrough();
        component.dataFormationForGroupUsers(accessList);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onCancel", () => {
        const spy = spyOn(component, "onCancel").and.callThrough();
        component.onCancel();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onGridReady ", () => {
        const spy = spyOn(component, "onGridReady").and.callThrough();
        component.onGridReady({
            api: mockGridApiNew,
            columnApi: mockGridColumnApiNew,
        } as unknown as GridParameters);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on keyboardNavigation ", () => {
        const eventValue = {
            event: {
                key: "Enter",
            },
        };
        const spy = spyOn(component, "keyboardNavigation").and.callThrough();
        component.keyboardNavigation(eventValue);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterToGetFindValue() when value is null ", () => {
        component.gridApi = mockGridApiNew;
        const spy = spyOn(component, "onEnterToGetFindValue").and.callThrough();
        // eslint-disable-next-line unicorn/no-null
        component.onEnterToGetFindValue(null);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterToGetFindValue()  ", () => {
        const event = { key: "Enter" };
        component.gridApi = mockGridApiNew;
        component.totalNoOfFindValue = 1;
        spyOn(component, "onEnterToGetFindValue").and.callThrough();
        component.onEnterToGetFindValue(event);
        expect(component.matchedIndexOfFindValue).toEqual(0);
    });

    it("should resolve for onEnterToGetFindValue()  ", () => {
        const event = { key: "ArrowLeft" };
        component.gridApi = mockGridApiNew;
        component.totalNoOfFindValue = 1;
        spyOn(component, "onEnterToGetFindValue").and.callThrough();
        component.onEnterToGetFindValue(event);
        expect(component.matchedIndexOfFindValue).toEqual(0);
    });

    it("should call dataFormationForDirectUsers", () => {
        const accessList = viewAccessListResponse;
        component.accessData = accessDataValues;
        const spy = spyOn(component, "dataFormationForDirectUsers").and.callThrough();
        component.dataFormationForDirectUsers(accessList);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for navigateToPreviousNext() when matchedIndexOfFindValue is 1 ", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("Test");
        component.totalNoOfFindValue = 1;
        component.matchedIndexOfFindValue = 1;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowLeft");
        expect(component.matchedIndexOfFindValue).toEqual(1);
    });

    it("should resolve for navigateToPreviousNext() when matchedIndexOfFindValue is 0 ", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("Test");
        component.totalNoOfFindValue = 1;
        component.matchedIndexOfFindValue = 0;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowLeft");
        expect(component.matchedIndexOfFindValue).toEqual(-1);
    });

    it("should resolve for navigateToPreviousNext() when matchedIndexOfFindValue is 1", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("Test");
        component.totalNoOfFindValue = 1;
        component.matchedIndexOfFindValue = 1;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowRight");
        expect(component.matchedIndexOfFindValue).toEqual(1);
    });

    it("should resolve for navigateToPreviousNext()  when matchedIndexOfFindValue is 2  ", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("Test");
        component.totalNoOfFindValue = 1;
        component.matchedIndexOfFindValue = 2;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowRight");
        expect(component.matchedIndexOfFindValue).toEqual(3);
    });

    it("should resolve for navigateToPreviousNext()  when totalNoOfFindValue is 0 ", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("");
        component.totalNoOfFindValue = 0;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowRight");
        expect(component.matchedIndexOfFindValue).toEqual(0);
    });

    it("should call on createTreeStructure", () => {
        const spy = spyOn(component, "createTreeStructure").and.callThrough();
        component.createTreeStructure();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on hightlightFindValueBasedOnIndex", () => {
        component.gridApi = mockGridApiNew;
        const spy = spyOn(component, "hightlightFindValueBasedOnIndex").and.callThrough();
        component.hightlightFindValueBasedOnIndex(false);
        expect(spy).toHaveBeenCalled();
    });
});
