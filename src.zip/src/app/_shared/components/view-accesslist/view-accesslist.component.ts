import { Component, ElementRef, HostListener, Inject, OnInit } from "@angular/core";
import { ColDef } from "@ag-grid-community/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { AppDataService } from "@te-services/app-data/app.data.service";
import { GridParameters } from "@te-shared/models";
import { forEach, delay } from "lodash";
import { GRID_SELECTION_TYPE, KEYBOARD_KEYS, LINEAGE_CLASS_NAME } from "@te-shared/constants/common.constant";
import { UntypedFormControl } from "@angular/forms";
import { NGXLogger } from "ngx-logger";
import { BomAttributes } from "@te-shared/models/attributes-model";
import { debounceTime } from "rxjs/operators";
import { LineageHelper } from "@te-experiment-editor/helpers/lineage.helper";
import { RESTRICTED_ACCESS_GRID_APPLY_COLUMN } from "@te-shared/constants/tree-view.constant";
import { ViewAccessListHelper } from "@te-shared/helpers/view-accesslist.helper";
import { EMPTY, LOADING } from "../../../app.constant";
import { AgGridConfigHelper } from "../../helpers/ag-grid-config";
import { AgGridUtil } from "../../helpers/ag-grid-util";
import { ViewAccesslistIconRendererComponent } from "../view-accesslist-icon-renderer/view-accesslist-icon-renderer.component";
import { PRODUCT_USAGE_ACCESS_LIST, RESTRICTED_USER_GROUP_OR_SINGLE } from "../product-data/product-data-constant";
import {
    RestrictedUsageAccessList,
    RestrictedUsageAccessListResponse,
    RestrictedUsageListPayload,
    RestrictedUsageListTreeView,
} from "../product-data/models/product-data.model";

@Component({
    selector: "app-view-accesslist",
    templateUrl: "./view-accesslist.component.html",
})
export class ViewAccesslistComponent implements OnInit {
    @HostListener("document:keydown.escape", ["$event"]) onKeydownHandler(): void {
        this.onCancel();
    }

    public accessData: RestrictedUsageAccessList[];

    public autoGroupColumnDef: ColDef;

    public getDataPath;

    public gridApi;

    public gridColumnApi;

    public rowData = [];

    public icons;

    public rowHeight = 42;

    public totalNoOfFindValue = 0;

    public ValueToBeHighlighted: UntypedFormControl = new UntypedFormControl("");

    public searchIcon = RESTRICTED_USER_GROUP_OR_SINGLE.SEARCH_ICON;

    public matchedIndexOfFindValue = 0;

    public context;

    public storeData = [...PRODUCT_USAGE_ACCESS_LIST];

    public directionToNavigate = KEYBOARD_KEYS;

    public productDetails: BomAttributes;

    public productDescription: string;

    public ipc: string;

    public columnDefs: ColDef[];

    public rowSelection = GRID_SELECTION_TYPE.SINGLE_SELECTION;

    constructor(
        public dialogReference: MatDialogRef<ViewAccesslistComponent>,
        private readonly appBroadCastService: AppBroadCastService,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        @Inject(MAT_DIALOG_DATA) public data: any,
        private readonly appDataService: AppDataService,
        public myElement: ElementRef,
        private readonly logger: NGXLogger,
        public readonly lineageHelper: LineageHelper,
    ) {}

    ngOnInit(): void {
        this.productDescription = this.data?.productDescription;
        this.ipc = this.data?.ipc;
        this.configAgGrid();
        this.viewAccesslist();
        this.broadCastFindFieldTextValue();
    }

    /**
     * Method to get user details
     * @returns {void}
     * @memberof ViewAccesslistComponent
     */
    public viewAccesslist(): void {
        if (this.data?.restrictedUse) {
            this.accessData = this.data?.restrictedUse;
            const payload: RestrictedUsageListPayload = {
                globalUserIds: this.getAccessListUsers(),
                groupNames: this.getSecurityGroupNames(),
            };
            this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
            this.appDataService.post(this.appDataService.url.getSecurityGroupsUsers, [], payload).subscribe({
                next: (response) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (!response) {
                        return;
                    }
                    this.dataFormationForDirectUsers(response);
                    this.dataFormationForGroupUsers(response);
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            });
        } else {
            this.createTreeStructure();
        }
    }

    /**
     * Method to get security group names
     * @returns {Array<string>}
     * @memberof ViewAccesslistComponent
     */
    public getSecurityGroupNames(): Array<string> {
        return ViewAccessListHelper.getSecurityGroupNames(this.accessData);
    }

    /**
     * Method to get global user IDs of all users
     * @returns {Array<string>}
     * @memberof ViewAccesslistComponent
     */
    public getAccessListUsers(): Array<string> {
        return ViewAccessListHelper.getAccessListUsers(this.accessData);
    }

    /**
     * Method to format the data for security group users
     * @param {RestrictedUsageAccessListResponse[]} values
     * @memberof ViewAccesslistComponent
     */
    public dataFormationForGroupUsers(values: RestrictedUsageAccessListResponse[]): void {
        if (values) {
            forEach(values, (group) => {
                if (group?.securityGroupCode) {
                    const formatResponseData = {
                        flagGroupCode: group?.userName,
                        parentFlagGroupCode: group?.securityGroupCode,
                        name: group?.userName,
                        regionName: group?.regionName,
                        department: group?.deptName,
                        position: group?.position,
                        globalUserID: group?.globalUserId,
                        userDeptPosition: `${group?.position} | ${group?.deptName}`,
                    };
                    this.storeData.push(formatResponseData);
                }
            });
        }
        this.createTreeStructure();
    }

    /**
     * Method to format the data for direct users
     * @param {RestrictedUsageAccessListResponse[]} values
     * @memberof ViewAccesslistComponent
     */
    // eslint-disable-next-line sonarjs/cognitive-complexity
    public dataFormationForDirectUsers(values: RestrictedUsageAccessListResponse[]): void {
        if (values) {
            const filteredUsers = values.filter((data) => !data?.securityGroupCode);
            if (filteredUsers) {
                this.accessData.forEach((accessList) => {
                    const getUserName = filteredUsers.find(
                        (user) => user?.globalUserId.toUpperCase() === accessList?.accessgiven.toUpperCase(),
                    );
                    // let formatData;
                    const formatData =
                        accessList?.inherited === RESTRICTED_USER_GROUP_OR_SINGLE.IS_ACCESS_LIST_INHERITED
                            ? {
                                  flagGroupCode: getUserName ? getUserName?.userName : accessList?.accessgiven,
                                  parentFlagGroupCode: `${accessList?.flagcode} ${RESTRICTED_USER_GROUP_OR_SINGLE.INHERITED}`,
                                  name: getUserName ? getUserName?.userName : accessList?.accessgiven,
                                  regionName: getUserName ? getUserName?.regionName : EMPTY,
                                  department: getUserName ? getUserName?.deptName : EMPTY,
                                  position: getUserName ? getUserName?.position : EMPTY,
                                  globalUserID: getUserName ? getUserName?.globalUserId : EMPTY,
                                  userDeptPosition: getUserName ? `${getUserName?.position} | ${getUserName?.deptName}` : EMPTY,
                              }
                            : {
                                  flagGroupCode: getUserName ? getUserName?.userName : accessList?.accessgiven,
                                  parentFlagGroupCode: accessList?.flagcode,
                                  name: getUserName ? getUserName?.userName : accessList?.accessgiven,
                                  regionName: getUserName ? getUserName?.regionName : EMPTY,
                                  department: getUserName ? getUserName?.deptName : EMPTY,
                                  position: getUserName ? getUserName?.position : EMPTY,
                                  globalUserID: getUserName ? getUserName?.globalUserId : EMPTY,
                                  userDeptPosition: getUserName ? `${getUserName?.position} | ${getUserName?.deptName}` : EMPTY,
                              };
                    this.storeData.push(formatData);
                });
            }
        }
    }

    /**
     * Method to form tree structure
     * @memberof ViewAccesslistComponent
     */
    public createTreeStructure(): void {
        ViewAccessListHelper.createTreeStructure(this.storeData);
        this.rowData = this.storeData;
    }

    public configAgGrid(): void {
        this.icons = {
            groupExpanded: '<i class="ag-icon ag-icon-small-down"/>',
            groupContracted: '<i class="ag-icon ag-icon-small-right"/>',
        };
        this.autoGroupColumnDef = AgGridConfigHelper.getAutoGroupColumnDefinition(ViewAccesslistIconRendererComponent);
        this.autoGroupColumnDef.cellRendererParams.suppressDoubleClickExpand = true;
        this.getDataPath = (data: RestrictedUsageListTreeView) => data.filePath;
        this.context = {
            componentParent: this,
        };
        this.columnDefs = AgGridConfigHelper.getRestrictedAccessDefaultColDef();
    }

    public onGridReady(parameters: GridParameters): void {
        this.gridApi = parameters.api;
        this.gridColumnApi = parameters.columnApi;
        this.gridColumnApi.applyColumnState(RESTRICTED_ACCESS_GRID_APPLY_COLUMN);
    }

    /**
     * Method to close the screen
     * @memberof ViewAccesslistComponent
     */
    public onCancel(): void {
        this.accessData = [];
        this.rowData = [];
        this.storeData = [];
        this.dialogReference.close();
    }

    /**
     * Method to broadcast find field value to viewaccesslist component
     * @returns {void}
     * @memberof ViewAccesslistComponent
     */
    public broadCastFindFieldTextValue(): void {
        this.ValueToBeHighlighted.valueChanges.pipe(debounceTime(1)).subscribe((value) => {
            this.matchedIndexOfFindValue = 0;
            if (value && value.length > 2) {
                AgGridUtil.expandAllCollapsedRowData(this.gridApi);
                this.appBroadCastService.onPublishFindRestrictedViewList(value);
                delay(() => {
                    this.totalNoOfFindValue = this.lineageHelper.getTotalCountOfFindTextValue(
                        this.gridApi,
                        this.ValueToBeHighlighted.value,
                        RESTRICTED_USER_GROUP_OR_SINGLE.SEARCH_SCREEN_NAME,
                    );
                }, 100);
            }
        });
    }

    /**
     * Method to broadcast find field value to viewaccesslist component
     * @returns {void}
     * @memberof ViewAccesslistComponent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public onEnterToGetFindValue(event: any): void {
        if (event !== null) {
            AgGridUtil.expandAllCollapsedRowData(this.gridApi);
            if (this.totalNoOfFindValue > 0 && event.key === KEYBOARD_KEYS.ENTER) {
                this.navigateToPreviousNext(KEYBOARD_KEYS.RIGHT_ARROW);
            } else if (
                this.ValueToBeHighlighted.value === "" ||
                this.ValueToBeHighlighted.value === null ||
                event.key === KEYBOARD_KEYS.BACK_SPACE ||
                event === this.searchIcon ||
                event.key === KEYBOARD_KEYS.ENTER
            ) {
                this.getTotalCountOfFindText();
                // eslint-disable-next-line no-useless-return
                return;
            }
        }
    }

    /**
     * Method to increase/decrease index of find text
     * @param {string} position
     * @returns {void}
     * @memberof ViewAccesslistComponent
     */
    public navigateToPreviousNext(position: string): void {
        AgGridUtil.expandAllCollapsedRowData(this.gridApi);
        if (this.ValueToBeHighlighted.value === "" || this.ValueToBeHighlighted.value === null || this.totalNoOfFindValue === 0) {
            return;
        }
        if (position === KEYBOARD_KEYS.LEFT_ARROW) {
            if (this.matchedIndexOfFindValue === 1) {
                this.matchedIndexOfFindValue = this.totalNoOfFindValue;
            } else {
                this.matchedIndexOfFindValue -= 1;
            }
            this.changeClassNameForFindText();
        } else {
            if (this.matchedIndexOfFindValue === this.totalNoOfFindValue) {
                this.matchedIndexOfFindValue = 0;
            }
            this.matchedIndexOfFindValue += 1;
            this.changeClassNameForFindText();
        }
    }

    /**
     * Method to get total count of find text and broadcast to pipe to apply class
     * @returns {void}
     * @memberof ViewAccesslistComponent
     */
    public getTotalCountOfFindText(): void {
        this.appBroadCastService.onPublishFindRestrictedViewList(this.ValueToBeHighlighted.value);
        delay(() => {
            this.totalNoOfFindValue = this.lineageHelper.getTotalCountOfFindTextValue(
                this.gridApi,
                this.ValueToBeHighlighted.value,
                RESTRICTED_USER_GROUP_OR_SINGLE.SEARCH_SCREEN_NAME,
            );
        }, 100);
    }

    /**
     * Method to change class name for the find text
     * @returns {void}
     * @memberof ViewAccesslistComponent
     */
    public changeClassNameForFindText(): void {
        const hasRowHightlightClass = false;
        delay(() => {
            const highlightTextClassArray = this.myElement.nativeElement.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT);
            highlightTextClassArray.forEach((value, index) => {
                if (index === this.matchedIndexOfFindValue - 1) {
                    this.myElement.nativeElement.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT)[
                        index
                    ].outerHTML = `<span class="highlight-text yellow">${this.ValueToBeHighlighted.value}</span>`;
                    this.hightlightFindValueBasedOnIndex(hasRowHightlightClass);
                } else {
                    this.myElement.nativeElement.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT)[
                        index
                    ].outerHTML = `<span class="highlight-text">${this.ValueToBeHighlighted.value}</span>`;
                }
            });
        }, 100);
    }

    /**
     * Method to add highlight yellow color and scroll to current index of the find text value
     * @param {boolean} hasRowHightlightClass
     * @returns {void}
     * @memberof ViewAccesslistComponent
     */
    public hightlightFindValueBasedOnIndex(hasRowHightlightClass: boolean): void {
        const treeViewRowData = AgGridUtil.getGridRowData(this.gridApi);
        for (let rowIndex = 0; rowIndex < treeViewRowData.length; rowIndex += 1) {
            const currentIndexElement = this.myElement.nativeElement.querySelectorAll(`[row-index="${rowIndex}"]`);
            const currentIndexRow = currentIndexElement[1];
            if (
                currentIndexRow.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT) &&
                currentIndexRow.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT_YELLOW).length > 0 &&
                !hasRowHightlightClass
            ) {
                // eslint-disable-next-line no-param-reassign
                hasRowHightlightClass = true;
            }
            if (hasRowHightlightClass && currentIndexRow.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT)) {
                // eslint-disable-next-line unicorn/no-null
                this.gridApi.ensureIndexVisible(rowIndex, null);
                break;
            }
        }
    }

    /**
     * Method to navigate to next/previous/expand/collapse row on down/up/left/right key pressed
     * @param agGrigEvent
     * @memberof ViewAccesslistComponent
     */
    public keyboardNavigation = (argument) => {
        this.lineageHelper.keyboardNavigationHandler(argument);
    };
}
