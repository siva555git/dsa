/* eslint-disable id-length */
/* eslint-disable no-irregular-whitespace */
/* eslint-disable max-lines-per-function */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable import/no-unresolved */
import { CdkDragDrop, DragDropModule } from "@angular/cdk/drag-drop";
import { SimpleChanges } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { UntypedFormControl, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatSelectModule } from "@angular/material/select";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { COLUMN_ATTRIBUTE_DISPLAY_LIST } from "@te-shared/constants/common.constant";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { MockAppStateService } from "@te-testing/mock-app.state.service";
import { mockPlantAndSources } from "@te-testing/mock-user-setting-data";
import { NGXLogger } from "ngx-logger";
import { of } from "rxjs";
import { MockAppDataService } from "src/app/testing/mock-app.data.service";
import { MockLoggerService } from "src/app/testing/mock-logger.service";
import { AppBroadCastService, AppDataService, AppStateService } from "src/app/_services";
import { MockExperimentHelper } from "../../../testing/mock-experiment.helper";
import { ExperimentHelper } from "../../helpers/experiment-helper";
import { MasterDataHelper } from "../../master-data/helpers/master-data.helper";
import { BaseColumnLayoutComponent } from "./base-column-layout.component";
import { BaseColumnHelper } from "./helper/base-column-helper";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";

describe("BaseColumnLayoutComponent", () => {
    const getAttributeValuesKey = "getAttributeValues";
    const hideColumnErrorKey = "hideColumnError";
    let component: BaseColumnLayoutComponent;
    let fixture: ComponentFixture<BaseColumnLayoutComponent>;
    class MockMasterData {
        checkAndFetchDefaultData = () => {
            return of([]);
        };
    }

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            imports: [BrowserModule, ReactiveFormsModule, FormsModule, MatSelectModule, BrowserAnimationsModule, DragDropModule],
            providers: [
                BaseColumnHelper,
                SpaceTrimPipe,
                { provide: AppStateService, useClass: MockAppStateService },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                { provide: MasterDataHelper, useClass: MockMasterData },
                { provide: ExperimentHelper, useClass: MockExperimentHelper },
                AppBroadCastService,
                SecurityHelper
            ],
            declarations: [BaseColumnLayoutComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BaseColumnLayoutComponent);
        component = fixture.componentInstance;
        component.columnLayoutFormArray().push(
            component.formBuilder.group({
                Columns: new UntypedFormControl("test"),
                Attributes: new UntypedFormControl("test"),
            }),
        );
        component.columnLayoutForm.setControl("Columns", component.columnLayoutFormArray());
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should invoke ngOnChanges", () => {
        const changes = {
            selectedTabIndex: {
                currentValue: "1",
            },
            copiedColumnsToCustom: {
                currentValue: ["first"],
                previousValue: ["first", "second"],
            },
            userColumnLayoutFormData: {
                currentValue: "listData",
            },
        } as unknown as SimpleChanges;
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for deleteColumn() ", () => {
        const spy = spyOn(component, "deleteColumn").and.callThrough();
        component.deleteColumn(0);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for addNewColumn() ", () => {
        const spy = spyOn(component, "addNewColumn").and.callThrough();
        component.addNewColumn();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onScroll() ", () => {
        const spy = spyOn(component, "onScroll").and.callThrough();
        component.onScroll();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for resetColumnLayout1() ", () => {
        const spy = spyOn(component, "resetColumnLayout").and.callThrough();
        component.resetColumnLayout();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getDefaultData() ", () => {
        const spy = spyOn(component, "getDefaultData").and.callThrough();
        component.getDefaultData();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for defaultSetColumns() ", () => {
        const spy = spyOn(component, "defaultSetColumns").and.callThrough();
        component.defaultSetColumns(1);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for bindColumnLayoutFormData() ", () => {
        const spy = spyOn(component, "bindColumnLayoutFormData").and.callThrough();
        component.bindColumnLayoutFormData(1);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for disableNoAttribute() ", () => {
        const spy = spyOn(component, "disableNoAttribute").and.callThrough();
        component.disableNoAttribute("experiment", "Stock");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for disableNoColumn() ", () => {
        const spy = spyOn(component, "disableNoColumn").and.callThrough();
        component.disableNoColumn("experiment");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onChangeAttributes() ", () => {
        const spy = spyOn(component, "onChangeAttributes").and.callThrough();
        component.onChangeAttributes(0);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for drop()", () => {
        const spy = spyOn(component, "drop").and.callThrough();
        const cdkDragDrop: CdkDragDrop<string[]> = {
            previousIndex: 1,
            currentIndex: 0,
            item: undefined,
            container: undefined,
            previousContainer: undefined,
            isPointerOverContainer: false,
            dropPoint: {
                x: 1,
                y: 5,
            },
            distance: {
                x: 1,
                y: 5,
            },
        } as CdkDragDrop<string[]>;
        component.drop(cdkDragDrop);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for disableNoColumn() ", () => {
        component.disabledColumn = [{ Columns: [{ Columns: "CostPerKg", Attributes: "BAFL" }] }];
        const spy = spyOn(component, "disableNoColumn").and.callThrough();
        component.disableNoColumn("experiment");
        expect(spy).toHaveBeenCalled();
    });

    xit("should resolve for onSelectColumn() ", () => {
        const spy = spyOn(component, "onSelectColumn").and.callThrough();
        spyOn(component, "columnLayoutFormArray").and.stub();
        component.onSelectColumn(0);
        component.columnLayoutFormArray().push(
            component.formBuilder.group({
                Columns: new UntypedFormControl("test"),
                Attributes: new UntypedFormControl("test"),
            }),
        );
        component.columnLayoutForm.setControl("Columns", component.columnLayoutFormArray());
        component.bindAttributesControl(0);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for speccode layoutForm()", () => {
        const formControl = {
            value: [
                { Columns: "Spec", Attributes: "% BET" },
                { Columns: "FlagCBW", Attributes: "CP SNACKS CBW" },
            ],
        };
        component.specsList = [{ speccode: "% BET" }];
        component.cbwflagsList = [{ flagcode: "CP SNACKS CBW" }];
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for costbook layoutForm() ", () => {
        const formControl = {
            value: [{ Columns: "CostPerKg", Attributes: "AKFL" }],
        };
        component.costBooksList = [
            {
                costbookcode: "AKFL",
            },
        ];
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for flagcode layoutForm() ", () => {
        const formControl = {
            value: [{ Columns: "Flag", Attributes: "00020358 BHT ROL-UP" }],
        };
        component.flagsList = [
            {
                flagcode: "00020358 BHT ROL-UP",
            },
        ];
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for stock layoutForm() ", () => {
        const formControl = {
            value: [{ Columns: "Stock", Attributes: "HHFL" }],
        };
        component.plantLists = [
            {
                plantCode: "HHFL",
            },
        ];
        const spy = spyOn(component, "layoutForm").and.callThrough();
        component.layoutForm(formControl as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getAttributeValues() when columnValue as value", () => {
        const spy = spyOn<any>(component, "getAttributeValues").and.callThrough();
        component.plantLists = mockPlantAndSources;
        component[getAttributeValuesKey]("", "", 1);
        component[getAttributeValuesKey](COLUMN_ATTRIBUTE_DISPLAY_LIST.SPEC, "", 1);
        component[getAttributeValuesKey](COLUMN_ATTRIBUTE_DISPLAY_LIST.COST_PER_KG, "", 1);
        component[getAttributeValuesKey](COLUMN_ATTRIBUTE_DISPLAY_LIST.COST_PER_PARTS, "", 1);
        component[getAttributeValuesKey](COLUMN_ATTRIBUTE_DISPLAY_LIST.COST_CONTRIBUTION, "", 1);
        component[getAttributeValuesKey](COLUMN_ATTRIBUTE_DISPLAY_LIST.FLAG, "", 1);
        component[getAttributeValuesKey](COLUMN_ATTRIBUTE_DISPLAY_LIST.CBWFLAG, "", 1);
        component[getAttributeValuesKey](COLUMN_ATTRIBUTE_DISPLAY_LIST.PLANT_ALLOCATION, "", 1);
        component[getAttributeValuesKey](COLUMN_ATTRIBUTE_DISPLAY_LIST.STOCK, "", 1);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for hideColumnError()", () => {
        const spy = spyOn<any>(component, "hideColumnError").and.callThrough();
        component.errorColumnDelete = true;
        component[hideColumnErrorKey]();
        expect(spy).toHaveBeenCalled();
    });
});
