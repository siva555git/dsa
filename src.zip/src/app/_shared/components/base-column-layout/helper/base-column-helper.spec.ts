/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { columnLayoutResponseMock } from "@te-testing/mock-bom-view-data";
import { UntypedFormControl } from "@angular/forms";
import { throwError } from "rxjs";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { MockAppDataService } from "../../../../testing/mock-app.data.service";
import { AppBroadCastService, AppDataService, AppStateService } from "../../../../_services";
import { BaseColumnHelper } from "./base-column-helper";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";
import {
    ColumnLayoutResponse,
    CustomLayoutPayload,
    UserPreferenceColumnLayoutPayload,
} from "../../../../master-data/models/column-layout.model";

xdescribe("BaseColumnHelper", () => {
    const failedResponseErrorMessage = "Response Failed";
    let service: BaseColumnHelper;
    let appData: AppDataService;
    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [
                AppBroadCastService,
                BaseColumnHelper,
                SecurityHelper,
                SpaceTrimPipe,
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                { provide: AppStateService, useClass: MockAppStateService },
            ],
        })));

    beforeEach(() => {
        service = TestBed.inject(BaseColumnHelper);
        appData = TestBed.inject(AppDataService);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call formatColumnLayoutFormData ", () => {
        spyOn(service, "formatColumnLayoutFormData").and.callThrough();
        const formdata = [
            {
                ColumnName: "",
                ColumnSelectedValue: "",
            },
        ];
        service.formatColumnLayoutFormData(formdata, 1);
        expect(service.formatColumnLayoutFormData).toHaveBeenCalled();
    });

    it("should call getSavedColumnLayout ", () => {
        spyOn(service, "getSavedColumnLayout").and.callThrough();
        service.getSavedColumnLayout();
        expect(service.getSavedColumnLayout).toHaveBeenCalled();
    });

    it("should call formatColumnLayoutData ", () => {
        spyOn(service, "formatColumnLayoutData").and.callThrough();
        service.formatColumnLayoutData({} as unknown as ColumnLayoutResponse[]);
        expect(service.formatColumnLayoutData).toHaveBeenCalled();
    });

    it("should call getSavedColumnLayoutList when reach response", () => {
        spyOn(service, "getSavedColumnLayoutList").and.callThrough();
        service.getSavedColumnLayoutList();
        expect(service.getSavedColumnLayoutList).toHaveBeenCalled();
    });

    it("should call getSavedColumnLayoutList when response Error", () => {
        const failureMessage = failedResponseErrorMessage;
        const spy = spyOn(service, "getSavedColumnLayoutList").and.callThrough();
        spyOn(appData, "get").and.returnValue(throwError(() => failureMessage));
        service.getSavedColumnLayoutList();
        expect(spy).toHaveBeenCalled();
    });

    it("should call getLastUsedColumnLayoutForProductSearch when reach response", () => {
        spyOn(service, "getLastUsedColumnLayoutForProductSearch").and.callThrough();
        service.getLastUsedColumnLayoutForProductSearch();
        expect(service.getLastUsedColumnLayoutForProductSearch).toHaveBeenCalled();
    });

    it("should call getLastUsedColumnLayoutForProductSearch when response Error", () => {
        const failureMessage = failedResponseErrorMessage;
        const spy = spyOn(service, "getLastUsedColumnLayoutForProductSearch").and.callThrough();
        spyOn(appData, "get").and.returnValue(throwError(() => failureMessage));
        service.getLastUsedColumnLayoutForProductSearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should call updateLastUsedColumnLayoutForSaved ", () => {
        const data = {
            prefTypeCode: "EXC",
            ColumnValue: "123",
            userTabID: 12,
        };
        spyOn(service, "updateLastUsedColumnLayoutForSaved").and.callThrough();
        service.updateLastUsedColumnLayoutForSaved(data);
        service.formatColumnLayoutInfo(columnLayoutResponseMock);
        expect(service.updateLastUsedColumnLayoutForSaved).toHaveBeenCalled();
    });

    it("should call updateLastUsedColumnLayoutForSaved when response Error", () => {
        const failureMessage = failedResponseErrorMessage;
        const spy = spyOn(service, "updateLastUsedColumnLayoutForSaved").and.callThrough();
        spyOn(appData, "put").and.returnValue(throwError(() => failureMessage));
        service.updateLastUsedColumnLayoutForSaved({} as unknown as UserPreferenceColumnLayoutPayload);
        service.formatColumnLayoutInfo(columnLayoutResponseMock);
        expect(spy).toHaveBeenCalled();
    });

    it("should call updateLastUsedColumnLayoutForCustom", () => {
        const customLayoutPayloadMock = {
            prefTypeCode: "lastUsed",
            userTabID: 10,
            customColumnLayoutType: columnLayoutResponseMock,
        };
        const spy = spyOn(service, "updateLastUsedColumnLayoutForCustom").and.callThrough();
        service.updateLastUsedColumnLayoutForCustom(customLayoutPayloadMock as unknown as CustomLayoutPayload);
        service.formatColumnLayoutInfo(columnLayoutResponseMock);
        expect(spy).toHaveBeenCalled();
    });

    it("should call updateLastUsedColumnLayoutForCustom when response Error", () => {
        const failureMessage = failedResponseErrorMessage;
        const spy = spyOn(service, "updateLastUsedColumnLayoutForCustom").and.callThrough();
        spyOn(appData, "post").and.returnValue(throwError(() => failureMessage));
        service.updateLastUsedColumnLayoutForCustom({} as unknown as CustomLayoutPayload);
        service.formatColumnLayoutInfo(columnLayoutResponseMock);
        expect(spy).toHaveBeenCalled();
    });

    it("should call setColumnLayout", () => {
        const spy = spyOn(service, "setColumnLayout").and.callThrough();
        service.setColumnLayout();
        service.formatColumnLayoutInfo(columnLayoutResponseMock);
        expect(spy).toHaveBeenCalled();
    });

    it("should call formatColumnLayoutInfo", () => {
        const spy = spyOn(service, "formatColumnLayoutInfo").and.callThrough();
        service.formatColumnLayoutFormData(columnLayoutResponseMock[0].UserColumnLayout, columnLayoutResponseMock[0].ColumnLayoutTypeID);
        service.formatColumnLayoutInfo(columnLayoutResponseMock);
        expect(spy).toHaveBeenCalled();
    });

    it("should call getDefaultColumnFromSavedLayouts", () => {
        spyOn(BaseColumnHelper, "getDefaultColumnFromSavedLayouts").and.callThrough();
        BaseColumnHelper.getDefaultColumnFromSavedLayouts();
        expect(BaseColumnHelper.getDefaultColumnFromSavedLayouts).toHaveBeenCalled();
    });

    it("should resolve for filterDropDownData() ", () => {
        const data = [
            {
                active: true,
                costbookcode: "AKFL",
                countrycode: "NZ",
                createdby: "JVH7213",
                currencycode: "NZD",
                description: "Auckland Flavors RESALE Costbook",
            },
        ];
        const spy = spyOn(service, "filterDropDownData").and.callThrough();
        service.filterDropDownData(data, "costbookcode", "AKFL", 1);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for whitespaceValidator() ", () => {
        const spy = spyOn(service, "whitespaceValidator").and.callThrough();
        service.whitespaceValidator({} as unknown as UntypedFormControl);
        expect(spy).toHaveBeenCalled();
    });
});
