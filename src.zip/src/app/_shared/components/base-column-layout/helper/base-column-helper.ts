/* eslint-disable @typescript-eslint/no-explicit-any */
/** Angular Modules */
import { Injectable } from "@angular/core";
import { UntypedFormControl, ValidationErrors } from "@angular/forms";
import { DIVISION_LIST } from "@te-shared/components/product-data/product-data-constant";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { filter, forEach, includes, map } from "lodash";
import { NGXLogger } from "ngx-logger";
import { Observable, of } from "rxjs";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { EMPTY, LOADING } from "../../../../app.constant";
import { defaultAttributeColumns } from "../../../../experiment-editor/constants/grid-mock-data";
import {
    ColumnLayoutResponse,
    CustomLayoutPayload,
    UserPreferenceColumnLayoutPayload,
} from "../../../../master-data/models/column-layout.model";
import { AppBroadCastService, AppDataService, AppStateService } from "../../../../_services";
// eslint-disable-next-line import/named
import {
    ALLOCATION,
    COLUMN_ATTRIBUTE_DISPLAY_LIST,
    COLUMN_LAYOUT,
    COLUMN_LAYOUTS_CRITERIA,
    COLUMN_LAYOUT_ADDED_PAGE,
    COLUMN_LAYOUT_DEFAULT,
    COLUMN_LAYOUT_TYPES,
    COST_ATTRIBUTES,
    PROD_SEARCH_COLUMN_LAYOUT_URL,
    STOCK_UNIT_DISPLAY,
    ZERO_LENGTH,
} from "../../../constants/common.constant";

@Injectable()
export class BaseColumnHelper {
    constructor(
        private readonly appBroadCastService: AppBroadCastService,
        private readonly appDataService: AppDataService,
        private readonly appStateService: AppStateService,
        private readonly logger: NGXLogger,
        public readonly securityHelper: SecurityHelper,
        private readonly spaceTrim: SpaceTrimPipe,
    ) {}

    /**
     * Method to format the form data
     *
     * @param {*} formData
     * @returns {*}
     * @memberof BaseColumnHelper
     */
    public formatColumnLayoutFormData = (formData: any, layoutTypeID): any => {
        return map(formData, (layout) => {
            return {
                Columns: layout?.isCBWFlag ? COLUMN_ATTRIBUTE_DISPLAY_LIST.CBWFLAG : layout?.ColumnName,
                isCost: COST_ATTRIBUTES.includes(layout?.ColumnName),
                Attributes: layout?.ColumnSelectedValue ? layout.ColumnSelectedValue.replace(` ${STOCK_UNIT_DISPLAY}`, "") : "",
                ColumnLayoutTypeID: layoutTypeID,
                ColumnHeader:
                    layout.ColumnName === COLUMN_LAYOUTS_CRITERIA.PLANT_ALLOCATION
                        ? `${layout.ColumnSelectedValue} ${ALLOCATION}`
                        : layout.ColumnHeader,
            };
        });
    };

    /**
     * Method to get the saved column layouts list
     * @returns {void}
     * @memberof BaseColumnHelper
     */
    public getSavedColumnLayoutList(): void {
        this.appDataService.get(this.appDataService.url.getColumnLayoutList, []).subscribe({
            next: (columnLayoutList) => {
                this.formatColumnLayoutData(columnLayoutList);
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to get the saved column layouts list
     * @returns {Observable<ColumnLayoutResponse[]>}
     * @memberof BaseColumnHelper
     */
    public getSavedColumnLayout(): Observable<ColumnLayoutResponse[]> {
        return this.appDataService.get(this.appDataService.url.getColumnLayoutList, []);
    }

    /**
     * Method to format column layout data
     * @param {ColumnLayoutResponse[]} columnLayoutList
     * @returns {void}
     * @memberof BaseColumnHelper
     */
    public formatColumnLayoutData(columnLayoutList: ColumnLayoutResponse[]): void {
        if (columnLayoutList) {
            forEach(columnLayoutList, (layoutData) => {
                forEach(layoutData.UserColumnLayout, (columLayout) => {
                    const layout = columLayout;
                    layout.isCost = COST_ATTRIBUTES.includes(columLayout.ColumnName);
                });
            });
            this.appStateService.setSavedColumnLayoutList(columnLayoutList);
        }
    }

    /**
     * Method to get last used layout from api for product search.
     * @returns {void}
     * @memberof BaseColumnHelper
     */
    public getLastUsedColumnLayoutForProductSearch(): void {
        this.appDataService.get(`${this.appDataService.url.columnLayoutLastUsed}/${PROD_SEARCH_COLUMN_LAYOUT_URL}`, []).subscribe({
            next: (result) => {
                if (result && result.length > 0) {
                    this.appStateService.setLastUsedColumnLayout(result);
                    return;
                }
                this.appStateService.setLastUsedColumnLayout([]);
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to update last used layout for saved section bom/search
     * @param {UserPreferenceColumnLayoutPayload} savedLayoutPayload
     * @returns {void}
     * @memberof BaseColumnHelper
     */
    public updateLastUsedColumnLayoutForSaved(savedLayoutPayload: UserPreferenceColumnLayoutPayload): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.appDataService.put(this.appDataService.url.columnLayoutLastUsed, [], savedLayoutPayload).subscribe({
            next: (savedResponse) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.appStateService.setLastUsedColumnLayout(savedResponse);
                this.formatColumnLayoutInfo(savedResponse);
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to update last used layout for custom section bom/search.
     * @param {CustomLayoutPayload} customLayoutPayload
     * @returns {void}
     * @memberof BaseColumnHelper
     */
    public updateLastUsedColumnLayoutForCustom(customLayoutPayload: CustomLayoutPayload): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.appDataService.post(this.appDataService.url.customLastUsedLayout, [], customLayoutPayload).subscribe({
            next: (customResponse) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.appStateService.setLastUsedColumnLayout(customResponse);
                this.formatColumnLayoutInfo(customResponse);
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to set layout in grid
     *
     * @memberof BaseColumnHelper
     */
    public setColumnLayout(): void {
        const lastUsedLayout = AppStateService.getLastUsedLColumnLayout() ?? [];
        if (lastUsedLayout?.length === 0) {
            lastUsedLayout.push(BaseColumnHelper.setDefaultAtrributes());
        }
        this.formatColumnLayoutInfo(lastUsedLayout);
    }

    /**
     * Method to form and broadcast column layout header for prod search
     * @param {ColumnLayoutResponse[]} lastUsedLayout
     * @returns {void}
     * @memberof BaseColumnHelper
     */
    public formatColumnLayoutInfo(lastUsedLayout: ColumnLayoutResponse[]): void {
        const defaultColumnInfo = {
            data: {
                Columns: this.formatColumnLayoutFormData(lastUsedLayout[0].UserColumnLayout, lastUsedLayout[0].ColumnLayoutTypeID),
            },
            type: COLUMN_LAYOUT_ADDED_PAGE.BOM,
            eventType: false,
            columnLayoutTypeID: lastUsedLayout[0].ColumnLayoutTypeID,
        };
        this.appBroadCastService.onLayoutChange(defaultColumnInfo);
    }

    /**
     * Method to get default column layout or return 0th index from saved list
     * @param {string} columnLayoutTypeID
     * @returns {ColumnLayoutResponse}
     * @memberof BaseColumnHelper
     */
    public static getDefaultColumnFromSavedLayouts(columnLayoutTypeID?: string): ColumnLayoutResponse {
        const savedColumnList = AppStateService.getSavedColumnLayoutList();
        let savedList;
        if (savedColumnList?.length) {
            savedList = savedColumnList.filter((list) => {
                if (columnLayoutTypeID) {
                    return list.ColumnLayoutTypeID === Number(columnLayoutTypeID);
                }
                return list.IsDefault === COLUMN_LAYOUT_DEFAULT.IS_DEFAULT;
            });
        }
        if (savedList?.length) {
            return savedList[0];
        }
        return savedColumnList?.length ? savedColumnList[0] : undefined;
    }

    /**
     * Method to set default columns in custom tab if last used column layout is empty
     * @returns {ColumnLayoutResponse}
     * @memberof BaseColumnHelper
     */
    public static setDefaultAtrributes(): ColumnLayoutResponse {
        if (this.getDefaultColumnFromSavedLayouts()) {
            return this.getDefaultColumnFromSavedLayouts();
        }
        return {
            IsActive: false,
            UserID: 0,
            IsChecked: false,
            IsDefault: COLUMN_LAYOUT_DEFAULT.IS_NOT_DEFAULT,
            ColumnLayoutTypeID: 0,
            LayoutName: "",
            LayoutType: COLUMN_LAYOUT_TYPES.PRODUCT_SEARCH_CUSTOM,
            UserColumnLayout: defaultAttributeColumns,
        };
    }

    /**
     * Method to filter data that matches search
     *
     * @param {Array<any>} list
     * @param {string} keyToCheck
     * @param {string} search
     * @param {number} page
     * @return {*}  {Observable<Array<any>>}
     * @memberof BaseColumnLayoutComponent
     */
    public filterDropDownData(list: Array<any>, keyToCheck: string, search: string, page: number): Observable<Array<any>> {
        const take = 10;
        const skip = page > 0 ? (page - 1) * take : 0;
        if (keyToCheck === COLUMN_LAYOUT.COST_BOOK_CODE) {
            // eslint-disable-next-line no-param-reassign
            list =
                this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION) === false
                    ? filter(list, (cost) => includes(cost.costbookcode, DIVISION_LIST.FLAV))
                    : list;
        }
        const filtered = list?.filter((column) => {
            return column[keyToCheck].toLowerCase().includes(this.spaceTrim.transform(search.toLowerCase()));
        });
        return of(filtered?.slice(skip, skip + take));
    }

    /**
     * Method to validate white space
     *
     * @param {FormControl} control
     * @return {ValidationErrors}
     * @memberof BaseColumnLayoutComponent
     */
    public whitespaceValidator = (control: UntypedFormControl): ValidationErrors => {
        const isWhitespace = (control.value || EMPTY).trim()?.length === ZERO_LENGTH;
        return isWhitespace ? { whitespace: true } : undefined;
    };
}
