/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from "@angular/core";
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, ValidationErrors, Validators } from "@angular/forms";
import { delay, each, forEach, orderBy } from "lodash";
import { NGXLogger } from "ngx-logger";
import { Observable, of, Subject } from "rxjs";
import { exhaustMap, scan, startWith, switchMap, takeWhile, tap } from "rxjs/operators";
import { TasteEditorUtilClass } from "../../helpers/taste-editor-utils";
import { SpaceTrimPipe } from "../../pipes/space-trim/space-trim.pipe";
import { CopyColumnLayoutModel } from "../../../experiment-editor/models/experiment-editor.model";
import {
    COLUMN_ATTRIBUTE_DISPLAY_LIST,
    COLUMN_LAYOUT,
    COLUMN_LAYOUT_DELETE_ERROR,
    COLUMN_LAYOUT_FORMCONTROLNAME,
    COULMN_LAYOUT_WITH_ATTRIBUTES,
    DYNAMIC_PRODUCT_SEARCH_COLUMNS,
    MASTER_DATA,
    IPC_COLUMN_LAYOUT_VALIDATION_MSG,
} from "../../constants/common.constant";
// eslint-disable-next-line import/no-cycle
import { ExperimentHelper } from "../../helpers/experiment-helper";
import { MasterDataHelper } from "../../master-data/helpers/master-data.helper";
import { BaseColumnHelper } from "./helper/base-column-helper";
import { DISPLAY_VALUE } from "../../../creative-review/creative-review.constant";
import { CONTROLS, DRAG_AND_DROP_TOOLTIP } from "../../../app.constant";

const DEFAULT_FORM_COLUMN_LAYOUT = 13;

@Component({
    selector: "app-base-column-layout",
    templateUrl: "./base-column-layout.component.html",
})
export class BaseColumnLayoutComponent implements OnInit, OnChanges {
    public columnLayoutForm: UntypedFormGroup;

    public filteredAttributes: Observable<any>[] = [];

    public columnDisplayList = COLUMN_ATTRIBUTE_DISPLAY_LIST;

    public drapAndDropTooltip = DRAG_AND_DROP_TOOLTIP;

    public costBooksList: any;

    public flagsList: any;

    public cbwflagsList: any;

    public specsList: any;

    public plantLists: any;

    public errorColumnDelete = false;

    public columnsData = [];

    public disabledColumn = [];

    private nextPage$ = new Subject<void>();

    public defaultColumnCount = DEFAULT_FORM_COLUMN_LAYOUT;

    public validationMsg = IPC_COLUMN_LAYOUT_VALIDATION_MSG;

    @Input() public userColumnLayoutFormData: any;

    @Input() public isSavedTemplateTab: boolean;

    @Input() public isTitle: any;

    @Output()
    public onEmitFormValues = new EventEmitter();

    public columnLayoutFormName = COLUMN_LAYOUT_FORMCONTROLNAME;

    @Input() public copiedColumnsToCustom: CopyColumnLayoutModel[] = [];

    @Input() public selectedTabIndex: number;

    columnLayoutFormArray(): UntypedFormArray {
        return this.columnLayoutForm.get("Columns") as UntypedFormArray;
    }

    columnFormGroup(): UntypedFormGroup {
        return this.formBuilder.group({
            Columns: new UntypedFormControl(""),
            Attributes: new UntypedFormControl(""),
            ColumnHeader: new UntypedFormControl(""),
        });
    }

    constructor(
        public readonly formBuilder: UntypedFormBuilder,
        private readonly logger: NGXLogger,
        private readonly experimentHelper: ExperimentHelper,
        private readonly masterData: MasterDataHelper,
        private readonly baseColumnHelper: BaseColumnHelper,
        private readonly spaceTrim: SpaceTrimPipe,
    ) {
        this.columnLayoutForm = this.createColumnLayoutForm();
        this.columnsData = orderBy(DYNAMIC_PRODUCT_SEARCH_COLUMNS, DISPLAY_VALUE);
    }

    public ngOnInit(): void {
        this.getDefaultData();
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.selectedTabIndex) {
            this.selectedTabIndex = changes.selectedTabIndex.currentValue;
        }
        if (
            changes.copiedColumnsToCustom?.currentValue?.length > 0 &&
            changes.copiedColumnsToCustom?.previousValue !== changes.copiedColumnsToCustom?.currentValue
        ) {
            this.bindColumnLayoutFormData(changes.copiedColumnsToCustom.currentValue);
        }
        if (changes.userColumnLayoutFormData?.currentValue?.length > 0) {
            this.bindColumnLayoutFormData(changes.userColumnLayoutFormData.currentValue);
            return;
        }
        if (this.columnLayoutForm.get("Columns") && this.columnLayoutForm.get("Columns")[CONTROLS].length === 0) {
            this.defaultSetColumns(this.defaultColumnCount);
        }
    }

    /**
     * Method to load the auto complete values
     *
     * @memberof BaseColumnLayoutComponent
     */
    public getDefaultData(): void {
        this.masterData
            .checkAndFetchDefaultData([
                MASTER_DATA.FACILITIES,
                MASTER_DATA.FLAGS,
                MASTER_DATA.CBW_FLAGS,
                MASTER_DATA.COSTS,
                MASTER_DATA.SPECS,
                MASTER_DATA.PLANT_SOURCE,
                MASTER_DATA.FLAVOR_TYPES,
            ])
            .subscribe({
                next: (response) => {
                    if (response) {
                        this.costBooksList = response.costs;
                        this.flagsList = response?.flags;
                        this.cbwflagsList = response?.cbwflags;
                        this.specsList = response?.specs;
                        this.plantLists = this.experimentHelper.getPlantInfoBasedOnFacilities(response);
                        this.plantLists = TasteEditorUtilClass.getUniqueListBy(this.plantLists, "plantCode");
                    }
                },
                error: (error) => {
                    this.logger.error(error);
                },
            });
    }

    /**
     * Method to intiate the form group
     *
     * @private
     * @memberof BaseColumnLayoutComponent
     */
    private createColumnLayoutForm = (): UntypedFormGroup => {
        return this.formBuilder.group({
            Columns: new UntypedFormArray([], [this.layoutForm]),
        });
    };

    /**
     * Method to load the default column and attributes
     *
     * @memberof BaseColumnLayoutComponent
     */
    public defaultSetColumns(layoutCount: number): void {
        for (let index = 0; index < layoutCount; index += 1) this.columnLayoutFormArray().push(this.columnFormGroup());
        this.hideColumnError();
    }

    /**
     * Method to add the new columns
     *
     * @memberof BaseColumnLayoutComponent
     */
    public addNewColumn(): void {
        if (this.columnLayoutForm.get("Columns").value.length < this.defaultColumnCount) {
            const columnData = this.columnFormGroup();
            this.columnLayoutFormArray().push(columnData);
        }
        this.hideColumnError();
    }

    /**
     * Method to trigger next page while scrolling
     *
     * @memberof BaseColumnLayoutComponent
     */
    public onScroll() {
        this.nextPage$.next();
    }

    /**
     * Method to bind the autocomplete data for attributes
     *
     * @param {number} index
     * @memberof BaseColumnLayoutComponent
     */
    public bindAttributesControl(index: number): void {
        const arrayControl = this.columnLayoutFormArray();
        this.filteredAttributes[index] = arrayControl
            .at(index)
            .get("Attributes")
            .valueChanges.pipe(
                startWith(""),
                switchMap((search: string) => {
                    // Note: Reset the page with every new seach text
                    let currentPage = 1;
                    return this.nextPage$.pipe(
                        startWith(currentPage),
                        exhaustMap(() => this.getAttributeValues(arrayControl.at(index).get("Columns").value, search, currentPage)),
                        tap(() => {
                            currentPage += 1;
                        }),
                        /** Note: This is a custom operator because we also need the last emitted value.
                            Note: Stop if there are no more pages, or no results at all for the current search text.
                        */
                        takeWhile((filteredItems) => filteredItems?.length > 0, true),
                        // eslint-disable-next-line unicorn/prefer-spread
                        scan((filteredItems: Array<any>, newItems: Array<any>) => filteredItems.concat(newItems), []),
                    );
                }),
            );
    }

    /**
     * Method to get attribute values for given column
     *
     * @param {string} columnValue
     * @param {string} search
     * @param {number} page
     * @return {*}  {Observable<Array<any>>}
     * @memberof BaseColumnLayoutComponent
     */
    private getAttributeValues(columnValue: string, search: string, page: number): Observable<Array<any>> {
        let attributeArray = [];
        let keytoCheck = "";
        const columnValueMap = {
            [this.columnDisplayList.SPEC]: () => {
                attributeArray = this.specsList;
                keytoCheck = COLUMN_LAYOUT.SPEC_CODE;
            },
            [this.columnDisplayList.COST_PER_KG]: () => {
                attributeArray = this.costBooksList;
                keytoCheck = COLUMN_LAYOUT.COST_BOOK_CODE;
            },
            [this.columnDisplayList.COST_PER_PARTS]: () => {
                attributeArray = this.costBooksList;
                keytoCheck = COLUMN_LAYOUT.COST_BOOK_CODE;
            },
            [this.columnDisplayList.COST_CONTRIBUTION]: () => {
                attributeArray = this.costBooksList;
                keytoCheck = COLUMN_LAYOUT.COST_BOOK_CODE;
            },
            [this.columnDisplayList.FLAG]: () => {
                attributeArray = this.flagsList;
                keytoCheck = COLUMN_LAYOUT.FLAG_CODE;
            },
            [this.columnDisplayList.CBWFLAG]: () => {
                attributeArray = this.cbwflagsList;
                keytoCheck = COLUMN_LAYOUT.FLAG_CODE;
            },
            [this.columnDisplayList.STOCK]: () => {
                attributeArray = this.plantLists;
                keytoCheck = COLUMN_LAYOUT.PLANT_CODE;
            },
            [this.columnDisplayList.PLANT_ALLOCATION]: () => {
                attributeArray = this.costBooksList;
                keytoCheck = COLUMN_LAYOUT.COST_BOOK_CODE;
            },
        };
        if (columnValueMap[columnValue]) {
            columnValueMap[columnValue]();
            return this.baseColumnHelper.filterDropDownData(attributeArray, keytoCheck, search, page);
        }
        return of([]);
    }

    /**
     * Method to bind the data when click on edit/view
     *
     * @param {*} formData
     * @memberof BaseColumnLayoutComponent
     */
    public bindColumnLayoutFormData(formData: any): void {
        this.columnLayoutForm = this.createColumnLayoutForm();
        this.disabledColumn = [];
        each(formData, (layout, key) => {
            this.columnLayoutFormArray().push(
                this.formBuilder.group({
                    Columns: new UntypedFormControl(layout.Columns),
                    Attributes: new UntypedFormControl(layout.Attributes),
                    ColumnHeader: new UntypedFormControl(layout.ColumnHeader),
                }),
            );
            this.columnLayoutForm.setControl("Columns", this.columnLayoutFormArray());
            if (layout.Attributes && this.selectedTabIndex === 0) {
                this.bindAttributesControl(Number(key));
            } else {
                this.disabledColumn.push(layout.Columns);
                this.disableNoColumn(layout.Columns);
            }
        });
        this.hideColumnError();
        this.onEmitFormValues.emit(this.columnLayoutForm);
    }

    /**
     * Method to call when selecting the value in the columns
     *
     * @param {number} index
     * @memberof BaseColumnLayoutComponent
     */
    public onSelectColumn(index: number, column?): void {
        this.columnLayoutFormArray().at(index).get("Attributes").setValue("");
        if (COULMN_LAYOUT_WITH_ATTRIBUTES.includes(this.columnLayoutFormArray().at(index).get("Columns").value)) {
            this.columnLayoutFormArray().at(index).get("Attributes").setValidators([Validators.required]);
            this.columnLayoutFormArray().at(index).get("ColumnHeader").setValue("");
        } else {
            this.disabledColumn.push(this.columnLayoutFormArray().at(index).get("Columns").value);
            this.columnLayoutFormArray().at(index).get("Attributes").clearValidators();
            this.columnLayoutFormArray().at(index).get("Attributes").reset();
            this.columnLayoutFormArray()
                .at(index)
                .get("ColumnHeader")
                .setValue(column?.displayValue ?? "");
        }
        this.bindAttributesControl(index);
        this.onEmitFormValues.emit(this.columnLayoutForm);
    }

    /**
     * Method to disable the columns in the type
     *
     * @returns {boolean}
     * @memberof BaseColumnLayoutComponent
     */
    public disableNoColumn(value: string): boolean {
        if (this.disabledColumn.length === 0) return false;

        const notDisableField = new Set(COULMN_LAYOUT_WITH_ATTRIBUTES);
        const selectedColumns = this.columnLayoutFormArray()
            .value.map((layout) => layout.Columns)
            .filter((column) => !notDisableField.has(column));
        return selectedColumns.includes(value);
    }

    /**
     * Method to disable attributes in layout dropdown
     *
     * @param {string} value
     * @param {string} displayList
     * @returns {boolean}
     * @memberof BaseColumnLayoutComponent
     */
    public disableNoAttribute(value: string, displayList: string): boolean {
        const dropDowns = {};
        each(COULMN_LAYOUT_WITH_ATTRIBUTES, (layoutColumn) => {
            dropDowns[layoutColumn] = [];
        });
        each(this.columnLayoutFormArray().value, (column) => {
            if (COULMN_LAYOUT_WITH_ATTRIBUTES.includes(column.Columns)) {
                dropDowns[column.Columns].push(column.Attributes);
            }
        });
        return dropDowns[displayList].includes(value);
    }

    /**
     * Method to emit the values after changing the attributes
     *
     * @memberof BaseColumnLayoutComponent
     */
    public onChangeAttributes(index: number): void {
        this.disabledColumn.push(this.columnLayoutFormArray().at(index).get("Attributes").value);
        this.bindAttributesControl(index);
        this.onEmitFormValues.emit(this.columnLayoutForm);
    }

    /**
     * Method to delete the column from the layout
     *
     * @param {number} index
     * @returns {void}
     * @memberof BaseColumnLayoutComponent
     */
    public deleteColumn(index: number): void {
        if (this.columnLayoutForm.get("Columns").value.length > 1) {
            const columnLayoutList =
                this.columnLayoutFormArray().at(index).value.Attributes ?? this.columnLayoutFormArray().at(index).value.Columns;
            const disableIndex = this.disabledColumn.indexOf(columnLayoutList);
            if (disableIndex > -1) {
                this.disabledColumn.splice(disableIndex, 1);
            }
            this.columnLayoutFormArray().removeAt(index);
            this.copiedColumnsToCustom.splice(index, 1);
            this.onEmitFormValues.emit(this.columnLayoutForm);
            return;
        }
        this.errorColumnDelete = true;
        delay(() => {
            this.errorColumnDelete = false;
        }, COLUMN_LAYOUT_DELETE_ERROR);
    }

    /**
     * Method to handle the drag and drop
     *
     * @param {CdkDragDrop<string[]>} event
     * @memberof BaseColumnLayoutComponent
     */
    public drop(event: CdkDragDrop<string[]>): void {
        moveItemInArray(this.columnLayoutForm.get("Columns")[CONTROLS], event.previousIndex, event.currentIndex);
        moveItemInArray(this.columnLayoutForm.get("Columns").value, event.previousIndex, event.currentIndex);
        this.bindAttributesControl(event.currentIndex);
        this.onEmitFormValues.emit(this.columnLayoutForm);
    }

    /**
     * Method to reset the defalt column layout
     *
     * @memberof BaseColumnLayoutComponent
     */
    public resetColumnLayout(): void {
        this.columnLayoutForm = this.createColumnLayoutForm();
        this.defaultSetColumns(this.defaultColumnCount);
        this.onEmitFormValues.emit(this.columnLayoutForm);
        this.disabledColumn = [];
    }

    /**
     * Method to check form is valid or invalid based on input values
     * @param {FormControl} control
     * @returns {ValidationErrors | null}
     * @memberof BaseColumnLayoutComponent
     */
    public layoutForm = (control: UntypedFormControl): ValidationErrors | null => {
        let isFormInvalid = false;
        forEach(control.value, (values, index) => {
            let result = {};
            // eslint-disable-next-line unicorn/prefer-switch
            if (values.Columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.SPEC) {
                result = this.specsList?.find(
                    (spec) => spec?.speccode?.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                );
            } else if (
                values.Columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.COST_PER_KG ||
                values.Columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.COST_PER_PARTS ||
                values.Columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.COST_CONTRIBUTION ||
                values.Columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.PLANT_ALLOCATION
            ) {
                result = this.costBooksList?.find(
                    (cost) => cost?.costbookcode?.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                );
            } else if (values.Columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.FLAG) {
                result = this.flagsList?.find(
                    (flag) => flag?.flagcode?.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                );
            } else if (values.Columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.CBWFLAG) {
                result = this.cbwflagsList?.find(
                    (cbwflag) => cbwflag?.flagcode?.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                );
            } else if (values.Columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.STOCK) {
                result = this.plantLists?.find(
                    (stock) => stock?.plantCode?.toUpperCase() === this.spaceTrim.transform(values?.Attributes?.toUpperCase()),
                );
            }
            if (!result) {
                isFormInvalid = true;
                control[CONTROLS][index].controls.Attributes.setErrors({ isInvalid: true });
            }
        });
        if (isFormInvalid) {
            return { isInvalid: true };
        }
        // eslint-disable-next-line unicorn/no-null
        return null;
    };

    /**
     * Method to reset error displayed
     */
    private hideColumnError(): void {
        if (this.errorColumnDelete) {
            this.errorColumnDelete = false;
        }
    }
}
