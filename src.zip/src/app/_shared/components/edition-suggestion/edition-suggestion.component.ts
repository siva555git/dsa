/* eslint-disable unicorn/no-nested-ternary */
/* eslint-disable max-lines */
import { Component, Inject, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MatTableDataSource } from "@angular/material/table";
import { delay, forEach, orderBy, sortBy } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { forkJoin, Subscription } from "rxjs";
import { filter, take } from "rxjs/operators";
import { PRODUCT } from "../../constants/context-menu.constant";
import {
    BOM_DIALOG_HEADING,
    BOM_RIGHTS,
    EDIT_SUGGEST_ACTIONS,
    IS_BOM_ACCESS,
} from "../../../experiment-editor/constants/experiment-editor.constant";
import { EditionSuggesstColumnLayoutHelper } from "../../../experiment-editor/helpers/edition-suggesst-column-layout.helper";
import { GridApiService } from "../../../experiment-editor/helpers/grid-api-service";
import { AppStateService } from "../../../_services/app-state/app.state.service";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { SearchDrawerHelper } from "../../helpers/search-drawer.helper";
import { AppCacheHelper } from "../../helpers/app-cache.service";
import { EDIT_SUGGEST_TABS } from "../../constants/experiment.constant";
import { ExperimentsModel } from "../../models/experiment-bom.model";
import { EMPTY, LOADING } from "../../../app.constant";
import { ColumnLayoutHelper } from "../../../master-data/helpers/column.layout.helper";
import {
    CartItemModel,
    EditionSuggesstionDialogDataModel,
    EditionSuggesstionItemModel,
    EditSuggestActionModel,
    LastUsedColumnLayoutModel,
    PassAuditModel,
} from "../../../experiment-editor/models/experiment-editor.model";
import {
    ALREADY_ADDED_IN_CART,
    ALREADY_OPEN,
    CANT_OPEN_EXPERIMENTS,
    CANT_OPEN_MORE_EXPERIMENTS,
    COLUMN_LAYOUT_ADDED_PAGE,
    COLUMN_LAYOUT_SUCCESS,
    COMMON_DIALOG_OLD,
    IPC_VALIDATION,
    KEYBOARD_KEYS,
} from "../../constants";
import { SelectedTabId, MAX_EXPORPRO_OPEN_LENGTH, SEARCH_AUDIT_STATUS } from "../../constants/common.constant";
import { BaseColumnHelper } from "../base-column-layout/helper/base-column-helper";
import { ConfirmationDialogComponent } from "../confirmation-dialog/confirmation-dialog.component";
import { SuggestFemaComponent } from "./suggest-fema/suggest-fema.component";
import { SuggestSolutionComponent } from "./suggest-solution/suggest-solution.component";
import { SuggestVariantComponent } from "./suggest-variant/suggest-variant.component";
import { SuggestEnumComponent } from "./suggest-enum/suggest-enum.component";

@Component({
    selector: "app-edit-suggest",
    templateUrl: "./edition-suggestion.component.html",
})
export class EditionSuggesstionComponent implements OnInit, OnDestroy {
    public displayColumns = [];

    public gridDataSource = new MatTableDataSource();

    public tabIndex = 0;

    public selectedIndex = 0;

    public selectedTabMap = SelectedTabId;

    public hideReplaceIcon: boolean;

    public isOpenColumnLayout = false;

    public disableSolutionTab: boolean;

    public disableFemaTab: boolean;

    public isLayoutChanged = false;

    public shouldShowVariantsColumns = true;

    public columnLayoutPage = COLUMN_LAYOUT_ADDED_PAGE;

    public lastUsedColumnLayout: LastUsedColumnLayoutModel[];

    public columnLayoutSlideOn;

    public dialogData: EditionSuggesstionDialogDataModel;

    public openProduct: ExperimentsModel;

    public cartList: CartItemModel[];

    public showSolutionPassAudits = true;

    public showFemaPassAudits = true;

    public showVariantPassAudits = true;

    public getDialogData: EditionSuggesstionDialogDataModel;

    public editSuggestTabName = EDIT_SUGGEST_TABS;

    public solutionData: EditionSuggesstionItemModel[];

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public variantData: any;

    public femaData: EditionSuggesstionItemModel[];

    private componentSubscriptions: Subscription = new Subscription();

    @ViewChild("suggestSolution") suggestSolution: SuggestSolutionComponent;

    @ViewChild("suggestFema") suggestFema: SuggestFemaComponent;

    @ViewChild("suggestVariant") suggestVariant: SuggestVariantComponent;

    @ViewChild("suggestEnum") suggestEnum: SuggestEnumComponent;

    constructor(
        private readonly dialogReference: MatDialogRef<EditionSuggesstionComponent>,
        private readonly toastrService: ToastrService,
        @Inject(MAT_DIALOG_DATA) private data: EditionSuggesstionDialogDataModel,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly editionSuggesstColumnLayoutHelper: EditionSuggesstColumnLayoutHelper,
        private readonly baseColumnHelper: BaseColumnHelper,
        private readonly dialog: MatDialog,
        private readonly gridApiService: GridApiService,
        private readonly logger: NGXLogger,
        private readonly appCacheHelper: AppCacheHelper,
    ) {}

    public ngOnInit(): void {
        this.dialogData = this.data;
        this.componentSubscriptions.add(
            this.dialogReference
                .keydownEvents()
                .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.onDialogClose();
                }),
        );
        this.hideReplaceIcon = this.dialogData?.isProductSearch ?? this.dialogData.titleDescription === undefined;
        this.subscribeTabNameService();
        this.columnLayoutSelection();
        this.listenColumnLayoutChanges();
        if (!this.dialogData.editionColumnLayout) {
            this.baseColumnHelper.setColumnLayout();
        }
        this.columnLayoutSlideOn = false;
        this.openProduct = this.data.openedExperimentOrProduct;
        this.cartList = this.data.cartList;
    }

    public ngOnDestroy(): void {
        this.componentSubscriptions.unsubscribe();
    }

    /**
     * Method to slide the column layout
     *
     * @memberof EditionSuggesstionComponent
     */
    public onSlidingColumnLayout(): void {
        this.columnLayoutSlideOn = !this.columnLayoutSlideOn;
        if (this.columnLayoutSlideOn) {
            this.lastUsedColumnLayout = ColumnLayoutHelper.updateLastUsedColumnLayout(AppStateService.getUserTabDetails());
        }
    }

    /**
     * Method to listening for colum layout change
     *
     * @memberof EditionSuggesstionComponent
     */
    public columnLayoutSelection(): void {
        this.componentSubscriptions.add(
            this.appBroadCastService.editLayouts.subscribe((results) => {
                if (results.type !== this.columnLayoutPage.BOM) return;

                this.isLayoutChanged = true;
                const { isFema, isSolution, isVariant, isEnum } = this.dialogData.productRow;
                if (isFema || isSolution || isVariant || isEnum) {
                    this.dialogData.editionColumnLayout = this.editionSuggesstColumnLayoutHelper.getDynamicColumnsForColumLayout(
                        results,
                        this.dialogData.facilities,
                    );
                    this.editionSuggesstColumnLayoutHelper.processEditionWithColumnLayout(
                        this.dialogData.productRow,
                        this.dialogData.facilities,
                        this.dialogData.editionColumnLayout,
                    );
                }
                if (results.eventType) {
                    this.toastrService.success(COLUMN_LAYOUT_SUCCESS.APPLIED_COLUMN_LAYOUT);
                }
            }),
        );
    }

    /**
     * Method to listen suggestion changes
     *
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public listenColumnLayoutChanges(): void {
        this.componentSubscriptions.add(
            this.appBroadCastService.getSuggestGridData.subscribe((gridData: EditionSuggesstionDialogDataModel) => {
                this.dialogData = gridData;
                if (this.columnLayoutSlideOn) this.columnLayoutSlideOn = false;
                this.getSuggestionColumnHeaderWidth();
            }),
        );
    }

    /**
     Method to handle tabName when opening Dialog Box
     *
     * @memberof EditionSuggesstionComponent
     */
    public subscribeTabNameService(): void {
        const requestedObservables = [this.appCacheHelper.getLatestTab(), this.appBroadCastService.getSuggestGridData.pipe(take(1))];
        this.componentSubscriptions.add(
            forkJoin(requestedObservables).subscribe({
                next: (resultData) => {
                    const latestTabResponse = resultData[0];
                    const getGridDataResponse = resultData[1];
                    this.dialogData = getGridDataResponse;
                    const solutionDetail = getGridDataResponse?.solutionData?.length;
                    const femaDetail = getGridDataResponse?.femaData?.length;
                    const variantDetail = getGridDataResponse?.variantData?.length;
                    const enumDetail = getGridDataResponse?.enumData?.length;
                    const lastSelectedValue = latestTabResponse[0]?.selectedLastTab;
                    this.solutionData = getGridDataResponse?.solutionData;
                    this.femaData = getGridDataResponse?.femaData;
                    this.variantData = getGridDataResponse?.variantData;
                    delay(() => {
                        this.selectedIndex =
                            (lastSelectedValue === EDIT_SUGGEST_TABS.SOLUTION && solutionDetail) ||
                            (lastSelectedValue === EDIT_SUGGEST_TABS.FEMA && femaDetail) ||
                            (lastSelectedValue === EDIT_SUGGEST_TABS.VARIANT && variantDetail) ||
                            (lastSelectedValue === EDIT_SUGGEST_TABS.ENUM.replace(/\s+/g, "") && enumDetail)
                                ? +SelectedTabId[lastSelectedValue]
                                : this.getDefaultTab(solutionDetail, femaDetail, enumDetail, variantDetail);
                    }, 500);
                    this.getSuggestionColumnHeaderWidth();
                    this.getLastActionOfPassAuditToggle(latestTabResponse);
                },
                error: (error) => {
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to handle default tab selection
     *
     * @param {number} solutionDataSize
     * @param {number} femaDataSize
     * @param {number} variantDataSize
     * @memberof EditionSuggesstionComponent
     */
    public getDefaultTab = (solutionDataSize: number, femaDataSize: number, enumDataSize: number, variantDataSize: number): number => {
        if (solutionDataSize) return SelectedTabId.SOLUTION;
        if (femaDataSize) return SelectedTabId.FEMA;
        if (enumDataSize) return SelectedTabId.ENUM;
        if (variantDataSize) return SelectedTabId.VARIANT;
        return SelectedTabId.SOLUTION;
    };

    /**
     * Method to handle Add/Replace Action for Suggestion
     *
     * @param {EditSuggestActionModel} event
     * @memberof EditionSuggesstionComponent
     */
    public onHandlingEditionAction(event: EditSuggestActionModel): void {
        this.storeHeaderWidthForSuggestion();
        const modifiedEvent = {
            ...event,
            ipc: event?.row?.ipc,
            femaDetails: this.dialogData.femaData,
            enumDetails: this.dialogData.enumData,
            solutionDetails: this.dialogData.solutionData,
            variantDetails: this.dialogData.variantData,
        };
        if (!this.openProduct) {
            this.validateProduct(modifiedEvent);
            return;
        }
        if (!modifiedEvent?.row?.otherdetails?.isbom) {
            const dialogMessage = CANT_OPEN_EXPERIMENTS;
            dialogMessage.message = BOM_DIALOG_HEADING.IS_BOM;
            dialogMessage.subMesssage = ` ${modifiedEvent.ipc} ${IS_BOM_ACCESS} `;
            const dialogOptions = COMMON_DIALOG_OLD;
            dialogOptions.data = dialogMessage;
            this.dialog.open(ConfirmationDialogComponent, dialogOptions);
            return;
        }
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.componentSubscriptions.add(
            this.gridApiService.getBomRightsForIpcs({ ipcs: [modifiedEvent.ipc] }).subscribe({
                next: (result) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (result[0]?.bomright) {
                        this.validateProduct(modifiedEvent);
                    } else {
                        const dialogMessage = CANT_OPEN_EXPERIMENTS;
                        dialogMessage.message = BOM_DIALOG_HEADING.BOM_RIGHTS;
                        dialogMessage.subMesssage = result[0]?.comment ? `${BOM_RIGHTS} ${modifiedEvent.ipc}` : result[0][EMPTY];
                        const dialogOptions = COMMON_DIALOG_OLD;
                        dialogOptions.data = dialogMessage;
                        this.dialog.open(ConfirmationDialogComponent, dialogOptions);
                    }
                },
                error: (error) => {
                    this.logger.error(error);
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                },
            }),
        );
    }

    /**
     * Method to validate product
     *
     * @param {any} productData
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public validateProduct(productData: EditSuggestActionModel): void {
        const isValidProducts = this.validateOpenProduct(productData, this.openProduct, this.cartList);
        this.onDialogClose(isValidProducts ? productData : undefined);
    }

    /**
     * Method to validate open product
     *
     * @param {ExperimentsModel} productData
     * @param {BomDetailExperimentsModel[]} openedExperimentOrProduct
     * @param {CartItemModel[]} cartLists
     * @return {boolean}
     * @memberof EditionSuggesstionComponent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
    public validateOpenProduct(productData: any, openedExperimentOrProduct: any, cartLists: CartItemModel[]): boolean {
        // eslint-disable-next-line no-param-reassign
        productData.IPC = productData.ipc;
        // eslint-disable-next-line no-param-reassign
        productData.Type = PRODUCT;
        if (!openedExperimentOrProduct) {
            return true;
        }
        const isMaxExpExceeds = SearchDrawerHelper.isMaxExpExceeds(openedExperimentOrProduct, cartLists);
        if (isMaxExpExceeds && productData?.action !== EDIT_SUGGEST_ACTIONS.REPLACE) {
            const dialogMessage = CANT_OPEN_MORE_EXPERIMENTS;
            dialogMessage.subMesssage = `${IPC_VALIDATION.CANNOT_ADD} ${cartLists.length + 1} ${IPC_VALIDATION.WORKSPACE_CAPACITY} ${
                MAX_EXPORPRO_OPEN_LENGTH - openedExperimentOrProduct.length
            } ${IPC_VALIDATION.BOM_COMPARE}`;
            const dialogOptions = COMMON_DIALOG_OLD;
            dialogOptions.data = dialogMessage;
            this.dialog.open(ConfirmationDialogComponent, dialogOptions);
            return false;
        }
        const isAlreadyOpened = SearchDrawerHelper.isAlreadyOpened(productData, openedExperimentOrProduct);
        if (isAlreadyOpened) {
            const dialogMessage = ALREADY_OPEN;
            dialogMessage.subMesssage = `${productData.ipc} ${IPC_VALIDATION.ALREADY_OPEN_SUB_MESSAGE}`;
            dialogMessage.message = `${IPC_VALIDATION.ALREADY_OPEN_MESSAGE}`;
            const dialogOptions = COMMON_DIALOG_OLD;
            dialogOptions.data = ALREADY_OPEN;
            this.dialog.open(ConfirmationDialogComponent, dialogOptions);
            return false;
        }
        const isAddedInCart = SearchDrawerHelper.isAddedInCart(productData, cartLists);
        if (isAddedInCart) {
            const dialogMessage = ALREADY_ADDED_IN_CART;
            dialogMessage.subMesssage = `${productData.ipc} ${IPC_VALIDATION.ADDED_IN_CART_SUB}`;
            dialogMessage.message = `${IPC_VALIDATION.ADDED_IN_CART_MESSAGE}`;
            const dialogOptions = COMMON_DIALOG_OLD;
            dialogOptions.data = ALREADY_ADDED_IN_CART;
            this.dialog.open(ConfirmationDialogComponent, dialogOptions);
            return false;
        }
        return true;
    }

    /**
     * Method to close dialog and to handle last selected tab
     * @param {*} [modifiedEvent]
     * @memberof EditionSuggesstionComponent
     */
    public onDialogClose(modifiedEvent?: EditSuggestActionModel): void {
        // eslint-disable-next-line unicorn/prefer-default-parameters
        const dialogResult = modifiedEvent ?? false;
        const getlastActionOfPassAuditToggle = {
            solutionAuditToggle: this.showSolutionPassAudits,
            femaAuditToggle: this.showFemaPassAudits,
            variantAuditToggle: this.showVariantPassAudits,
            selectedLastTab: SelectedTabId[Number(this.selectedIndex)],
        };
        this.appCacheHelper.storeLatestTab(getlastActionOfPassAuditToggle);
        this.storeHeaderWidthForSuggestion();
        this.dialogReference.close(dialogResult);
    }

    /**
     * Method to store column header width in ngrx store for solution/fema
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public storeHeaderWidthForSuggestion(): void {
        const storeCompHeaderMap = {
            [SelectedTabId.SOLUTION]: this.suggestSolution,
            [SelectedTabId.FEMA]: this.suggestFema,
            [SelectedTabId.ENUM]: this.suggestEnum,
            [SelectedTabId.VARIANT]: this.suggestVariant,
        };
        storeCompHeaderMap[this.selectedIndex].storeHeaderWidthForSuggestion(this.data.openEditionPopupFrom);
    }

    /**
     * Method to get last used width from store for solution/fema column header
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public getSuggestionColumnHeaderWidth(): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        delay(() => {
            const storeCompHeaderMap = {
                [SelectedTabId.SOLUTION]: this.suggestSolution,
                [SelectedTabId.FEMA]: this.suggestFema,
                [SelectedTabId.ENUM]: this.suggestEnum,
                [SelectedTabId.VARIANT]: this.suggestVariant,
            };
            storeCompHeaderMap[this.selectedIndex].getSuggestionColumnHeaderWidth(this.data.openEditionPopupFrom);
            const getActiveTabName =
                // eslint-disable-next-line no-nested-ternary
                this.selectedIndex === this.selectedTabMap.SOLUTION
                    ? EDIT_SUGGEST_TABS.SOLUTION
                    : this.selectedIndex === this.selectedTabMap.FEMA
                    ? EDIT_SUGGEST_TABS.FEMA
                    : EDIT_SUGGEST_TABS.VARIANT;
            this.showPassAudits(getActiveTabName);
            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
        }, 550);
    }

    /**
     * Method to show pass audit toggle based on active tab
     * @param {string} getTabName
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public showPassAudits(getTabName: string): void {
        if (getTabName === EDIT_SUGGEST_TABS.SOLUTION) {
            const actualSolution = this.dialogData?.solutionData;
            const filteredSolutionData = this.showSolutionPassAudits ? this.filterPassAuditToggleBased(actualSolution) : actualSolution;
            this.solutionData = sortBy(filteredSolutionData, (product) => product?.audit?.priority);
        }
        if (getTabName === EDIT_SUGGEST_TABS.FEMA) {
            const actualFema = this.dialogData?.femaData;
            const filteredFemaData = this.showFemaPassAudits ? this.filterPassAuditToggleBased(actualFema) : actualFema;
            this.femaData = sortBy(filteredFemaData, (product) => product?.audit?.priority);
        }
        if (getTabName === EDIT_SUGGEST_TABS.VARIANT) {
            const actualVariant = this.dialogData?.variantData;
            const filteredVariantData = this.showVariantPassAudits ? this.filterPassAuditToggleBased(actualVariant) : actualVariant;
            this.variantData = sortBy(filteredVariantData, (product) => product?.audit?.priority);
            this.variantData = orderBy(this.variantData, ["variantipc"], ["asc"]);
        }
    }

    /**
     * Method to show pass audit toggle from cache
     * @param {PassAuditModel} toggleAction
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public getLastActionOfPassAuditToggle(passAudittoggleAction: PassAuditModel[]): void {
        this.showSolutionPassAudits = passAudittoggleAction[0]?.solutionAuditToggle ?? this.showSolutionPassAudits;
        this.showFemaPassAudits = passAudittoggleAction[0]?.femaAuditToggle ?? this.showFemaPassAudits;
        this.showVariantPassAudits = passAudittoggleAction[0]?.variantAuditToggle ?? this.showVariantPassAudits;
        const updateBulbTabLists = [EDIT_SUGGEST_TABS.SOLUTION, EDIT_SUGGEST_TABS.FEMA, EDIT_SUGGEST_TABS.VARIANT];
        forEach(updateBulbTabLists, (tabList) => {
            this.showPassAudits(tabList);
        });
    }

    /**
     * Method to filter data based on show products that pass audit only toggle
     * @param {any} editionSuggestData
     * @return {any}
     * @memberof EditionSuggesstionComponent
     */
    // eslint-disable-next-line class-methods-use-this, @typescript-eslint/no-explicit-any
    public filterPassAuditToggleBased(editionSuggestData: any): any {
        return editionSuggestData?.filter(
            (product) =>
                product?.audit?.status === SEARCH_AUDIT_STATUS.STATUS_INFO || product?.audit?.status === SEARCH_AUDIT_STATUS.STATUS_PASS,
        );
    }
}
