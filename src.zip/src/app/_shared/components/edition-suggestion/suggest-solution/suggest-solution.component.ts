import { AfterViewInit, Component, ElementRef, EventEmitter, Input, Output, SimpleChanges, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTable, MatTableDataSource } from "@angular/material/table";
import { map } from "lodash";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import {
    EDIT_SUGGEST_ACTIONS,
    EDIT_SUGGEST_SOLUTION_DISPLAY_COLUMN,
} from "../../../../experiment-editor/constants/experiment-editor.constant";
import {
    ColumnLayoutDetails,
    EditionSuggestionProductRow,
    EditSuggestActionModel,
    ExpTrusteeModel,
} from "../../../../experiment-editor/models/experiment-editor.model";
import {
    COLUMN_LAYOUTS_CRITERIA,
    DEFAULT_SPEC_FLASHPOINT,
    EDITION_SUGGESTION_CONSTANTS,
    PRODUCT_SEARCH_CONSTANTS,
    SEARCH_AUDIT_STATUS,
} from "../../../constants";
import { EDIT_SUGGEST_TABS } from "../../../constants/experiment.constant";
import { BomSearchHelper } from "../../../helpers/bom-search.helper";
import { FlashpointConversionPipe } from "../../../pipes/flashpoint-conversion.pipe";
import { COLUMN_ID } from "../../display-grid-data/display-grid-data-constants";

@Component({
    selector: "app-suggest-solution",
    templateUrl: "./suggest-solution.component.html",
})
export class SuggestSolutionComponent implements AfterViewInit {
    @Input() public gridData = [];

    @Input() public hideReplaceIcon: boolean;

    @Input() public columnDetails: ColumnLayoutDetails;

    @Input() public passAuditToggle: boolean;

    @Output()
    public emitAction = new EventEmitter<EditSuggestActionModel>();

    public gridColumns = EDIT_SUGGEST_SOLUTION_DISPLAY_COLUMN;

    public constants = EDITION_SUGGESTION_CONSTANTS;

    public displayColumns = [];

    public dynamicColumns = [];

    public dataLoaded = false;

    public auditStatus = SEARCH_AUDIT_STATUS;

    public gridDataSource = new MatTableDataSource([{}]);

    @ViewChild(MatTable, { read: ElementRef }) private matTableRef: ElementRef;

    @ViewChild(MatSort) set content(content: ElementRef) {
        this.sort = content;
        if (this.sort) {
            this.gridDataSource.sort = this.sort;
        }
    }

    public flashPoint = DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME;

    public showText = false;

    public columnLayouts = COLUMN_LAYOUTS_CRITERIA;

    public productSearchConstant = PRODUCT_SEARCH_CONSTANTS;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public sort: any;

    public applicationPermissions = APPLICATION_PERMISSIONS;

    constructor(private readonly flashpointConversion: FlashpointConversionPipe, private readonly bomSearchHelper: BomSearchHelper) {}

    public ngAfterViewInit(): void {
        if (this.gridDataSource) {
            this.gridDataSource.sort = this.sort;
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.gridData?.currentValue && !changes.gridData?.firstChange) {
            if (!this.dataLoaded) this.dataLoaded = true;
            this.gridData = changes.gridData?.currentValue;
        }
        if (changes.columnDetails?.currentValue) {
            this.columnDetails = changes.columnDetails?.currentValue;
            this.dynamicColumns = this.columnDetails?.dynamicColumns;
            const columns = this.columnDetails?.dynamicColumns?.map((column) => column.value);
            columns.unshift(...map(this.gridColumns, COLUMN_ID));
            this.displayColumns = [...new Set(columns)];
        }
        if (this.gridData) {
            if (this.displayColumns.includes(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME)) {
                this.gridData = this.flashpointConversion.transform(this.gridData, true);
            }
            this.gridDataSource.data = this.gridData;
        }
    }

    /**
     * Method to handle Add Action for Suggestion
     *
     * @param {EditionSuggestionProductRow} row
     * @memberof SuggestSolutionComponent
     */
    public onAddSuggestion(row: EditionSuggestionProductRow): void {
        this.emitAction.emit({ action: EDIT_SUGGEST_ACTIONS.ADD, suggestionType: EDIT_SUGGEST_TABS.SOLUTION, row });
    }

    /**
     * Method to handle Replace Action for Suggestion
     *
     * @param {EditionSuggestionProductRow} row
     * @memberof SuggestSolutionComponent
     */
    public onReplaceSuggestion(row: EditionSuggestionProductRow): void {
        this.emitAction.emit({ action: EDIT_SUGGEST_ACTIONS.REPLACE, suggestionType: EDIT_SUGGEST_TABS.SOLUTION, row });
    }

    /**
     * Method to store column header width in ngrx store for solution/fema
     *  @param {string} actionFor
     * @return {void}
     * @memberof SuggestSolutionComponent
     */
    public storeHeaderWidthForSuggestion(actionFor: string): void {
        this.bomSearchHelper.storeColumnLayoutWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to set last used width in solution/fema column header
     * @return {void}
     * @memberof SuggestSolutionComponent
     */
    public getSuggestionColumnHeaderWidth(actionFor: string): void {
        this.bomSearchHelper.getColumnHeaderWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to fetch trustee name
     * @param {ExpTrusteeModel} row
     * @returns {string}
     *
     * @memberof SuggestSolutionComponent
     */
    // eslint-disable-next-line class-methods-use-this
    public getTrusteeDisplayName(row: ExpTrusteeModel): string {
        return BomSearchHelper.getTrusteeDisplayName(row);
    }
}
