/* eslint-disable dot-notation */
/* eslint-disable no-empty-function */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable max-lines-per-function */
import { HttpClient, HttpHandler } from "@angular/common/http";
import { CUSTOM_ELEMENTS_SCHEMA, ElementRef, SimpleChanges } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { AppDataService } from "@te-services/app-data/app.data.service";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { BaseColumnHelper } from "@te-shared/components/base-column-layout/helper/base-column-helper";
import { OAuthService } from "angular-oauth2-oidc";
import { NGXLogger } from "ngx-logger";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { FlashpointConversionPipe } from "@te-shared/pipes/flashpoint-conversion.pipe";
import { DEFAULT_SPEC_FLASHPOINT } from "@te-shared/constants";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { PassAuditFilterPipe } from "@te-shared/pipes/pass-audit-filter/pass-audit-filter.pipe";
import { MockOAuthService } from "../../../../testing/mock-oauth.service";
import { DISPLAY_GRID_DATA } from "../../../../testing/mock-display-grid.helper";
import { SuggestSolutionComponent } from "./suggest-solution.component";
import { MatTableModule } from "@angular/material/table";
import { MatTabsModule } from "@angular/material/tabs";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { AttributeColumnHeaderPipe } from "@te-shared/pipes/attribute-column-header.pipe";
import { RestrictedAccessLabelPipe } from "@te-shared/pipes/restricted-access-label.pipe";
import { AttributeColumnHelper } from "@te-experiment-editor/helpers/attribute-column-helper";
import { ResizeColumnDirective } from "@te-shared/directives/resize-column/resize-column.directive";

describe("SuggestSolutionComponent", () => {
    let component: SuggestSolutionComponent;
    let fixture: ComponentFixture<SuggestSolutionComponent>;
    const editionSuggestionProductRow = {
        isSolution: true,
        isFema: true,
        isEnum: true,
        ipc: "123",
        solutionData: [
            {
                ipc: "00159000",
                description: "OXYPHENYLON",
                materialparts: 0.1,
                solutionipc: "00150363",
                solutiontype: "d",
                solventdescription: "ETH ALC TAX PAID 95 PCT",
                solventipc: "00058604",
                solventparts: 1,
            },
            {
                ipc: "00159000",
                description: "OXYPHENYLON",
                materialparts: 0.1,
                solutionipc: "00150363",
                solutiontype: "d",
                solventdescription: "ETH ALC TAX PAID 95 PCT",
                solventipc: "00058604",
                solventparts: 1,
            },
        ],
    };
    class MockSearchDrawer {
        public storeColumnLayoutWidth = () => {};

        public getColumnHeaderWidth = () => {};
    }
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            providers: [
                BaseColumnHelper,
                AppBroadCastService,
                AppDataService,
                HttpClient,
                HttpHandler,
                AppStateService,
                SpaceTrimPipe,
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: BomSearchHelper,
                    useClass: MockSearchDrawer,
                },
                FlashpointConversionPipe,
                PassAuditFilterPipe,
                AttributeColumnHeaderPipe,
                RestrictedAccessLabelPipe,
                AttributeColumnHelper
            ],
            declarations: [SuggestSolutionComponent,
                AttributeColumnHeaderPipe,
                RestrictedAccessLabelPipe,
                ResizeColumnDirective
            ],
            imports: [
                MatTableModule,
                MatTabsModule,
                MatSlideToggleModule,
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SuggestSolutionComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should match the display columns count", () => {
        component.gridData = DISPLAY_GRID_DATA.DISPLAY_GRID;
        component.gridColumns = DISPLAY_GRID_DATA.DISPLAY_GRID_COLUMNS;
        const changes = {
            gridData: {
                currentValue: DISPLAY_GRID_DATA.DISPLAY_GRID,
            },
            columnDetails: {
                currentValue: DISPLAY_GRID_DATA.MOCK_COLUMN_DETAILS,
            },
        } as unknown as SimpleChanges;
        component.ngOnChanges(changes);
        fixture.detectChanges();
        expect(component.displayColumns.length).toBe(6);
    });

    it("should call onAddSuggestion", () => {
        const spy = spyOn(component, "onAddSuggestion").and.callThrough();
        component.onAddSuggestion(editionSuggestionProductRow);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onReplaceSuggestion", () => {
        const spy = spyOn(component, "onReplaceSuggestion").and.callThrough();
        component.onReplaceSuggestion(editionSuggestionProductRow);
        expect(spy).toHaveBeenCalled();
    });

    it("should call ngOnChanges if the flashpoint column is present", () => {
        component.displayColumns = [];
        component.displayColumns.push(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME);
        spyOn(component["flashpointConversion"], "transform").and.returnValue([]);
        component.ngOnChanges({});
        fixture.detectChanges();
        expect(component.displayColumns.length).toBe(1);
    });

    it("should call storeHeaderWidthForSuggestion", () => {
        component["matTableRef"] = {} as ElementRef;
        const spy = spyOn(component, "storeHeaderWidthForSuggestion").and.callThrough();
        component.storeHeaderWidthForSuggestion("productSearch");
        expect(spy).toHaveBeenCalled();
    });

    it("should call getSuggestionColumnHeaderWidth", () => {
        component["matTableRef"] = {} as ElementRef;
        const spy = spyOn(component, "getSuggestionColumnHeaderWidth").and.callThrough();
        component.getSuggestionColumnHeaderWidth("productSearch");
        expect(spy).toHaveBeenCalled();
    });
});
