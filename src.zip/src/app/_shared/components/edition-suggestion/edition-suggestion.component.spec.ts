/* eslint-disable no-empty-function */
/* eslint-disable max-lines-per-function */
import { HttpClient, HttpHandler } from "@angular/common/http";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from "@angular/material/dialog";
import { EditionSuggesstColumnLayoutHelper } from "@te-experiment-editor/helpers/edition-suggesst-column-layout.helper";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { AppDataService } from "@te-services/app-data/app.data.service";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { AppCacheHelper } from "@te-shared/helpers/app-cache.service";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { mockBomDetail, mockExperiment, mockProductBomDetails } from "@te-testing/mock-ag-grid-data";
import { MockAppcacheHelper } from "@te-testing/mock-app-cache-helper";
import { DISPLAY_GRID_DATA } from "@te-testing/mock-display-grid.helper";
import { MockGridapiService } from "@te-testing/mock-gridapi.service";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { MockOAuthService } from "@te-testing/mock-oauth.service";

import { MockToastrService } from "@te-testing/mock-toastr.service";
import { OAuthService } from "angular-oauth2-oidc";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { Observable, of } from "rxjs";
import { ExperimentsModel } from "@te-shared/models/experiment-bom.model";
import { SearchDrawerHelper } from "@te-shared/helpers/search-drawer.helper";
import { Store } from "@ngrx/store";
import { ColumnLayoutHelper } from "src/app/master-data/helpers/column.layout.helper";
import { MatTabsModule } from "@angular/material/tabs";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { BrowserModule } from "@angular/platform-browser";
import { MatButtonModule } from "@angular/material/button";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { EditionSuggesstionComponent } from "./edition-suggestion.component";
import { BaseColumnHelper } from "../base-column-layout/helper/base-column-helper";
import { KEYBOARD_KEYS } from "../../constants";
import {
    EditionSuggesstionDialogDataModel,
    EditSuggestActionModel,
    WorkSpaceModel,
} from "../../../experiment-editor/models/experiment-editor.model";

describe("EditionSuggesstionComponent", () => {
    let component: EditionSuggesstionComponent;
    let fixture: ComponentFixture<EditionSuggesstionComponent>;
    let sildingSpy;
    let columnLayoutSelectionSpy;
    let listenColumnLayoutChangesSpy;
    let subscribeTabNameServiceSpy;
    class MockDialogReference {
        public keydownEvents = () => {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const observable: Observable<any> = component.tabIndex === 2 ? of({ key: KEYBOARD_KEYS.ESCAPE }) : of();
            return observable;
        };

        public close = () => {
            return of();
        };
    }
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [EditionSuggesstionComponent],
            providers: [
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: AppCacheHelper, useClass: MockAppcacheHelper },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                AppBroadCastService,
                SpaceTrimPipe,
                SecurityHelper,
                EditionSuggesstColumnLayoutHelper,
                BaseColumnHelper,
                AppDataService,
                HttpClient,
                HttpHandler,
                AppStateService,
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                { provide: MAT_DIALOG_DATA, useValue: {} },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => {} },
                },
                { provide: GridApiService, useClass: MockGridapiService },
                {
                    provide: Store,
                },
                { provide: MAT_DIALOG_DATA, useValue: { solutionData: [] } },
            ],
            imports: [MatTabsModule, MatSlideToggleModule, MatDialogModule, BrowserAnimationsModule, BrowserModule, MatButtonModule],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(EditionSuggesstionComponent);
        component = fixture.componentInstance;
        component.dialogData = { solutionData: [], femaData: [] } as EditionSuggesstionDialogDataModel;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        sildingSpy = spyOn<any>(BomSearchHelper, "getLastUsedColumnLayout").and.returnValue({});
        columnLayoutSelectionSpy = spyOn(component, "columnLayoutSelection").and.returnValue();
        listenColumnLayoutChangesSpy = spyOn(component, "listenColumnLayoutChanges").and.returnValue();
        subscribeTabNameServiceSpy = spyOn(component, "subscribeTabNameService").and.returnValue();
        spyOn(component, "getSuggestionColumnHeaderWidth").and.returnValue();
        const service: BaseColumnHelper = TestBed.inject(BaseColumnHelper);
        const servicespyOn = spyOn(service, "formatColumnLayoutInfo");
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const spy = spyOn<any>(AppStateService, "getLastUsedLColumnLayout");
        spy.and.returnValue([{}]);
        servicespyOn.and.returnValue();
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on ngOnInit", () => {
        component.selectedIndex = 2;
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    it("should call onHandlingEditionAction", () => {
        const mockevent: EditSuggestActionModel = {
            action: "add",
            row: {
                isSolution: true,
                isFema: true,
                isEnum: true,
                ipc: "123",
                solutionData: [],
            },
            suggestionType: "FEMA",
        };
        spyOn(component, "storeHeaderWidthForSuggestion").and.returnValue();
        const spy = spyOn(component, "onHandlingEditionAction").and.callThrough();
        component.onHandlingEditionAction(mockevent);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onSlidingColumnLayout", () => {
        sildingSpy.and.returnValue({});
        spyOn(ColumnLayoutHelper, "updateLastUsedColumnLayout").and.returnValue([]);
        spyOn(AppStateService, "getUserTabDetails").and.returnValue({} as WorkSpaceModel);
        const spy = spyOn(component, "onSlidingColumnLayout").and.callThrough();
        component.onSlidingColumnLayout();
        expect(spy).toHaveBeenCalled();
    });

    it("should call columnLayoutSelection", () => {
        columnLayoutSelectionSpy.and.callThrough();
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        service.editLayoutSubject.next({ type: "Search" });
        // spyOn(service.editLayouts, "subscribe").and.returnValue(new Subscription({}));
        const service2: EditionSuggesstColumnLayoutHelper = TestBed.inject(EditionSuggesstColumnLayoutHelper);
        const newspy = spyOn(service2, "getDynamicColumnsForColumLayout");
        newspy.and.returnValue(DISPLAY_GRID_DATA.MOCK_COLUMN_DETAILS);
        spyOn(service2, "processEditionWithColumnLayout").and.returnValue();
        component.columnLayoutSelection();
        expect(columnLayoutSelectionSpy).toHaveBeenCalled();
    });

    it("should call listenColumnLayoutChanges", () => {
        listenColumnLayoutChangesSpy.and.callThrough();
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        service.getSuggestGridDataSubject.next({
            solutionData: [],
            femaData: [],
        });
        component.listenColumnLayoutChanges();
        expect(listenColumnLayoutChangesSpy).toHaveBeenCalled();
    });

    it("should call subscribeTabNameService", () => {
        subscribeTabNameServiceSpy.and.callThrough();
        component.subscribeTabNameService();
        expect(subscribeTabNameServiceSpy).toHaveBeenCalled();
    });

    it("should call onHandlingEditionAction", () => {
        component.openProduct = mockBomDetail as unknown as ExperimentsModel;
        spyOn(component, "storeHeaderWidthForSuggestion").and.returnValue();
        spyOn(component, "validateOpenProduct").and.returnValue(true);
        spyOn(component, "onHandlingEditionAction").and.callThrough();
        component.onHandlingEditionAction({} as EditSuggestActionModel);
        expect(subscribeTabNameServiceSpy).toHaveBeenCalled();
    });

    it("should call onHandlingEditionAction else", () => {
        component.openProduct = mockBomDetail as unknown as ExperimentsModel;
        const gridApiService = TestBed.inject(GridApiService);
        spyOn(component, "storeHeaderWidthForSuggestion").and.returnValue();
        spyOn(gridApiService, "getBomRightsForIpcs").and.returnValue(of([{ comment: "No Bom rights" }]));
        spyOn(component, "validateOpenProduct").and.returnValue(false);
        spyOn(component, "onHandlingEditionAction").and.callThrough();
        component.onHandlingEditionAction({} as EditSuggestActionModel);
        expect(subscribeTabNameServiceSpy).toHaveBeenCalled();
    });

    it("should call validateOpenProduct => maximum capacity on bom", () => {
        const cartList = [
            {
                Parts: "5",
                ExpFormulaID: "231234",
                SUBType: "E",
                Instruction: "test",
                IsDelete: 1,
            },
        ];
        const spy = spyOn(component, "validateOpenProduct").and.callThrough();
        component.validateOpenProduct({ IPC: "00010000" } as ExperimentsModel, mockProductBomDetails, cartList);
        expect(spy).toHaveBeenCalled();
    });

    it("should call validateOpenProduct => is added in cart", () => {
        const cartList = [
            {
                Parts: "5",
                ExpFormulaID: "231234",
                SUBType: "I",
                Instruction: "test",
                IsDelete: 1,
                SUBCode: "12345",
            },
        ];
        spyOn(SearchDrawerHelper, "isAddedInCart").and.returnValue(true);
        const isOpenProduct = component.validateOpenProduct({ IPC: "12345" } as ExperimentsModel, [mockBomDetail], cartList);
        expect(isOpenProduct).toBe(false);
    });

    it("should call validateOpenProduct => is alreay open", () => {
        const cartList = [
            {
                Parts: "5",
                ExpFormulaID: "231234",
                SUBType: "E",
                Instruction: "test",
                IsDelete: 1,
                IPC: "12345",
            },
        ];
        spyOn(SearchDrawerHelper, "isAlreadyOpened").and.returnValue(true);
        const hasMock = component.validateOpenProduct({ IPC: "12345" } as ExperimentsModel, [mockExperiment], cartList);
        expect(hasMock).toBe(false);
    });

    it("should call subscribeTabNameService", () => {
        const service: AppBroadCastService = TestBed.inject(AppBroadCastService);
        spyOn(service.getSuggestGridData, "pipe").and.returnValue(
            of({
                solutionData: [],
                femaData: [],
                variantData: [],
            }),
        );
        const latestTab = TestBed.inject(AppCacheHelper);
        spyOn(latestTab, "getLatestTab").and.returnValue(of("SOLUTION"));
        subscribeTabNameServiceSpy.and.callThrough();
        component.subscribeTabNameService();
        component.getDefaultTab(0, 1, 2, 3);
        expect(subscribeTabNameServiceSpy).toHaveBeenCalled();
    });

    it("should call showPassAudits is solution tab is active", () => {
        component.dialogData = { solutionData: [] } as EditionSuggesstionDialogDataModel;
        const spy = spyOn(component, "showPassAudits").and.callThrough();
        component.showPassAudits("SOLUTION");
        expect(spy).toHaveBeenCalled();
    });

    it("should call showPassAudits is fema tab is active", () => {
        component.dialogData = { femaData: [] } as EditionSuggesstionDialogDataModel;
        const spy = spyOn(component, "showPassAudits").and.callThrough();
        component.showPassAudits("FEMA");
        expect(spy).toHaveBeenCalled();
    });

    it("should call showPassAudits is variant tab is active", () => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        component.dialogData = { variantData: [] } as any;
        const spy = spyOn(component, "showPassAudits").and.callThrough();
        component.showPassAudits("VARIANT");
        expect(spy).toHaveBeenCalled();
    });

    it("should call getLastActionOfPassAuditToggle", () => {
        const spy = spyOn(component, "getLastActionOfPassAuditToggle").and.callThrough();
        component.getLastActionOfPassAuditToggle([]);
        expect(spy).toHaveBeenCalled();
    });
});
