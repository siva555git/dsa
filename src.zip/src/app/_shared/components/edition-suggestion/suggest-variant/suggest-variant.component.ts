import { AfterViewInit, Component, ElementRef, EventEmitter, Input, Output, SimpleChanges, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTable, MatTableDataSource } from "@angular/material/table";
import {
    EDIT_SUGGEST_ACTIONS,
    EDIT_SUGGEST_SOLUTION_DISPLAY_COLUMN,
    EDIT_SUGGEST_VARIANT_DISPLAY_COLUMNS,
} from "@te-experiment-editor/constants/experiment-editor.constant";
import {
    ColumnLayoutDetails,
    EditionSuggestionProductRow,
    EditSuggestActionModel,
    ExpTrusteeModel,
} from "@te-experiment-editor/models/experiment-editor.model";
import {
    COLUMN_ID,
    COLUMN_LAYOUTS_CRITERIA,
    DEFAULT_SPEC_FLASHPOINT,
    EDITION_SUGGESTION_CONSTANTS,
    SEARCH_AUDIT_STATUS,
} from "@te-shared/constants";
import { EDIT_SUGGEST_TABS } from "@te-shared/constants/experiment.constant";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { FlashpointConversionPipe } from "@te-shared/pipes/flashpoint-conversion.pipe";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";

@Component({
    selector: "app-suggest-variant",
    templateUrl: "./suggest-variant.component.html",
})
export class SuggestVariantComponent implements AfterViewInit {
    @Input() public gridData = [];

    @Input() public hideReplaceIcon: boolean;

    @Input() public shouldShowVariantsColumns: boolean;

    @Input() public columnDetails: ColumnLayoutDetails;

    @Input() public passAuditToggle: boolean;

    @Input() public parentIPC: string;

    @Output()
    public emitAction = new EventEmitter<EditSuggestActionModel>();

    @ViewChild(MatTable, { read: ElementRef }) private matTableRef: ElementRef;

    @ViewChild(MatSort) set content(content: ElementRef) {
        this.sort = content;
        if (this.sort) {
            this.gridDataSource.sort = this.sort;
        }
    }

    public constants = EDITION_SUGGESTION_CONSTANTS;

    public displayColumns = new Set();

    public dynamicColumns = [];

    public dataLoaded = false;

    public auditStatus = SEARCH_AUDIT_STATUS;

    public gridDataSource = new MatTableDataSource([{}]);

    public columnLayouts = COLUMN_LAYOUTS_CRITERIA;

    public showOnlyPassAudits = true;

    public applicationPermissions = APPLICATION_PERMISSIONS;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public sort: any;

    constructor(private readonly flashpointConversion: FlashpointConversionPipe, private readonly bomSearchHelper: BomSearchHelper) {}

    public ngAfterViewInit(): void {
        if (this.gridDataSource) {
            this.gridDataSource.sort = this.sort;
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.gridData?.currentValue) {
            if (!this.dataLoaded) this.dataLoaded = true;
            this.gridData = changes.gridData?.currentValue;
        }
        if (changes.columnDetails?.currentValue) {
            this.columnDetails = changes.columnDetails?.currentValue;
            this.configureColumns(this.shouldShowVariantsColumns);
        }
        if (this.gridData) {
            if (this.displayColumns.has(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME)) {
                this.gridData = this.flashpointConversion.transform(this.gridData, true);
            }
            this.gridDataSource.data = this.gridData;
        }
        if (changes.shouldShowVariantsColumns) this.configureColumns(changes.shouldShowVariantsColumns.currentValue);
    }

    /**
     * Method to configure Variant columns
     *
     * @private
     * @param {boolean} shouldShowVariantsColumns
     * @memberof SuggestVariantComponent
     */
    private configureColumns(shouldShowVariantsColumns: boolean): void {
        this.dynamicColumns = shouldShowVariantsColumns
            ? // eslint-disable-next-line no-unsafe-optional-chaining
              [...EDIT_SUGGEST_VARIANT_DISPLAY_COLUMNS, ...this.columnDetails?.dynamicColumns]
            : this.columnDetails?.dynamicColumns;

        const columns = EDIT_SUGGEST_SOLUTION_DISPLAY_COLUMN.map((column) => column[COLUMN_ID]);
        // eslint-disable-next-line no-unsafe-optional-chaining
        columns.push(...this.dynamicColumns?.map((column) => column.value));
        this.displayColumns = new Set(columns);
    }

    /**
     * Method to handle Add Action for Suggestion
     *
     * @param {EditionSuggestionProductRow} row
     * @returns {void}
     * @memberof SuggestVariantComponent
     */
    public onAddSuggestion(row: EditionSuggestionProductRow): void {
        this.emitAction.emit({ action: EDIT_SUGGEST_ACTIONS.ADD, suggestionType: EDIT_SUGGEST_TABS.VARIANT, row });
    }

    /**
     * Method to handle Replace Action for Suggestion
     *
     * @param {EditionSuggestionProductRow} row
     * @returns {void}
     * @memberof SuggestVariantComponent
     */
    public onReplaceSuggestion(row: EditionSuggestionProductRow): void {
        this.emitAction.emit({ action: EDIT_SUGGEST_ACTIONS.REPLACE, suggestionType: EDIT_SUGGEST_TABS.VARIANT, row });
    }

    /**
     * Method to store column header width in ngrx store for solution/fema
     *  @param {string} actionFor
     * @return {void}
     * @memberof SuggestVariantComponent
     */
    public storeHeaderWidthForSuggestion(actionFor: string): void {
        this.bomSearchHelper.storeColumnLayoutWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to set last used width in solution/fema column header
     * @return {void}
     * @memberof SuggestVariantComponent
     */
    public getSuggestionColumnHeaderWidth(actionFor: string): void {
        this.bomSearchHelper.getColumnHeaderWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to fetch trustee name
     * @param {ExpTrusteeModel} row
     * @returns {string}
     *
     * @memberof SuggestVariantComponent
     */
    // eslint-disable-next-line class-methods-use-this
    public getTrusteeDisplayName(row: ExpTrusteeModel): string {
        return BomSearchHelper.getTrusteeDisplayName(row);
    }
}
