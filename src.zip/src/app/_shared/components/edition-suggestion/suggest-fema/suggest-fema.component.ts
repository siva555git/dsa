import { AfterViewInit, Component, ElementRef, EventEmitter, Input, Output, SimpleChanges, ViewChild } from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTable, MatTableDataSource } from "@angular/material/table";
// import { EventEmitter } from "events";
import { map } from "lodash";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { EDIT_SUGGEST_ACTIONS, EDIT_SUGGEST_FEMA_DISPLAY_COLUMN } from "../../../../experiment-editor/constants/experiment-editor.constant";
import {
    ColumnLayoutDetails,
    EditionSuggestionProductRow,
    EditSuggestActionModel,
    ExpTrusteeModel,
} from "../../../../experiment-editor/models/experiment-editor.model";
import { COLUMN_LAYOUTS_CRITERIA, DEFAULT_SPEC_FLASHPOINT, EDITION_SUGGESTION_CONSTANTS, SEARCH_AUDIT_STATUS } from "../../../constants";
import { EDIT_SUGGEST_TABS } from "../../../constants/experiment.constant";
import { BomSearchHelper } from "../../../helpers/bom-search.helper";
import { FlashpointConversionPipe } from "../../../pipes/flashpoint-conversion.pipe";
import { COLUMN_ID } from "../../display-grid-data/display-grid-data-constants";

@Component({
    selector: "app-suggest-fema",
    templateUrl: "./suggest-fema.component.html",
})
export class SuggestFemaComponent implements AfterViewInit {
    @Input() public gridData = [];

    @Input() public hideReplaceIcon: boolean;

    @Input() public columnDetails: ColumnLayoutDetails;

    @Input() public passAuditToggle: boolean;

    @Output()
    public emitAction = new EventEmitter<EditSuggestActionModel>();

    public auditStatus = SEARCH_AUDIT_STATUS;

    public gridColumns = EDIT_SUGGEST_FEMA_DISPLAY_COLUMN;

    public constants = EDITION_SUGGESTION_CONSTANTS;

    public displayColumns = [];

    public dynamicColumns = [];

    public dataLoaded = false;

    public pageSize = 20;

    public gridDataSource = new MatTableDataSource([{}]);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public sort: any;

    @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

    @ViewChild(MatTable, { read: ElementRef }) private matTableRef: ElementRef;

    @ViewChild(MatSort) set content(content: ElementRef) {
        this.sort = content;
        if (this.sort) {
            this.gridDataSource.sort = this.sort;
        }
    }

    public flashPoint = DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME;

    public columnLayouts = COLUMN_LAYOUTS_CRITERIA;

    public showOnlyPassAudits = true;

    public applicationPermissions = APPLICATION_PERMISSIONS;

    constructor(private readonly flashpointConversion: FlashpointConversionPipe, private readonly bomSearchHelper: BomSearchHelper) {}

    public ngAfterViewInit(): void {
        if (this.gridDataSource) {
            this.gridDataSource.sort = this.sort;
            this.gridDataSource.paginator = this.paginator;
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.gridData?.currentValue) {
            if (!this.dataLoaded) this.dataLoaded = true;
            this.gridData = changes.gridData?.currentValue;
        }
        if (changes.columnDetails?.currentValue) {
            this.columnDetails = changes.columnDetails?.currentValue;
            this.dynamicColumns = this.columnDetails?.dynamicColumns;
            const columns = this.columnDetails?.dynamicColumns?.map((column) => column.value);
            columns.unshift(...map(this.gridColumns, COLUMN_ID));
            this.displayColumns = [...new Set(columns)];
        }
        if (this.gridData) {
            if (this.displayColumns.includes(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME)) {
                this.gridData = this.flashpointConversion.transform(this.gridData, true);
            }
            this.gridDataSource.data = this.gridData;
            this.pageSize = this.gridDataSource && this.gridDataSource.data?.length < 20 ? 20 : 8;
        }
    }

    /**
     * Method to handle Add Action for Suggestion
     *
     * @param {EditionSuggestionProductRow} row
     * @memberof SuggestFemaComponent
     */
    public onAddSuggestion(row: EditionSuggestionProductRow): void {
        this.emitAction.emit({ action: EDIT_SUGGEST_ACTIONS.ADD, suggestionType: EDIT_SUGGEST_TABS.FEMA, row });
    }

    /**
     * Method to handle Replace Action for Suggestion
     *
     * @param {EditionSuggestionProductRow} row
     * @memberof SuggestFemaComponent
     */
    public onReplaceSuggestion(row: EditionSuggestionProductRow): void {
        this.emitAction.emit({ action: EDIT_SUGGEST_ACTIONS.REPLACE, suggestionType: EDIT_SUGGEST_TABS.FEMA, row });
    }

    /**
     * Method to store column header width in ngrx store for solution/fema
     * @param {string} actionFor
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public storeHeaderWidthForSuggestion(actionFor: string): void {
        this.bomSearchHelper.storeColumnLayoutWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to set last used width in solution/fema column header
     * @param {string} actionFor
     * @return {void}
     * @memberof EditionSuggesstionComponent
     */
    public getSuggestionColumnHeaderWidth(actionFor: string): void {
        this.bomSearchHelper.getColumnHeaderWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to fetch trustee name
     * @param {ExpTrusteeModel} row
     * @returns {string}
     *
     * @memberof EditionSuggesstionComponent
     */
    // eslint-disable-next-line class-methods-use-this
    public getTrusteeDisplayName(row: ExpTrusteeModel): string {
        return BomSearchHelper.getTrusteeDisplayName(row);
    }
}
