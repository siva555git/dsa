/* eslint-disable dot-notation */
/* eslint-disable no-empty-function */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable max-lines-per-function */
import { CUSTOM_ELEMENTS_SCHEMA, ElementRef, SimpleChanges } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { DEFAULT_SPEC_FLASHPOINT } from "@te-shared/constants";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { FlashpointConversionPipe } from "@te-shared/pipes/flashpoint-conversion.pipe";
import { PassAuditFilterPipe } from "@te-shared/pipes/pass-audit-filter/pass-audit-filter.pipe";
import { MockTabHelperService } from "@te-testing/mock-tabhelper.service";
import { MatTableModule } from "@angular/material/table";
import { AttributeColumnHeaderPipe } from "@te-shared/pipes/attribute-column-header.pipe";
import { RestrictedAccessLabelPipe } from "@te-shared/pipes/restricted-access-label.pipe";
import { AttributeColumnHelper } from "@te-experiment-editor/helpers/attribute-column-helper";
import { AppBroadCastService, AppStateService } from "@te-services/index";
import { ResizeColumnDirective } from "@te-shared/directives/resize-column/resize-column.directive";
import { DISPLAY_GRID_DATA } from "../../../../testing/mock-display-grid.helper";
import { SuggestFemaComponent } from "./suggest-fema.component";

describe("SuggestFemaComponent", () => {
    let component: SuggestFemaComponent;
    let fixture: ComponentFixture<SuggestFemaComponent>;
    const editionSuggestionProductRow = {
        isSolution: true,
        isFema: true,
        isEnum: true,
        ipc: "123",
        solutionData: [
            {
                ipc: "00159000",
                description: "OXYPHENYLON",
                materialparts: 0.1,
                solutionipc: "00150363",
                solutiontype: "d",
                solventdescription: "ETH ALC TAX PAID 95 PCT",
                solventipc: "00058604",
                solventparts: 1,
            },
            {
                ipc: "00159000",
                description: "OXYPHENYLON",
                materialparts: 0.1,
                solutionipc: "00150363",
                solutiontype: "d",
                solventdescription: "ETH ALC TAX PAID 95 PCT",
                solventipc: "00058604",
                solventparts: 1,
            },
        ],
    };
    class MockSearchDrawer {
        public storeColumnLayoutWidth = () => {};

        public getColumnHeaderWidth = () => {};
    }
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            providers: [
                {
                    provide: TabHelper,
                    useClass: MockTabHelperService,
                },
                {
                    provide: BomSearchHelper,
                    useClass: MockSearchDrawer,
                },
                FlashpointConversionPipe,
                PassAuditFilterPipe,
                AttributeColumnHeaderPipe,
                RestrictedAccessLabelPipe,
                AttributeColumnHelper,
                AppStateService,
                AppBroadCastService,
            ],
            declarations: [SuggestFemaComponent, AttributeColumnHeaderPipe, RestrictedAccessLabelPipe, ResizeColumnDirective],
            imports: [MatTableModule],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SuggestFemaComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should match the display columns count", () => {
        component.gridData = DISPLAY_GRID_DATA.DISPLAY_GRID;
        component.gridColumns = DISPLAY_GRID_DATA.DISPLAY_GRID_COLUMNS;
        const changes = {
            gridData: {
                currentValue: DISPLAY_GRID_DATA.DISPLAY_GRID,
            },
            columnDetails: {
                currentValue: DISPLAY_GRID_DATA.MOCK_COLUMN_DETAILS,
            },
        } as unknown as SimpleChanges;
        component.ngOnChanges(changes);
        fixture.detectChanges();
        expect(component.displayColumns.length).toBe(6);
    });

    it("should call onAddSuggestion", () => {
        const spy = spyOn(component, "onAddSuggestion").and.callThrough();
        component.onAddSuggestion(editionSuggestionProductRow);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onReplaceSuggestion", () => {
        const spy = spyOn(component, "onReplaceSuggestion").and.callThrough();
        component.onReplaceSuggestion(editionSuggestionProductRow);
        expect(spy).toHaveBeenCalled();
    });

    it("should call ngOnChanges if the flashpoint column is present", () => {
        component.displayColumns = [];
        component.displayColumns.push(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME);
        spyOn(component["flashpointConversion"], "transform").and.returnValue([]);
        component.ngOnChanges({});
        fixture.detectChanges();
        expect(component.displayColumns.length).toBe(1);
    });

    it("should call storeHeaderWidthForSuggestion", () => {
        component["matTableRef"] = {} as ElementRef;
        const spy = spyOn(component, "storeHeaderWidthForSuggestion").and.callThrough();
        component.storeHeaderWidthForSuggestion("productSearch");
        expect(spy).toHaveBeenCalled();
    });

    it("should call getSuggestionColumnHeaderWidth", () => {
        component["matTableRef"] = {} as ElementRef;
        const spy = spyOn(component, "getSuggestionColumnHeaderWidth").and.callThrough();
        component.getSuggestionColumnHeaderWidth("productSearch");
        expect(spy).toHaveBeenCalled();
    });
});
