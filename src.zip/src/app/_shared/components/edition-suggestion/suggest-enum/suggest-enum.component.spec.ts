/* eslint-disable dot-notation */
/* eslint-disable no-empty-function */
/* eslint-disable @typescript-eslint/no-empty-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";

import { FlashpointConversionPipe } from "@te-shared/pipes/flashpoint-conversion.pipe";
import { TabHelper } from "@te-shared/helpers/tab-helper";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { MockTabHelperService } from "@te-testing/mock-tabhelper.service";
import { DISPLAY_GRID_DATA } from "@te-testing/mock-display-grid.helper";
import { CUSTOM_ELEMENTS_SCHEMA, ElementRef, SimpleChanges } from "@angular/core";
import { DEFAULT_SPEC_FLASHPOINT } from "@te-shared/constants/common.constant";
import { SuggestEnumComponent } from "./suggest-enum.component";
import { MatTableDataSource, MatTableModule } from "@angular/material/table";
import { AttributeColumnHeaderPipe } from "@te-shared/pipes/attribute-column-header.pipe";
import { ResizeColumnDirective } from "@te-shared/directives/resize-column/resize-column.directive";

// eslint-disable-next-line max-lines-per-function
describe("SuggestEnumComponent", () => {
    let component: SuggestEnumComponent;
    let fixture: ComponentFixture<SuggestEnumComponent>;
    const editionSuggestionProductRow = {
        isSolution: true,
        isFema: true,
        isEnum: true,
        ipc: "123",
        solutionData: [
            {
                ipc: "00159000",
                description: "OXYPHENYLON",
                materialparts: 0.1,
                solutionipc: "00150363",
                solutiontype: "d",
                solventdescription: "ETH ALC TAX PAID 95 PCT",
                solventipc: "00058604",
                solventparts: 1,
            },
            {
                ipc: "00159000",
                description: "OXYPHENYLON",
                materialparts: 0.1,
                solutionipc: "00150363",
                solutiontype: "d",
                solventdescription: "ETH ALC TAX PAID 95 PCT",
                solventipc: "00058604",
                solventparts: 1,
            },
        ],
    };

    class MockSearchDrawer {
        // eslint-disable-next-line @typescript-eslint/no-empty-function
        public storeColumnLayoutWidth = () => {};

        public getColumnHeaderWidth = () => {};
    }
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [SuggestEnumComponent,AttributeColumnHeaderPipe,ResizeColumnDirective],
            imports: [MatTableModule],
            providers: [
                {
                    provide: TabHelper,
                    useClass: MockTabHelperService,
                },
                {
                    provide: BomSearchHelper,
                    useClass: MockSearchDrawer,
                },
                FlashpointConversionPipe,
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SuggestEnumComponent);
        component = fixture.componentInstance;
        component.gridColumns = DISPLAY_GRID_DATA.DISPLAY_GRID_COLUMNS;
        component.gridDataSource = new MatTableDataSource(DISPLAY_GRID_DATA.DISPLAY_GRID);
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should match the display columns count", () => {
        const changes = {
            gridData: {
                currentValue: DISPLAY_GRID_DATA.DISPLAY_GRID,
            },
            columnDetails: {
                currentValue: DISPLAY_GRID_DATA.MOCK_COLUMN_DETAILS,
            },
        } as unknown as SimpleChanges;
        component.ngOnChanges(changes);
        fixture.detectChanges();
        expect(component.displayColumns.length).toBe(6);
    });
    it("should call onAddSuggestion", () => {
        spyOn(component.emitAction, "emit");
        const spy = spyOn(component, "onAddSuggestion").and.callThrough();
        component.onAddSuggestion(editionSuggestionProductRow);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onReplaceSuggestion", () => {
        const spy = spyOn(component, "onReplaceSuggestion").and.callThrough();
        component.onReplaceSuggestion(editionSuggestionProductRow);
        expect(spy).toHaveBeenCalled();
    });

    it("should call ngOnChanges if the flashpoint column is present", () => {
        component.displayColumns = [];
        component.displayColumns.push(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME);
        spyOn(component["flashpointConversion"], "transform").and.returnValue([]);
        component.ngOnChanges({});
        fixture.detectChanges();
        expect(component.displayColumns.length).toBe(1);
    });

    it("should call storeHeaderWidthForSuggestion", () => {
        component["matTableRef"] = {} as ElementRef;
        const spy = spyOn(component, "storeHeaderWidthForSuggestion").and.callThrough();
        component.storeHeaderWidthForSuggestion("productSearch");
        expect(spy).toHaveBeenCalled();
    });

    it("should call getSuggestionColumnHeaderWidth", () => {
        component["matTableRef"] = {} as ElementRef;
        const spy = spyOn(component, "getSuggestionColumnHeaderWidth").and.callThrough();
        component.getSuggestionColumnHeaderWidth("productSearch");
        expect(spy).toHaveBeenCalled();
    });
});
