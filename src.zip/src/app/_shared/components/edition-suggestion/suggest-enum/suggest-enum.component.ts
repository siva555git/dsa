import { Component, AfterViewInit, Input, Output, EventEmitter, ElementRef, SimpleChanges, ViewChild } from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource, MatTable } from "@angular/material/table";
import { EDIT_SUGGEST_ACTIONS, EDIT_SUGGEST_ENUM_DISPLAY_COLUMN } from "@te-experiment-editor/constants/experiment-editor.constant";
import {
    ColumnLayoutDetails,
    EditionSuggestionProductRow,
    EditSuggestActionModel,
    ExpTrusteeModel,
} from "@te-experiment-editor/models/experiment-editor.model";
import {
    COLUMN_ID,
    COLUMN_LAYOUTS_CRITERIA,
    DEFAULT_SPEC_FLASHPOINT,
    EDITION_SUGGESTION_CONSTANTS,
    SEARCH_AUDIT_STATUS,
} from "@te-shared/constants";
import { EDIT_SUGGEST_TABS } from "@te-shared/constants/experiment.constant";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { FlashpointConversionPipe } from "@te-shared/pipes/flashpoint-conversion.pipe";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { map, sortBy } from "lodash";

@Component({
    selector: "app-suggest-enum",
    templateUrl: "./suggest-enum.component.html",
})
export class SuggestEnumComponent implements AfterViewInit {
    public auditStatus = SEARCH_AUDIT_STATUS;

    public gridColumns = EDIT_SUGGEST_ENUM_DISPLAY_COLUMN;

    public constants = EDITION_SUGGESTION_CONSTANTS;

    public displayColumns: Array<string> = [];

    public dynamicColumns: Array<string> = [];

    public dataLoaded = false;

    public pageSize = 20;

    public gridDataSource = new MatTableDataSource([{}]);

    public flashPoint = DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME;

    public columnLayouts = COLUMN_LAYOUTS_CRITERIA;

    @ViewChild(MatSort, { static: false }) sort: MatSort;

    @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

    @ViewChild(MatTable, { read: ElementRef }) private matTableRef: ElementRef;

    @Input() public gridData = [];

    @Input() public hideReplaceIcon: boolean;

    @Input() public columnDetails: ColumnLayoutDetails;

    @Output()
    public emitAction = new EventEmitter<EditSuggestActionModel>();

    public applicationPermissions = APPLICATION_PERMISSIONS;

    constructor(private readonly flashpointConversion: FlashpointConversionPipe, private readonly bomSearchHelper: BomSearchHelper) {}

    public ngAfterViewInit(): void {
        if (this.gridDataSource) {
            this.gridDataSource.sort = this.sort;
            this.gridDataSource.paginator = this.paginator;
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.gridData?.currentValue) {
            if (!this.dataLoaded) this.dataLoaded = true;
            this.gridData = changes.gridData?.currentValue;
        }
        if (changes.columnDetails?.currentValue) {
            this.columnDetails = changes.columnDetails?.currentValue;
            this.dynamicColumns = this.columnDetails?.dynamicColumns;
            const columns = this.columnDetails?.dynamicColumns?.map((column) => column.value);
            columns.unshift(...map(this.gridColumns, COLUMN_ID));
            this.displayColumns = [...new Set(columns)];
        }
        if (this.gridData) {
            if (this.displayColumns.includes(DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME)) {
                this.gridData = this.flashpointConversion.transform(this.gridData, true);
            }
            this.gridData = sortBy(this.gridData, (product) => product?.audit?.priority);
            this.gridDataSource.data = this.gridData;
            this.pageSize = this.gridDataSource && this.gridDataSource.data?.length < 20 ? 20 : 8;
        }
    }

    /**
     * Method to handle Add Action for Suggestion
     *
     * @param {EditionSuggestionProductRow} row
     * @memberof SuggestEnumComponent
     */
    public onAddSuggestion(row: EditionSuggestionProductRow): void {
        this.emitAction.emit({ action: EDIT_SUGGEST_ACTIONS.ADD, suggestionType: EDIT_SUGGEST_TABS.ENUM, row });
    }

    /**
     * Method to handle Replace Action for Suggestion
     *
     * @param {EditionSuggestionProductRow} row
     * @memberof SuggestFemaComponent
     */
    public onReplaceSuggestion(row: EditionSuggestionProductRow): void {
        this.emitAction.emit({ action: EDIT_SUGGEST_ACTIONS.REPLACE, suggestionType: EDIT_SUGGEST_TABS.ENUM, row });
    }

    /**
     * Method to store column header width in ngrx store for solution/fema/enum
     * @param {string} actionFor
     * @return {void}
     * @memberof SuggestEnumComponent
     */
    public storeHeaderWidthForSuggestion(actionFor: string): void {
        this.bomSearchHelper.storeColumnLayoutWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to set last used width in solution/fema/enum column header
     * @param {string} actionFor
     * @return {void}
     * @memberof SuggestEnumComponent
     */
    public getSuggestionColumnHeaderWidth(actionFor: string): void {
        this.bomSearchHelper.getColumnHeaderWidth(this.matTableRef, actionFor);
    }

    /**
     * Method to fetch trustee name
     * @param {ExpTrusteeModel} row
     * @returns {string}
     *
     * @memberof SuggestEnumComponent
     */
    // eslint-disable-next-line class-methods-use-this
    public getTrusteeDisplayName(row: ExpTrusteeModel): string {
        return BomSearchHelper.getTrusteeDisplayName(row);
    }
}
