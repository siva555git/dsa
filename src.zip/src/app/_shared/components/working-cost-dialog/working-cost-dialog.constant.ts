export const WORKING_COST_DIALOG_DATA = [
    {
        costingHeader: "Total SAP Working Cost Per KG:",
        costingCalculation: undefined,
        isStatic: true,
    },
    {
        costingHeader: "Setup Machine (Fixed)",
        costingCalculation: "Setup Machine / Batch size in KG",
        isStatic: false,
    },
    {
        costingHeader: "Machine Rate (Variable)",
        costingCalculation: "Machine Rate",
        isStatic: false,
    },
    {
        costingHeader: "Packaging (Variable)",
        costingCalculation: "Packaging",
        isStatic: false,
    },
    {
        costingHeader: "Setup Labor (Fixed)",
        costingCalculation: "Setup Labor / Batch size in KG",
        isStatic: false,
    },
    {
        costingHeader: "Labor Rate (Variable)",
        costingCalculation: "Labor Rate",
        isStatic: false,
    },
    {
        costingHeader: "Total Manufacturing Cost per KG",
        costingCalculation: "Setup Machine (F) + Machine Rate (V) + Setup Labor (F) + Labor Rate (V)",
        isStatic: false,
    },
    {
        costingHeader: "Total Working Cost per KG",
        costingCalculation: "Total Manufacturing Cost per KG + Packaging (Variable)",
        isStatic: false,
    },
];

export const WORKING_COST_HEADER = {
    TOTAL_SAP_WORKING_COSTING: "Total SAP Working Cost Per KG:",
    SETUP_MACHINE: "Setup Machine (Fixed)",
    MACHINE_TIME: "Machine Rate (Variable)",
    PACKAGING: "Packaging (Variable)",
    SETUP_LABOR: "Setup Labor (Fixed)",
    LABOR_TIME: "Labor Rate (Variable)",
    TOTAL_MANUFACTURING_COST: "Total Manufacturing Cost per KG",
    TOTAL_WORKING_COST: "Total Working Cost per KG",
};
