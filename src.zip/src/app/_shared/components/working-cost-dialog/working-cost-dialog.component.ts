import { Component, OnInit, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { COST_KEYS_FOR_CURRENCY_CONVERSION, KEYBOARD_KEYS } from "@te-shared/constants";
import { forEach } from "lodash";
import { filter as rxFilter } from "rxjs/operators";
import { EMPTY } from "src/app/app.constant";
import { WorkingCostDialogData, WorkingCostResponse } from "../../models/costing-model";
import { WORKING_COST_DIALOG_DATA, WORKING_COST_HEADER } from "./working-cost-dialog.constant";

@Component({
    selector: "app-working-cost-dialog",
    templateUrl: "./working-cost-dialog.component.html",
    styleUrls: ["./working-cost-dialog.component.scss"],
})
export class WorkingCostDialogComponent implements OnInit {
    public workingCostDetail: WorkingCostResponse;

    public costDialogData: WorkingCostDialogData[] = WORKING_COST_DIALOG_DATA;

    public workingCostData = [];

    constructor(
        @Inject(MAT_DIALOG_DATA)
        public data: { workingCostInfo: WorkingCostResponse[]; batchSizeValue: number; plantID: string; techonology: string },
        private readonly dialogReference: MatDialogRef<WorkingCostDialogComponent>,
    ) {}

    ngOnInit(): void {
        [this.workingCostDetail] = this.data.workingCostInfo;
        this.formatCostBasedOnCurrency();
        this.formatDialogData();
        this.dialogReference
            .keydownEvents()
            .pipe(rxFilter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
            .subscribe(() => {
                this.dialogReference.close();
            });
    }

    /**
     * Method to format cost based on currency
     * @memberof WorkingCostDialogComponent
     */
    public formatCostBasedOnCurrency(): void {
        const conversionRate = AppStateService.getConversionRate() ?? 1;
        const rate = Number(1 / Number(conversionRate)).toFixed(3);
        Object.keys(this.workingCostDetail).forEach((costKeys) => {
            if (COST_KEYS_FOR_CURRENCY_CONVERSION.includes(costKeys)) {
                const costValue = Number(this.workingCostDetail[costKeys]) ?? 0;
                const costConvertedValue = costValue === 0 ? costValue : Number(Number(costValue) * Number(rate));
                this.workingCostDetail[costKeys] = costConvertedValue;
            } else {
                const costValue = Number(this.workingCostDetail[costKeys]) ?? 0;
                this.workingCostDetail[costKeys] = costValue;
            }
        });
    }

    /**
     * Method to format Dialog Data
     * @memberof WorkingCostDialogComponent
     */
    public formatDialogData(): void {
        forEach(this.costDialogData, (dialogData) => {
            const formattedCostingDialogData = this.handleDialogData(dialogData);
            this.workingCostData.push(formattedCostingDialogData);
        });
    }

    /**
     * Method to round off cost value
     * @memberof WorkingCostDialogComponent
     */
    public formattedCostValue(costValue) {
        return costValue.toFixed(3);
    }

    /**
     * Method to handle dialog Data
     * @param {WorkingCostDialogData} costingData
     * @returns {WorkingCostDialogData}
     * @memberof WorkingCostDialogComponent
     */
    // eslint-disable-next-line max-lines-per-function
    public handleDialogData(costingData: WorkingCostDialogData): WorkingCostDialogData {
        let payloadData;
        switch (costingData.costingHeader) {
            case WORKING_COST_HEADER.TOTAL_SAP_WORKING_COSTING: {
                payloadData = {
                    costingHeader: costingData.costingHeader,
                    costingCalculation: costingData.costingCalculation,
                    isStatic: costingData.isStatic,
                    costingValue: `${this.formattedCostValue(this.workingCostDetail.SAPWorkingCost)} ${AppStateService.getCurrencyValue()}`,
                };
                break;
            }
            case WORKING_COST_HEADER.SETUP_MACHINE: {
                payloadData = {
                    costingHeader: costingData.costingHeader,
                    costingCalculation: costingData.costingCalculation,
                    isStatic: costingData.isStatic,
                    costingCalculationValue: `${this.formattedCostValue(this.workingCostDetail?.SetupMachine)} / ${
                        this.data?.batchSizeValue
                    }`,
                    costingValue: this.formattedCostValue(Number(this.workingCostDetail?.SetupMachine) / Number(this.data?.batchSizeValue)),
                };
                break;
            }
            case WORKING_COST_HEADER.MACHINE_TIME: {
                payloadData = {
                    costingHeader: costingData.costingHeader,
                    costingCalculation: costingData.costingCalculation,
                    isStatic: costingData.isStatic,
                    costingCalculationValue: `${this.formattedCostValue(this.workingCostDetail?.MachineTime)}`,
                    costingValue: this.formattedCostValue(this.workingCostDetail?.MachineTime),
                };
                break;
            }
            case WORKING_COST_HEADER.PACKAGING: {
                payloadData = {
                    costingHeader: costingData.costingHeader,
                    costingCalculation: costingData.costingCalculation,
                    isStatic: costingData.isStatic,
                    costingCalculationValue: `${this.formattedCostValue(this.workingCostDetail?.Packaging)}`,
                    costingValue: this.formattedCostValue(this.workingCostDetail?.Packaging),
                };
                break;
            }
            case WORKING_COST_HEADER.SETUP_LABOR: {
                payloadData = {
                    costingHeader: costingData.costingHeader,
                    costingCalculation: costingData.costingCalculation,
                    isStatic: costingData.isStatic,
                    costingCalculationValue: `${this.formattedCostValue(this.workingCostDetail?.SetupLabor)} / ${
                        this.data?.batchSizeValue
                    }`,
                    costingValue: this.formattedCostValue(Number(this.workingCostDetail?.SetupLabor) / Number(this.data?.batchSizeValue)),
                };
                break;
            }
            case WORKING_COST_HEADER.LABOR_TIME: {
                payloadData = {
                    costingHeader: costingData.costingHeader,
                    costingCalculation: costingData.costingCalculation,
                    isStatic: costingData.isStatic,
                    costingCalculationValue: `${this.formattedCostValue(this.workingCostDetail?.LaborTime)}`,
                    costingValue: this.formattedCostValue(this.workingCostDetail?.LaborTime),
                };
                break;
            }
            case WORKING_COST_HEADER.TOTAL_MANUFACTURING_COST: {
                const costValue = Number(
                    Number(this.workingCostDetail?.SetupMachine) +
                        Number(this.workingCostDetail?.MachineTime) +
                        Number(this.workingCostDetail?.SetupLabor) +
                        Number(this.workingCostDetail?.LaborTime),
                );
                payloadData = {
                    costingHeader: costingData.costingHeader,
                    costingCalculation: costingData.costingCalculation,
                    isStatic: costingData.isStatic,
                    costingCalculationValue: `${this.formattedCostValue(this.workingCostDetail?.SetupMachine)} + ${this.formattedCostValue(
                        this.workingCostDetail?.MachineTime,
                    )} + ${this.formattedCostValue(this.workingCostDetail?.SetupLabor)} + ${this.formattedCostValue(
                        this.workingCostDetail?.LaborTime,
                    )}`,
                    costingValue: this.formattedCostValue(costValue),
                };
                break;
            }
            case WORKING_COST_HEADER.TOTAL_WORKING_COST: {
                const totalManufactingCalculatedValue = Number(
                    Number(this.workingCostDetail?.SetupMachine) +
                        Number(this.workingCostDetail?.MachineTime) +
                        Number(this.workingCostDetail?.SetupLabor) +
                        Number(this.workingCostDetail?.LaborTime),
                );
                const workingCostCalculatedValue = Number(totalManufactingCalculatedValue) + Number(this.workingCostDetail?.Packaging);
                payloadData = {
                    costingHeader: costingData.costingHeader,
                    costingCalculation: costingData.costingCalculation,
                    isStatic: costingData.isStatic,
                    costingCalculationValue: `${this.formattedCostValue(totalManufactingCalculatedValue)} + ${this.formattedCostValue(
                        this.workingCostDetail?.Packaging,
                    )}`,
                    costingValue: this.formattedCostValue(workingCostCalculatedValue),
                };
                break;
            }
            default: {
                payloadData = {
                    costingHeader: EMPTY,
                    costingCalculation: EMPTY,
                    isStatic: false,
                };
            }
        }
        return payloadData;
    }
}
