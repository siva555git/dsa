/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";

import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { MockDialogReference } from "@te-testing/mock-dialog.reference";
import { WorkingCostDialogComponent } from "./working-cost-dialog.component";
import { MatTooltipModule } from "@angular/material/tooltip";

describe("WorkingCostDialogComponent", () => {
    let component: WorkingCostDialogComponent;
    let fixture: ComponentFixture<WorkingCostDialogComponent>;

    const dialogData = {
        workingCostInfo: [
            {
                BatchUpperSize: 10_000,
                LaborTime: 1.429_999_947_547_91,
                MachineTime: 0,
                // eslint-disable-next-line unicorn/no-null
                MinUsed: null,
                Packaging: 0.321_999_996_900_558,
                SAPWorkingCost: "1.752",
                SetupLabor: 0,
                SetupMachine: 0,
            },
        ],
        batchSizeValue: 10,
        plantID: "HHFL",
        techonology: "LIQUID ALCHOHOL",
    };

    class MockAppState {
        public getCurrencyValue = () => {
            return "USD";
        };

        public getConversionRate = () => {
            return 1;
        };
    }

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [WorkingCostDialogComponent],
            providers: [
                { provide: AppStateService, useClass: MockAppState },
                { provide: MAT_DIALOG_DATA, useValue: dialogData },
                { provide: MatDialogRef, useClass: MockDialogReference },
            ],
            imports: [MatTooltipModule]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(WorkingCostDialogComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on formatCostBasedOnCurrency", () => {
        spyOn(AppStateService, "getCurrencyValue").and.returnValue("USD");
        spyOn(AppStateService, "getConversionRate").and.returnValue(1);
        spyOn(component, "formatCostBasedOnCurrency").and.callThrough();
        component.formatCostBasedOnCurrency();
        expect(component.workingCostDetail?.MachineTime).toEqual(0);
    });

    it("should call on formatDialogData", () => {
        spyOn(component, "formatDialogData").and.callThrough();
        component.formatDialogData();
        expect(component.workingCostData[0].isStatic).toEqual(true);
    });

    it("should call on handleDialogData", () => {
        component.workingCostDetail = {
            BatchUpperSize: 10_000,
            LaborTime: 1.429_999_947_547_91,
            MachineTime: 0,
            // eslint-disable-next-line unicorn/no-null
            MinUsed: null,
            Packaging: 0.321_999_996_900_558,
            SAPWorkingCost: "1.752",
            SetupLabor: 0,
            SetupMachine: 0,
        };
        const costingDataPayload = {
            costingHeader: "Total SAP Working Cost Per KG:",
            costingCalculation: undefined,
            isStatic: true,
        };
        spyOn(component, "handleDialogData").and.callThrough();
        spyOn(component, "formattedCostValue").and.returnValue("1.752");
        const result = component.handleDialogData(costingDataPayload);
        expect(result.isStatic).toBe(true);
    });
});
