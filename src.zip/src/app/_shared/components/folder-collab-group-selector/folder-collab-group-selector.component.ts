import { AfterViewInit, ChangeDetectorRef, Component, Input, OnInit, ViewChild, SimpleChanges, HostListener } from "@angular/core";
import { UntypedFormControl } from "@angular/forms";
import { MatAutocompleteSelectedEvent, MatAutocompleteTrigger } from "@angular/material/autocomplete";
import { MatMenuTrigger } from "@angular/material/menu";
import { AppStateService } from "@te-services/index";
import { ExperimentFolderSelectorComponent } from "@te-shared/ag-grid-components/experiment-folder-selector/experiment-folder-selector.component";
import { EXPERIMENT_ACCESS, COLLABORATION_OWN_GROUP } from "@te-shared/constants";
import { BomSearchHelper } from "@te-shared/helpers/bom-search.helper";
import { TreeViewModel } from "@te-shared/models";
import { CollaborationGroupListModel } from "@te-shared/models/user-collaboration-group.model";
import { map, startWith } from "rxjs/operators";
import { delay } from "lodash";
import { EMPTY } from "../../../app.constant";

@Component({
    selector: "app-folder-collab-group-selector",
    templateUrl: "./folder-collab-group-selector.component.html",
})
export class FolderCollabGroupSelectorComponent implements OnInit, AfterViewInit {
    @HostListener("document:keydown.escape", ["$event"]) onKeydownHandler(): void {
        this.menu.closeMenu();
    }

    @Input() public userCollaborationGroupList: CollaborationGroupListModel[];

    @Input() public selectedFolderID: number;

    @Input() public selectedCollabGrpID: number;

    @Input() public isSelectorDisabled = false;

    @Input() public expFolderName = EMPTY;

    @Input() public customFolderMenuclass = EMPTY;

    @ViewChild("folderSelector") folderSelector: ExperimentFolderSelectorComponent;

    @ViewChild(MatMenuTrigger, { static: false }) menu: MatMenuTrigger;

    @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;

    public collaborationFormTitle = EXPERIMENT_ACCESS.ADD_TO_COLLABORATION_GROUP;

    public folderFormTitle = "Store in Folder";

    public selectedExpFolderName = EMPTY;

    public collaborationControl: UntypedFormControl = new UntypedFormControl(EMPTY);

    public chosenCollabGroup: CollaborationGroupListModel;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public searchResultList: any = [];

    public activeExpFolder: TreeViewModel;

    public collaborationOwnGroup = COLLABORATION_OWN_GROUP;

    public collabGroupDisplayValue = EMPTY;

    constructor(private readonly cdref: ChangeDetectorRef, private readonly appStateService: AppStateService) {}

    ngOnInit(): void {
        this.bindCollaborationControl();
        if (!this.isSelectorDisabled) this.selectedExpFolderName = this.appStateService.getCurrentUser().globaluserid;
    }

    ngAfterViewInit(): void {
        this.folderSelector.configAgGrid();
        this.cdref.detectChanges();
        this.folderSelector.foldersFetchSub$.subscribe(() => {
            if (this.selectedFolderID !== undefined) {
                delay(() => {
                    this.activeExpFolder = this.folderSelector.verifySelectedFolder(this.selectedFolderID);
                    this.selectedExpFolderName = this.activeExpFolder?.FolderName ?? this.selectedExpFolderName;
                }, 0);
            }
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.expFolderName?.currentValue !== undefined) {
            this.selectedExpFolderName = changes.expFolderName.currentValue;
            this.clearCollaborationGroup();
        }
        if (changes.isSelectorDisabled?.currentValue !== undefined) {
            if (changes.isSelectorDisabled?.currentValue) {
                this.activeExpFolder = undefined;
                this.collaborationControl.disable();
                // eslint-disable-next-line no-unused-expressions
                this.autocomplete?.closePanel();
                this.collaborationControl.setValue(EMPTY);
            } else {
                this.collaborationControl.enable();
                this.collaborationControl.setValue(this.chosenCollabGroup?.GroupName ?? EMPTY);
            }
        }
        if (changes.selectedCollabGrpID?.currentValue !== undefined) {
            this.chosenCollabGroup = this.userCollaborationGroupList?.find(
                (group) => group.CollaborationGroupID === changes.selectedCollabGrpID.currentValue,
            );
            if (this.collaborationControl.enabled) this.collaborationControl.setValue(this.chosenCollabGroup.GroupName);
        }
    }

    /**
     * Method to bind the valueChanges functions for collaboration form
     *
     * @memberof FolderCollabGroupSelectorComponent
     */
    public bindCollaborationControl(): void {
        this.searchResultList = this.collaborationControl.valueChanges.pipe(
            startWith(EMPTY),
            map((value) => BomSearchHelper.filterCategoryValues(this.userCollaborationGroupList, "GroupName", value)),
        );
    }

    /**
     * Method to handle folder selection
     *
     * @param {TreeViewModel} selectedFolder
     * @memberof FolderCollabGroupSelectorComponent
     */
    public onSelectedFolder(selectedFolder: TreeViewModel): void {
        this.activeExpFolder = selectedFolder;
        this.selectedExpFolderName = selectedFolder.FolderName;
        this.menu.closeMenu();
    }

    /**
     * Method to handle collaboration group selection
     *
     * @param {MatAutocompleteSelectedEvent} [autoCompleteEvent]
     * @memberof FolderCollabGroupSelectorComponent
     */
    public onSelectGroup(autoCompleteEvent?: MatAutocompleteSelectedEvent): void {
        if (!autoCompleteEvent) return;

        this.chosenCollabGroup = this.userCollaborationGroupList.find((group) => group.GroupName === autoCompleteEvent.option.value);
        this.collabGroupDisplayValue =
            this.chosenCollabGroup?.UserCollaborationGroupMapped[0].IsOwnedGroup.toString() === this.collaborationOwnGroup
                ? `${autoCompleteEvent.option.value} (${this.chosenCollabGroup?.CreatedByUser?.FirstName ?? ""})`
                : autoCompleteEvent.option.value;
        this.collaborationControl.setValue(this.collabGroupDisplayValue);
    }

    /**
     * Method to return the selected data
     *
     * @return {*}  {*}
     * @memberof FolderCollabGroupSelectorComponent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getSelectedData(): any {
        let expFolderID = this.activeExpFolder?.FolderID;
        if (!expFolderID) {
            expFolderID = this.folderSelector.getDefaultFolderID();
        }
        return {
            ExpFolderID: expFolderID,
            CollaborationGroupID: this.chosenCollabGroup?.CollaborationGroupID ?? 0,
        };
    }

    /**
     * Method to refresh the grid
     *
     * @memberof FolderCollabGroupSelectorComponent
     */
    public onMenuOpened(): void {
        this.folderSelector.refreshGrid();
    }

    /**
     * Method to clear the selected Collaboration Group
     *
     * @param {Event} event
     * @memberof FolderCollabGroupSelectorComponent
     */
    public clearCollaborationGroup(event?: Event): void {
        this.collaborationControl.setValue(EMPTY);
        this.chosenCollabGroup = undefined;
        // eslint-disable-next-line no-unused-expressions
        event?.stopPropagation();
    }
}
