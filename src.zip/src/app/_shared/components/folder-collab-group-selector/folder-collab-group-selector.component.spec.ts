/* eslint-disable max-lines-per-function */
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChange } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatAutocompleteModule, MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { MatMenuModule } from "@angular/material/menu";
import { AppStateService } from "@te-services/index";
import { ExperimentFolderSelectorComponent } from "@te-shared/ag-grid-components/experiment-folder-selector/experiment-folder-selector.component";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { TreeViewModel } from "@te-shared/models";
import {
    CollaborationGroupCreatedUser,
    CollaborationGroupListModel,
    CollaborationGroupMappedUser,
} from "@te-shared/models/user-collaboration-group.model";
import { MockAppStateService } from "@te-testing/mock-app.state.service";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { cloneDeep } from "lodash";
import { FolderCollabGroupSelectorComponent } from "./folder-collab-group-selector.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

describe("FolderCollabGroupSelectorComponent", () => {
    let component: FolderCollabGroupSelectorComponent;
    let fixture: ComponentFixture<FolderCollabGroupSelectorComponent>;
    const mockCreatedByUserInfo = { UserID: 65_820 };
    const mockCollaborationGroupListData = [
        {
            CollaborationGroupID: 420,
            CreatedByUser: mockCreatedByUserInfo as CollaborationGroupCreatedUser,
            GroupName: "light",
            UserCollaborationGroupMapped: [{ IsOwnedGroup: 0 } as CollaborationGroupMappedUser],
            GroupDescription: "test",
        },
    ];

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [FolderCollabGroupSelectorComponent, ExperimentFolderSelectorComponent],
            providers: [
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: ExperimentHelper, useClass: MockExperimentHelper },
            ],
            imports: [HttpClientTestingModule, MatMenuModule, MatAutocompleteModule, FormsModule, ReactiveFormsModule],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(FolderCollabGroupSelectorComponent);
        component = fixture.componentInstance;
        component.userCollaborationGroupList = cloneDeep(mockCollaborationGroupListData as CollaborationGroupListModel[]);
        fixture.detectChanges();
    });

    it("should create", () => {
        component.selectedFolderID = 0;
        expect(component).toBeTruthy();
    });

    it("should resolve for ngOnChanges", () => {
        component.expFolderName = "Testing";
        component.ngOnChanges({
            expFolderName: new SimpleChange(component.expFolderName, component.expFolderName, false),
            isSelectorDisabled: new SimpleChange(false, true, false),
            selectedCollabGrpID: new SimpleChange(undefined, 420, true),
        });
        fixture.detectChanges();
        expect(component.chosenCollabGroup).toEqual(component.userCollaborationGroupList[0]);
    });

    it("should resolve for onSelectedFolder", () => {
        const folderName = "Testing 2";
        component.onSelectedFolder({
            FolderName: folderName,
        } as unknown as TreeViewModel);
        expect(component.selectedExpFolderName).toEqual(folderName);
    });

    it("should resolve for onSelectGroup", () => {
        component.onSelectGroup({
            option: { value: "light" },
        } as unknown as MatAutocompleteSelectedEvent);
        expect(component.chosenCollabGroup).toEqual(component.userCollaborationGroupList[0]);
    });

    it("should resolve for getSelectedData", () => {
        const folderID = 12_345_678;
        component.activeExpFolder = { FolderID: folderID } as unknown as TreeViewModel;
        const result = component.getSelectedData();
        expect(result.ExpFolderID).toEqual(folderID);
    });

    it("should resolve for clearCollaborationGroup", () => {
        component.onSelectGroup({
            option: { value: "light" },
        } as unknown as MatAutocompleteSelectedEvent);
        component.clearCollaborationGroup();
        expect(component.chosenCollabGroup).toBeUndefined();
    });
});
