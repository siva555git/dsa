import { SelectionModel } from "@angular/cdk/collections";
import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MatTableDataSource } from "@angular/material/table";
import { map } from "lodash";
import { filter } from "rxjs/operators";
import { ExplodeBomItemDialogDataModel } from "../../../experiment-editor/models/experiment-editor.model";
import { COLUMN_ID } from "../../../experiment-editor/constants/experiment-editor.constant";
import { KEYBOARD_KEYS } from "../../constants/common.constant";

@Component({
    selector: "app-open-workspace-grid",
    templateUrl: "./open-workspace-grid.component.html",
})
export class OpenWorkspaceGridComponent implements OnInit {
    public displayColumns;

    public displayGridDataSource;

    public displayGridColumns;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public selection = new SelectionModel<any>(true, []);

    constructor(
        private readonly dialogReference: MatDialogRef<OpenWorkspaceGridComponent>,
        @Inject(MAT_DIALOG_DATA) public data: ExplodeBomItemDialogDataModel,
    ) {}

    ngOnInit(): void {
        this.dialogReference
            .keydownEvents()
            .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
            .subscribe(() => {
                this.dialogReference.close();
            });
        this.displayGridColumns = this.data.gridColumns;
        this.displayColumns = map(this.data.gridColumns, COLUMN_ID);
        this.displayGridDataSource = new MatTableDataSource(this.data.gridData);
        this.displayGridDataSource.data.forEach((row) => {
            if (row.bomRights) {
                this.selection.select(row);
            }
        });
    }

    /**
     * Method to close the open workspace grid Dialog
     * @returns {void}
     * @memberof OpenWorkspaceGridComponent
     */
    public closeOpenWorkspaceDialog(): void {
        this.dialogReference.close(this.selection.selected);
    }

    /**
     * Method to get selected data from open workspace grid model
     * @param {ExplodeBomItemModel} row
     * @returns {void}
     * @memberof OpenWorkspaceGridComponent
     */
    public emitSelectedData(row: ExplodeBomItemDialogDataModel): void {
        this.selection.toggle(row);
    }
}
