import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from "@angular/material/dialog";
import { mockExplodeBomItemDialogData } from "@te-testing/mock-context-menu.helper";
import { ExplodeBomItemDialogDataModel } from "@te-experiment-editor/models/experiment-editor.model";
import { CUSTOM_ELEMENTS_SCHEMA, EventEmitter } from "@angular/core";
import { OpenWorkspaceGridComponent } from "./open-workspace-grid.component";

describe("OpenWorkspaceGridComponent", () => {
    let component: OpenWorkspaceGridComponent;
    let fixture: ComponentFixture<OpenWorkspaceGridComponent>;
    let dialogReferenceSpy: jasmine.SpyObj<MatDialogRef<OpenWorkspaceGridComponent>>;

    beforeEach(waitForAsync(() => {
        dialogReferenceSpy = jasmine.createSpyObj("MatDialogRef", ["keydownEvents", "close"]);
        TestBed.configureTestingModule({
            imports: [MatDialogModule],
            declarations: [OpenWorkspaceGridComponent],
            providers: [
                { provide: MatDialogRef, useValue: dialogReferenceSpy },
                { provide: MAT_DIALOG_DATA, useValue: {} },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(OpenWorkspaceGridComponent);
        component = fixture.componentInstance;
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for closeOpenWorkspaceDialog() ", () => {
        const spy = spyOn(component, "closeOpenWorkspaceDialog").and.callThrough();
        component.closeOpenWorkspaceDialog();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for emitSelectedData() ", () => {
        const spy = spyOn(component, "emitSelectedData").and.callThrough();
        component.emitSelectedData(mockExplodeBomItemDialogData as unknown as ExplodeBomItemDialogDataModel);
        expect(spy).toHaveBeenCalled();
    });
    it("should close the dialog on ESCAPE keydown", () => {
        const eventEmitter = new EventEmitter<KeyboardEvent>();
        dialogReferenceSpy.keydownEvents.and.returnValue(eventEmitter.asObservable());
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
        fixture.detectChanges();
        eventEmitter.emit(new KeyboardEvent("keydown", { key: "Escape" }));
        expect(dialogReferenceSpy.close).toHaveBeenCalled();
    });
});
