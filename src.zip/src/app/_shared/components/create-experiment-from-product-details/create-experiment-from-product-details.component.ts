import { Component, Input, OnChanges, SimpleChanges } from "@angular/core";

@Component({
    selector: "app-create-experiment-from-product-details",
    templateUrl: "./create-experiment-from-product-details.component.html",
})
export class CreateExperimentFromProductDetailsComponent implements OnChanges {
    public productDetails;

    @Input() public productResults;

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.productResults?.currentValue) {
            this.productDetails = changes.productResults.currentValue;
        }
    }
}
