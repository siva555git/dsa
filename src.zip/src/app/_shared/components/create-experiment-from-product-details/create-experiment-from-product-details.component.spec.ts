import { SimpleChanges } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { CreateExperimentFromProductDetailsComponent } from "./create-experiment-from-product-details.component";

describe("CreateExperimentFromProductDetailsComponent", () => {
    let component: CreateExperimentFromProductDetailsComponent;
    let fixture: ComponentFixture<CreateExperimentFromProductDetailsComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CreateExperimentFromProductDetailsComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CreateExperimentFromProductDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on ngOnChanges", () => {
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        const changes = {
            productResults: {
                currentValue: {
                    IPC: "1RR04333",
                    description: "FOREST FRUITS",
                },
            },
        } as unknown as SimpleChanges;
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });
});
