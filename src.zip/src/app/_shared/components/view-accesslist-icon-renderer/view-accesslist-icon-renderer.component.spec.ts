import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { HighlightTextPipe } from "@te-shared/pipes/highlight-text.pipe";
import { ViewAccesslistIconRendererComponent } from "./view-accesslist-icon-renderer.component";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";

describe("ViewAccesslistIconRendererComponent", () => {
    let component: ViewAccesslistIconRendererComponent;
    let fixture: ComponentFixture<ViewAccesslistIconRendererComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ViewAccesslistIconRendererComponent, HighlightTextPipe],
            providers: [AppBroadCastService],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ViewAccesslistIconRendererComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call agInit", () => {
        const spy = spyOn(component, "agInit").and.callThrough();
        component.agInit(fixture.componentInstance.params);
        expect(spy).toHaveBeenCalled();
    });

    it("should call refresh", () => {
        const spy = spyOn(component, "refresh").and.callThrough();
        component.refresh();
        expect(spy).toBeTruthy();
    });

    it("should call findTextFromViewAccessList", () => {
        component.termToHighlighted = "Name";
        const spy = spyOn(component, "findTextFromViewAccessList").and.callThrough();
        component.findTextFromViewAccessList();
        expect(spy).toHaveBeenCalled();
    });
});
