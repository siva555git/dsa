import { ICellRendererAngularComp } from "@ag-grid-community/angular";
import { ICellRendererParams } from "@ag-grid-community/core";
import { Component } from "@angular/core";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { APPEND_EMPTY_VALUE, RESTRICTED_USE_FLAG_CODES } from "@te-shared/constants/common.constant";

@Component({
    selector: "app-view-accesslist-icon-renderer",
    templateUrl: "./view-accesslist-icon-renderer.component.html",
})
export class ViewAccesslistIconRendererComponent implements ICellRendererAngularComp {
    public params: ICellRendererParams;

    public termToHighlighted = APPEND_EMPTY_VALUE;

    public restrictedUseFlags = RESTRICTED_USE_FLAG_CODES;

    constructor(private readonly appBroadCastService: AppBroadCastService) {}

    agInit(parameters: ICellRendererParams): void {
        this.params = parameters;
        this.findTextFromViewAccessList();
    }

    /**
     * Method to subscribe find text from view access list component
     * @returns { void }
     * @memberof ViewAccesslistIconRendererComponent
     */
    public findTextFromViewAccessList(): void {
        this.termToHighlighted = this.params?.context?.componentParent?.ValueToBeHighlighted?.value;
        this.appBroadCastService.onPublishFindTextFromRestrictedViewList.subscribe((findTerm: string) => {
            this.termToHighlighted = findTerm;
        });
    }

    // eslint-disable-next-line class-methods-use-this
    public refresh(): boolean {
        return true;
    }
}
