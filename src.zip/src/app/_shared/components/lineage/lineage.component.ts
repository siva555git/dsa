/* eslint-disable max-lines-per-function */
import { ENTER } from "@angular/cdk/keycodes";
import { Component, ElementRef, Inject, OnInit, ViewChild } from "@angular/core";
import { ColDef } from "@ag-grid-community/core";
import { UntypedFormControl } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { NGXLogger } from "ngx-logger";
import { debounceTime } from "rxjs/operators";
import { delay, forEach } from "lodash";
import { LineageIconRendererComponent } from "../../../experiment/framework-components/lineage-icon/lineage-icon-renderer.component";
import { CreativeReviewHelper } from "../../../creative-review/helpers/creative-review-helper";
import { EXPERIMENTS_SEARCH, IPC_EXPCODE_LENGTH, KEYBOARD_KEYS, LINEAGE_CLASS_NAME, LINEAGE_ERROR_MSGS } from "../../constants";
import { GridParameters } from "../../models/experiment-list.model";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { EMPTY, LOADING } from "../../../app.constant";
import { ExperimentApiService } from "../../helpers/experiment-api.service";
import { AgGridConfigHelper } from "../../helpers/ag-grid-config";
import { LineageHelper } from "../../../experiment-editor/helpers/lineage.helper";
import { LineagePayload, LineageResponseModel } from "../../models/lineage.model";
import { SearchCriteria } from "../../models/search-criteria.model";
import { AgGridUtil } from "../../helpers/ag-grid-util";

@Component({
    selector: "app-lineage",
    templateUrl: "./lineage.component.html",
})
export class LineageComponent implements OnInit {
    visible = true;

    selectable = true;

    removable = true;

    addOnBlur = false;

    separatorKeysCodes = [ENTER];

    public selectedIpcOrExpCode = [];

    public searchValue: UntypedFormControl = new UntypedFormControl();

    public errorMsgInvalidIpcOrExpCode = "";

    @ViewChild("inputControl") inputControl: ElementRef<HTMLInputElement>;

    public autoGroupColumnDef: ColDef;

    public groupDefaultExpanded;

    public getDataPath;

    public rowData = [];

    public gridApi;

    public gridColumnApi;

    public rowHeight = 28;

    public icons;

    public ValueToBeHighlighted: UntypedFormControl = new UntypedFormControl("");

    public totalNoOfFindValue = 0;

    public matchedIndexOfFindValue = 0;

    public directionToNavigate = KEYBOARD_KEYS;

    public context;

    public searchIcon = "searchIcon";

    public showNoDataMsg = false;

    public showRelative = false;

    constructor(
        public dialogReference: MatDialogRef<LineageComponent>,
        @Inject(MAT_DIALOG_DATA) public data: { selectedExperimentCode: string },
        private readonly creativeReviewHelper: CreativeReviewHelper,
        private readonly logger: NGXLogger,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly experimentApiService: ExperimentApiService,
        public readonly lineageHelper: LineageHelper,
        public myElement: ElementRef,
    ) {}

    ngOnInit(): void {
        this.dialogReference.keydownEvents().subscribe((event) => {
            if (event.key === "Escape") {
                this.dialogReference.close();
            }
        });
        this.ValidateIpcOrExpCode(this.data.selectedExperimentCode);
        this.configAgGrid();
        this.broadCastFindFieldTextValue();
    }

    /**
     * Configure the ag grid properties to load the grid
     * @param {parameters} GridParameters
     *  @returns {void}
     * @memberof LineageComponent
     */
    onGridReady(parameters: GridParameters): void {
        this.gridApi = parameters.api;
        this.gridColumnApi = parameters.columnApi;
    }

    /**
     * Configure the ag grid properties to load the grid, set the default values
     *  @returns {void}
     * @memberof LineageComponent
     */
    public configAgGrid(): void {
        this.icons = {
            groupExpanded: '<i class="ag-icon ag-icon-small-down"/>',
            groupContracted: '<i class="ag-icon ag-icon-small-right"/>',
        };
        this.autoGroupColumnDef = AgGridConfigHelper.getAutoGroupColumnDefinition(LineageIconRendererComponent);
        this.autoGroupColumnDef.cellRendererParams.suppressDoubleClickExpand = true;
        this.groupDefaultExpanded = -1;
        this.getDataPath = (data: LineageResponseModel) => data.lineageHierarchyPath;
        this.context = {
            componentParent: this,
        };
    }

    /**
     * Method to expand/collapse on row click
     * @param {event}
     * @returns { void }
     * @memberof LineageComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public expandCollapseOnRowSelect = (event) => {
        this.lineageHelper.keyboardNavigationHandler(event);
    };

    /**
     * Method to close the drawer and reset the data
     * @returns { void }
     * @memberof LineageComponent
     */
    public onCloseDrawer(): void {
        this.dialogReference.close();
    }

    /**
     * Method to validate entered value is valid ipc or exp code
     * @param {string} searchValue
     * @returns { void }
     * @memberof LineageComponent
     */
    public ValidateIpcOrExpCode(searchValue: string): void {
        this.showNoDataMsg = false;
        if ((this.selectedIpcOrExpCode && this.selectedIpcOrExpCode.length === 1) || searchValue === "" || searchValue === null) {
            return;
        }
        this.selectedIpcOrExpCode.push(searchValue.toUpperCase());
        if (
            searchValue &&
            (searchValue.length === IPC_EXPCODE_LENGTH.INVALID_EXPCODE_OR_IPC || searchValue.length < IPC_EXPCODE_LENGTH.IPC_LENGTH)
        ) {
            this.errorMsgInvalidIpcOrExpCode = LINEAGE_ERROR_MSGS.INVALID_INGREDIENT;
            this.searchValue.setValue("");
            return;
        }
        if (searchValue && searchValue.length === IPC_EXPCODE_LENGTH.EXP_CODE_LENGTH) {
            this.onExpCodeValidation(searchValue);
        }
        if (searchValue && searchValue.length === IPC_EXPCODE_LENGTH.IPC_LENGTH) {
            this.onIpcValidation(searchValue);
        }
        this.searchValue.setValue("");
    }

    /**
     * Method to remove chip from text field when click on remove icon
     * @param {string} experiment
     * @returns { void }
     * @memberof LineageComponent
     */
    public removeIpcOrExpCodeFromChip(experiment: string): void {
        const index = this.selectedIpcOrExpCode.indexOf(experiment);
        if (index >= 0) {
            this.selectedIpcOrExpCode.splice(index, 1);
            this.errorMsgInvalidIpcOrExpCode = "";
            this.rowData = [];
            this.showNoDataMsg = true;
        }
        this.matchedIndexOfFindValue = 0;
        this.totalNoOfFindValue = 0;
    }

    /**
     * Method to navigate to next/previous/expand/collapse row on down/up/left/right key pressed
     *  @param argument
     * @memberof LineageComponent
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public keyboardNavigation = (argument) => {
        this.lineageHelper.keyboardNavigationHandler(argument);
    };

    /**
     * Method to validate experiment code
     *  @param {boolean} expCode
     *  @returns {void}
     * @memberof LineageComponent
     */
    public onExpCodeValidation(expCode: string): void {
        const expCodeValidationPayload: SearchCriteria = {
            limit: EXPERIMENTS_SEARCH.LIMIT,
            offset: EXPERIMENTS_SEARCH.START_FROM,
            searchBy: ["code"],
            searchText: expCode,
            searchType: "equalsto",
        };
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.experimentApiService.searchExperiment(expCodeValidationPayload).subscribe({
            next: (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                if (result && result.count === 0 && result.rows.length === 0) {
                    this.errorMsgInvalidIpcOrExpCode = LINEAGE_ERROR_MSGS.INVALID_EXP_CODE;
                    return;
                }
                this.errorMsgInvalidIpcOrExpCode = "";
                this.getViewLineageData();
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to validate IPC
     * @param {string} ipcValue
     * @returns { void }
     * @memberof LineageComponent
     */
    public onIpcValidation(ipcValue: string): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.creativeReviewHelper.validateIpc([ipcValue]).subscribe(
            (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                if (result?.length > 0) {
                    this.errorMsgInvalidIpcOrExpCode = result[0].isValid ? "" : LINEAGE_ERROR_MSGS.INVALID_IPC;
                    if (result[0].isValid) {
                        this.getViewLineageData();
                    }
                }
            },
            (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        );
    }

    /**
     * Method to call api to get lineage data for the given ipc/exp code
     *  @returns {void}
     * @memberof LineageComponent
     */
    public getViewLineageData(): void {
        const payload: LineagePayload = {
            formulaIds: this.selectedIpcOrExpCode,
            showRelative: this.showRelative,
        };
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.lineageHelper.getLienageForIpcOrExpCode(payload).subscribe({
            next: (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                if (result) {
                    forEach(result, (data, index) => {
                        // eslint-disable-next-line no-param-reassign, dot-notation
                        data["id"] = index + 1;
                        return data;
                    });
                    this.rowData = this.lineageHelper.formLineageTreeViewStructure(result);
                    this.showNoDataMsg = true;
                    this.getTotalCountOfFindText();
                }
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to broadcast find field value to lineageicon component
     *  @returns {void}
     * @memberof LineageComponent
     */
    public broadCastFindFieldTextValue(): void {
        this.ValueToBeHighlighted.valueChanges.pipe(debounceTime(1)).subscribe((value) => {
            this.matchedIndexOfFindValue = 0;
            if (value && value.length > 2) {
                AgGridUtil.expandAllCollapsedRowData(this.gridApi);
                this.appBroadCastService.onPublishFindTextFromLineage(value);
                delay(() => {
                    this.totalNoOfFindValue = this.lineageHelper.getTotalCountOfFindTextValue(
                        this.gridApi,
                        this.ValueToBeHighlighted.value,
                        "LINEAGE",
                    );
                }, 100);
            }
        });
    }

    /**
     * Method to broadcast find field value to lineageicon component
     *  @returns {void}
     * @memberof LineageComponent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public onEnterToGetFindValue(event?: any): void {
        if (event !== null) {
            AgGridUtil.expandAllCollapsedRowData(this.gridApi);
            if (this.totalNoOfFindValue > 0 && event.key === KEYBOARD_KEYS.ENTER) {
                this.navigateToPreviousNext(KEYBOARD_KEYS.RIGHT_ARROW);
            } else if (
                this.ValueToBeHighlighted.value === "" ||
                this.ValueToBeHighlighted.value === null ||
                event.key === KEYBOARD_KEYS.BACK_SPACE ||
                event === this.searchIcon ||
                event.key === KEYBOARD_KEYS.ENTER
            ) {
                this.getTotalCountOfFindText();
                // eslint-disable-next-line no-useless-return
                return;
            }
        }
    }

    /**
     * Method to get total count of find text and broadcast to pipe to apply class
     *  @returns {void}
     * @memberof LineageComponent
     */
    public getTotalCountOfFindText(): void {
        this.appBroadCastService.onPublishFindTextFromLineage(this.ValueToBeHighlighted.value);
        delay(() => {
            this.totalNoOfFindValue = this.lineageHelper.getTotalCountOfFindTextValue(
                this.gridApi,
                this.ValueToBeHighlighted.value,
                "LINEAGE",
            );
        }, 100);
    }

    /**
     * Method to increase/decrease index of find text
     * @param {string} position
     *  @returns {void}
     * @memberof LineageComponent
     */
    public navigateToPreviousNext(position: string): void {
        AgGridUtil.expandAllCollapsedRowData(this.gridApi);
        if (this.ValueToBeHighlighted.value === "" || this.ValueToBeHighlighted.value === null || this.totalNoOfFindValue === 0) {
            return;
        }
        if (position === KEYBOARD_KEYS.LEFT_ARROW) {
            if (this.matchedIndexOfFindValue === 1) {
                this.matchedIndexOfFindValue = this.totalNoOfFindValue;
            } else {
                this.matchedIndexOfFindValue -= 1;
            }
        } else {
            if (this.matchedIndexOfFindValue === this.totalNoOfFindValue) {
                this.matchedIndexOfFindValue = 0;
            }
            this.matchedIndexOfFindValue += 1;
        }
        this.changeClassNameForFindText();
    }

    /**
     * Method to change class name for the find text
     *  @returns {void}
     * @memberof LineageComponent
     */
    public changeClassNameForFindText(): void {
        const hasRowHightlightClass = false;
        delay(() => {
            const highlightTextClassArray = this.myElement.nativeElement.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT);
            highlightTextClassArray.forEach((value, index) => {
                if (index === this.matchedIndexOfFindValue - 1) {
                    highlightTextClassArray[
                        index
                    ].outerHTML = `<span class="highlight-text yellow">${this.ValueToBeHighlighted.value}</span>`;
                    this.hightlightFindValueBasedOnIndex(hasRowHightlightClass);
                } else {
                    highlightTextClassArray[index].outerHTML = `<span class="highlight-text">${this.ValueToBeHighlighted.value}</span>`;
                }
            });
        }, 100);
    }

    /**
     * Method to add highlight yellow color and scroll to current index of the find text value
     * @param {boolean}hasRowHightlightClass
     *  @returns {void}
     * @memberof LineageComponent
     */
    public hightlightFindValueBasedOnIndex(hasRowHightlightClass: boolean): void {
        const treeViewRowData = AgGridUtil.getGridRowData(this.gridApi);
        for (let rowIndex = 0; rowIndex < treeViewRowData.length; rowIndex += 1) {
            const currentIndexElement = this.myElement.nativeElement.querySelectorAll(`[row-index="${rowIndex}"]`);
            const currentIndexRow = currentIndexElement[1];
            if (currentIndexRow) {
                if (
                    currentIndexRow.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT) &&
                    currentIndexRow.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT_YELLOW).length > 0 &&
                    !hasRowHightlightClass
                ) {
                    // eslint-disable-next-line no-param-reassign
                    hasRowHightlightClass = true;
                }
                if (hasRowHightlightClass && currentIndexRow.querySelectorAll(LINEAGE_CLASS_NAME.HIGHTLIGHT_TEXT)) {
                    // eslint-disable-next-line unicorn/no-null
                    this.gridApi.ensureIndexVisible(rowIndex, null);
                    break;
                }
            }
        }
    }
}
