/* eslint-disable class-methods-use-this */
/* eslint-disable max-classes-per-file */
/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { NGXLogger } from "ngx-logger";
import { of, throwError } from "rxjs";
import { AppBroadCastService } from "../../../_services";
import { LineageHelper } from "../../../experiment-editor/helpers/lineage.helper";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { CreativeReviewHelper } from "../../../creative-review/helpers/creative-review-helper";
import { MockCreativereview } from "../../../testing/mock-creativereview-helper";

import { LineageComponent } from "./lineage.component";
import { ExperimentApiService } from "../../helpers/experiment-api.service";
import { AgGridUtil } from "../../helpers/ag-grid-util";
import { gridParameters, mockGridApiNew } from "../../../testing/mock-context-menu.helper";
import { mockLineageData } from "../../../testing/mock-lineage-helper";
import { CUSTOM_ELEMENTS_SCHEMA, EventEmitter } from "@angular/core";
import { GridParameters } from "@te-shared/models";
import { MatChipsModule } from "@angular/material/chips";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AgGridModule } from "@ag-grid-community/angular";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { MatInputModule } from "@angular/material/input";

describe("LineageComponent", () => {
    let component: LineageComponent;
    let fixture: ComponentFixture<LineageComponent>;  
    let dialogReferenceSpy: jasmine.SpyObj<MatDialogRef<LineageComponent>>;
    class MockDialogReference {
        public keydownEvents() {
            return of({key :'Escape'});
        }

        public close() {
            return of();
        }

        public getGridRowData() {
            return mockGridApiNew;
        }

        public expandAllCollapsedRowData() {
            return mockGridApiNew;
        }
    }

    class MockExperimentApiService {
        public searchExperiment() {
            return of({
                count: 0,
                rows: [],
            });
        }
    }
    class MockLineageHelper {
        public getLienageForIpcOrExpCode() {
            return of(mockLineageData);
        }

        public keyboardNavigationHandler() {
            return "";
        }

        public formLineageTreeViewStructure() {
            return [
                {
                    IPCDescription: "TEST",
                    ParentID: "N3C00016AA",
                    childExpCode: "N3C00016AA",
                    childExpID: "5004829",
                    childExpName: "Test Lineage",
                    childID: "N3C00016AA",
                    childTypeID: 2,
                    isOtherUserFormula: false,
                    isParent: false,
                    lineageHierarchyPath: ["Test Lineage"],
                    plant: "TEST",
                    region: "TEST",
                    topExp: "N3C00016AA",
                    trustee: "TEST",
                },
            ];
        }

        public getTotalCountOfFindTextValue() {
            return 0;
        }
    }
    beforeEach(waitForAsync(() => {  
        dialogReferenceSpy = jasmine.createSpyObj('MatDialogRef', ['keydownEvents', 'close']);
        TestBed.configureTestingModule({
            declarations: [LineageComponent],
            imports: [
                MatChipsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule,
                AgGridModule,
                MatFormFieldModule,
                MatIconModule,
                MatSlideToggleModule,
                MatInputModule
            ],
            providers: [
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: MAT_DIALOG_DATA, useValue: {} },
                {
                    provide: CreativeReviewHelper,
                    useClass: MockCreativereview,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                AppBroadCastService,
                { provide: AgGridUtil, useClass: MockDialogReference },
                { provide: LineageHelper, useClass: MockLineageHelper },
                { provide: ExperimentApiService, useClass: MockExperimentApiService },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LineageComponent);
        component = fixture.componentInstance;
        component.data.selectedExperimentCode = "nxc00004aa";
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
    
    it("should resolve for onGridReady() ", () => {
        spyOn(component, "onGridReady").and.callThrough();
        component.onGridReady(gridParameters as unknown as GridParameters);
        expect(component.dialogReference).toBeDefined();
    });

    it("should resolve for onCloseDrawer() ", () => {
        spyOn(component, "onCloseDrawer").and.callThrough();
        component.onCloseDrawer();
        expect(component.dialogReference).toBeDefined();
    });
    
    it("should resolve for ValidateIpcOrExpCode() when searchvalue is test ", () => {
        component.searchValue.setValue("Testingss");
        component.selectedIpcOrExpCode = ["Testingss"];
        spyOn(component, "ValidateIpcOrExpCode").and.callThrough();
        component.ValidateIpcOrExpCode("Testingss");
        expect(component.selectedIpcOrExpCode).toEqual(["Testingss"]);
    });

    it("should resolve for ValidateIpcOrExpCode()  when searchvalue is 1rr04333", () => {
        component.searchValue.setValue("1rr04333");
        component.selectedIpcOrExpCode = ["1rr04333"];
        spyOn(component, "ValidateIpcOrExpCode").and.callThrough();
        component.ValidateIpcOrExpCode("1rr04333");
        expect(component.selectedIpcOrExpCode).toEqual(["1rr04333"]);
    });

    it("should resolve for ValidateIpcOrExpCode()  when searchvalue is nxc00004aa", () => {
        component.searchValue.setValue("nxc00004aa");
        component.selectedIpcOrExpCode = ["nxc00004aa"];
        spyOn(component, "ValidateIpcOrExpCode").and.callThrough();
        component.ValidateIpcOrExpCode("nxc00004aa");
        expect(component.selectedIpcOrExpCode).toEqual(["nxc00004aa"]);
    });

    it("should resolve for removeIpcOrExpCodeFromChip()  ", () => {
        component.selectedIpcOrExpCode = ["nxc00014aa"];
        spyOn(component, "removeIpcOrExpCodeFromChip").and.callThrough();
        component.removeIpcOrExpCodeFromChip("nxc00014aa");
        expect(component.errorMsgInvalidIpcOrExpCode).toEqual("");
    });

    it("should resolve for keyboardNavigation()  ", () => {
        const eventValue = {
            event: {
                key: "Enter",
            },
        };
        const spy = spyOn(component, "keyboardNavigation").and.callThrough();
        component.keyboardNavigation(eventValue);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for removeIpcOrExpCodeFromChip()  is index is -1", () => {
        component.selectedIpcOrExpCode = ["nxc00014ab"];
        spyOn(component, "removeIpcOrExpCodeFromChip").and.callThrough();
        component.removeIpcOrExpCodeFromChip("nxc00014aa");
        expect(component.matchedIndexOfFindValue).toEqual(0);
    });

    it("should resolve for getViewLineageData()  ", () => {
        const spy = spyOn(component, "getViewLineageData").and.callThrough();
        component.getViewLineageData();
        expect(spy).toHaveBeenCalled();
    });
    
    it("should resolve for getViewLineageData() when getLienageForIpcOrExpCode throws error ", () => {
        const lineageHelper = TestBed.inject(LineageHelper);
        spyOn(lineageHelper, "getLienageForIpcOrExpCode").and.returnValue(throwError(() => "Test error"));
        const spy = spyOn(component, "getViewLineageData").and.callThrough();
        component.getViewLineageData();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onEnterToGetFindValue() when value is null ", () => {
        component.gridApi = mockGridApiNew;
        const spy = spyOn(component, "onEnterToGetFindValue").and.callThrough();
        // eslint-disable-next-line unicorn/no-null
        component.onEnterToGetFindValue(null);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for navigateToPreviousNext() when matchedIndexOfFindValue is 1 ", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("Test");
        component.totalNoOfFindValue = 1;
        component.matchedIndexOfFindValue = 1;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowLeft");
        expect(component.matchedIndexOfFindValue).toEqual(1);
    });

    it("should resolve for navigateToPreviousNext() when matchedIndexOfFindValue is 0 ", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("Test");
        component.totalNoOfFindValue = 1;
        component.matchedIndexOfFindValue = 0;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowLeft");
        expect(component.matchedIndexOfFindValue).toEqual(-1);
    });

    it("should resolve for changeClassNameForFindText()  ", () => {
        const spy = spyOn(component, "changeClassNameForFindText").and.callThrough();
        component.changeClassNameForFindText();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onIpcValidation()  ", () => {
        const spy = spyOn(component, "onIpcValidation").and.callThrough();
        component.onIpcValidation("1rr04333");
        expect(spy).toHaveBeenCalled();
    });
    
    it("should resolve for onIpcValidation() when validateIpc throws error ", () => {
        const creativeReviewHelper = TestBed.inject(CreativeReviewHelper);
        spyOn(creativeReviewHelper,'validateIpc').and.returnValue(throwError(() => "Test error"))
        const spy = spyOn(component, "onIpcValidation").and.callThrough();
        component.onIpcValidation("1rr04333");
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for hightlightFindValueBasedOnIndex()  ", () => {
        component.gridApi = mockGridApiNew;
        const spy = spyOn(component, "hightlightFindValueBasedOnIndex").and.callThrough();
        component.hightlightFindValueBasedOnIndex(false);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for expandCollapseOnRowSelect()  ", () => {
        const spy = spyOn(component, "expandCollapseOnRowSelect").and.callThrough();
        component.expandCollapseOnRowSelect(mockGridApiNew);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for navigateToPreviousNext() when matchedIndexOfFindValue is 1", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("Test");
        component.totalNoOfFindValue = 1;
        component.matchedIndexOfFindValue = 1;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowRight");
        expect(component.matchedIndexOfFindValue).toEqual(1);
    });

    it("should resolve for navigateToPreviousNext()  when matchedIndexOfFindValue is 2  ", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("Test");
        component.totalNoOfFindValue = 1;
        component.matchedIndexOfFindValue = 2;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowRight");
        expect(component.matchedIndexOfFindValue).toEqual(3);
    });

    it("should resolve for navigateToPreviousNext()  when totalNoOfFindValue is 0 ", () => {
        component.gridApi = mockGridApiNew;
        component.ValueToBeHighlighted.setValue("");
        component.totalNoOfFindValue = 0;
        spyOn(component, "navigateToPreviousNext").and.callThrough();
        component.navigateToPreviousNext("ArrowRight");
        expect(component.matchedIndexOfFindValue).toEqual(0);
    });

    it("should resolve for onEnterToGetFindValue()  ", () => {
        const event = { key: "Enter" };
        component.gridApi = mockGridApiNew;
        component.totalNoOfFindValue = 1;
        spyOn(component, "onEnterToGetFindValue").and.callThrough();
        component.onEnterToGetFindValue(event);
        expect(component.matchedIndexOfFindValue).toEqual(0);
    });

    it("should resolve for onEnterToGetFindValue()  ", () => {
        const event = { key: "ArrowLeft" };
        component.gridApi = mockGridApiNew;
        component.totalNoOfFindValue = 1;
        spyOn(component, "onEnterToGetFindValue").and.callThrough();
        component.onEnterToGetFindValue(event);
        expect(component.matchedIndexOfFindValue).toEqual(0);
    });

    it("should call on onExpCodeValidation error", () => {
        const service = TestBed.inject(ExperimentApiService);
        spyOn(service, "searchExperiment").and.returnValue(throwError(() => "Test error"));
        spyOn(component, "onExpCodeValidation").and.callThrough();
        component.onExpCodeValidation("NXC00200AA");
        expect(component.onExpCodeValidation).toHaveBeenCalled();
    });
});
