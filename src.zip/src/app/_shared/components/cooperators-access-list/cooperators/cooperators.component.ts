/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from "@angular/core";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { forEach } from "lodash";
import { REFRESH_EXPERIMENT_HEADER } from "@te-experiment-editor/constants/experiment-editor.constant";
import { SharedExperimentUtil } from "@te-shared/helpers/shared-experiment.util";
import { ExperimentColumnHelper } from "@te-experiment-editor/helpers/experiment-column-helper";
import { EMPTY, LOADING } from "../../../../app.constant";
import {
    CooperatorsAccessPayload,
    CooperatorUserModel,
    CreateNotesPayload,
    MultipleNotificationExpDetail,
} from "../../../models/cooperator-access.model";
import { AppBroadCastService, AppDataService, AppStateService } from "../../../../_services";
import { NotificationHelper } from "../../notification-drawer/helper/notification-helper";
import { NotesHelper } from "../../../helpers/notes.helper";

import {
    COOPERATOR_ACCESS,
    IS_PUSH_NOTIFICATION,
    NOTIFICATION_EVENTS_TYPE,
    NOTIFICATION_EVENT_ID,
    NOTIFICATION_TYPE_ID,
} from "../../../constants/common.constant";
import { NOTIFICATION_SETTING_CODE } from "../../../constants/notification.constant";
import { ES_RESPONSE } from "../../../constants";

@Component({
    selector: "app-cooperators",
    templateUrl: "./cooperators.component.html",
})
export class CooperatorsComponent implements OnChanges {
    @Input() public cooperatorAccessData;

    @Input() public activeExp;

    public staffList: [];

    @Output()
    public accessListToggle = new EventEmitter();

    @Output()
    public expPrivacyUpdate = new EventEmitter();

    constructor(
        private readonly appDataService: AppDataService,
        private readonly logger: NGXLogger,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly notificationHelper: NotificationHelper,
        private readonly experimentColumnHelper: ExperimentColumnHelper,
        private readonly notesHelper: NotesHelper,
        private readonly appStateService: AppStateService,
        private readonly toasterService: ToastrService,
    ) {}

    public ngOnChanges(changes: SimpleChanges): void {
        this.staffList = [];
        if (changes.cooperatorAccessData && changes.cooperatorAccessData.currentValue) {
            this.getUsersListByExpId(changes.cooperatorAccessData.currentValue);
        }
    }

    /**
     * Method to get saved users list from api
     *
     * @memberof CooperatorsComponent
     */
    public getUsersListByExpId(data: any): void {
        this.appDataService.get(`${this.appDataService.url.staffLists}/${data.expId}/${data.currentPage}`, []).subscribe({
            next: (result) => {
                if (result) {
                    this.staffList = result;
                }
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to send selected user list to api
     *
     * @memberof CooperatorsComponent
     */
    // eslint-disable-next-line max-lines-per-function
    public addStaffToList(staffDetails: CooperatorUserModel[]): void {
        const currentUser = this.appStateService.getCurrentUser();
        const staffId = staffDetails.map((list) => list.userId);
        this.cooperatorAccessData.action = COOPERATOR_ACCESS.ADD_ACTION;
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        const createNotesPayload: CreateNotesPayload = {
            staffs: {
                expId: this.cooperatorAccessData.expId,
                userId: staffId,
                staffType: this.cooperatorAccessData.currentPage,
            },
            notes:
                this.cooperatorAccessData.currentPage === COOPERATOR_ACCESS.ACCESSLIST
                    ? this.prepareNotesForShareExperiment(staffDetails) || []
                    : [],
            notifications: this.notificationHelper.notificationPayload(staffId, {
                Subject:
                    this.cooperatorAccessData.currentPage === COOPERATOR_ACCESS.ACCESSLIST
                        ? NOTIFICATION_EVENTS_TYPE.SHARE_EXPERIMENT
                        : NOTIFICATION_EVENTS_TYPE.SHARE_CO_OP,
                Body:
                    this.cooperatorAccessData.currentPage === COOPERATOR_ACCESS.ACCESSLIST
                        ? `<b>${currentUser.fullname}</b> has shared <a><b>${this.cooperatorAccessData.expCode}</b></a> experiment`
                        : `<b>${currentUser.fullname}</b> has added as a <b>Cooperator</b> to <b>${this.cooperatorAccessData.expCode}</b> Experiment.`,
                ExpCode: this.cooperatorAccessData.expCode,
                UserName: currentUser.fullname,
                TypeID: NOTIFICATION_TYPE_ID.INFORMATION,
                EventID:
                    this.cooperatorAccessData.currentPage === COOPERATOR_ACCESS.ACCESSLIST
                        ? NOTIFICATION_EVENT_ID.SHARE_EXPERIMENT
                        : NOTIFICATION_EVENT_ID.SHARE_CO_OP,
                IsPush: IS_PUSH_NOTIFICATION.false,
                UserSettingCode: NOTIFICATION_SETTING_CODE.SHARED_ME_EXP,
            }),
        };
        this.appDataService.post(this.appDataService.url.staffLists, [], createNotesPayload).subscribe({
            next: (result) => {
                if (result) {
                    this.getUsersListByExpId(this.cooperatorAccessData);
                }
                this.experimentColumnHelper.handleToasterForExperimentResend(
                    result?.iffManResponse,
                    undefined,
                    result?.isESResponseFlag ? undefined : ES_RESPONSE.ADD_STAFF_LIST,
                );
                this.refreshActiveExperiment(createNotesPayload.staffs);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to call api to remove user from list
     *
     * @memberof CooperatorsComponent
     */
    public removeStaffFromList(data: any): void {
        const currentUser = this.appStateService.getCurrentUser();
        const createNotesPayload: CreateNotesPayload = {
            staffs: {
                expId: data.expID,
                userId: data.userID,
                staffType: this.cooperatorAccessData.currentPage,
            },
            notes: [],
            notifications: this.notificationHelper.notificationPayload([data.userID], {
                Subject:
                    this.cooperatorAccessData.currentPage === COOPERATOR_ACCESS.ACCESSLIST
                        ? NOTIFICATION_EVENTS_TYPE.UN_SHARE_EXPERIMENT
                        : NOTIFICATION_EVENTS_TYPE.UN_SHARE_CO_OP,
                Body:
                    this.cooperatorAccessData.currentPage === COOPERATOR_ACCESS.ACCESSLIST
                        ? `<b>${currentUser.fullname}</b> has un shared <b>${this.cooperatorAccessData.expCode}</b> experiment`
                        : `<b>${currentUser.fullname}</b> has removed as cooperator from <b>${this.cooperatorAccessData.expCode}</b> experiment`,
                ExpCode: this.cooperatorAccessData.expCode,
                UserName: currentUser.fullname,
                TypeID: NOTIFICATION_TYPE_ID.INFORMATION,
                EventID:
                    this.cooperatorAccessData.currentPage === COOPERATOR_ACCESS.ACCESSLIST
                        ? NOTIFICATION_EVENT_ID.UN_SHARE_EXPERIMENT
                        : NOTIFICATION_EVENT_ID.UN_SHARE_CO_OP,
                IsPush: IS_PUSH_NOTIFICATION.false,
                UserSettingCode: NOTIFICATION_SETTING_CODE.SHARED_ME_EXP,
            }),
        };
        this.cooperatorAccessData.action = COOPERATOR_ACCESS.REMOVE_ACTION;
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.appDataService.post(this.appDataService.url.removeStaffList, [], createNotesPayload).subscribe({
            next: (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.getUsersListByExpId(this.cooperatorAccessData);
                this.refreshActiveExperiment(createNotesPayload.staffs);
                this.experimentColumnHelper.handleToasterForExperimentResend(result?.iffManResponse);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to refresh the active experiment staff details
     *
     * @param {CooperatorsAccessPayload} staffDetails
     */
    public refreshActiveExperiment(staffDetails: CooperatorsAccessPayload): void {
        this.cooperatorAccessData.selectedExpRows.ExperimentStaffDetails =
            this.cooperatorAccessData.selectedExpRows.ExperimentStaffDetails ?? [];
        if (this.cooperatorAccessData.action === COOPERATOR_ACCESS.ADD_ACTION) {
            forEach(staffDetails.userId, (userID) => {
                this.cooperatorAccessData.selectedExpRows.ExperimentStaffDetails.push({
                    UserID: userID,
                    StaffType: staffDetails.staffType,
                });
            });
        } else {
            this.cooperatorAccessData.selectedExpRows.ExperimentStaffDetails.splice(
                this.cooperatorAccessData?.selectedExpRows?.ExperimentStaffDetails?.findIndex(
                    (expStaff) => expStaff.UserID === staffDetails.userId && expStaff.StaffType === staffDetails.staffType,
                ),
                1,
            );
        }
        const refreshExperimentHeader = SharedExperimentUtil.createRefreshExperimentHeader(
            REFRESH_EXPERIMENT_HEADER.EXPERIMENT_DATA_UPDATE,
            [this.cooperatorAccessData.selectedExpRows],
        );
        this.appBroadCastService.onRefreshExperimentHeader(refreshExperimentHeader);
    }

    /**
     * Method to close cooperator-access drawer
     *
     * @memberof CooperatorsComponent
     */
    public closeDrawer(): void {
        this.accessListToggle.emit();
    }

    /**
     * Method to send notes to payload
     *
     * @private
     * @memberof CooperatorsComponent
     */
    private prepareNotesForShareExperiment(userDetails: CooperatorUserModel[]) {
        const expDetails: MultipleNotificationExpDetail = {
            expCode: this.cooperatorAccessData.expCode,
            expId: this.cooperatorAccessData.expId,
        };
        return this.notesHelper.createMultiplePayloadNotification(expDetails, "", userDetails);
    }

    /**
     * Method to add privacy updation
     *
     * @private
     * @memberof CooperatorsComponent
     */
    public expPrivacyUpdation(): void {
        this.expPrivacyUpdate.emit();
    }
}
