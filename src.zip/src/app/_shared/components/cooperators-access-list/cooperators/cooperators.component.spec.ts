/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { of, throwError } from "rxjs";
import { COOPERATOR_ACCESS } from "@te-shared/constants";
import { ExperimentApiService } from "@te-shared/helpers/experiment-api.service";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { MockExperimentApiService } from "@te-testing/mock-experiment-api.service";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { MatDialog } from "@angular/material/dialog";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from "@angular/core";
import { ExperimentColumnHelper } from "@te-experiment-editor/helpers/experiment-column-helper";
import { MockNotificationHelper } from "../../../../testing/mock-notification.helper";
import { MockAppDataService } from "../../../../testing/mock-app.data.service";
import { MockLoggerService } from "../../../../testing/mock-logger.service";
import { AppBroadCastService, AppDataService, AppStateService } from "../../../../_services";
import { NotificationHelper } from "../../notification-drawer/helper/notification-helper";
import { CooperatorsComponent } from "./cooperators.component";
import { NotesHelper } from "../../../helpers/notes.helper";
import { MockAppStateService } from "../../../../testing/mock-app.state.service";
import { MockToastrService } from "../../../../testing/mock-toastr.service";

describe("CooperatorsComponent", () => {
    let component: CooperatorsComponent;
    let fixture: ComponentFixture<CooperatorsComponent>;
    const dialogReferenceStub = {
        afterClosed() {
            return of(); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    const cooperatorData = {
        countryCode: "IN",
        department: "department",
        email: "ranjithkumar.p@iff.com",
        firstName: "Ranjith",
        globalUserID: "RXP1926",
        initials: "RXP",
        isActive: "1",
        isLocked: "1",
        profilePicURL: "",
        regionName: "",
        surName: "kumar",
        userId: 30_979,
    };
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CooperatorsComponent],
            providers: [
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                ExperimentAccessHelper,
                SecurityHelper,
                {
                    provide: ExperimentHelper,
                    useClass: MockExperimentHelper,
                },
                { provide: ExperimentApiService, useClass: MockExperimentApiService },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                AppBroadCastService,
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: ToastrService, useClass: MockToastrService },
                { provide: NotificationHelper, useClass: MockNotificationHelper },
                NotesHelper,
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CooperatorsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for closeDrawer()", () => {
        const spy = spyOn(component, "closeDrawer").and.callThrough();
        component.closeDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for addStaffToList()", () => {
        component.cooperatorAccessData = { currentPage: "CO", expId: 123_487 };
        spyOn(component, "refreshActiveExperiment");
        spyOn(component, "getUsersListByExpId");
        const helper: ExperimentColumnHelper = TestBed.inject(ExperimentColumnHelper);
        spyOn(helper, "handleToasterForExperimentResend");
        const spy = spyOn(component, "addStaffToList").and.callThrough();
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", globaluserid: "axb1234" });
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of([]));
        component.addStaffToList([cooperatorData]);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getUsersListByExpId()", () => {
        const spy = spyOn(component, "getUsersListByExpId").and.callThrough();
        component.getUsersListByExpId({ currentPage: "CO", expId: 123_487 });
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for ngOnChanges ", () => {
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        const changes = {
            cooperatorAccessData: {
                currentValue: true,
            },
        } as unknown as SimpleChanges;
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve prepareNotesForShareExperiment()", () => {
        const expDetails = {
            expCode: "RXP00033AA",
            expId: 123_456,
        };
        const cooperatorUserData = {
            countryCode: "IN",
            department: "department",
            email: "ranjithkumar.p@iff.com",
            firstName: "Ranjith",
            globalUserID: "RXP1926",
            initials: "RXP",
            isActive: "1",
            isLocked: "1",
            profilePicURL: "",
            regionName: "",
            surName: "kumar",
            userId: 30_979,
        };

        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", globaluserid: "axb1234" });

        const service: NotesHelper = TestBed.inject(NotesHelper);
        spyOn(service, "createMultiplePayloadNotification").and.callThrough();
        service.createMultiplePayloadNotification(expDetails, "", [cooperatorUserData]);
        expect(service.createMultiplePayloadNotification).toHaveBeenCalled();
    });

    it("should resolve refreshActiveExperiment", () => {
        const spy = spyOn(component, "refreshActiveExperiment").and.callThrough();
        component.cooperatorAccessData = { action: COOPERATOR_ACCESS.ADD_ACTION, selectedExpRows: { ExperimentStaffDetails: [] } };
        component.refreshActiveExperiment({ expId: 34_222, userId: [70_823], staffType: "CO" });
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve refreshActiveExperiment", () => {
        const spy = spyOn(component, "refreshActiveExperiment").and.callThrough();
        component.cooperatorAccessData = {
            action: COOPERATOR_ACCESS.REMOVE_ACTION,
            selectedExpRows: { ExperimentStaffDetails: [{ UserID: 70_823, StaffType: "CO" }] },
        };
        component.refreshActiveExperiment({ expId: 34_222, userId: [70_823], staffType: "CO" });
        expect(spy).toHaveBeenCalled();
    });

    it("should call on expPrivacyUpdation", () => {
        const spy = spyOn(component, "expPrivacyUpdation").and.callThrough();
        component.expPrivacyUpdation();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on removeStaffFromList", () => {
        spyOn(component, "refreshActiveExperiment");
        spyOn(component, "getUsersListByExpId");
        const helper = TestBed.inject(ExperimentColumnHelper);
        spyOn(helper, "handleToasterForExperimentResend");
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of([]));
        component.cooperatorAccessData = { currentPage: "Un Share Experiment" };
        const spy = spyOn(component, "removeStaffFromList").and.callThrough();
        component.removeStaffFromList(1234);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on removeStaffFromList if returns error", () => {
        const service = TestBed.inject(AppDataService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(service, "post").and.returnValue(throwError(() => {}));
        component.cooperatorAccessData = { currentPage: "Un Share Experiment" };
        const spy = spyOn(component, "removeStaffFromList").and.callThrough();
        component.removeStaffFromList(1234);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getUsersListByExpId() if return error", () => {
        const service = TestBed.inject(AppDataService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(service, "get").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "getUsersListByExpId").and.callThrough();
        component.getUsersListByExpId({ currentPage: "CO", expId: 123_487 });
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for addStaffToList if returns error", () => {
        component.cooperatorAccessData = { currentPage: "CO", expId: 123_487 };
        spyOn(component, "refreshActiveExperiment");
        const spy = spyOn(component, "addStaffToList").and.callThrough();
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", globaluserid: "axb1234" });
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(throwError([]));
        component.addStaffToList([cooperatorData]);
        expect(spy).toHaveBeenCalled();
    });
});
