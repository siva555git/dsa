/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, ElementRef, EventEmitter, HostListener, Input, Output, SimpleChanges, ViewChild } from "@angular/core";
import { UntypedFormControl } from "@angular/forms";
import { MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { NGXLogger } from "ngx-logger";
import { debounceTime } from "rxjs/operators";
import { ToastrService } from "ngx-toastr";
import { forEach } from "lodash";
import { AppDataService } from "../../../_services";
import { UsersListSearchPayload } from "../../models/cooperator-access.model";
import { CooperatorsComponent } from "./cooperators/cooperators.component";
import { FORM_VALIDATION } from "../../constants/notification.constant";
import { EVENT_KEYS, COOPERATOR_ACCESS, DEFAULT_EXPERIMENT_PRIVACY, PRIVATE_EXPERIMENT_PRIVACY, PRIVACY_LISTS } from "../../constants";

@Component({
    selector: "app-cooperators-access-list",
    templateUrl: "./cooperators-access-list.component.html",
})
export class CooperatorsAccessListComponent {
    @HostListener("document:keydown.escape", ["$event"]) onKeydownHandler(): void {
        this.onCancelDrawer();
    }

    @Input() public staffList: [];

    @Input() public cooperatorAccessData;

    @Input() public activeExp;

    visible = true;

    selectable = true;

    removable = true;

    addOnBlur = false;

    filteredStaffsList: [];

    users = [];

    allUsersList = [];

    public currentPageName: string;

    @ViewChild("searchUserInput") searchUserInput: ElementRef;

    public displayedColumns: string[] = ["Cooperators", "Remove"];

    public dataSource = [];

    @Output()
    public cooperatorAccessToggle = new EventEmitter();

    @Output()
    public expPrivacyUpdated = new EventEmitter();

    public columnHeader: string;

    public isCooperator = COOPERATOR_ACCESS.COOPERATOR;

    public searchValue: UntypedFormControl = new UntypedFormControl();

    public isViewMode: boolean;

    public privacyLists = PRIVACY_LISTS;

    public isPrivate: string;

    constructor(
        private readonly appDataService: AppDataService,
        private readonly logger: NGXLogger,
        private cooperatorsComponent: CooperatorsComponent,
        private readonly toastrService: ToastrService,
    ) {}

    public ngOnChanges(changes: SimpleChanges): void {
        this.filteredStaffsList = [];
        if (changes?.activeExp?.currentValue) {
            const activeExperiment = changes?.activeExp?.currentValue;
            forEach(this.privacyLists, (privacyList) => {
                privacyList.isChecked = activeExperiment.IsPublic
                    ? privacyList.name === DEFAULT_EXPERIMENT_PRIVACY
                    : privacyList.name === PRIVATE_EXPERIMENT_PRIVACY;
            });
        }
        if (changes?.cooperatorAccessData?.currentValue) {
            this.isViewMode = changes.cooperatorAccessData.currentValue.isViewMode;
        }
        this.currentPageName =
            this.cooperatorAccessData?.currentPage === COOPERATOR_ACCESS.COOPERATOR
                ? COOPERATOR_ACCESS.COOPERATOR_STAFF
                : COOPERATOR_ACCESS.EXPERIMENT_LIST;
        this.columnHeader =
            this.cooperatorAccessData?.currentPage === COOPERATOR_ACCESS.COOPERATOR
                ? COOPERATOR_ACCESS.COOPERATORS_HEADER
                : COOPERATOR_ACCESS.ACCESSLIST_HEADER;
        if (changes.staffList && changes.staffList.currentValue) {
            this.dataSource = changes.staffList.currentValue;
        }
        if (this.cooperatorAccessData?.action !== COOPERATOR_ACCESS.REMOVE_ACTION) {
            this.users = [];
        }
    }

    public ngOnInit() {
        this.searchValue.valueChanges.pipe(debounceTime(500)).subscribe((value) => {
            this.filteredStaffsList = [];
            if (value.length >= 3) {
                this.getUsersListBySearch();
            }
        });
    }

    /**
     * Method to remove user from mat chip
     *
     * @memberof CooperatorsAccessListComponent
     */
    public removeUserFromChip(user: any): void {
        this.filteredStaffsList = [];
        const index = this.users.indexOf(user);
        if (index >= 0) {
            this.users.splice(index, 1);
        }
    }

    /**
     * Method to add Private and Public
     *
     * @memberof CooperatorsAccessListComponent
     */
    public addPrivatePublic(): void {
        this.expPrivacyUpdated.emit();
    }

    /**
     * Method to select user from search drop down
     *
     * @memberof CooperatorsAccessListComponent
     */
    public selectedUser(event: MatAutocompleteSelectedEvent): void {
        this.filteredStaffsList = [];
        const userDetails = event.option.value;
        this.users.push(userDetails);
        this.searchUserInput.nativeElement.value = "";
    }

    /**
     * Method to get list of users from api when start typing in search field
     *
     * @memberof CooperatorsAccessListComponent
     */
    public getUsersListBySearch(event?: KeyboardEvent): void {
        if (event && event.key === EVENT_KEYS.ENTER && !this.onDisableAdd()) {
            this.onAddStaffs();
        }
        const payload: UsersListSearchPayload = { searchText: this.searchValue.value };
        this.appDataService.post(this.appDataService.url.getUsersListSearch, [], payload).subscribe({
            next: (result) => {
                if (result?.length > 0) {
                    const loggedInUserId = this.appDataService.getUserId();
                    const filteredLoggedInStaffData = result.filter((user) => user.globalUserID !== loggedInUserId);
                    this.filteredStaffsList = this.removeDuplicateUserFromList(filteredLoggedInStaffData);
                }
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to remove duplicate user from list
     *
     * @memberof CooperatorsAccessListComponent
     */
    public removeDuplicateUserFromList(userList) {
        let staffList;
        const staffsArray = [...this.dataSource, ...this.users];
        if (staffsArray.length > 0) {
            staffList = userList.filter(
                // eslint-disable-next-line unicorn/explicit-length-check
                (user) => !staffsArray.filter((staff) => staff.userID === user.userId || staff.userId === user.userId).length,
            );
        }
        return staffList || userList;
    }

    /**
     * Method to close cooperator-access drawer
     *
     * @memberof CooperatorsAccessListComponent
     */
    public onAddStaffs(): void {
        if (this.users.length > 0) {
            this.cooperatorsComponent.addStaffToList(this.users);
        } else {
            this.toastrService.error(FORM_VALIDATION.FIELDS_REQUIRED);
        }
    }

    /**
     * Method to close cooperator-access drawer
     *
     * @memberof CooperatorsAccessListComponent
     */
    public onRemoveStaffs(list: any): void {
        this.cooperatorsComponent.removeStaffFromList(list);
    }

    /**
     * Method to close cooperator-access drawer
     *
     * @memberof CooperatorsAccessListComponent
     */
    public onCancelDrawer(): void {
        this.appDataService.resetSearchValues(this.searchValue, this.searchUserInput);
        this.cooperatorAccessToggle.emit();
    }

    /**
     * Method to disable add button
     *
     * @memberof CooperatorsAccessListComponent
     */
    public onDisableAdd(): boolean {
        if (this.users.length === 0) {
            return true;
        }
        const staffsArray = [...this.dataSource, ...this.users];
        let isDisabled = true;
        if (staffsArray.length > 0) {
            isDisabled =
                (this.dataSource.length === 2 && this.cooperatorAccessData?.currentPage === COOPERATOR_ACCESS.COOPERATOR) ||
                (staffsArray.length > 2 && this.cooperatorAccessData?.currentPage === COOPERATOR_ACCESS.COOPERATOR);
        }
        return isDisabled;
    }
}
