/* eslint-disable max-lines-per-function */
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChange, SimpleChanges } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatAutocompleteModule, MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { ExperimentApiService } from "@te-shared/helpers/experiment-api.service";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { MatDialog } from "@angular/material/dialog";
import { of, throwError } from "rxjs";
import { KEYBOARD_KEYS } from "@te-shared/constants/common.constant";
import { MockNotificationHelper } from "../../../testing/mock-notification.helper";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { AppBroadCastService, AppDataService, AppStateService } from "../../../_services";
import { NotificationHelper } from "../notification-drawer/helper/notification-helper";
import { NotesHelper } from "../../helpers/notes.helper";
import { CooperatorsAccessListComponent } from "./cooperators-access-list.component";
import { CooperatorsComponent } from "./cooperators/cooperators.component";
import { MockToastrService } from "../../../testing/mock-toastr.service";
import { MatChipsModule } from "@angular/material/chips";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";

describe("CooperatorsAccessListComponent", () => {
    let component: CooperatorsAccessListComponent;
    let fixture: ComponentFixture<CooperatorsAccessListComponent>;
    let element;
    const userResponse = [
        {
            countryCode: "IN",
            department: "IT",
            email: "AAAAA@xyz.com",
            firstName: "AAAAA",
            globalUserID: "AXB1234",
            initials: "AXB",
            isActive: "1",
            isLocked: "0",
            name: "AAAAA BBBBB",
            regionName: "GASIA",
            searchTxtIdx: 0,
            surName: "Devan",
            userId: 1234,
        },
    ];
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CooperatorsAccessListComponent],
            imports: [MatAutocompleteModule,
                MatChipsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule
            ],
            providers: [
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                ExperimentApiService,
                ExperimentAccessHelper,
                SecurityHelper,
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
                    useValue: { open: () => {}, closeAll: () => {} },
                },
                {
                    provide: ExperimentHelper,
                    useClass: MockExperimentHelper,
                },
                CooperatorsComponent,
                AppBroadCastService,
                AppStateService,
                { provide: NotificationHelper, useClass: MockNotificationHelper },
                NotesHelper,
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CooperatorsAccessListComponent);
        component = fixture.componentInstance;
        element = fixture.nativeElement;
        component.cooperatorAccessData = { currentPage: "CO", expId: 12_345_677 };
        component.dataSource = [
            {
                globalUserID: 33_343,
            },
        ];
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should resolve for onCancelDrawer()", () => {
        const spy = spyOn(component, "onCancelDrawer").and.callThrough();
        component.onCancelDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for removeUserFromChip()", () => {
        component.users = [{ userId: 123 }];
        const spy = spyOn(component, "removeUserFromChip").and.callThrough();
        component.removeUserFromChip({ userId: 123 });
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for removeDuplicateUserFromList()", () => {
        const data = [
            {
                userId: 33_343,
            },
        ];
        const spy = spyOn(component, "removeDuplicateUserFromList").and.callThrough();
        component.removeDuplicateUserFromList(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should render staffList CO", () => {
        component.cooperatorAccessData = { currentPage: "CO" };
        component.staffList = [];
        component.ngOnChanges({
            savedColumnList: new SimpleChange(component.staffList, component.staffList, false),
        });
        fixture.detectChanges();
        expect(element.querySelector("h2").textContent).toBe("Add Cooperator Staff");
    });

    it("should render staffList AL", () => {
        component.cooperatorAccessData = { currentPage: "AL" };
        component.staffList = [];
        component.ngOnChanges({
            savedColumnList: new SimpleChange(component.staffList, component.staffList, false),
        });
        fixture.detectChanges();
        expect(element.querySelector("h2").textContent).toBe("Experiment Access");
    });

    it("should resolve for selectedUser()", () => {
        const event: MatAutocompleteSelectedEvent = {
            option: {
                value: [
                    {
                        userId: 33_343,
                    },
                ],
            },
        } as MatAutocompleteSelectedEvent;
        const spy = spyOn(component, "selectedUser").and.callThrough();
        component.selectedUser(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for removeDuplicateUserFromList()", () => {
        component.dataSource = [{ userID: 33_343 }];
        const data = [
            {
                userId: 33_343,
            },
        ];
        const spy = spyOn(component, "removeDuplicateUserFromList").and.callThrough();
        component.removeDuplicateUserFromList(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onDisableAdd() with empty array", () => {
        component.dataSource = [];
        component.users = [];
        const spy = spyOn(component, "onDisableAdd").and.callThrough();
        component.onDisableAdd();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onDisableAdd() with user array", () => {
        component.dataSource = [{ userId: 33_343 }, { userId: 47_333 }];
        component.users = [];
        component.cooperatorAccessData = { currentPage: "CO" };
        const spy = spyOn(component, "onDisableAdd").and.callThrough();
        component.onDisableAdd();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onAddStaffs", () => {
        const spy = spyOn(component, "onAddStaffs").and.callThrough();
        component.onAddStaffs();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getUsersListBySearch", () => {
        const spy = spyOn(component, "getUsersListBySearch").and.callThrough();
        component.getUsersListBySearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on addPrivatePublic", () => {
        const spy = spyOn(component, "addPrivatePublic").and.callThrough();
        component.addPrivatePublic();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnChanges", () => {
        const changes = {
            activeExp: {
                currentValue: true,
            },
            cooperatorAccessData: {
                currentValue: true,
            },
            staffList: {
                currentValue: true,
            },
        } as unknown as SimpleChanges;
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getUsersListBySearch if throw error", () => {
        const service = TestBed.inject(AppDataService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(service, "post").and.returnValue(throwError(() => {}));
        const keyboardEvent = new KeyboardEvent("keyenter", { key: KEYBOARD_KEYS.ENTER });
        const spy = spyOn(component, "getUsersListBySearch").and.callThrough();
        component.getUsersListBySearch(keyboardEvent);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getUsersListBySearch if return response", () => {
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of(userResponse));
        spyOn(service, "getUserId");
        const keyboardEvent = new KeyboardEvent("keyenter", { key: KEYBOARD_KEYS.ENTER });
        const spy = spyOn(component, "getUsersListBySearch").and.callThrough();
        component.getUsersListBySearch(keyboardEvent);
        expect(spy).toHaveBeenCalled();
    });
});
