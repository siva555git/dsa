import { Component, Input, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { VIEW_ACCESS_POPUP, RESTRICTED_USE_FLAG_CODES } from "@te-shared/constants";
import { BomAttributes } from "@te-shared/models/attributes-model";
import { find } from "lodash";
import { FlagsESModel } from "../product-data/models/product-data.model";
import { ViewAccesslistComponent } from "../view-accesslist/view-accesslist.component";

@Component({
    selector: "app-view-flag-notes",
    templateUrl: "./view-flag-notes.component.html",
})
export class ViewFlagNotesComponent implements OnInit {
    @Input() public productFlagList: FlagsESModel[];

    @Input() public productFlagValue: string;

    @Input() public fromViewProductData: boolean;

    @Input() public productDetails: BomAttributes;

    @Input() public restrictedUse;

    @Input() public productDescription: string;

    @Input() public ipc: string;

    public flagNotes: FlagsESModel;

    public restrictedFlagCode = RESTRICTED_USE_FLAG_CODES;

    public ngOnInit(): void {
        this.flagNotes = find(this.productFlagList, (flag) => flag.flagcode === this.productFlagValue);
    }

    constructor(private dialog: MatDialog) {}

    /**
     * Method to open restricted view access list screen
     * @memberof ViewFlagNotesComponent
     */
    public viewAccessDetails(): void {
        const dialogOptions = VIEW_ACCESS_POPUP;
        dialogOptions.data = {
            productDescription: this.productDescription,
            ipc: this.ipc,
            restrictedUse: this.restrictedUse,
        };
        this.dialog.open(ViewAccesslistComponent, dialogOptions);
    }
}
