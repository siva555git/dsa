import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { mockAttributes } from "@te-testing/mock-ag-grid-data";
import { cloneDeep } from "lodash";
import { MatDialog } from "@angular/material/dialog";
import { of } from "rxjs";
import { ViewFlagNotesComponent } from "./view-flag-notes.component";

describe("ViewFlagNotesComponent", () => {
    let component: ViewFlagNotesComponent;
    let fixture: ComponentFixture<ViewFlagNotesComponent>;
    const dialogReferenceStub = {
        afterClosed() {
            return of();
        },
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ViewFlagNotesComponent],
            providers: [
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ViewFlagNotesComponent);
        component = fixture.componentInstance;
        component.productFlagValue = "ASPAC RAW MATERIAL";
        const data = cloneDeep(mockAttributes.flags);
        component.productFlagList = data;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call viewAccessDetails", () => {
        const spy = spyOn(component, "viewAccessDetails").and.callThrough();
        component.viewAccessDetails();
        expect(spy).toHaveBeenCalled();
    });
});
