import { Injectable } from "@angular/core";
import { DatePipe } from "@angular/common";
import { forkJoin, Observable, of } from "rxjs";
import { forEach, includes } from "lodash";
import { MatDialog } from "@angular/material/dialog";
import { NGXLogger } from "ngx-logger";
import { catchError } from "rxjs/operators";
import { BomAttributes } from "../../../models/attributes-model";
import { TasteEditorUtilClass } from "../../../helpers/taste-editor-utils";
import { FacilitiesModel } from "../../../models/facilities-model";
import { ProductCostStockModel, ProductCostStockPayload, ProductDataCostModel, ProductDataNotesModel } from "../models/product-data.model";
import { DisplayGridColumnModel } from "../../display-grid-data/display.grid.model";
import {
    DIVISION_LIST,
    PRODUCT_DATA_COST,
    PRODUCT_DATA_COST_STOCK,
    PRODUCT_DATA_MANUFACTURE_PLANT,
    PRODUCT_DATA_MATERIAL_ALLOCATION,
    PRODUCT_DATA_TABS,
    PRODUCT_VARIANT,
} from "../product-data-constant";
import { MASTER_DATA } from "../../../constants";
import { MasterDataHelper } from "../../../master-data/helpers/master-data.helper";
import { ExperimentHelper } from "../../../helpers/experiment-helper";
import { AppBroadCastService, AppDataService } from "../../../../_services";
import { CurrencyConversionHelper } from "../../../helpers/currency-conversion.helper";
import { EMPTY } from "../../../../app.constant";

@Injectable()
export class ProductDataCostHelper {
    constructor(
        private datePipe: DatePipe,
        private readonly appDataService: AppDataService,
        private masterDataHelper: MasterDataHelper,
        private experimentHelper: ExperimentHelper,
        private readonly dialog: MatDialog,
        public appBroadCastService: AppBroadCastService,
        private logger: NGXLogger,
    ) {}

    public tabsList = PRODUCT_DATA_TABS;

    public currrentTabs = PRODUCT_DATA_TABS.PRODUCT_SPEC;

    /**
     * returns the facility based on the costbook code match
     * @param {FacilitiesModel[]} facilitiesDetails
     * @param {string} facilityKey
     * @param {any} facilitiyValue
     * @memberof TasteEditorUtilClass
     */
    public static configProductCostColumns(): DisplayGridColumnModel[] {
        const productCostColumns: DisplayGridColumnModel[] = [
            {
                columndID: PRODUCT_DATA_COST.COSTBOOK_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST.COSTBOOK_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST.NAME_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST.NAME_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST.SOURCE_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST.SOURCE_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST.MNC_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST.MNC_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST.MNC_LAST_UPDATE_ID,
                displayColumnName: PRODUCT_DATA_COST.MNC_LAST_UPDATE_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST.WORKINGCOST_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST.WORKINGCOST_COLUMN_HEADERTEXT,
            },
        ];
        return productCostColumns;
    }

    /**
     * returns the product data based on IPC
     * @param {string} ipcNumber
     * @memberof ProductDataCostHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getProductData(ipcNumber: string): Observable<any> {
        const requestedURLs = [
            this.experimentHelper.getProductInfoByIpc(ipcNumber).pipe(catchError((error) => of(error))),
            this.masterDataHelper
                .checkAndFetchDefaultData([MASTER_DATA.FACILITIES, MASTER_DATA.FLAGS])
                .pipe(catchError((error) => of(error))),
            this.experimentHelper.getKeywordInfoByIpc(ipcNumber).pipe(catchError((error) => of(error))),
        ];
        return forkJoin(requestedURLs);
    }

    /**
     * returns the facility based on the costbook code match
     * @param {FacilitiesModel[]} facilitiesDetails
     * @param {BomAttributes} productData
     * @param {any} facilitiyValue
     * @memberof TasteEditorUtilClass
     */
    public formatProductCostGridDataSource(productData: BomAttributes, facilitiesDetails: FacilitiesModel[]): ProductDataCostModel[] {
        if (!productData || facilitiesDetails?.length === 0) return [];
        const productDataCostValues: ProductDataCostModel[] = [];
        forEach(productData.costbooks, (productCostData) => {
            if (!includes(productCostData.costbookcode, DIVISION_LIST.FLAV)) return;

            const mncValue = productCostData.mnc ? CurrencyConversionHelper.calculateConversionRate(productCostData.mnc) : undefined;
            const facilityDetail = TasteEditorUtilClass.getFacilityDetail(
                facilitiesDetails,
                PRODUCT_DATA_COST.COSTBOOK_CODE,
                productCostData.costbookcode,
            );
            const dateModify = this.datePipe.transform(new Date(productCostData.mncupdatedon), PRODUCT_DATA_COST.COST_DATE_FORMAT);
            const productDataCostModel = {
                costbook: productCostData.costbookcode,
                costbookName: facilityDetail?.displayValue ?? EMPTY,
                source: productCostData.sourcedesc,
                mnc: mncValue,
                mncLastUpdate: dateModify.toUpperCase(),
                workingCost: CurrencyConversionHelper.calculateConversionRate(productCostData.workingcost),
            };
            productDataCostValues.push(productDataCostModel);
        });
        return productDataCostValues;
    }

    /**
     * Method to config the stock display stock
     *
     * @static
     * @returns {DisplayGridColumnModel[]}
     * @memberof ProductDataCostHelper
     */
    public static configProductCostStockColumns(): DisplayGridColumnModel[] {
        const productCostStockColumns: DisplayGridColumnModel[] = [
            {
                columndID: PRODUCT_DATA_COST_STOCK.STOCK_PlANT_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST_STOCK.STOCK_PlANT_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST_STOCK.STOCK_PlANT_NAME_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST_STOCK.STOCK_PlANT_NAME_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST_STOCK.STOCK_QUALITY_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST_STOCK.STOCK_QUALITY_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST_STOCK.STOCK_BLOCK_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST_STOCK.STOCK_BLOCK_COULMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_COST_STOCK.STOCK_AVAILABLE_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_COST_STOCK.STOCK_AVAILABLE_COLUMN_HEADERTEXT,
            },
        ];
        return productCostStockColumns;
    }

    /**
     * Method to get the product cost stock
     *
     * @returns {Observable<ProductCostStockModel[]>}
     * @memberof ProductDataCostHelper
     */
    public getProductCostStockDataSource(stockPayload: ProductCostStockPayload): Observable<ProductCostStockModel[]> {
        return this.appDataService.post(this.appDataService.url.getProductCostStock, [], stockPayload);
    }

    /**
     * Method to config the manufacturing plant display
     *
     * @static
     * @returns {DisplayGridColumnModel[]}
     * @memberof ProductDataCostHelper
     */
    public static configManufacturingPlantColumns(): DisplayGridColumnModel[] {
        const manufacturingPlantColumns: DisplayGridColumnModel[] = [
            {
                columndID: PRODUCT_DATA_MANUFACTURE_PLANT.COSTBOOK_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_MANUFACTURE_PLANT.COSTBOOK_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_MANUFACTURE_PLANT.PLANT_ID,
                displayColumnName: PRODUCT_DATA_MANUFACTURE_PLANT.PLANT_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_MANUFACTURE_PLANT.FACILITY_TYPE_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_MANUFACTURE_PLANT.FACILITY_TYPE_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_MANUFACTURE_PLANT.BATCH_SIZE_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_MANUFACTURE_PLANT.BATCH_SIZE_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_MANUFACTURE_PLANT.PHANTOM_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_MANUFACTURE_PLANT.PHANTOM_COLUMN_HEADERTEXT,
            },
        ];
        return manufacturingPlantColumns;
    }

    /**
     * Method to config the material allocation display
     *
     * @static
     * @returns {DisplayGridColumnModel[]}
     * @memberof ProductDataCostHelper
     */
    public static configMaterialAllocationColumns(): DisplayGridColumnModel[] {
        const materialAllocationColumns: DisplayGridColumnModel[] = [
            {
                columndID: PRODUCT_DATA_MATERIAL_ALLOCATION.COSTBOOK_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_MATERIAL_ALLOCATION.COSTBOOK_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_MANUFACTURE_PLANT.PLANT_ID,
                displayColumnName: PRODUCT_DATA_MANUFACTURE_PLANT.PLANT_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_MANUFACTURE_PLANT.FACILITY_TYPE_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_MANUFACTURE_PLANT.FACILITY_TYPE_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_DATA_MATERIAL_ALLOCATION.PROCUREMENT_TYPE_COLUMN_ID,
                displayColumnName: PRODUCT_DATA_MATERIAL_ALLOCATION.PROCUREMENT_TYPE_COLUMN_HEADERTEXT,
            },
        ];
        return materialAllocationColumns;
    }

    /**
     * Method to configure product variant display
     * @static
     * @return {*}  {DisplayGridColumnModel[]}
     * @memberof ProductDataCostHelper
     */
    public static configProductVariantColumns(): DisplayGridColumnModel[] {
        const productVariantColumns: DisplayGridColumnModel[] = [
            {
                columndID: PRODUCT_VARIANT.ROOT_IPC_COLUMN_ID,
                displayColumnName: PRODUCT_VARIANT.ROOT_IPC_HEADERTEXT,
            },
            {
                columndID: PRODUCT_VARIANT.VARIANT_IPC_COLUMN_ID,
                displayColumnName: PRODUCT_VARIANT.VARIANT_IPC_COLUMN_HEADERTEXT,
            },
            {
                columndID: PRODUCT_VARIANT.CHANGE_CONDITION_COLUMN_ID,
                displayColumnName: PRODUCT_VARIANT.CHANGE_CONDITION_HEADERTEXT,
            },
            {
                columndID: PRODUCT_VARIANT.VARIANT_CHANGE_COLUMN_ID,
                displayColumnName: PRODUCT_VARIANT.VARIANT_CHANGE_HEADERTEXT,
            },
            {
                columndID: PRODUCT_VARIANT.VARIANT_COMMENT_COLUMN_ID,
                displayColumnName: PRODUCT_VARIANT.VARIANT_COMMENT_HEADERTEXT,
            },
            {
                columndID: PRODUCT_VARIANT.VARIANT_ENTEREDBY_COLUMN_ID,
                displayColumnName: PRODUCT_VARIANT.VARIANT_ENTEREDBY_HEADERTEXT,
            },
            {
                columndID: PRODUCT_VARIANT.VARIANT_DATE_TIME_COLUMN_ID,
                displayColumnName: PRODUCT_VARIANT.VARIANT_DATE_TIME_HEADERTEXT,
            },
        ];
        return productVariantColumns;
    }

    /*
     * Method to convert cost value in insert product search list
     *
     * @static
     * @param {string} value
     * @return {*}  {string}
     * @memberof ProductDataCostHelper
     */
    public static costConversionByCurrency(value: string): string {
        return CurrencyConversionHelper.calculateConversionRate(Number(value), true);
    }

    /**
     * Method to get product data notes for respective IPC
     * @param {string} searchIpc
     * @returns {Observable<ProductDataNotesModel[]>}
     * @memberof ProductDataCostHelper
     */
    public getProductDataNotes(searchIpc: string): Observable<ProductDataNotesModel[]> {
        return this.appDataService.get(this.appDataService.url.getProductDataNotes, [searchIpc]);
    }
}
