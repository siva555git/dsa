import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { TestBed, waitForAsync } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { AppBroadCastService, AppDataService } from "@te-services/index";
import { MockAppDataService } from "@te-testing/mock-app.data.service";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { DatePipe } from "@angular/common";
import { MasterDataHelper } from "@te-shared/master-data/helpers/master-data.helper";
import { MockMasterDataHelper } from "@te-testing/mock-master-data-helper";
import { MatDialog } from "@angular/material/dialog";
import { ProductDataCostHelper } from "./product-data-cost.helper";
import { BomAttributes } from "../../../models/attributes-model";
import { ProductCostStockPayload } from "../models/product-data.model";
import { of, throwError } from "rxjs";
import { mockAttributesArray } from "@te-testing/mock-ag-grid-data";
import { facilities } from "@te-testing/mock-data-audit";

describe("ProductDataCostHelper", () => {
    let productDataCostHelper : ProductDataCostHelper;
    let masterDataHelper : MasterDataHelper;
    let experimentHelper :ExperimentHelper;
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                ProductDataCostHelper,
                DatePipe,
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: MasterDataHelper,
                    useClass: MockMasterDataHelper,
                },
                {
                    provide: ExperimentHelper,
                    useClass: MockExperimentHelper,
                },           
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
                    useValue: { open: () => {}, closeAll: () => {} },
                },
                {
                    provide: AppBroadCastService,
                    useValue:{},
                },
                {
                    provide: NGXLogger,
                    useValue: MockLoggerService,
                },
            ],
        })
        productDataCostHelper = TestBed.inject(ProductDataCostHelper);
        experimentHelper = TestBed.inject(ExperimentHelper);
        masterDataHelper = TestBed.inject(MasterDataHelper);
    }
    ));

    it("should create", () => {
        expect(productDataCostHelper).toBeTruthy();
    });
    it("should call configProductCostColumns", () => {
        const spy = spyOn(ProductDataCostHelper, "configProductCostColumns").and.callThrough();
        ProductDataCostHelper.configProductCostColumns();
        expect(spy).toHaveBeenCalled();
    });

    it("should call getProductData", () => {
        const spy = spyOn(productDataCostHelper, "getProductData").and.callThrough();
        productDataCostHelper.getProductData('TE123').subscribe((result)=>{
            expect(result).toEqual(jasmine.any(Array))
        });
    });
    
    it("should call getProductData when service throws error", () => {
        spyOn(experimentHelper,'getProductInfoByIpc').and.returnValue(throwError(()=> 'Response Failed'));
        spyOn(masterDataHelper,'checkAndFetchDefaultData').and.returnValue(throwError(()=> 'Response Failed'));
        spyOn(experimentHelper,'getKeywordInfoByIpc').and.returnValue(throwError(()=> 'Response Failed'));
        const spy = spyOn(productDataCostHelper, "getProductData").and.callThrough();
        productDataCostHelper.getProductData('TE123').subscribe((result)=>{
            expect(result).toEqual(jasmine.any(Array))
        });
    });

    it("should call formatProductCostGridDataSource", () => {
        const spy = spyOn(productDataCostHelper, "formatProductCostGridDataSource").and.callThrough();
        const productData : BomAttributes = mockAttributesArray[0] as unknown as BomAttributes;
        productDataCostHelper.formatProductCostGridDataSource(productData, facilities);
        expect(spy).toHaveBeenCalled();
    });
    it("should resolve for formatProductCostGridDataSource when there is no facilities ", () => {
        const spy = spyOn(productDataCostHelper, "formatProductCostGridDataSource").and.callThrough();
        const productData : BomAttributes = mockAttributesArray[0] as unknown as BomAttributes;
        productDataCostHelper.formatProductCostGridDataSource(productData, []);
        expect(spy).toHaveBeenCalled();
    });
    it("should call configProductCostStockColumns", () => {
        const spy = spyOn(ProductDataCostHelper, "configProductCostStockColumns").and.callThrough();
        ProductDataCostHelper.configProductCostStockColumns();
        expect(spy).toHaveBeenCalled();
    });
    it("should call getProductCostStockDataSource", () => {
        const service = TestBed.inject(AppDataService);
        const getProductCostStockDataSource =  []
        spyOn(service, "post").and.returnValue(of([getProductCostStockDataSource]));
        const spy = spyOn(productDataCostHelper, "getProductCostStockDataSource").and.callThrough();
        const payload :ProductCostStockPayload =  {
            PlantID: ['Plant1'],
            MaterialNo: ["Material1"]
        }
        productDataCostHelper.getProductCostStockDataSource(payload)
        expect(spy).toHaveBeenCalled();
    });
    it("should call configManufacturingPlantColumns", () => {
        const spy = spyOn(ProductDataCostHelper, "configManufacturingPlantColumns").and.callThrough();
        ProductDataCostHelper.configManufacturingPlantColumns();
        expect(spy).toHaveBeenCalled();
    });
    it("should call configMaterialAllocationColumns", () => {
        const spy = spyOn(ProductDataCostHelper, "configMaterialAllocationColumns").and.callThrough();
        ProductDataCostHelper.configMaterialAllocationColumns();
        expect(spy).toHaveBeenCalled();
    });
    it("should call configProductVariantColumns", () => {
        const spy = spyOn(ProductDataCostHelper, "configProductVariantColumns").and.callThrough();
        ProductDataCostHelper.configProductVariantColumns();
        expect(spy).toHaveBeenCalled();
    });
    it("should call costConversionByCurrency", () => {  
        const productDataCostHelper = ProductDataCostHelper;
        const spy = spyOn(productDataCostHelper, "costConversionByCurrency").and.callThrough();
        productDataCostHelper.costConversionByCurrency('23');
        expect(spy).toHaveBeenCalled();
    });
    it("should call getProductDataNotes", () => {
        const service = TestBed.inject(AppDataService);
        const getProductDataNotes =  [];
        spyOn(service, "get").and.returnValue(of([getProductDataNotes]));
        const spy = spyOn(productDataCostHelper, "getProductDataNotes").and.callThrough();
        productDataCostHelper.getProductDataNotes("TE123");
        expect(spy).toHaveBeenCalled();
    });
});
