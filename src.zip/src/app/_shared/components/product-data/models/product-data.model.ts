// eslint-disable-next-line import/no-cycle
import { FlagAuditModel } from "../../../models";

/* eslint-disable @typescript-eslint/no-explicit-any */

export interface ProductDataDialogModel {
    ipcValues: any;
    facilities: any;
    flags: any;
}

export interface ProductData {
    IPC: string;
    "Product Type"?: string;
    Yield?: number;
    "Taste Descriptor"?: any;
    Trustee?: any;
}
export interface SpecESModel {
    presentationstyle: number;
    speccode: string;
    valuetext: string;
    lockedby: string;
    origuomcode: string;
    origvalue1: number;
    origvalue2: number;
    active: boolean;
    locked: boolean;
    lockedon: Date;
    displayvalue: string;
    sortcode: string;
}

export interface FlagsESModel {
    sortcode: string;
    flagcode: string;
    inheritedflag: boolean;
    updatedby: Date;
    createdby: string;
    comment: string;
    isbom: boolean;
    updatedon: Date;
    inheritedcontent: number;
    ipc: string;
    createdon: Date;
    description?: string;
}

export interface SpecFilterModel {
    name: string;
    checked: boolean;
    class: string;
}

export interface ProductDataCostModel {
    costbook: string;
    costbookName: string;
    source: string;
    mnc: string;
    mncLastUpdate: string;
    workingCost: string;
}

export interface ProductCostStockModel {
    PlantID: string;
    PlantName: string;
    MaterialNo: string;
    AvailableStock: string;
    QualityStock: string;
    BlockStock: string;
    RejectedStock: string;
    BulkAdjustment: string;
}

export interface ProductCostStockPayload {
    PlantID: string[];
    MaterialNo: string[];
}

export interface ProductBomDetails {
    audit: FlagAuditModel;
    bomitemtype: string;
    isbom: number;
    isbomrights: number;
    isdne: number;
    comment: string;
    description: string;
    ipc: string;
    parts: number;
    sequence: number;
    subipc: string;
    yield: number;
    instruction?: null;
}

export interface RestrictedUsageAccessListResponse {
    deptName: string;
    position: string;
    globalUserId: string;
    isGroup: string;
    name: string;
    regionName: string;
    securityGroupCode: string;
    userName: string;
}

export interface RestrictedUsageAccessList {
    accessgiven: string;
    flagcode: string;
    inherited: string;
    restricteduseoverride: string;
    tag: string;
}

export interface RestrictedUsageListPayload {
    globalUserIds?: Array<string>;
    groupNames?: Array<string>;
}

export interface RestrictedUsageListTreeView {
    flagGroupCode: string;
    parentFlagGroupCode?: string;
    globalUserID: string;
    name: string;
    regionName: string;
    department: string;
    position: string;
    filePath?: Array<string>;
}
export interface ProductDataNotesModel {
    CreatedBy: string;
    CreatedOn: string;
    IsPrivate: string | boolean;
    NoteType: string;
    Description: string;
    ExpID: number;
    ExpNoteID: number;
    UpdatedBy: string;
    UpdatedOn: string;
}
export interface ProductDataCurrencyModel {
    ipc: string;
    currency: string;
    currencyConversionRate: number;
    currencyDecimal: number;
    costBookCode: string;
}

export interface ProductYieldData {
    productType: string;
    yield: number;
}
