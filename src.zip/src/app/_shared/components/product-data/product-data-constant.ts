import { DisplayGridColumnModel } from "../display-grid-data/display.grid.model";

export const SPEC_FILTER_PRODUCT_DATA = [
    { name: "Locked", class: "pdo-spec-opt_lock", checked: true },
    { name: "Unlocked", class: "pdo-spec-opt_unlock", checked: true },
    { name: "Active", class: "pdo-spec-opt_act", checked: true },
    { name: "Inactive", class: "pdo-spec-opt_inact", checked: true },
];

export const SPEC_FILTER_LIST = {
    LOCKED: "Locked",
    UNLOCKED: "Unlocked",
    ACTIVE: "Active",
    INACTIVE: "Inactive",
};

export const SORT_ORDER = {
    ASCENDING: "Ascending",
    DESCENDING: "Descending",
    SORT_ICON: "icon-sort",
    ASC_ICON: "icon-ascending",
    DESC_ICON: "icon-decending",
};

export const DISPLAY_FLAGS_ICON_LIST = [
    { name: "NO NEW USE", class: "VA", displayText: "NNU" },
    { name: "INHERITED RESTRICTED USE", class: "EX", displayText: "IRU" },
    { name: "DO NOT USE", class: "DN", displayText: "DNU" },
    { name: "RESTRICTED USE", class: "RU", displayText: "RU" },
];

export const PRODUCT_DATA_TABS = {
    PRODUCT_SPEC: "Product Specification",
    COST: "Cost",
    BOM_DETAILS: "BOM Details",
    NOTE: "Note",
    VARIANT: "Variant",
};

export const DIVISION_LIST = {
    FLAV: "FL",
    FRAG: "FR",
};

export const PRODUCT_DATA_COST = {
    COSTBOOK_COLUMN_ID: "costbook",
    COSTBOOK_COLUMN_HEADERTEXT: "Costbook",

    NAME_COLUMN_ID: "costbookName",
    NAME_COLUMN_HEADERTEXT: "Costbook Name",

    SOURCE_COLUMN_ID: "source",
    SOURCE_COLUMN_HEADERTEXT: "Source",

    MNC_COLUMN_ID: "mnc",
    MNC_COLUMN_HEADERTEXT: "MNC",

    MNC_LAST_UPDATE_ID: "mncLastUpdate",
    MNC_LAST_UPDATE_HEADERTEXT: "MNC Last Update",

    WORKINGCOST_COLUMN_ID: "workingCost",
    WORKINGCOST_COLUMN_HEADERTEXT: "Working Cost",

    COSTBOOK_CODE: "costbookcode",

    COST_DATE_FORMAT: "dd-MMM-yyy | h:mm a",
};

export const PRODUCT_DATA_COST_STOCK = {
    STOCK_PlANT_COLUMN_ID: "PlantID",
    STOCK_PlANT_COLUMN_HEADERTEXT: "Plant ID",

    STOCK_PlANT_NAME_COLUMN_ID: "PlantName",
    STOCK_PlANT_NAME_COLUMN_HEADERTEXT: "Plant Name",

    STOCK_AVAILABLE_COLUMN_ID: "AvailableStock",
    STOCK_AVAILABLE_COLUMN_HEADERTEXT: "Available Stock",

    STOCK_QUALITY_COLUMN_ID: "QualityStock",
    STOCK_QUALITY_COLUMN_HEADERTEXT: "Quality Stock",

    STOCK_BLOCK_COLUMN_ID: "BlockStock",
    STOCK_BLOCK_COULMN_HEADERTEXT: "Block Stock",
};

export const PRODUCT_DATA_MANUFACTURE_PLANT = {
    COSTBOOK_COLUMN_ID: "facilitycostbookcode",
    COSTBOOK_COLUMN_HEADERTEXT: "Costbook",

    PLANT_ID: "plant",
    PLANT_COLUMN_HEADERTEXT: "Plant",

    FACILITY_TYPE_COLUMN_ID: "facilitytypename",
    FACILITY_TYPE_COLUMN_HEADERTEXT: "Facility Type",

    BATCH_SIZE_COLUMN_ID: "batchsizeinkg",
    BATCH_SIZE_COLUMN_HEADERTEXT: "Batch Size(KG)",

    PHANTOM_COLUMN_ID: "phantom",
    PHANTOM_COLUMN_HEADERTEXT: "PHANTOM",
};

export const PRODUCT_DATA_MATERIAL_ALLOCATION = {
    COSTBOOK_COLUMN_ID: "facilitycostbookcode",
    COSTBOOK_COLUMN_HEADERTEXT: "Costbook",

    PROCUREMENT_TYPE_COLUMN_ID: "procurementtype",
    PROCUREMENT_TYPE_COLUMN_HEADERTEXT: "Make/Purchase",
};

export const PRODUCT_COST_COUMNS_WITH_CURRENCY = [PRODUCT_DATA_COST.MNC_COLUMN_HEADERTEXT, PRODUCT_DATA_COST.WORKINGCOST_COLUMN_HEADERTEXT];

export const DEFAULT_ERROR_DETAILS = {
    errorHeader: "Enter Valid IPC Number",
    errorMessage: "After entering valid IPC, data will populate here",
};

export const DEFAULT_ERROR_BOM_ACCESS = "BOM Access Restricted";

export const TASTE = "taste";

export const PRODUCT_VARIANT = {
    ROOT_IPC_COLUMN_ID: "ipc",
    ROOT_IPC_HEADERTEXT: "Root IPC",

    IPC_DESCRIPTION_COLUMN_ID: "variantDeipcDescriptionscription",
    IPC_DESCRIPTION_COLUMN_HEADERTEXT: "Root IPC Description",

    VARIANT_IPC_COLUMN_ID: "variantipc",
    VARIANT_IPC_COLUMN_HEADERTEXT: "Variant IPC",

    VARIANT_DESCRIPTION_COLUMN_ID: "variantDescription",
    VARIANT_DESCRIPTION_COLUMN_HEADERTEXT: "Variant IPC Description",

    CHANGE_CONDITION_COLUMN_ID: "changeconditiondesc",
    CHANGE_CONDITION_HEADERTEXT: "Change Condition",

    VARIANT_CHANGE_COLUMN_ID: "variantchange",
    VARIANT_CHANGE_HEADERTEXT: "Variant Change",

    VARIANT_COMMENT_COLUMN_ID: "comment",
    VARIANT_COMMENT_HEADERTEXT: "Comments",

    VARIANT_ENTEREDBY_COLUMN_ID: "createdby",
    VARIANT_ENTEREDBY_HEADERTEXT: "Entered By",

    VARIANT_DATE_TIME_COLUMN_ID: "createdon",
    VARIANT_DATE_TIME_HEADERTEXT: "Entered Date/Time",
};
export const GRID_PROPERTIES = {
    rowModelType: "serverSide",
    serverSideInfiniteScroll: true,
    cacheBlockSize: 100,
    maxBlocksInCache: 1,
    rowBuffer: 20,
    rowHeight: "26",
    headerHeight: "32",
};
export const OVERLAY_CONSTANTS = {
    NoRows: "No rows to show",
    Loading: "Loading...",
};

export const PRODUCT_USAGE_ACCESS_LIST = [
    {
        flagGroupCode: "INHERITED RESTRICTED USE",
        parentFlagGroupCode: undefined,
        globalUserID: "",
        name: "",
        regionName: "",
        department: "",
        position: "",
    },
    {
        flagGroupCode: "INHERITED RESTRICTED USE (INHERITED)",
        parentFlagGroupCode: undefined,
        globalUserID: "",
        name: "",
        regionName: "",
        department: "",
        position: "",
    },
    {
        flagGroupCode: "RESTRICTED USE",
        parentFlagGroupCode: undefined,
        globalUserID: "",
        name: "",
        regionName: "",
        department: "",
        position: "",
    },
];

export const RESTRICTED_USER_GROUP_OR_SINGLE = {
    RESTRICTED_USER_ACCESS_LIST_GROUP: "RESTRICTEDUSEOVERRIDEGROUP",
    RESTRICTED_USER_ACCESS_LIST_SINGLE: "RESTRICTEDUSEOVERRIDESINGLE",
    INHERITED: "(INHERITED)",
    IS_ACCESS_LIST_INHERITED: "Y",
    INDEX: 0,
    SEARCH_ICON: "searchIcon",
    SEARCH_SCREEN_NAME: "VIEW_ACCESS",
};
export const PRODUCT_KEYWORD = {
    USE_LEVEL_COLUMN_ID: "UseLevel",
    USE_LEVEL_HEADERTEXT: "Use Level",

    RATING_COLUMN_ID: "Rating",
    RATING_HEADERTEXT: "Rating",

    EVALUATOR_COLUMN_ID: "EvaluatorCode",
    EVALUATOR_HEADERTEXT: "Evaluator",

    END_USE_CODE_COLUMN_ID: "EndUseCode",
    END_USE_CODE_HEADERTEXT: "Enduse Code",

    END_USE_DESC_COLUMN_ID: "Description",
    END_USE_DESC_HEADERTEXT: "Description",

    EVALUATION_DATE_COLUMN_ID: "EnteredOn",
    EVALUATION_DATE_HEADERTEXT: "Evaluation Date",

    KEYWORD_DATE_FORMAT: "dd-MMM-yyy hh:mm:ss",
};
export const PRODUCT_KEYWORD_COLUMNS: DisplayGridColumnModel[] = [
    {
        columndID: PRODUCT_KEYWORD.USE_LEVEL_COLUMN_ID,
        displayColumnName: PRODUCT_KEYWORD.USE_LEVEL_HEADERTEXT,
    },
    {
        columndID: PRODUCT_KEYWORD.RATING_COLUMN_ID,
        displayColumnName: PRODUCT_KEYWORD.RATING_HEADERTEXT,
    },
    {
        columndID: PRODUCT_KEYWORD.EVALUATOR_COLUMN_ID,
        displayColumnName: PRODUCT_KEYWORD.EVALUATOR_HEADERTEXT,
    },
    {
        columndID: PRODUCT_KEYWORD.END_USE_CODE_COLUMN_ID,
        displayColumnName: PRODUCT_KEYWORD.END_USE_CODE_HEADERTEXT,
    },
    {
        columndID: PRODUCT_KEYWORD.END_USE_DESC_COLUMN_ID,
        displayColumnName: PRODUCT_KEYWORD.END_USE_DESC_HEADERTEXT,
    },
    {
        columndID: PRODUCT_KEYWORD.EVALUATION_DATE_COLUMN_ID,
        displayColumnName: PRODUCT_KEYWORD.EVALUATION_DATE_HEADERTEXT,
    },
];
