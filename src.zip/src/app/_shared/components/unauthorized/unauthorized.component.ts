import { Component, OnInit } from "@angular/core";
import { NGXLogger } from "ngx-logger";
import { AppStateService } from "../../../_services/app-state/app.state.service";
import { UserStatus } from "../../enums";

@Component({
    selector: "app-unauthorized",
    templateUrl: "./unauthorized.component.html",
    styleUrls: ["./unauthorized.component.scss"],
    host: { class: "pageUnauthorized" },
})
export class UnauthorizedComponent implements OnInit {
    public isDisabledUser;

    constructor(private appState: AppStateService, private logger: NGXLogger) {}

    public ngOnInit(): void {
        this.isDisabledUser = this.appState.get(this.appState.stateId.userAppStatus) === UserStatus.DISABLED;
        this.logger.debug("User Status:", this.appState.stateId.userAppStatus);
    }
}
