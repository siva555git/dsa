/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from "@angular/material/dialog";
import { Router } from "@angular/router";
import { NGXLogger } from "ngx-logger";
import { of, throwError } from "rxjs";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { MockExperimentApiService } from "../../../testing/mock-experiment-api.service";
import { MockDialogReference } from "../../../testing/mock-dialog.reference";
import { ExperimentApiService } from "../../helpers/experiment-api.service";
import { AppStateService } from "../../../_services/app-state/app.state.service";
import { MockAppStateService } from "../../../testing/mock-app.state.service";
import { ViewMembershipComponent } from "./view-membership.component";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { MatTooltipModule } from "@angular/material/tooltip";

describe("ViewMembershipComponent", () => {
    let component: ViewMembershipComponent;
    const mockRouter = { navigateByUrl: jasmine.createSpy("navigateByUrl") };
    let fixture: ComponentFixture<ViewMembershipComponent>;
    const dialogData = {
        expId: 63_399_886,
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ViewMembershipComponent],
            providers: [
                { provide: ExperimentApiService, useClass: MockExperimentApiService },
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: MAT_DIALOG_DATA, useValue: dialogData },
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: Router, useValue: mockRouter },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                AppBroadCastService,
            ],
            imports: [
                MatDialogModule,
                MatTooltipModule
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ViewMembershipComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call OnFolderClicked and navigate", () => {
        const spy = spyOn(component, "OnFolderClicked").and.callThrough();
        component.OnFolderClicked("K1S30096AA", "Test", 1, "123");
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getMembershipDetails when throw error", () => {
        const service: ExperimentApiService = TestBed.inject(ExperimentApiService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(service, "getCollaborationAndFolderInfo").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "getMembershipDetails").and.callThrough();
        component.getMembershipDetails();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getMembershipDetails when return response", () => {
        const response = [
            {
                CollaborationGroupMappedID: 123,
                CollaborationGroupID: 909,
                ExpID: 989,
                CreatedBy: 126,
                CreatedOn: Date,
                UpdatedBy: 987,
                UpdatedOn: Date,
                UserID: 678,
                ExpFolderID: 1,
                ExpFolderMappedID: 12,
                ExperimentFolder: {
                    Description: "Validate",
                    FolderName: "Test",
                    IsDefault: "Yes",
                    IsShared: "isShared",
                    ParentFolderID: 121,
                },
                UserCollaborationGroup: {
                    CollaborationGroupID: 12,
                    CreatedByUser: {
                        FirstName: "AAAA",
                        Surname: "BBBB",
                    },
                    GroupDescription: "Description",
                    GroupName: "Collaboration",
                    UserCollaborationGroupMapped: [
                        {
                            IsOwnedGroup: 675,
                        },
                    ],
                },
            },
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        ] as any;
        const service: ExperimentApiService = TestBed.inject(ExperimentApiService);
        spyOn(service, "getCollaborationAndFolderInfo").and.returnValue(of(response));
        const spy = spyOn(component, "getMembershipDetails").and.callThrough();
        component.getMembershipDetails();
        expect(spy).toHaveBeenCalled();
    });
});
