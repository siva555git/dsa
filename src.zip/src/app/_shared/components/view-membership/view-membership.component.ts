import { Component, Inject, OnInit } from "@angular/core";
import { filter } from "rxjs/operators";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { keys } from "lodash";
import { Subscription } from "rxjs";
import { EMPTY, LOADING } from "src/app/app.constant";
import { NGXLogger } from "ngx-logger";
import { ExperimentApiService } from "../../helpers/experiment-api.service";
import { DefaultExperimentFolderIds, EXPERIMENT_FOLDER, KEYBOARD_KEYS } from "../../constants/common.constant";
import { CollaborationAndFolderModel, CollaborationGroupListModel } from "../../models/user-collaboration-group.model";
import { AppStateService } from "../../../_services/app-state/app.state.service";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { ExperimentDetails } from "../../models/experiment-list.model";
import { TasteEditorUtilClass } from "../../helpers/taste-editor-utils";

@Component({
    selector: "app-view-membership",
    templateUrl: "./view-membership.component.html",
})
export class ViewMembershipComponent implements OnInit {
    public membershipAndFolderDetails: CollaborationAndFolderModel[];

    public folderDetails: CollaborationAndFolderModel;

    public loggedInUserId: number;

    public collaborationGroupId = DefaultExperimentFolderIds.COLLABORATION_FOLDER_ID;

    public viewMembershipSubscriptions: Subscription[] = [];

    constructor(
        private readonly experimentApiService: ExperimentApiService,
        private readonly dialogReference: MatDialogRef<ViewMembershipComponent>,
        private readonly appStateService: AppStateService,
        private readonly appBroadCastService: AppBroadCastService,
        @Inject(MAT_DIALOG_DATA) public data: { expId: number; experimentName: string; expCode: string },
        private readonly logger: NGXLogger,
    ) {}

    ngOnInit(): void {
        this.viewMembershipSubscriptions.push(
            this.dialogReference
                .keydownEvents()
                .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.dialogReference.close();
                }),
        );

        this.getMembershipDetails();
    }

    /**
     * Method to get the respective Folder details while clicking the folder in View Membership
     * @memberof ViewMembershipComponent
     */
    public getMembershipDetails(): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.experimentApiService.getCollaborationAndFolderInfo(this.data.expId).subscribe({
            next: (collaborationFolderData) => {
                if (collaborationFolderData.length > 0) {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.membershipAndFolderDetails = collaborationFolderData;
                    this.folderDetails = this.membershipAndFolderDetails.find((folderData) => keys(folderData).includes(EXPERIMENT_FOLDER));
                    const index = this.membershipAndFolderDetails.findIndex((folderData) => keys(folderData).includes(EXPERIMENT_FOLDER));
                    this.membershipAndFolderDetails.splice(index, 1);
                    this.loggedInUserId = Number(this.appStateService.getCurrentUserSapEmpId());
                }
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to get the respective Folder details while clicking the folder in View Membership
     * @memberof ViewMembershipComponent
     */
    public OnFolderClicked(
        expCode: string,
        folderName: string,
        folderId: number,
        parentFolderID?: string,
        createdby?: number,
        selectedCollaborationGroup?: CollaborationGroupListModel,
    ): void {
        if (createdby && createdby !== this.loggedInUserId) {
            return;
        }
        const experimentDetails: ExperimentDetails = {
            ExperimentCode: expCode,
            FolderName: folderName,
            FolderID: folderId,
            ParentFolderID: parentFolderID,
            SelectedCollaborationGroup: selectedCollaborationGroup,
        };
        this.dialogReference.close(experimentDetails);
    }

    /**
     * Method to destroy subscriptions
     * @returns {void}
     * @memberof ViewMembershipComponent
     */
    public ngOnDestroy(): void {
        TasteEditorUtilClass.removeSubscriptions(this.viewMembershipSubscriptions);
    }
}
