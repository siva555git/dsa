/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { CREATE_EXPERIMENT_SUGGESTION, WORKSPACE_DIALOG_BUTTONS } from "@te-experiment/experiment.constant";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { ProductDataCostHelper } from "@te-shared/components/product-data/product-data-cost/product-data-cost.helper";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { SelectedRowDataModel } from "@te-shared/models/selected-row-data.model";
import { MockAppStateService } from "@te-testing/mock-app.state.service";
import { MockExperimentAccessHelper } from "@te-testing/mock-experiment-access.helper";
import { MockProductDataCostHelper } from "@te-testing/mock-product-data-cost-helper";
import { ToastrService } from "ngx-toastr";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { MockDialogReference } from "../../../../testing/mock-dialog.reference";
import { AppBroadCastService } from "../../../../_services/app-broadcast/app.broadcast.service";
import { WorkspacePopupComponent } from "./workspace-popup.component";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

describe("WorkspacePopupComponent", () => {
    let component: WorkspacePopupComponent;
    let fixture: ComponentFixture<WorkspacePopupComponent>;
    const dialogData = {
        dialogData: [
            {
                workspaceDetails: [
                    {
                        UserTabID: 17_227,
                        TabName: "Workspace 43",
                        Sequence: 222,
                        CreatedBy: 44_991,
                        UpdatedBy: 44_991,
                        SavedLayoutTypeID: undefined,
                        CustomLayoutTypeID: undefined,
                        IsSavedSelected: true,
                        IsCurrent: "0",
                        IsOpen: "1",
                        CreatedOn: "2022-02-07T09:38:14.000Z",
                        UpdatedOn: "2022-02-07T21:19:25.221Z",
                    },
                ],
                selectedExp: [{ ExpCode: "BXR00001AA" }],
            },
        ],
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [WorkspacePopupComponent],
            providers: [
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
                    useValue: { open: () => {} },
                },
                { provide: MatDialogRef, useClass: MockDialogReference },
                AppBroadCastService,
                { provide: MAT_DIALOG_DATA, useValue: dialogData },
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: ProductDataCostHelper, useClass: MockProductDataCostHelper },
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(WorkspacePopupComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call onClickTabName", () => {
        const workSpaceDetail = {
            UserTabID: 17_227,
            TabName: "Workspace 43",
            Sequence: 222,
            CreatedBy: 44_991,
            UpdatedBy: 44_991,
            SavedLayoutTypeID: undefined,
            CustomLayoutTypeID: undefined,
            IsSavedSelected: true,
            IsCurrent: "0",
            IsOpen: "1",
            CreatedOn: "2022-02-07T09:38:14.000Z",
            UpdatedOn: "2022-02-07T21:19:25.221Z",
            IsHideDeletedSetting: false,
            ProductSearchID: 0,
        };
        const spy = spyOn(component, "onClickWorkSpaceName").and.callThrough();
        component.onClickWorkSpaceName(workSpaceDetail);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onClickTabName for open new exp in existing workspace", () => {
        component.type = CREATE_EXPERIMENT_SUGGESTION;
        const workSpaceDetail = {
            UserTabID: 17_227,
            TabName: "Workspace 43",
            Sequence: 222,
            CreatedBy: 44_991,
            UpdatedBy: 44_991,
            SavedLayoutTypeID: undefined,
            CustomLayoutTypeID: undefined,
            IsSavedSelected: true,
            IsCurrent: "0",
            IsOpen: "1",
            CreatedOn: "2022-02-07T09:38:14.000Z",
            UpdatedOn: "2022-02-07T21:19:25.221Z",
            IsHideDeletedSetting: false,
            ProductSearchID: 0,
        };
        const spy = spyOn(component, "onClickWorkSpaceName").and.callThrough();
        component.onClickWorkSpaceName(workSpaceDetail);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onDialogResponseClick", () => {
        const spy = spyOn(component, "onDialogResponseClick").and.callThrough();
        component.onDialogResponseClick(WORKSPACE_DIALOG_BUTTONS.OPEN_IN_NEW_WORKSPACE);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on filterAndShowWorkSpaces", () => {
        const spy = spyOn(component, "filterAndShowWorkSpaces").and.callThrough();
        component.filterAndShowWorkSpaces();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on checkAccess", () => {
        const spy = spyOn(component, "checkAccess").and.callThrough();
        const selectedExp = [{ ExpCode: "BXR00001AA" }] as SelectedRowDataModel[];
        component.checkAccess(selectedExp[0]);
        expect(spy).toHaveBeenCalled();
    });
});
