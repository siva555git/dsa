import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
    CREATE_EXPERIMENT_SUGGESTION,
    DESC,
    MAX_EXPERIMENT_IN_WORKSPACE,
    SEQUENCE,
    TOASTER_MESSAGE_FOR_MAX_EXPERIMENT,
    WORKSPACE_DIALOG_BUTTONS,
    WORKSPACE_MULTIPLE_EXPERIMENT_BOM_DIALOG_SUB_TITLE,
} from "@te-experiment/experiment.constant";
import { ExperimentListHelper } from "@te-experiment/helpers/experiment-list.helper";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { BOM_TYPE, KEYBOARD_KEYS, LOCKED_BY_STATUS, MAX_EXPORPRO_OPEN_LENGTH } from "@te-shared/constants/common.constant";
import { PRODUCT, EXPERIMENT } from "@te-shared/constants/context-menu.constant";
import { EXPERIMENT_ACCESS } from "@te-shared/constants/experiment-access.constant";
import { ExperimentAccessHelper } from "@te-shared/helpers/experiment-access.helper";
import { WorkSpaces } from "@te-shared/models/create-tab.model";
import { forEach, orderBy } from "lodash";
import { ToastrService } from "ngx-toastr";
import { ExperimentListComponent } from "../../../../experiment/experiment-list/experiment-list.component";
import { AppBroadCastService } from "../../../../_services/app-broadcast/app.broadcast.service";

@Component({
    selector: "app-workspace-popup",
    templateUrl: "./workspace-popup.component.html",
})
export class WorkspacePopupComponent implements OnInit {
    public dialogMsg;

    public workSpaceDetail = [];

    public listTitle = WORKSPACE_MULTIPLE_EXPERIMENT_BOM_DIALOG_SUB_TITLE;

    public items = [];

    public lockStatus = LOCKED_BY_STATUS;

    public type: string;

    public isMulipleBomScreen = false;

    public validateSelectionCount = true;

    constructor(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        @Inject(MAT_DIALOG_DATA) public data: any,
        private readonly dialogReference: MatDialogRef<ExperimentListComponent>,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly appState: AppStateService,
        private readonly experimentAccessHelper: ExperimentAccessHelper,
        private readonly toastrService: ToastrService,
    ) {}

    ngOnInit() {
        this.dialogReference.keydownEvents().subscribe((event) => {
            if (event.key === KEYBOARD_KEYS.ESCAPE) {
                this.dialogReference.close();
            }
        });
        this.dialogMsg = this.data;
        this.isMulipleBomScreen = this.data.dialogData[0]?.isMulipleBomScreen;
        if (this.isMulipleBomScreen) {
            const selectedExp = this.data.dialogData[0]?.selectedExp;
            selectedExp.forEach((item) => {
                // eslint-disable-next-line no-lone-blocks
                {
                    Object.assign(item, { ipcSelected: false, expSelected: false });
                    this.items.push(item);
                }
            });
        } else {
            this.workSpaceDetail = this.data.dialogData[0]?.workspaceDetails;
        }
        this.type = this.data.dialogData[0]?.type;
    }

    /**
     * Method to click on workspace name
     *
     * @param {WorkSpaces} workSpaceDetail
     * @memberof WorkspacePopupComponent
     */
    public onClickWorkSpaceName(workSpaceDetail: WorkSpaces): void {
        if (this.type === CREATE_EXPERIMENT_SUGGESTION) {
            if (workSpaceDetail?.WorkSpaceDetail?.length === MAX_EXPERIMENT_IN_WORKSPACE) {
                this.toastrService.error(TOASTER_MESSAGE_FOR_MAX_EXPERIMENT);
            } else {
                this.dialogReference.close({
                    type: WORKSPACE_DIALOG_BUTTONS.EXISTING_WORKSPACE,
                    workSpaceDetail,
                });
            }
        } else {
            let activeExpCode;
            if (this.data.dialogData?.length > 0 && this.data.dialogData[0]?.selectedExp?.length > 0) {
                activeExpCode = this.data.dialogData[0]?.selectedExp[0]?.ExpCode;
            }
            if (activeExpCode) AppStateService.setExpToBeActiveInWorkSpace(activeExpCode);
            this.dialogReference.close({
                type: WORKSPACE_DIALOG_BUTTONS.EXISTING_WORKSPACE,
            });
            this.appBroadCastService.getWorkSpaceDetails(workSpaceDetail);
        }
    }

    /**
     * Method to send the confirmation type response to where it is called
     *
     * @param {string} type
     * @memberof WorkspacePopupComponent
     */
    public onDialogResponseClick(type: string): void {
        const payloadExp = this.items
            .filter((item) => item.expSelected)
            .map((item) => {
                return {
                    SUBCode: item?.ExpID,
                    SUBType: BOM_TYPE.EXPERIMENT,
                    ExpName: item?.ExpName,
                    ExpCode: item?.ExpCode,
                    ExpID: item?.ExpID,
                    // eslint-disable-next-line unicorn/no-null
                    IPC: null,
                    IsLocked: item?.IsLocked,
                    Type: EXPERIMENT,
                };
            });

        const payloadIpc = this.items
            .filter((item) => item.ipcSelected)
            .map((item) => {
                return {
                    SUBCode: item?.IPC,
                    SUBType: BOM_TYPE.PRODUCT,
                    ExpName: item?.description,
                    ExpCode: item?.IPC,
                    // eslint-disable-next-line unicorn/no-null
                    ExpID: null,
                    IPC: item?.IPC,
                    IsLocked: LOCKED_BY_STATUS.LOCKED,
                    Type: PRODUCT,
                };
            });
        const responseData = {
            type,
            workSpaceDetail:
                type === WORKSPACE_DIALOG_BUTTONS.OPEN_IN_MOST_RECENT_WORKSPACE && this.workSpaceDetail?.length > 0
                    ? this.workSpaceDetail[0]
                    : undefined,
            // eslint-disable-next-line unicorn/prefer-spread
            selectedRows: this.isMulipleBomScreen ? payloadExp.concat(payloadIpc) : undefined,
        };
        this.dialogReference.close(responseData);
    }

    /**
     * Method to trigger on change and search for workspaces
     * @returns {void}
     * @memberof WorkspacePopupComponent
     */
    public filterAndShowWorkSpaces(): void {
        const workSpaces = this.data.dialogData[0]?.workspaceDetails;
        const workSpaceDetails = ExperimentListHelper.getMatchedWorkspaceDetails(workSpaces, this.items);
        this.workSpaceDetail = workSpaceDetails && workSpaceDetails.length > 0 ? orderBy(workSpaceDetails, SEQUENCE, DESC) : [];
        let selectionCount = this.items.filter((item) => item.ipcSelected || item.expSelected).length;
        forEach(this.items, (selectedData) => {
            if (selectedData.ipcSelected && selectedData.expSelected) {
                selectionCount += 1;
            }
        });
        this.validateSelectionCount = selectionCount === 0 || selectionCount > MAX_EXPORPRO_OPEN_LENGTH;
    }

    /**
     * Method to check access for exp
     * @param {*} item
     * @returns {boolean}
     * @memberof WorkspacePopupComponent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public checkAccess(item: any): boolean {
        const userId = this.appState.getCurrentUserSapEmpId();
        if (item.CreatedBy === Number(userId)) {
            return true;
        }
        const hasAccess = this.experimentAccessHelper.getExperimentAccessCheck(
            [item],
            Number(userId),
            EXPERIMENT_ACCESS.OPEN_EXPERIMEMT_IN_WORKSPACE,
        );
        return hasAccess.isPermitted;
    }
}
