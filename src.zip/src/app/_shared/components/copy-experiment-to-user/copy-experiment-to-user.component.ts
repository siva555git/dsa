/* eslint-disable @typescript-eslint/no-explicit-any */
import {
    Component,
    ElementRef,
    EventEmitter,
    HostListener,
    Input,
    OnDestroy,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild,
} from "@angular/core";
import { UntypedFormControl, Validators } from "@angular/forms";
import { MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { NGXLogger } from "ngx-logger";
import { debounceTime } from "rxjs/operators";
import { Subscription } from "rxjs";
import { ToastrService } from "ngx-toastr";
import { map } from "lodash";
import { MatDialog } from "@angular/material/dialog";
import { MatMenuTrigger } from "@angular/material/menu";
import { CollaborationGroupListModel } from "@te-shared/models/user-collaboration-group.model";
import { ExperimentHelper } from "../../helpers/experiment-helper";
import {
    COPY_TO_USER_RESPONSE_STATUS,
    NOT_MEMBER_FOR_CREATIVE_TASK,
    NO_CREATIVE_TASK,
    USER_PLANT_ALLOCATION_ISSUE_SCENARIOS,
} from "../../constants/common.constant";
import { AppDataService, AppBroadCastService, AppStateService } from "../../../_services";
import { CooperatorUserModel, CopyToUserPayload, UsersListSearchPayload } from "../../models/cooperator-access.model";
import { SelectedRowDataModel } from "../../models";
import { EMPTY, LOADING } from "../../../app.constant";
import { ES_RESPONSE } from "../../constants";
import {
    COPY_TO_USER_ERROR_MSG,
    COPY_TO_USER_SUCCESS_MSG,
    EXP_ID_OBJ_KEY,
    USER_FETCH_ERROR_MSG,
    USER_FETCH_ERROR_TOASTER_MSG,
} from "../../constants/experiment.constant";
import { TasteEditorUtilClass } from "../../helpers/taste-editor-utils";
import { FolderCollabGroupSelectorComponent } from "../folder-collab-group-selector/folder-collab-group-selector.component";
import { REFRESH_EXPERIMENT_HEADER } from "../../../experiment-editor/constants/experiment-editor.constant";
import { SharedExperimentUtil } from "../../helpers/shared-experiment.util";

@Component({
    selector: "app-copy-experiment-to-user",
    templateUrl: "./copy-experiment-to-user.component.html",
    host: { class: "copy-expToUser" },
})
export class CopyExperimentToUserComponent implements OnInit, OnDestroy {
    @HostListener("document:keydown.escape", ["$event"]) onKeydownHandler(): void {
        this.onCancelDrawer();
    }

    public filteredUsersList: Array<CooperatorUserModel>;

    public users = [];

    public currentUser;

    public IsCopyCreativeTask = false;

    public isSelectorDisabled = true;

    public selectedExpFolderName = EMPTY;

    public activeExpFolderID = 0;

    public appDataSubscriptions: Subscription[] = [];

    public searchControl: UntypedFormControl = new UntypedFormControl(EMPTY, [Validators.required]);

    public userNotesControl: UntypedFormControl = new UntypedFormControl(EMPTY, [Validators.maxLength(255)]);

    public addVariant: UntypedFormControl = new UntypedFormControl(false);

    public copyCreativeTask: UntypedFormControl = new UntypedFormControl(false);

    @Input() public selectedExperiments: SelectedRowDataModel[] = [];

    @Input() public selectedCollabGrpID: number;

    @Input() public userCollaborationGroupList: CollaborationGroupListModel[];

    @Output()
    public copyToUserdrawerToggle = new EventEmitter();

    @ViewChild("searchUserInput") searchUserInput: ElementRef;

    @ViewChild("selector") folderCollabGroupSelectorComponent: FolderCollabGroupSelectorComponent;

    @ViewChild(MatMenuTrigger, { static: false }) menu: MatMenuTrigger;

    public isVariantEnabled = false;

    public isMyTaskMember = true;

    public copyToUserFullName: string;

    public noCreativeTask = NO_CREATIVE_TASK;

    public notCreativeTaskMember = NOT_MEMBER_FOR_CREATIVE_TASK;

    public notTaskMemberMsg: string;

    constructor(
        private readonly logger: NGXLogger,
        private readonly toasterService: ToastrService,
        private readonly appDataService: AppDataService,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly appState: AppStateService,
        public readonly dialog: MatDialog,
        private readonly experimentHelper: ExperimentHelper,
    ) {}

    public ngOnInit(): void {
        this.searchControl.valueChanges.pipe(debounceTime(500)).subscribe((value) => {
            this.filteredUsersList = [];
            if (value && value.length >= 3) {
                this.getUsersListBySearch();
            }
        });
        this.currentUser = this.appState.getCurrentUser();
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.selectedExperiments?.currentValue && this.selectedExperiments[0]?.ExperimentVariant) {
            this.isVariantEnabled = true;
            this.addVariant.setValue(true);
        }
        if (changes.selectedExperiments?.currentValue && this.selectedExperiments[0]?.TaskID) {
            this.IsCopyCreativeTask = true;
            this.copyCreativeTask.setValue(false);
        }
    }

    public ngOnDestroy(): void {
        TasteEditorUtilClass.removeSubscriptions(this.appDataSubscriptions);
    }

    /**
     * Method to remove user from mat chip
     *
     * @memberof CopyExperimentToUserComponent
     */
    public removeUserFromChip(): void {
        this.users = [];
        this.searchControl.enable();
        this.isSelectorDisabled = true;
        this.selectedExpFolderName = EMPTY;
        this.isMyTaskMember = false;
        this.appDataService.resetSearchValues(this.searchControl, this.searchUserInput);
        this.copyCreativeTask.setValue(false);
    }

    /**
     * Method to select user from search drop down
     *
     * @param {MatAutocompleteSelectedEvent} event
     * @memberof CopyExperimentToUserComponent
     */
    public selectedUser(event: MatAutocompleteSelectedEvent): void {
        this.filteredUsersList = [];
        const userDetails = event.option.value;
        this.selectedExpFolderName = userDetails.globalUserID;
        this.users.push(userDetails);
        this.searchControl.disable();
        this.searchUserInput.nativeElement.value = EMPTY;
        this.isSelectorDisabled = this.selectedExpFolderName !== this.currentUser.globaluserid;
        this.copyToUserFullName = userDetails?.name;
        this.checkAvailableTask();
    }

    /**
     * Method to check available task details based on userID
     * @memberof CopyExperimentToUserComponent
     */
    public checkAvailableTask(): void {
        if (!this.selectedExperiments[0]?.TaskID) {
            return;
        }
        this.isMyTaskMember = true;
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.appDataService.get(this.appDataService.url.getTaskDetailsByTaskId, [this.selectedExperiments[0]?.TaskID]).subscribe({
            next: (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                if (!result) {
                    return;
                }
                const getTaskMembers = result[0]?.udfTaskAPIUsingTaskid[0]?.TaskMembers?.map((user) => user?.UserId);
                const checkCureentUserAvailability = getTaskMembers?.includes(this.selectedExpFolderName);
                this.isMyTaskMember = checkCureentUserAvailability;
                this.notTaskMemberMsg = `${this.copyToUserFullName} ${this.notCreativeTaskMember}`;
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to get list of users from api when start typing in search field
     *
     * @memberof CopyExperimentToUserComponent
     */
    public getUsersListBySearch(): void {
        const payload: UsersListSearchPayload = { searchText: this.searchControl.value };
        const isCurentUserExp = this.selectedExperiments[0].ExpCode.slice(0, 3).trim() === this.currentUser.initials;
        this.appDataSubscriptions.push(
            this.appDataService
                .post(`${this.appDataService.url.getUsersListSearch}?includeCurrentUser=${!isCurentUserExp}`, [], payload)
                .subscribe({
                    next: (result: Array<CooperatorUserModel>) => {
                        if (result && result.length > 0) {
                            this.filteredUsersList = this.removeDuplicateUserFromList(result);
                        } else {
                            this.toasterService.error(`${USER_FETCH_ERROR_TOASTER_MSG}`);
                        }
                    },
                    error: (error) => {
                        this.toasterService.error(USER_FETCH_ERROR_MSG);
                        this.logger.error(error);
                    },
                }),
        );
    }

    /**
     * Method to remove duplicate user from list
     *
     * @param {Array<CooperatorUserModel>} userList
     * @return {*}  {Array<CooperatorUserModel>}
     * @memberof CopyExperimentToUserComponent
     */
    public removeDuplicateUserFromList(userList: Array<CooperatorUserModel>): Array<CooperatorUserModel> {
        let staffList;
        if (this.users?.length > 0) {
            staffList = TasteEditorUtilClass.getUniqueListBy(this.users, "userID");
        }
        return staffList || userList;
    }

    /**
     * Method to close cooperator-access drawer
     *
     * @memberof CopyExperimentToUserComponent
     */
    public onCopyToUser(): void {
        const selectedExpIds = map(this.selectedExperiments, EXP_ID_OBJ_KEY);
        const isExpPublic = !this.appState.getPrivacyModelInfo();
        const selectedData = this.folderCollabGroupSelectorComponent.getSelectedData();

        const copyToUserPayload: CopyToUserPayload = {
            expIds: selectedExpIds,
            copyToGlobalUserId: this.users[0].globalUserID,
            copyToUserInitial: this.users[0].initials,
            userNotes: this.userNotesControl.value ?? EMPTY,
            IsPublic: isExpPublic,
            IsCopyAllNotes: false,
            ExpFolderID: this.isSelectorDisabled ? undefined : selectedData.ExpFolderID,
            CollaborationGroupID: this.isSelectorDisabled ? undefined : selectedData.CollaborationGroupID,
            AddVariant: this.addVariant.value,
            IscopyCreativeTask: this.copyCreativeTask.value,
        };
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.appDataSubscriptions.push(
            this.appDataService.post(this.appDataService.url.copyExperimentToUser, [], copyToUserPayload).subscribe({
                next: (result) => {
                    this.copyToUserResponseHandling(result);
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.toasterService.error(COPY_TO_USER_ERROR_MSG);
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method for handling copy to user response
     * @param result {any}
     * @memberof CopyExperimentToUserComponent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private copyToUserResponseHandling(result: any): void {
        if (result?.status === COPY_TO_USER_RESPONSE_STATUS.SUCCESS) {
            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            if (result?.response[0].isESResponseFlag) {
                this.toasterService.success(`${COPY_TO_USER_SUCCESS_MSG} ${this.users[0].firstName} ${this.users[0].surName}`);
            } else {
                this.toasterService.success(
                    `${COPY_TO_USER_SUCCESS_MSG} ${this.users[0].firstName} ${this.users[0].surName} , ${ES_RESPONSE.ES_RESPONSE_ERROR}`,
                );
                this.logger.info(
                    `${COPY_TO_USER_SUCCESS_MSG} ${this.users[0].firstName} ${this.users[0].surName} , ${ES_RESPONSE.ES_RESPONSE_ERROR}`,
                );
            }
            const refreshExperimentHeader = SharedExperimentUtil.createRefreshExperimentHeader(
                REFRESH_EXPERIMENT_HEADER.COPY_TO_USER_NOTES_UPDATE,
                {
                    ExperimentNote: [],
                },
            );
            this.appBroadCastService.onRefreshExperimentHeader(refreshExperimentHeader);
            this.onCancelDrawer();
        } else if (result?.status === COPY_TO_USER_RESPONSE_STATUS.ERROR) {
            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            if (result?.errorCode === COPY_TO_USER_RESPONSE_STATUS.NO_USER_PLANT_EXIST_ERROR_CODE) {
                this.experimentHelper.openConfirmationPopup(
                    USER_PLANT_ALLOCATION_ISSUE_SCENARIOS.COPY_TO_USER,
                    this.users[0]?.globalUserID,
                );
            } else {
                this.toasterService.error(
                    result?.errorCode === COPY_TO_USER_RESPONSE_STATUS.COPY_TO_USER_FAILED_ERROR_CODE
                        ? result?.errorMsg
                        : COPY_TO_USER_ERROR_MSG,
                );
            }
            this.removeUserFromChip();
        }
    }

    /**
     * Method to close cooperator-access drawer
     *
     * @memberof CopyExperimentToUserComponent
     */
    public onCancelDrawer(): void {
        this.removeUserFromChip();
        this.appDataService.resetSearchValues(this.searchControl, this.searchUserInput);
        this.userNotesControl.reset();
        this.copyToUserdrawerToggle.emit(false);
        this.isSelectorDisabled = true;
    }
}
