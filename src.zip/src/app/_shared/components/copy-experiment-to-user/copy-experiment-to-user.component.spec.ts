/* eslint-disable max-lines */
/* eslint-disable unicorn/no-null */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-empty-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MatAutocompleteModule, MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { ExperimentFolderSelectorComponent } from "@te-shared/ag-grid-components/experiment-folder-selector/experiment-folder-selector.component";
import { MatMenuModule } from "@angular/material/menu";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from "@angular/core";
import { of, throwError } from "rxjs";
import { MockAppStateService } from "../../../testing/mock-app.state.service";
import { SelectedRowDataModel } from "../../models/selected-row-data.model";
import { MockDialogReference } from "../../../testing/mock-dialog.reference";
import { ExperimentHelper } from "../../helpers/experiment-helper";
import { MockExperimentHelper } from "../../../testing/mock-experiment.helper";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { MockToastrService } from "../../../testing/mock-toastr.service";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { AppDataService, AppBroadCastService, AppStateService } from "../../../_services";
import { CopyExperimentToUserComponent } from "./copy-experiment-to-user.component";
import { FolderCollabGroupSelectorComponent } from "../folder-collab-group-selector/folder-collab-group-selector.component";
import { MatChipsModule } from "@angular/material/chips";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatOptionModule } from "@angular/material/core";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { MatInputModule } from "@angular/material/input";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

// eslint-disable-next-line max-lines-per-function
describe("CopyExperimentToUserComponent", () => {
    let component: CopyExperimentToUserComponent;
    let fixture: ComponentFixture<CopyExperimentToUserComponent>;
    const users = [
        {
            countryCode: "IN",
            department: "IT",
            email: "gulsar.peermohamed@iff.com",
            firstName: "Gulsar",
            globalUserID: "GXP2103",
            initials: "GXP",
            isActive: "1",
            isLocked: "0",
            regionName: "Greater Asia",
            searchTxtIdx: 0,
            surName: "Peer Mohamed",
            userId: 40_865,
        },
    ];
    const mockExperimentFolderSelectorComponent = {
        configAgGrid: () => {},
        getDefaultFolderID: () => {
            return 12_345_678;
        },
        folderSelector: {
            configAgGrid: () => {},
            gridApi: {
                getDisplayedRowAtIndex: () => {
                    return { data: { FolderID: 12_345_678 } };
                },
            },
        },
    } as unknown as FolderCollabGroupSelectorComponent;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CopyExperimentToUserComponent, FolderCollabGroupSelectorComponent, ExperimentFolderSelectorComponent],
            imports: [MatAutocompleteModule,
                HttpClientTestingModule,
                MatMenuModule,
                MatChipsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                MatFormFieldModule,
                MatOptionModule,
                MatSlideToggleModule,
                MatInputModule,
                BrowserAnimationsModule
            ],
            providers: [
                AppBroadCastService,
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                { provide: MatDialogRef, useClass: MockDialogReference },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
                    useValue: { open: () => {} },
                },
                { provide: ExperimentHelper, useClass: MockExperimentHelper },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CopyExperimentToUserComponent);
        component = fixture.componentInstance;
        component.selectedExperiments = [{ ExpCode: "" } as SelectedRowDataModel];
        component.folderCollabGroupSelectorComponent = mockExperimentFolderSelectorComponent;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on removeUserFromChip", () => {
        spyOn(component, "removeUserFromChip").and.callThrough();
        component.removeUserFromChip();
        expect(component.users.length).toEqual(0);
    });

    it("should call on getUsersListBySearch", () => {
        const cooperatorData = [
            {
                countryCode: "IN",
                department: "Developer",
                email: "AAAAA",
                firstName: "BBBBB",
                globalUserID: "AZA123",
                initials: "AB",
                isActive: "Active",
                isLocked: "No",
                regionName: "XXXXX",
                surName: "XXX",
                userId: 12_345,
            },
        ];
        component.searchControl.setValue("1234");
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of(cooperatorData));
        const spy = spyOn(component, "getUsersListBySearch").and.callThrough();
        component.getUsersListBySearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onCancelDrawer", () => {
        const spy = spyOn(component, "onCancelDrawer").and.callThrough();
        component.onCancelDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for selectedUser()", () => {
        const event: MatAutocompleteSelectedEvent = {
            option: {
                value: [
                    {
                        userId: 33_343,
                    },
                ],
            },
        } as MatAutocompleteSelectedEvent;
        const spy = spyOn(component, "selectedUser").and.callThrough();
        component.selectedUser(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for removeDuplicateUserFromList() with duplicate user", () => {
        component.users = [{ userID: 33_343 }];
        const data = [
            {
                countryCode: "IN",
                department: "department",
                email: "ranjithkumar.p@iff.com",
                firstName: "Ranjith",
                globalUserID: "RXP1926",
                initials: "RXP",
                isActive: "1",
                isLocked: "1",
                profilePicURL: "",
                regionName: "",
                surName: "kumar",
                userId: 30_979,
            },
        ];
        const spy = spyOn(component, "removeDuplicateUserFromList").and.callThrough();
        component.removeDuplicateUserFromList(data);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onCopyToUser()", () => {
        component.selectedExperiments = [
            {
                CreatedBy: 47_442,
                ExpCode: "AXA00002AA",
                ExpID: 12_348_048,
                ExpName: "Testing",
                checked: false,
                IsLocked: "0",
                IPC: 12_345,
                MappedFolderID: 12_345_678,
                TaskID: "dataloadsept051724",
            },
        ];
        component.users = users;
        const result = { status: "Success", response: [{ isESResponseFlag: true }] };
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of(result));
        component.userNotesControl.setValue("Testing Copy To User");
        const spy = spyOn(component, "onCopyToUser").and.callThrough();
        component.onCopyToUser();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnChanges", () => {
        component.selectedExperiments = [
            {
                CreatedBy: 47_442,
                ExpCode: "AXA00002AA",
                ExpID: 12_348_048,
                ExpName: "Testing",
                checked: false,
                IsLocked: "0",
                IPC: 12_345,
                MappedFolderID: 12_345_678,
                TaskID: "dataloadsept051724",
                ExperimentVariant: {
                    ChangeConditionID: 1,
                    ChangeDesc: "test",
                    CreatedBy: 47_333,
                    CreatedOn: new Date(),
                    ExpID: 12_347_077,
                    ExpVariantID: 50_073,
                    RootIPC: "00010076",
                    UpdatedBy: 47_333,
                    UpdatedOn: new Date(),
                    Remark: "test",
                },
            },
        ];
        const changes = {
            selectedExperiments: {
                currentValue: {
                    CreatedBy: 47_442,
                    ExpCode: "AXA00002AA",
                    ExpID: 12_348_048,
                    ExpName: "Testing",
                    checked: false,
                    IsLocked: "0",
                    IPC: 12_345,
                    MappedFolderID: 12_345_678,
                    TaskID: "dataloadsept051724",
                },
            },
        } as unknown as SimpleChanges;
        component.isVariantEnabled = true;
        component.addVariant.setValue(true);
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on error getUsersListBySearch", () => {
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "getUsersListBySearch").and.callThrough();
        component.getUsersListBySearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on error onCopyToUser()", () => {
        component.users = users;
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "onCopyToUser").and.callThrough();
        component.onCopyToUser();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on success when isESResponseFlag is false onCopyToUser()", () => {
        component.users = users;
        const result = { status: "Success", response: [{ isESResponseFlag: false }] };
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of(result));
        const spy = spyOn(component, "onCopyToUser").and.callThrough();
        component.onCopyToUser();
        expect(spy).toHaveBeenCalled();
    });

    it("should call when result is error onCopyToUser()", () => {
        component.users = users;
        const result = { status: "ERROR", errorMsg: "0" };
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of(result));
        const spy = spyOn(component, "onCopyToUser").and.callThrough();
        component.onCopyToUser();
        expect(spy).toHaveBeenCalled();
    });

    it("should call when result is error but errorMsg is 1 onCopyToUser()", () => {
        component.users = users;
        const result = { status: "ERROR", errorMsg: "1" };
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(of(result));
        const spy = spyOn(component, "onCopyToUser").and.callThrough();
        component.onCopyToUser();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on error checkAvailableTask()", () => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        component.selectedExperiments = [{ TaskID: "13806704" }] as any;
        const appDataService = TestBed.inject(AppDataService);
        spyOn(appDataService, "get").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "checkAvailableTask").and.callThrough();
        component.checkAvailableTask();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on checkAvailableTask() if TaskId is available", () => {
        component.isMyTaskMember = true;
        const result = [
            {
                udfTaskAPIUsingTaskid: [
                    {
                        TaskMembers: [
                            {
                                Role: "Task Lead",
                                TaskSplitUp: null,
                                TotalTimeSpent: null,
                                UserId: "AXB1235",
                                UserStatus: null,
                                name: "Joseph Pagano",
                            },
                            {
                                Role: "Task Lead",
                                TaskSplitUp: null,
                                TotalTimeSpent: null,
                                UserId: "BXC5678",
                                UserStatus: null,
                                name: "Joseph Pagano",
                            },
                        ],
                    },
                ],
            },
        ];
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        component.selectedExperiments = [{ TaskID: "13806704" }] as any;
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        spyOn(appDataService, "get").and.returnValue(of(result));
        spyOn(component, "checkAvailableTask").and.callThrough();
        component.checkAvailableTask();
        expect(component.isMyTaskMember).toBeFalse();
    });
});
