/* eslint-disable max-lines */
/* eslint-disable unicorn/no-null */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-empty-function */
/* eslint-disable max-lines-per-function */
/* eslint-disable import/no-unresolved */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog, MatDialogModule } from "@angular/material/dialog";
import { ExperimentEditorService } from "@te-experiment-editor/helpers/experiment-editor.service";
import { RecentlyUsedActionModel } from "@te-experiment-editor/models/recently-used.model";
import { SUBTypes } from "@te-shared/enums";
import { MockCreativereview } from "@te-testing/mock-creativereview-helper";
import { MockErrorFormatService } from "@te-testing/mock-error-format.service";
import { MockExperimentEditorService } from "@te-testing/mock-experiment-editor.service";
import { NGXLogger, CustomNGXLoggerService } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { of, throwError } from "rxjs";
import { CreativeReviewHelper } from "src/app/creative-review/helpers/creative-review-helper";
import { GridApiService } from "src/app/experiment-editor/helpers/grid-api-service";
import { MockAppDataService } from "src/app/testing/mock-app.data.service";
import { MockDialogReference } from "src/app/testing/mock-dialog.reference";
import { MockGridapiService } from "src/app/testing/mock-gridapi.service";
import { MockLoggerService, MockNGXLoggerHttpService } from "src/app/testing/mock-logger.service";
import { MockToastrService } from "src/app/testing/mock-toastr.service";
import { AppDataService, ErrorFormatService, WindowReferenceService, AppStateService, MatomoService } from "src/app/_services";
import { MockAppStateService } from "@te-testing/mock-app.state.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { MatMenuModule } from "@angular/material/menu";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { ExperimentFolderSelectorComponent } from "@te-shared/ag-grid-components/experiment-folder-selector/experiment-folder-selector.component";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { MasterDataHelper } from "@te-shared/master-data/helpers/master-data.helper";
import { MockMasterDataHelper } from "@te-testing/mock-master-data-helper";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { MockMatomoService } from "@te-testing/mock-matomo.service";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { MatInputModule } from "@angular/material/input";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { BaseColumnHelper } from "../base-column-layout/helper/base-column-helper";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import { FolderCollabGroupSelectorComponent } from "../folder-collab-group-selector/folder-collab-group-selector.component";
import { CreateExperimentFromExperimentComponent } from "./create-experiment-from-experiment.component";

describe("CreateExperimentFromExperimentComponent", () => {
    let component: CreateExperimentFromExperimentComponent;
    let fixture: ComponentFixture<CreateExperimentFromExperimentComponent>;
    const dialogReferenceStub = {
        afterClosed() {
            const product = {
                ipc: "1RR04333",
            };
            return of(product); // this can be whatever, esp handy if you actually care about the value returned
        },
    };

    const mockSearchResultData = {
        Division: ["FLAV"],
        IPC: "1RR04332",
        PlantAllocation: ["MXFL", "TEFL", "BAFL"],
        ProductType: "KEY",
        Taste: ["Berry"],
        // eslint-disable-next-line sonarjs/no-duplicate-string
        Technology: "FLAVOR LIQUIDS",
        Trustee: "MPP4430",
        TrusteeName: "Mauricio",
        audit: { status: "PASS", results: [], priority: 0 },
        description: "BERRY KEY",
    };

    const mockSearchResultDataOnePlant = {
        IPC: "1RR04333",
        ProductType: "LIQUID-CONTAINS ALCOHOL",
        description: "FOREST FRUITS",
        Trustee: "MPP4430",
        TrusteeName: "Mauricio Leonardo",
        Taste: ["Forest Fruit"],
        Technology: "FLAVOR LIQUIDS",
        PlantAllocation: ["BAFL"],
        Division: ["FLAV"],
        audit: {
            status: "PASS",
            results: [],
            priority: 0,
        },
    };

    const mockSearchResultDataNoPlant = {
        IPC: "10800113",
        ProductType: "LIQUID-NO ALCOHOL",
        description: "STRAWBERRY INTERMEDIATE",
        Trustee: "cvd2273",
        TrusteeName: "Coert",
        Taste: [],
        Technology: "FLAVOR LIQUIDS",
        PlantAllocation: [],
        Division: ["FLAV"],
        audit: {
            status: "FAIL",
            results: [
                {
                    result: "FAIL",
                    type: "FLAG",
                    description: "Product has  INHERITED RESTRICTED USE flag",
                    priority: 3,
                },
                {
                    result: "INFO",
                    type: "CREATIVE CATALOG",
                    description: "NOT 100%",
                    priority: 1,
                },
            ],
            priority: 3,
        },
    };

    const mockExperimentFolderSelectorComponent = {
        configAgGrid: () => {},
        getSelectedData: () => {},
        allExpParentFolder: () => {},
        folderSelector: {
            configAgGrid: () => {},
        },
    } as unknown as FolderCollabGroupSelectorComponent;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CreateExperimentFromExperimentComponent, FolderCollabGroupSelectorComponent, ExperimentFolderSelectorComponent],
            providers: [
                UntypedFormBuilder,
                WindowReferenceService,
                SecurityHelper,
                { provide: CreativeReviewHelper, useClass: MockCreativereview },
                { provide: MatDialogRef, useClass: MockDialogReference },
                { provide: MAT_DIALOG_DATA, useValue: {} },
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: ExperimentEditorService, useClass: MockExperimentEditorService },
                {
                    provide: ErrorFormatService,
                    useClass: MockErrorFormatService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: CustomNGXLoggerService,
                    useClass: MockNGXLoggerHttpService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: ExperimentHelper, useClass: MockExperimentHelper },
                BaseColumnHelper,
                SpaceTrimPipe,
                {
                    provide: MasterDataHelper,
                    useClass: MockMasterDataHelper,
                },
                AppBroadCastService,
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
            ],
            imports: [
                HttpClientTestingModule,
                MatMenuModule,
                MatAutocompleteModule,
                MatDialogModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                BrowserAnimationsModule,
                MatFormFieldModule,
                MatProgressSpinnerModule,
                MatSlideToggleModule,
                MatInputModule,
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();

        fixture = TestBed.createComponent(CreateExperimentFromExperimentComponent);
        component = fixture.componentInstance;
        component.selector = mockExperimentFolderSelectorComponent;

        fixture.detectChanges();
    }));

    it("should call createExpFromExpForm", () => {
        const spy = spyOn(component, "createExpFromExpForm").and.callThrough();
        component.createExpFromExpForm();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onNoOfCopiesChange() if maxCopyLength is 1", () => {
        component.createExperimentFrom = "From Experiment";
        component.maxCopyLength = 1;
        const event = {
            target: {
                value: "4",
            },
        };
        const spy = spyOn(component, "onNoOfCopiesChange").and.callThrough();
        component.onNoOfCopiesChange(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onNoOfCopiesChange() if value length is greater than 1", () => {
        component.maxCopyLength = 1;
        const event = {
            target: {
                value: "22",
            },
        };
        spyOn(component, "onNoOfCopiesChange").and.callThrough();
        component.onNoOfCopiesChange(event);
        expect(component.expFromExperimentForm.controls.NumberOfCopies.value).toBe(
            component.expFromExperimentForm.controls.NumberOfCopies.value.slice(0, component.maxCopyLength),
        );
    });

    it("should resolve for onNoOfCopiesChange() if value is greater than 5", () => {
        component.maxCopyLength = 1;
        const event = {
            target: {
                value: "6",
            },
        };
        spyOn(component, "onNoOfCopiesChange").and.callThrough();
        component.onNoOfCopiesChange(event);
        expect(component.expFromExperimentForm.controls.NumberOfCopies.value).toBe("");
    });

    it("should call oncreate while creating", () => {
        component.createExperimentFrom = "From Product";
        const spy = spyOn(component, "onCreate").and.callThrough();
        component.onCreate();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for keyUpFunc()", () => {
        spyOn(component, "keyUpFunc").and.callThrough();
        component.keyUpFunc();
        expect(component.applyDisable).toBe(false);
    });

    it("should resolve for keyUpFunc() if no.of copies is empty", () => {
        component.expFromExperimentForm.controls.NumberOfCopies.setValue("-");
        spyOn(component, "keyUpFunc").and.callThrough();
        component.keyUpFunc();
        expect(component.applyDisable).toBe(true);
    });

    it("should resolve for keyUpFunc() if no.of copies is 0", () => {
        component.expFromExperimentForm.controls.NumberOfCopies.setValue(0);
        spyOn(component, "keyUpFunc").and.callThrough();
        component.keyUpFunc();
        expect(component.applyDisable).toBe(true);
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should invoke resetIpcTextBoxParameters", () => {
        const spy = spyOn(component, "resetIpcTextBoxParameters").and.callThrough();
        component.resetIpcTextBoxParameters();
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke onOpenRecentUsedPopup", () => {
        const spy = spyOn(component, "onOpenRecentUsedPopup").and.callThrough();
        const data: RecentlyUsedActionModel = {
            subType: SUBTypes.PRODUCT,
            product: {
                ipc: "50010011",
            },
        } as RecentlyUsedActionModel;
        const service = TestBed.inject(ExperimentEditorService);
        spyOn(service, "handleRecentlyUsedPopup").and.returnValue(of(data));
        component.onOpenRecentUsedPopup();
        expect(spy).toHaveBeenCalled();
    });

    it("should invoke onOpenSalesNumber", () => {
        spyOn(component, "onOpenSalesNumber").and.callThrough();
        component.expFromExperimentForm.patchValue({ ipc: "11R04332" });
        component.onOpenSalesNumber();
        expect(component.expFromExperimentForm.value.ipc).toMatch("1RR04333");
    });

    it("should invoke onOpenSalesNumber same ipc selected", () => {
        spyOn(component, "onOpenSalesNumber").and.callThrough();
        component.expFromExperimentForm.patchValue({ ipc: "1RR04333" });
        component.onOpenSalesNumber();
        expect(component.expFromExperimentForm.value.ipc).toBe("1RR04333");
    });

    it("should call on onFocusOutEvent", () => {
        component.ipcInvalid = true;
        spyOn(component, "resetIpcTextBoxParameters").and.returnValue();
        const spy = spyOn(component, "onFocusOutEvent").and.callThrough();
        component.onFocusOutEvent();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onSetCopyNotes", () => {
        component.version = true;
        const spy = spyOn(component, "onSetCopyNotes").and.callThrough();
        component.onSetCopyNotes(true);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ipcValidation", () => {
        component.ipcSearchResult = {
            ErrorCode: 0,
            // eslint-disable-next-line sonarjs/no-duplicate-string
            ErrorDescription: "AMBROPUR NN I/P DRAG 10% DEP",
            // eslint-disable-next-line sonarjs/no-duplicate-string
            ErrorMessage: "You do not have perimission to view BOM: 00010390. BOM trustee is GLOBALFAD",
        };
        component.isErrorIPC = true;
        const service = TestBed.inject(AppDataService);
        component.ipcSearchResult = mockSearchResultData;
        spyOn(service, "post").and.returnValue(of(component.ipcSearchResult));
        const spy = spyOn(component, "ipcValidation").and.callThrough();
        component.ipcValidation();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ipcValidation for single plant", () => {
        component.ipcSearchResult = {
            ErrorCode: 0,
            ErrorDescription: "AMBROPUR NN I/P DRAG 10% DEP",
            ErrorMessage: "You do not have perimission to view BOM: 00010390. BOM trustee is GLOBALFAD",
        };
        component.isErrorIPC = true;
        const service = TestBed.inject(AppDataService);
        component.ipcSearchResult = mockSearchResultDataOnePlant;
        spyOn(service, "post").and.returnValue(of(component.ipcSearchResult));
        const spy = spyOn(component, "ipcValidation").and.callThrough();
        component.ipcValidation();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ipcValidation for no plants", () => {
        component.ipcSearchResult = {
            ErrorCode: 0,
            ErrorDescription: "AMBROPUR NN I/P DRAG 10% DEP",
            ErrorMessage: "You do not have perimission to view BOM: 00010390. BOM trustee is GLOBALFAD",
        };
        component.isErrorIPC = true;
        const service = TestBed.inject(AppDataService);
        component.ipcSearchResult = mockSearchResultDataNoPlant;
        spyOn(service, "post").and.returnValue(of(component.ipcSearchResult));
        const spy = spyOn(component, "ipcValidation").and.callThrough();
        component.ipcValidation();
        expect(spy).toHaveBeenCalled();
    });

    it("should call for error onOpenRecentUsedPopup()", () => {
        const service = TestBed.inject(ExperimentEditorService);
        spyOn(service, "handleRecentlyUsedPopup").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "onOpenRecentUsedPopup").and.callThrough();
        component.onOpenRecentUsedPopup();
        expect(spy).toHaveBeenCalled();
    });

    it("should call for onOpenProductSearch()", () => {
        const spy = spyOn(component, "onOpenProductSearch").and.callThrough();
        component.onOpenProductSearch();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for getDefaultData() when checkAndFetchDefaultData throws error", () => {
        const masterDataHelper = TestBed.inject(MasterDataHelper);
        spyOn(masterDataHelper, "checkAndFetchDefaultData").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "getDefaultData").and.callThrough();
        component.getDefaultData();
        expect(spy).toHaveBeenCalled();
    });

    it("should call oncreate while creating from experiment", () => {
        component.createExperimentFrom = "From Experiment";
        const spy = spyOn(component, "onCreate").and.callThrough();
        component.onCreate();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on error part ipcValidation", () => {
        component.isErrorIPC = false;
        const service = TestBed.inject(AppDataService);
        spyOn(service, "post").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "ipcValidation").and.callThrough();
        component.ipcValidation();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on error checkAvailableTask()", () => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        component.validateObject = { taskID: "13806704" } as any;
        const appDataService = TestBed.inject(AppDataService);
        spyOn(appDataService, "get").and.returnValue(throwError(() => {}));
        const spy = spyOn(component, "checkAvailableTask").and.callThrough();
        component.checkAvailableTask();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on checkAvailableTask() if TaskId is available", () => {
        const result = [
            {
                udfTaskAPIUsingTaskid: [
                    {
                        TaskMembers: [
                            {
                                Role: "Task Lead",
                                TaskSplitUp: null,
                                TotalTimeSpent: null,
                                UserId: "AXB1235",
                                UserStatus: null,
                                name: "Joseph Pagano",
                            },
                            {
                                Role: "Task Lead",
                                TaskSplitUp: null,
                                TotalTimeSpent: null,
                                UserId: "BXC5678",
                                UserStatus: null,
                                name: "Joseph Pagano",
                            },
                        ],
                    },
                ],
            },
        ];
        component.isMyTaskMember = true;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        component.validateObject = { taskID: "13806704" } as any;
        const appDataService: AppDataService = TestBed.inject(AppDataService);
        spyOn(appDataService, "get").and.returnValue(of(result));
        spyOn(component, "checkAvailableTask").and.callThrough();
        component.checkAvailableTask();
        expect(component.isMyTaskMember).toBeFalse();
    });
});
