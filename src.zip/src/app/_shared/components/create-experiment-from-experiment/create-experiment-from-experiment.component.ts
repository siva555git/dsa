/* eslint-disable max-lines */
import { Component, Inject, OnInit, ViewChild, OnDestroy } from "@angular/core";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { SalesProductSearchComponent } from "@te-experiment-editor/quick-search/sales-product-search/sales-product-search.component";
import { CollaborationGroupListModel, CurrentUser } from "@te-shared/models/user-collaboration-group.model";
import { NGXLogger } from "ngx-logger";
import { filter } from "rxjs/operators";
import { Subscription } from "rxjs";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { SearchType } from "@te-experiment-editor/models/experiment-editor.model";
import { BomSearchDialogDataModel } from "@te-shared/models/dialog.model";
import { FacilitiesModel } from "@te-shared/models/facilities-model";
import { MasterDataHelper } from "@te-shared/master-data/helpers/master-data.helper";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { EMPTY, LOADING } from "../../../app.constant";
import { RECENTLY_USED_POPUP_ERROR } from "../../../experiment-editor/constants/experiment-editor.constant";
import { ExperimentEditorService } from "../../../experiment-editor/helpers/experiment-editor.service";
import { RecentlyUsedActionModel, RecentlyUsedParametersModel } from "../../../experiment-editor/models/recently-used.model";
// eslint-disable-next-line import/no-cycle
import { ExperimentListComponent } from "../../../experiment/experiment-list/experiment-list.component";
import { ErrorFormatService, MatomoService } from "../../../_services/app-common";
import { AppDataService } from "../../../_services/app-data/app.data.service";
import {
    COMMON_DIALOG_SALES_PRODUCT,
    CREATE_EXPERIMENT_FROM,
    KEYBOARD_KEYS,
    RECENTLY_USED_ACCESS_LIST,
    MAX_EXPORPRO_OPEN_LENGTH,
    NO_CREATIVE_TASK,
    NOT_MEMBER_FOR_CREATIVE_TASK,
    MASTER_DATA,
    PICK_IPC_POPUP,
} from "../../constants/common.constant";
import { EXPERIMENT_TYPE_CONTEXT_MENU } from "../../constants/context-menu.constant";
import { MatomoAction, MatomoCategory, MatomoLabel, SUBTypes } from "../../enums";
import { CreateExpFromExpProdPayload as CreateExpFromExpProductionPayload } from "../../models/create-experiment.model";
import { FolderCollabGroupSelectorComponent } from "../folder-collab-group-selector/folder-collab-group-selector.component";
// eslint-disable-next-line import/no-cycle
import { BomSearchComponent } from "../bom-search/bom-search.component";
import { BaseColumnHelper } from "../base-column-layout/helper/base-column-helper";

@Component({
    selector: "app-create-experiment-from-experiment",
    templateUrl: "./create-experiment-from-experiment.component.html",
})
export class CreateExperimentFromExperimentComponent implements OnInit, OnDestroy {
    public version;

    public maxCopyLength = 1;

    public isVariantChecked = false;

    public expFromExperimentForm: UntypedFormGroup = new UntypedFormGroup({});

    public applyDisable: boolean;

    public createExperimentFrom: string;

    public detailsLable = false;

    public ipc: string;

    public isErrorIPC = false;

    public showLoader = false;

    public ipcSearchResult;

    public experimentTypes = EXPERIMENT_TYPE_CONTEXT_MENU;

    public ipcInvalid = false;

    public isCopyNotesDisabled = false;

    public isCopyCreativeTaskDisabled = false;

    public expFromExpFormConstants = CREATE_EXPERIMENT_FROM;

    private subscriptionList: Subscription[] = [];

    public maxWSOpenExpLength = MAX_EXPORPRO_OPEN_LENGTH;

    public isVariantDisabled: boolean;

    public isMyTaskMember: boolean;

    public loggedInUser: CurrentUser;

    public noCreativeTask = NO_CREATIVE_TASK;

    public notCreativeTaskMember = NOT_MEMBER_FOR_CREATIVE_TASK;

    public notTaskMemberMsg: string;

    public plantsAndSources = [];

    public noPlantWarningStatus = false;

    public moreThanOnePlantWarningStatus = false;

    public productPlants = [];

    @ViewChild("selector") selector: FolderCollabGroupSelectorComponent;

    public facilities: FacilitiesModel[];

    public selectedplantSource = "";

    constructor(
        private readonly formBuilder: UntypedFormBuilder,
        private readonly dialogReference: MatDialogRef<ExperimentListComponent>,
        private readonly logger: NGXLogger,
        private readonly appDataService: AppDataService,
        private masterDataHelper: MasterDataHelper,
        private readonly baseColumnHelper: BaseColumnHelper,
        private readonly experimentEditorService: ExperimentEditorService,
        private readonly errorFormatService: ErrorFormatService,
        private readonly securityHelper: SecurityHelper,
        private readonly dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA)
        public validateObject: {
            version: boolean;
            createExperimentFrom: string;
            userCollaborationGroupList: CollaborationGroupListModel[];
            selectedFolderID: number;
            selectedCollabGrpID: number;
            taskID: string;
            isOtherUserExpOrProduct: boolean;
        },
        private readonly appState: AppStateService,
        private readonly appBroadCastService: AppBroadCastService,
        private matomoService: MatomoService,
    ) {
        if (this.validateObject) {
            this.version = this.validateObject.version;
            this.createExperimentFrom = this.validateObject.createExperimentFrom;
            this.expFromExperimentForm.patchValue({
                AddVariant: this.createExperimentFrom !== this.experimentTypes.FROM_EXPERIMENT,
            });
            this.isCopyCreativeTaskDisabled = !!(this.validateObject.taskID === null || this.validateObject.taskID === undefined);
        }
    }

    ngOnInit(): void {
        this.checkAvailableTask();
        this.expFromExperimentForm = this.createExpFromExpForm();
        this.baseColumnHelper.getSavedColumnLayoutList();
        this.baseColumnHelper.getLastUsedColumnLayoutForProductSearch();
        const isCopyNotes = this.createExperimentFrom !== this.experimentTypes.FROM_PRODUCT;
        this.isVariantChecked = this.createExperimentFrom === this.experimentTypes.FROM_EXPERIMENT;
        this.onSetCopyNotes(isCopyNotes);
        this.subscriptionList.push(
            this.dialogReference
                .keydownEvents()
                .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.dialogReference.close();
                }),
        );
        this.getDefaultData();
    }

    ngOnDestroy(): void {
        TasteEditorUtilClass.removeSubscriptions(this.subscriptionList);
    }

    /**
     * Method used to form the form group of create experiemnt from experiment
     * @memberof CreateExperimentFromExperimentComponent
     */
    public createExpFromExpForm = (): UntypedFormGroup => {
        return this.formBuilder.group({
            IsVersion: this.version,
            NumberOfCopies: new UntypedFormControl(this.maxCopyLength, [Validators.required]),
            ipc: this.ipc,
            selectedPlant: new UntypedFormControl(EMPTY),
            AddVariant: new UntypedFormControl(true),
            IsCopyAllNotes: new UntypedFormControl(true),
            IsCopyCreativeTask:
                this.validateObject.taskID && this.isMyTaskMember && !this.validateObject.isOtherUserExpOrProduct
                    ? new UntypedFormControl(true)
                    : new UntypedFormControl(false),
        });
    };

    /**
     * Method to trigger when doing the toggle
     * @memberof CreateExperimentFromExperimentComponent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public onNoOfCopiesChange(event: any): void {
        const { value } = event.target;
        if (value.length > this.maxCopyLength) {
            this.expFromExperimentForm.controls.NumberOfCopies.setValue(value.slice(0, this.maxCopyLength));
        } else if (value > this.maxWSOpenExpLength) {
            this.expFromExperimentForm.controls.NumberOfCopies.setValue("");
        }
        const numberOfCopies = Number(this.expFromExperimentForm.get(this.expFromExpFormConstants.NO_OF_COPIES).value);
        if (this.createExperimentFrom === this.experimentTypes.FROM_EXPERIMENT) {
            this.expFromExperimentForm.patchValue({ AddVariant: numberOfCopies === 1 });
        } else {
            this.expFromExperimentForm.patchValue({
                AddVariant: numberOfCopies === 1 ? this.expFromExperimentForm.value.AddVariant : false,
            });
        }
        this.isVariantDisabled = numberOfCopies !== this.maxCopyLength;
    }

    /**
     * Method to trigger when the user Copy the Notes
     * @memberof CreateExperimentFromExperimentComponent
     */
    public onSetCopyNotes(isChecked: boolean): void {
        if (isChecked && this.version && !this.validateObject.isOtherUserExpOrProduct) {
            this.expFromExperimentForm.get(this.expFromExpFormConstants.IS_COPY_ALL_NOTES).patchValue(true);
        } else if (this.validateObject.isOtherUserExpOrProduct) {
            this.expFromExperimentForm.get(this.expFromExpFormConstants.IS_COPY_ALL_NOTES).patchValue(false);
            this.isCopyNotesDisabled = true;
        } else {
            this.isCopyNotesDisabled = false;
        }
        if (isChecked && this.isMyTaskMember && this.validateObject?.taskID && !this.validateObject.isOtherUserExpOrProduct) {
            this.expFromExperimentForm.patchValue({ IsCopyCreativeTask: true });
        } else {
            this.expFromExperimentForm.patchValue({ IsCopyCreativeTask: false });
        }
    }

    /**
     * Method to trigger when on creating the experiment
     * @memberof CreateExperimentFromExperimentComponent
     */
    public onCreate(): void {
        let fromExpFromProductPayload: CreateExpFromExpProductionPayload;
        const noOfCopiesCheck = Number(this.expFromExperimentForm.value.NumberOfCopies);
        if (this.createExperimentFrom === this.experimentTypes.FROM_PRODUCT) {
            fromExpFromProductPayload = {
                ipc: this.expFromExperimentForm.value.ipc,
                NumberOfCopies: this.expFromExperimentForm.value.NumberOfCopies,
                AddVariant: this.expFromExperimentForm.value.AddVariant,
                ipcDescription: this.ipcSearchResult?.description ?? EMPTY,
                IsCopyAllNotes: false,
                selectedPlant: this.expFromExperimentForm.value.selectedPlant,
            };
        } else if (this.expFromExperimentForm.valid && noOfCopiesCheck !== 0) {
            fromExpFromProductPayload = {
                IsVersion: this.expFromExperimentForm.value.IsVersion,
                NumberOfCopies: this.expFromExperimentForm.value.NumberOfCopies,
                AddVariant: this.expFromExperimentForm.value.AddVariant,
                IsCopyAllNotes: this.isCopyNotesDisabled ? false : this.expFromExperimentForm.value.IsCopyAllNotes,
                IsCopyCreativeTask: this.isCopyCreativeTaskDisabled ? false : this.expFromExperimentForm.value.IsCopyCreativeTask,
            };
        }
        Object.assign(fromExpFromProductPayload, this.selector.getSelectedData());
        this.dialogReference.close(fromExpFromProductPayload);
    }

    /**
     * Method to trigger when user key ups
     * @memberof CreateExperimentFromExperimentComponent
     */
    public keyUpFunc(): void {
        this.applyDisable =
            this.expFromExperimentForm.value.NumberOfCopies === "-" ||
            this.expFromExperimentForm.value.NumberOfCopies === null ||
            this.expFromExperimentForm.value.NumberOfCopies.length === 0 ||
            this.expFromExperimentForm.value.NumberOfCopies === 0 ||
            this.expFromExperimentForm.value.NumberOfCopies === "0";
    }

    /**
     * Method to trigger the IPC validation API
     * @memberof CreateExperimentFromExperimentComponent
     */
    public onFocusOutEvent(): void {
        if (this.expFromExperimentForm.value?.ipc?.length === 8) {
            this.ipcInvalid = false;
            this.showLoader = true;
            this.ipcValidation();
            return;
        }
        this.ipcInvalid = true;
        this.resetIpcTextBoxParameters();
    }

    /**
     * Method to reset the IPC textbox
     *
     * @memberof CreateExperimentFromExperimentComponent
     */
    public resetIpcTextBoxParameters(): void {
        this.showLoader = false;
        this.ipcSearchResult = [];
        this.isErrorIPC = false;
        this.detailsLable = false;
        this.noPlantWarningStatus = false;
        this.moreThanOnePlantWarningStatus = false;
        this.expFromExperimentForm.controls.selectedPlant.setValue("");
    }

    /**
     * Method to validate the IPC and return details
     *
     * @param {number} this.expFromExperimentForm.value.ipc
     * @memberof CreateExperimentFromExperimentComponent
     */
    public ipcValidation(): void {
        this.ipcInvalid = false;
        const ipcSearchPayload = {
            ipc: this.expFromExperimentForm.value.ipc,
            isEncapsulationUser: this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION),
        };
        this.subscriptionList.push(
            this.appDataService.post(this.appDataService.url.getExperimentFromProductDetails, [], ipcSearchPayload).subscribe({
                next: (result) => {
                    this.ipcSearchResult = result;
                    if (!result.ErrorMessage) {
                        const productAllocation = this.ipcSearchResult.PlantAllocation;
                        this.productPlants = this.facilities.filter((facility) =>
                            this.plantsAndSources.some((plant) => plant.PlantID === facility.facilitycode),
                        );
                        const productAllocatedPlants = this.productPlants.filter((plant) => productAllocation.includes(plant.costbookcode));
                        if (productAllocation.length === 0 || productAllocatedPlants.length === 0) {
                            this.noPlantWarningStatus = true;
                        } else if (productAllocatedPlants.length === 1) {
                            this.expFromExperimentForm.controls.selectedPlant.setValue(productAllocatedPlants[0].facilitycode);
                        }
                        if (productAllocatedPlants.length >= 2) {
                            this.moreThanOnePlantWarningStatus = true;
                        }
                    }
                    this.showLoader = false;
                    this.isErrorIPC = !!result.ErrorMessage;
                },
                error: (error) => {
                    this.isErrorIPC = false;
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to open the recently used popup and get the list
     *
     * @memberof CreateExperimentFromExperimentComponent
     */
    public onOpenRecentUsedPopup(): void {
        const selectedDataParameters: RecentlyUsedParametersModel = {
            type: RECENTLY_USED_ACCESS_LIST.CREATE_EXPERIMENT_FROM_PRODUCT,
        };
        this.subscriptionList.push(
            this.experimentEditorService.handleRecentlyUsedPopup(undefined, selectedDataParameters).subscribe({
                next: (result: RecentlyUsedActionModel) => {
                    if (result && result.subType === SUBTypes.PRODUCT && this.expFromExperimentForm.value.ipc !== result.product?.ipc) {
                        this.expFromExperimentForm.patchValue({ ipc: result.product?.ipc });
                        this.resetIpcTextBoxParameters();
                        this.onFocusOutEvent();
                    }
                },
                error: (error) => {
                    this.errorFormatService.logFormattedError(RECENTLY_USED_POPUP_ERROR, error);
                },
            }),
        );
    }

    /**
     * Method to open the popup to search product by sales number
     *
     * @memberof CreateExperimentFromExperimentComponent
     */
    public onOpenSalesNumber(): void {
        const salesInfo = COMMON_DIALOG_SALES_PRODUCT;
        salesInfo.data = {
            type: RECENTLY_USED_ACCESS_LIST.CREATE_EXPERIMENT_FROM_PRODUCT,
        };
        const dialogReference = this.dialog.open(SalesProductSearchComponent, salesInfo);
        this.subscriptionList.push(
            dialogReference.afterClosed().subscribe((product) => {
                if (product && this.expFromExperimentForm.value.ipc !== product?.ipc) {
                    this.expFromExperimentForm.patchValue({ ipc: product?.ipc });
                    this.resetIpcTextBoxParameters();
                    this.onFocusOutEvent();
                }
            }),
        );
    }

    /**
     * Method to get the default data
     * @memberof CreateExperimentFromExperimentComponent
     */

    public getDefaultData(): void {
        this.masterDataHelper.checkAndFetchDefaultData([MASTER_DATA.FACILITIES, MASTER_DATA.PLANT_SOURCE]).subscribe({
            next: (result) => {
                this.facilities = result[MASTER_DATA.FACILITIES];
                this.plantsAndSources = result[MASTER_DATA.PLANT_SOURCE];
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to open the popup to search product by sales number
     *
     * @memberof CreateExperimentFromExperimentComponent
     */
    public onOpenProductSearch(): void {
        const dialogData: BomSearchDialogDataModel = {
            type: SearchType.pickIpc,
            openedExperimentOrProduct: [],
            fromLandingPage: true,
        };
        dialogData.facility = this.facilities;
        const dialogOptions = PICK_IPC_POPUP;
        dialogOptions.data = dialogData;
        const dialogReference = this.dialog.open(BomSearchComponent, dialogOptions);
        this.subscriptionList.push(
            dialogReference.afterClosed().subscribe((product) => {
                if (product && this.expFromExperimentForm.value.ipc !== product?.code) {
                    this.expFromExperimentForm.patchValue({ ipc: product?.code });
                    this.resetIpcTextBoxParameters();
                    this.onFocusOutEvent();
                    this.matomoService.trackEvent(MatomoCategory.EXPERIMENTS, MatomoAction.SELECT, MatomoLabel.SELECTED_IPC_FROM_PICKIPC);
                }
            }),
        );
        this.matomoService.trackEvent(MatomoCategory.EXPERIMENTS, MatomoAction.VIEW_PAGE, MatomoLabel.CREATE_EXPERIMENT_PICKIPC_CLICK);
    }

    /**
     * Method to check available task details based on userID
     * @memberof CreateExperimentFromExperimentComponent
     */
    public checkAvailableTask(): void {
        this.loggedInUser = this.appState.getCurrentUser();
        if (this.validateObject?.taskID) {
            this.isMyTaskMember = true;
            this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
            this.appDataService.get(this.appDataService.url.getTaskDetailsByTaskId, [this.validateObject?.taskID]).subscribe({
                next: (result) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (!result) {
                        return;
                    }
                    const getTaskMembers = result[0]?.udfTaskAPIUsingTaskid[0]?.TaskMembers?.map((user) => user?.UserId);
                    const checkCureentUserAvailability = getTaskMembers?.includes(this.loggedInUser?.globaluserid);
                    this.isMyTaskMember = checkCureentUserAvailability;
                    this.expFromExperimentForm.patchValue({
                        IsCopyCreativeTask: this.validateObject.isOtherUserExpOrProduct ? false : this.isMyTaskMember,
                    });
                    this.notTaskMemberMsg = `${this.loggedInUser?.fullname} ${this.notCreativeTaskMember}`;
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            });
        } else {
            this.expFromExperimentForm.patchValue({ IsCopyCreativeTask: false });
        }
    }
}
