import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { NgForm, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ExperimentEditorComponent } from "@te-experiment-editor/experiment-editor.component";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { FMP_CONST, KEYBOARD_KEYS, LOCKED_BY_STATUS } from "@te-shared/constants";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { TasteEditorUtilClass } from "@te-shared/helpers/taste-editor-utils";
import { ExperimentsModel } from "@te-shared/models/experiment-bom.model";
import { FMPDialogData, FMPResponseData, MaxDosageResponse } from "@te-shared/models/experiments.model";
import { filter } from "rxjs/operators";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { Subscription } from "rxjs";
import { isEmpty } from "lodash";
import { EMPTY, LOADING } from "../../../app.constant";
import { CreativeReviewHelper } from "../../../creative-review/helpers/creative-review-helper";

@Component({
    selector: "app-fmp-review",
    templateUrl: "./fmp-review.component.html",
})
export class FmpReviewComponent implements OnInit {
    public activeExperiment: ExperimentsModel;

    public fmpForm: UntypedFormGroup;

    public lockedByConst = LOCKED_BY_STATUS;

    public reviewMessageData = FMP_CONST.PASS;

    public requestPayloadForWithDosage;

    public fmpConstant = FMP_CONST;

    public canShowReviewMessage = false;

    public canDisableDosage = false;

    public canShowInvalidReviewMessage = false;

    public reviewInvalidMessage: string;

    public initalDosageValue: number;

    public fmpResponse: FMPResponseData;

    public maxDosageResponse: MaxDosageResponse;

    public moreDetailStatus = false;

    private subscriptionList: Subscription[] = [];

    @ViewChild("triggerForm", { static: false })
    triggerForm: NgForm;

    constructor(
        private readonly formBuilder: UntypedFormBuilder,
        private readonly dialogReference: MatDialogRef<ExperimentEditorComponent>,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly logger: NGXLogger,
        private readonly toasterService: ToastrService,
        private readonly experimentHelper: ExperimentHelper,
        @Inject(MAT_DIALOG_DATA) public data: FMPDialogData,
    ) {}

    ngOnInit(): void {
        this.activeExperiment = this.data?.experiment;
        this.fmpForm = this.createFmpReviewForm();
        this.onResettingInfoFlags();
        this.subscriptionList.push(
            this.dialogReference
                .keydownEvents()
                .pipe(filter((keyDownEvent) => keyDownEvent.key === KEYBOARD_KEYS.ESCAPE))
                .subscribe(() => {
                    this.dialogReference.close();
                }),
        );
        this.fetchingMaxPrediction();
    }

    ngOnDestroy(): void {
        TasteEditorUtilClass.removeSubscriptions(this.subscriptionList);
    }

    /**
     * Method to trigger the form on enter key press
     *
     * @memberof FmpReviewComponent
     */
    public triggerSubmit() {
        if (Number(this.fmpForm.value.Dosage) === 0) {
            this.fmpForm.patchValue({ Dosage: "" });
            this.triggerForm.form.controls.Dosage.markAsTouched();
            return;
        }
        if (this.triggerForm.valid) {
            const inputValue = CreativeReviewHelper.validateDosage({ target: { value: this.fmpForm.value.Dosage } });
            this.fmpForm.patchValue({ Dosage: inputValue.target.value });
            this.triggerForm.ngSubmit.emit();
        }
    }

    /**
     * Method to fetch the max predication value
     *
     * @return {*}
     * @memberof FmpReviewComponent
     */
    public fetchingMaxPrediction() {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        if (this.activeExperiment?.ExpID === null) {
            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            this.showErrorMessage(FMP_CONST.PRODUCT_ERROR);
            return;
        }
        const payload = { ExpCode: this.activeExperiment?.ExpCode };
        this.subscriptionList.push(
            this.experimentHelper.getFMPMaxDosage(this.activeExperiment?.ExpID.toString(), payload, FMP_CONST.VERSION.V2).subscribe({
                next: (response) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (response) {
                        this.maxDosageResponse = response;
                        if (!this.maxDosageResponse?.maxpassdosage || this.maxDosageResponse?.maxpassdosage === null) {
                            if (
                                this.maxDosageResponse?.message &&
                                Array.isArray(this.maxDosageResponse?.message) &&
                                this.maxDosageResponse?.message?.length > 0
                            ) {
                                this.maxDosageResponse.errormessage = this.maxDosageResponse?.message[0]?.message;
                            } else if (!this.onValidatingResponse(this.maxDosageResponse, FMP_CONST.FMP_TYPE.MAX_DOSAGE)) {
                                this.maxDosageResponse.errormessage =
                                    this.maxDosageResponse.errormessage.charAt(0).toUpperCase() +
                                    this.maxDosageResponse.errormessage.slice(1);
                            }
                        }
                        this.requestPayloadForWithDosage = response?.requestPayload;
                    }
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.maxDosageResponse = { errormessage: FMP_CONST.ERROR };
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to reset the error and display flag
     *
     * @private
     * @memberof FmpReviewComponent
     */
    private onResettingInfoFlags(): void {
        this.fmpForm.controls.Dosage.valueChanges.subscribe((value) => {
            if (value?.length === 0 || (this.initalDosageValue !== undefined && Number(this.initalDosageValue) !== Number(value))) {
                this.resettingFlags();
            }
        });
    }

    /**
     * Method to reset the flags
     *
     * @private
     * @memberof FmpReviewComponent
     */
    private resettingFlags() {
        this.canShowReviewMessage = false;
        this.canShowInvalidReviewMessage = false;
        this.reviewInvalidMessage = EMPTY;
        this.moreDetailStatus = false;
    }

    /**
     * Method to validate and display the fmp result
     *
     * @memberof FmpReviewComponent
     */
    public onFMPReviewSubmit(): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.initalDosageValue = this.fmpForm.value.Dosage;
        const payLoad = this.fmpForm.value;
        payLoad.ExpCode = this.activeExperiment?.ExpCode;
        if (this.activeExperiment?.ExpID === null) {
            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            this.showErrorMessage(FMP_CONST.PRODUCT_ERROR);
            return;
        }
        if (this.requestPayloadForWithDosage) {
            this.requestPayloadForWithDosage.dosage = this.fmpForm.value.Dosage;
        }
        this.resettingFlags();
        this.subscriptionList.push(
            this.experimentHelper.getFMPPrediction(this.requestPayloadForWithDosage).subscribe({
                next: (response) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.fmpResponse = response;
                    if (!this.onValidatingResponse(response)) return;
                    if (response?.message && Array.isArray(response?.message) && response?.message.length > 0) {
                        this.parsingFailedAndUnavailable(this.fmpResponse);
                    }

                    this.canShowReviewMessage = true;
                    this.showReviewDetails(response);
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.toasterService.error(FMP_CONST.ERROR);
                    this.logger.error(error);
                },
            }),
        );
    }

    /**
     * Method to validating the error message
     *
     * @param {*} response
     * @return {*}  {boolean}
     * @memberof FmpReviewComponent
     */
    public onValidatingResponse(response, type = FMP_CONST.FMP_TYPE.PREDICTION): boolean {
        if (isEmpty(response)) {
            this.toasterService.error(FMP_CONST.ERROR);
            this.logger.error(FMP_CONST.ERROR);
            return false;
        }
        if (response?.errormessage) {
            this.showErrorMessage(response?.errormessage);
            return false;
        }
        if (response?.errors && Array.isArray(response?.errors) && response?.errors.length > 0) {
            // eslint-disable-next-line no-unused-expressions
            type === FMP_CONST.FMP_TYPE.PREDICTION
                ? this.showErrorMessage(response?.errors[0])
                : // eslint-disable-next-line dot-notation
                  (response["errormessage"] = response?.errors[0]);
            return false;
        }
        if (response?.message && !Array.isArray(response?.message) && response?.message.length > 0) {
            // eslint-disable-next-line no-unused-expressions
            type === FMP_CONST.FMP_TYPE.PREDICTION
                ? this.showErrorMessage(response?.message)
                : // eslint-disable-next-line dot-notation
                  (response["errormessage"] = response?.message);
            return false;
        }
        return true;
    }

    /**
     * Method to parse the validated response data
     *
     * @param {FMPResponseData} response
     * @memberof FmpReviewComponent
     */
    public parsingFailedAndUnavailable(response: FMPResponseData): void {
        const failed = [];
        const unavailable = [];
        if (Array.isArray(response?.message)) {
            response?.message?.forEach((item) => {
                if (item?.type.toLowerCase() === this.fmpConstant.MESSAGE_TYPE.Failed.toLowerCase()) {
                    failed.push(item?.message);
                }
                if (item?.type.toLowerCase() === this.fmpConstant.MESSAGE_TYPE.Unavailable.toLowerCase()) {
                    unavailable.push(item?.message);
                }
            });
        }
        if (failed.length > 0) {
            Object.assign(response, { failed });
        }
        if (unavailable.length > 0) {
            Object.assign(response, { unavailable });
        }
    }

    /**
     * Method to display the error message for the FMP
     *
     * @param {string} errorMessage
     * @memberof FmpReviewComponent
     */
    public showErrorMessage(errorMessage: string): void {
        this.canShowInvalidReviewMessage = true;
        this.reviewInvalidMessage = errorMessage;
        this.canDisableDosage = true;
    }

    /**
     * Method for displaying prediction level percentage with color
     *
     * @param {FMPResponseData} response
     * @memberof FmpReviewComponent
     */
    // eslint-disable-next-line sonarjs/cognitive-complexity
    public showReviewDetails(response: FMPResponseData): void {
        if (response?.prediction === FMP_CONST.PREDICTION.PASS_VALUE || response?.prediction === FMP_CONST.PREDICTION.FAIL_VALUE) {
            const value = Number(response?.passscore).toFixed(2);

            if (Number(value) <= FMP_CONST.RANGE.HIGH_PREDICTION_LEVEL_FROM && Number(value) >= FMP_CONST.RANGE.HIGH_PREDICTION_LEVEL_TO) {
                this.reviewMessageData = FMP_CONST.PASS;
                this.reviewMessageData.VALUE = value.toString();
                return;
            }
            if (Number(value) < FMP_CONST.RANGE.HIGH_PREDICTION_LEVEL_TO && Number(value) >= FMP_CONST.RANGE.UNCERTAIN_PREDICTION_LEVEL) {
                this.reviewMessageData = FMP_CONST.UNCERTAIN;
                this.reviewMessageData.VALUE = value.toString();
                return;
            }
            if (Number(value) < FMP_CONST.RANGE.UNCERTAIN_PREDICTION_LEVEL && Number(value) >= FMP_CONST.RANGE.LOW_PREDICTION_LEVEL_FROM) {
                this.reviewMessageData = FMP_CONST.UNCERTAIN;
                this.reviewMessageData.VALUE = Number(response?.failscore).toFixed(2).toString();
                return;
            }
            if (Number(value) < FMP_CONST.RANGE.LOW_PREDICTION_LEVEL_FROM && Number(value) >= FMP_CONST.RANGE.LOW_PREDICTION_LEVEL_TO) {
                this.reviewMessageData = FMP_CONST.FAIL;
                this.reviewMessageData.VALUE = Number(response?.failscore).toFixed(2).toString();
                return;
            }
        }

        if (response?.prediction === null && response?.unavailable && response?.unavailable?.length > 0) {
            this.reviewMessageData = FMP_CONST.UNAVAILABLE;
        }
    }

    /**
     * Method to intiate the form group
     * @memberof FmpReviewComponent
     */
    public createFmpReviewForm(): UntypedFormGroup {
        return this.formBuilder.group({
            Dosage: new UntypedFormControl("", [Validators.required]),
        });
    }

    /**
     * Method for dosage validation
     * @param {KeyboardEvent} event
     * @returns {boolean}
     * @memberof FmpReviewComponent
     */
    // eslint-disable-next-line class-methods-use-this
    public onkeyPress(event: KeyboardEvent): boolean {
        return CreativeReviewHelper.dosageValidation(event);
    }

    /**
     * Method to validate the dosage in the form
     *
     * @param {Event} input
     * @memberof FmpReviewComponent
     */
    public validateDosage(input: Event): void {
        const inputValue = CreativeReviewHelper.validateDosage(input);
        this.fmpForm.patchValue({ Dosage: inputValue.target.value });
    }

    /**
     * Method for the more details toggle click
     *
     * @return {*}
     * @memberof FmpReviewComponent
     */
    public onMoreDetailsButtonToggling() {
        this.moreDetailStatus = !this.moreDetailStatus;
        return false;
    }

    /**
     * Method to show popup design based on the fmp max dosage
     *
     * @param {string} type
     * @return {*}  {boolean}
     * @memberof FmpReviewComponent
     */
    // eslint-disable-next-line consistent-return
    public canShowMaxDosageFailure(type: string): boolean {
        if (type === this.fmpConstant.MAX_DOSAGE.SUCCESS) {
            return !this.maxDosageResponse || (this.maxDosageResponse?.maxpassdosage && this.maxDosageResponse?.maxpassdosage !== null);
        }
        if (type === this.fmpConstant.MAX_DOSAGE.FAILURE) {
            return this.maxDosageResponse && (!this.maxDosageResponse?.maxpassdosage || this.maxDosageResponse?.maxpassdosage === null);
        }
    }
}
