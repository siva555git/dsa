import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder } from "@angular/forms";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from "@angular/material/dialog";
import { AppBroadCastService } from "@te-services/app-broadcast/app.broadcast.service";
import { AppDataService } from "@te-services/app-data/app.data.service";
import { AppStateService } from "@te-services/index";
import { DialogHelper } from "@te-shared/helpers/dialog-helper";
import { ExperimentApiService } from "@te-shared/helpers/experiment-api.service";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { MockAppStateService } from "@te-testing/mock-app.state.service";
import { MockCreativereview } from "@te-testing/mock-creativereview-helper";
import { MockDialogReference } from "@te-testing/mock-dialog.reference";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { MockOAuthService } from "@te-testing/mock-oauth.service";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { OAuthService } from "angular-oauth2-oidc";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { CreativeReviewHelper } from "../../../creative-review/helpers/creative-review-helper";

import { FmpReviewComponent } from "./fmp-review.component";
import { cloneDeep } from "lodash";
import { FMP_CONST } from "@te-shared/constants";
import { EMPTY } from "src/app/app.constant";
import { event } from "jquery";
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from "@angular/core";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";

describe("FmpReviewComponent", () => {
    let component: FmpReviewComponent;
    let fixture: ComponentFixture<FmpReviewComponent>;
    let inputElement: DebugElement;
    const mockBomDetail = {
        BatchSize: undefined,
        CountryCode: undefined,
        CreatedBy: 47_442,
        CreatedOn: new  Date("2022-02-05T09:49:23.000Z"),
        ExpCode: "AXA00002AA",
        ExpID: 12_348_048,
        ExpName: undefined,
        Yield:54_4656,
        ExperimentFormula: [
            {
                CreatedBy: 47_442,
                ExpFormulaID: "50481",
                ExpID: 12_348_048,
                FormulaSeq: 40,
                Instruction: undefined,
                IsDelete: 0,
                Parts: 1,
                SUBCode: "00010000",
                SUBType: "I",
            },
            {
                CreatedBy: 47_442,
                ExpFormulaID: "50487",
                ExpID: 12_348_048,
                FormulaSeq: 100,
                Instruction: undefined,
                IsDelete: 0,
                Parts: 2,
                SUBCode: "00010339",
                SUBType: "I",
            },
            {
                CreatedBy: 47_552,
                ExpFormulaID: "50488",
                ExpID: 12_348_048,
                FormulaSeq: 60,
                Instruction: undefined,
                IsDelete: 0,
                Parts: 2,
                SUBCode: "00020000",
                SUBType: "I",
            },
        ],
        ExperimentStaff: [],
        IPC: undefined,
        IsArchived: "0",
        IsDeleted: "0",
        IsLocked: "0",
        IsPublic: false,
        Level: 0,
        LockedBy: undefined,
        ProductTypeID: undefined,
        BOMType: "E",
        Type: "Experiment",
        UpdatedBy:123,
        UpdatedOn:new Date("2022-02-10T08:43:29.791Z"),
        UoMID:1234,
        MappedFolderID:5656
    };
    const mockEvent1 = {
        stopPropagation() {
            return true;
        },
        preventDefault() {
            return true;
        },
    };
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [FmpReviewComponent],
            imports: [HttpClientTestingModule, FormsModule, ReactiveFormsModule, MatDialogModule],
            providers: [
                UntypedFormBuilder,
                AppDataService,
                DialogHelper,
                SecurityHelper,
                ExperimentApiService,
                { provide: MatDialogRef, useClass: MockDialogReference },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
                    useValue: { open: () => {} },
                },
                AppBroadCastService,
                { provide: AppStateService, useClass: MockAppStateService },
                ExperimentHelper,
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                { provide: MAT_DIALOG_DATA, useValue: {} },
                {
                    provide: CreativeReviewHelper,
                    useClass: MockCreativereview,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(FmpReviewComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
    
    it('expect ngOnInit to be called',()=>{
        const spy = spyOn(component,"ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });
    
    it('expect ngOnDestroy to be called',()=>{
        const spy = spyOn(component,"ngOnDestroy").and.callThrough();
        component.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });
    
    it('expect triggerSubmit to be called',()=>{
        const spy = spyOn(component,"triggerSubmit").and.callThrough();
        component.triggerSubmit();
        expect(spy).toHaveBeenCalled();
    });
    it('expect triggerSubmit to be called when it is valid',()=>{
        // component.triggerForm.setValue({'Dosage': 50});
        component.fmpForm.setValue({'Dosage': 50});
        const spy = spyOn(component,"triggerSubmit").and.callThrough();
        component.triggerSubmit();
        expect(spy).toHaveBeenCalled();
    });
    it('expect fetchingMaxPrediction to be called',()=>{
        const spy = spyOn(component,"fetchingMaxPrediction").and.callThrough();
        component.fetchingMaxPrediction();
        expect(spy).toHaveBeenCalled();
    });
    it('should reslove for fetchingMaxPrediction if active experiment ExpID is null',()=>{
        
        const mockExp = cloneDeep(mockBomDetail);
        mockExp.CreatedOn= new Date();
        component.activeExperiment = mockExp;
        const spy = spyOn(component,"showErrorMessage").and.callThrough();
        component.activeExperiment['ExpID'] = null;
        component.fetchingMaxPrediction();
        expect(spy).toHaveBeenCalled();
    });
    it('should reslove for fetchingMaxPrediction if active experiment ExpID is not a null',()=>{     
        const mockExp = cloneDeep(mockBomDetail);
        mockExp.CreatedOn= new Date();
        component.activeExperiment = mockExp;
        const field =component.triggerForm.form.controls.Dosage;
        field.setValue(30)
        const spy = spyOn(component,"showErrorMessage").and.callThrough();
        component.fetchingMaxPrediction();
        expect(component.triggerForm.valid).toBe(true);
        expect(component.fmpForm.value.Dosage).toBe(30);
    });
    it('expect onFMPReviewSubmit to be called',()=>{
        const spy = spyOn(component,"onFMPReviewSubmit").and.callThrough();
        component.onFMPReviewSubmit();
        expect(spy).toHaveBeenCalled();
    });
    it('should reslove for onFMPReviewSubmit if active experiment ExpID is null',()=>{     
        const mockExp = cloneDeep(mockBomDetail);
        mockExp.CreatedOn= new Date();
        component.activeExperiment = mockExp;
        const field =component.triggerForm.form.controls.Dosage;
        field.setValue(30)
        component.requestPayloadForWithDosage ={'dosage':0}
        const spy = spyOn(component,"showErrorMessage").and.callThrough();
        component.onFMPReviewSubmit();
        expect(component.requestPayloadForWithDosage.dosage).toEqual(component.fmpForm.value.Dosage);
    });
    it('should reslove for onFMPReviewSubmit if active experiment ExpID is null',()=>{     
        const mockExp = cloneDeep(mockBomDetail);
        mockExp.CreatedOn= new Date();
        component.activeExperiment = mockExp;
        const spy = spyOn(component,"showErrorMessage").and.callThrough();
        component.activeExperiment['ExpID'] = null;
        component.onFMPReviewSubmit();
        expect(spy).toHaveBeenCalled();
    });
    it('expect onValidatingResponse to be called',()=>{
        const response = {
            errors:[]
        }
        const type =FMP_CONST.FMP_TYPE.PREDICTION
        const spy = spyOn(component,"onValidatingResponse").and.callThrough();
        component.onValidatingResponse(response,type);
        expect(spy).toHaveBeenCalled();
    });
    it('should resolve for onValidatingResponse if response is EMPTY',()=>{
        const response = EMPTY;
        const type =FMP_CONST.FMP_TYPE.PREDICTION;
        const result = component.onValidatingResponse(response,type);
        expect(result).toEqual(false);
    });
    it('should resolve for onValidatingResponse if there is error message in response',()=>{
        const response = {
            errormessage:"Validation error"
        }
        const type =FMP_CONST.FMP_TYPE.PREDICTION
        const spy = spyOn(component,"showErrorMessage").and.callThrough();
        const result =component.onValidatingResponse(response,type);
        expect(spy).toHaveBeenCalled();
        expect(result).toEqual(false);
    });
    it('should resolve for onValidatingResponse if there is list of errors in response',()=>{
        const response = {
            errors:["Validation error"]
        }
        const type =FMP_CONST.FMP_TYPE.PREDICTION
        const spy = spyOn(component,"showErrorMessage").and.callThrough();
        const result =component.onValidatingResponse(response,type);
        expect(spy).toHaveBeenCalled();
        expect(result).toEqual(false);
    });
    it('should resolve for onValidatingResponse if there is message in response',()=>{
        const response = {
            message:"Not allowed"
        }
        const type =FMP_CONST.FMP_TYPE.PREDICTION
        const spy = spyOn(component,"showErrorMessage").and.callThrough();
        const result =component.onValidatingResponse(response,type);
        expect(spy).toHaveBeenCalled();
        expect(result).toEqual(false);
    });
    it('expect parsingFailedAndUnavailable to be called',()=>{
        const response =  {
            expid: "123_3545",
            failscore: 3,
            passscore: 4,
            prediction: 5,
            message: [{type : "FAILED", message :"Parsing failed"},{type : "UNAVAILABLE", message :"Parsing unavailable"}],
            failed:[],
            unavailable:[]
        }
        const spy = spyOn(component,"parsingFailedAndUnavailable").and.callThrough();
        component.parsingFailedAndUnavailable(response);
        expect(spy).toHaveBeenCalled();
        expect(response.failed.length).toEqual(1);
        expect(response.unavailable.length).toEqual(1);
    });
    it('expect showReviewDetails to be called',()=>{
        const response =  {
            expid: "123_3545",
            failscore: 0,
            passscore: 100,
            prediction: 0,
            message: [{type : "FAILED", message :"Parsing failed"},{type : "UNAVAILABLE", message :"Parsing unavailable"}],
            failed:[],
            unavailable:[]
        }
        const spy = spyOn(component,"showReviewDetails").and.callThrough();
        component.showReviewDetails(response);
        expect(spy).toHaveBeenCalled();
        expect(component.reviewMessageData).toEqual(FMP_CONST.PASS);
    });
    it('should resolve for showReviewDetails when prediction is in between HIGH_PREDICTION_LEVEL_FROM and UNCERTAIN_PREDICTION_LEVEL',()=>{
        const response =  {
            expid: "123_3545",
            failscore: 0,
            passscore: 60,
            prediction: 0,
            message: [],
            failed:[],
            unavailable:[]
        }
        const spy = spyOn(component,"showReviewDetails").and.callThrough();
        component.showReviewDetails(response);
        expect(spy).toHaveBeenCalled();
        expect(component.reviewMessageData).toEqual(FMP_CONST.UNCERTAIN);
    });
    it('should resolve for showReviewDetails when prediction is in between HIGH_PREDICTION_LEVEL_FROM and UNCERTAIN_PREDICTION_LEVEL',()=>{
        const response =  {
            expid: "123_3545",
            failscore: 0,
            passscore: 30,
            prediction: 0,
            message: [],
            failed:[],
            unavailable:[]
        }
        const spy = spyOn(component,"showReviewDetails").and.callThrough();
        component.showReviewDetails(response);
        expect(spy).toHaveBeenCalled();
        expect(component.reviewMessageData).toEqual(FMP_CONST.UNCERTAIN);
    });
    it('should resolve for showReviewDetails when prediction is in between HIGH_PREDICTION_LEVEL_FROM and UNCERTAIN_PREDICTION_LEVEL',()=>{
        const response =  {
            expid: "123_3545",
            failscore: 0,
            passscore: 10,
            prediction: 0,
            message: [],
            failed:[],
            unavailable:[]
        }
        const spy = spyOn(component,"showReviewDetails").and.callThrough();
        component.showReviewDetails(response);
        expect(spy).toHaveBeenCalled();
        expect(component.reviewMessageData).toEqual(FMP_CONST.FAIL);
    });
    it('should resolve for showReviewDetails when prediction is in between HIGH_PREDICTION_LEVEL_FROM and UNCERTAIN_PREDICTION_LEVEL',()=>{
        const response =  {
            expid: "123_3545",
            failscore: 0,
            passscore: 10,
            prediction: null,
            message: [{type : "FAILED", message :"Parsing failed"},{type : "UNAVAILABLE", message :"Parsing unavailable"}],
            failed:[],
            unavailable:["Parsing unavailable"]
        }
        const spy = spyOn(component,"showReviewDetails").and.callThrough();
        component.showReviewDetails(response);
        expect(spy).toHaveBeenCalled();
        expect(component.reviewMessageData).toEqual(FMP_CONST.UNAVAILABLE);
    });
    it('expect validateDosage to be called',()=>{
        const spy = spyOn(component,"validateDosage").and.callThrough();
        const mockEvent = {
            target: {
                value: "3",
                select() {
                    return true;
                },
            },
        };
        fixture.detectChanges();
        component.validateDosage(mockEvent as unknown as InputEvent);
        expect(spy).toHaveBeenCalled();
        expect(component.fmpForm.value.Dosage).toBe(mockEvent.target.value)
    });
    it('expect onMoreDetailsButtonToggling to be called',()=>{
        const spy = spyOn(component,"onMoreDetailsButtonToggling").and.callThrough();
        fixture.detectChanges();
        component.moreDetailStatus = false;
        const result = component.onMoreDetailsButtonToggling();
        expect(result).toBe(false);
        expect(component.moreDetailStatus).toBe(true);
        expect(spy).toHaveBeenCalled();
    });
});
