export const MAX_DIRECT_IPC_INSERT_COUNT = 30;
export const STANDARD_IPC_LENGTH = 8;
export const ADD_IPC_WARNING = {
    IPC_LENGTH_LESS_THEN_STANDARD: "IPC value should be 8 character long",
    DIRECT_IPC_INSERT_WARNING:
        "Maximum limit reached in add IPCs section. Only 30 IPCs are allowed to add in the section. Kindly use Upload IPC",
    MAX_IPC_LIST_REACH: "Max. of 500 IPCs can be added",
};
export const IPC = "ipc";
export const REMOVE_IPC_FROM_LIST = {
    title: "Remove IPC",
    message: "",
    subMesssage: "",
    submitText: "Yes",
    cancelText: "No",
    submitBtnClass: "fill-button",
    data: {},
};
export const MAX_ALLOWED_IPCS = 500;
