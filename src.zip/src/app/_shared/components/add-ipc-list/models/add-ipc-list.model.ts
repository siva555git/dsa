export interface NewIpcListModel {
    ipc: string;
    isDuplicate?: boolean;
    isInvalid?: boolean;
}

export interface ExistingIpcListModel {
    ipc: string;
    description: string;
    productType: string;
    isNewlyAdded: boolean;
}

export interface IpcBasicAttributeInfo {
    ipc: string;
    description: string;
    prodtypecode: string;
}
