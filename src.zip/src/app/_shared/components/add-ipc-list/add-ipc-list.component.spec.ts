/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed } from "@angular/core/testing";

import { ToastrService } from "ngx-toastr";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { AppBroadCastService } from "@te-services/index";
import { of } from "rxjs";
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { AddIpcListHelper } from "@te-shared/helpers/add-ipc-list.helper";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from "@angular/core";
import { mockAttributeResponse, mockIpcListToBeAdded } from "@te-testing/mock-add-ipc-data";
import { EMPTY } from "src/app/app.constant";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatTableModule } from "@angular/material/table";
import { MatChipsModule } from "@angular/material/chips";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { AddIpcListComponent } from "./add-ipc-list.component";
import { ExistingIpcListModel } from "./models/add-ipc-list.model";

describe("AddIpcListComponent", () => {
    let component: AddIpcListComponent;
    let fixture: ComponentFixture<AddIpcListComponent>;

    const dialogReferenceStub = {
        afterClosed() {
            return of(); // this can be whatever, esp handy if you actually care about the value returned
        },
    };

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [AddIpcListComponent],
            providers: [
                AppBroadCastService,
                SpaceTrimPipe,
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                {
                    provide: AddIpcListHelper,
                    useValue: {
                        fetchIPCDetail: () => {
                            return [];
                        },
                        checkForInvalidIpc: () => {
                            return [];
                        },
                        checkForDuplicateAndInvalidIpc: () => {
                            return [];
                        },
                        getValidIpcs: () => {
                            return [];
                        },
                    },
                },
            ],
            imports: [MatTableModule, FormsModule, ReactiveFormsModule, CommonModule, BrowserModule, MatChipsModule],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        });
        fixture = TestBed.createComponent(AddIpcListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should invoke ngOnChanges", () => {
        const changes = {
            savedIpcListData: {
                currentValue: ["1RR04333"],
            },
        } as unknown as SimpleChanges;
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on listenIpcEdition", () => {
        spyOn(component, "listenIpcEdition").and.callThrough();
        const appBoardCastService: AppBroadCastService = TestBed.inject(AppBroadCastService);
        appBoardCastService.addedIpcListSubject.next(mockAttributeResponse);
        component.listenIpcEdition();
        expect(component.disableAddIPCbtn).toEqual(true);
    });

    it("should call on getAddedIpc", () => {
        spyOn(component, "getAddedIpc").and.callThrough();
        component.ipcList = [];
        component.addedIpcForm.setValue("1RR04332");
        component.getAddedIpc();
        expect(component.ipcList).toEqual([{ ipc: "1RR04332" }]);
    });

    it("should call on getAddedIpc 1", () => {
        spyOn(component, "getAddedIpc").and.callThrough();
        component.ipcList = [];
        component.addedIpcForm.setValue("1RR04332, 1RR04333");
        component.getAddedIpc();
        expect(component.ipcList).toEqual([{ ipc: "1RR04332" }, { ipc: "1RR04333" }]);
    });

    it("should call on getAddedIpc 2", () => {
        const spy = spyOn(component, "getAddedIpc").and.callThrough();
        component.ipcList = [];
        component.addedIpcForm.setValue("1RR043");
        component.getAddedIpc();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on checkIPCList ", () => {
        const spy = spyOn(component, "checkIPCList").and.callThrough();
        component.addedIpcForm.setValue(EMPTY);
        component.ipcList = [{ ipc: "1RR04333" }, { ipc: "1RR04332" }, { ipc: "100HSKDJF" }, { ipc: "1RR04333" }, { ipc: "00010000" }];
        component.existingIpcListData = [];
        component.checkIPCList();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on checkIPCList 1", () => {
        spyOn(component, "checkIPCList").and.callThrough();
        component.addedIpcForm.setValue(EMPTY);
        component.ipcList = [];
        component.existingIpcListData = [];
        component.checkIPCList();
        expect(component.disableAddIPCbtn).toEqual(true);
    });

    it("should call on onCancelDrawer", () => {
        spyOn(component, "onCancelDrawer").and.callThrough();
        component.onAddIpcListdrawerToggle.emit(false);
        component.onCancelDrawer();
        expect(component.onCancelDrawer).toHaveBeenCalled();
    });

    it("should call on removeIpcFromChip", () => {
        spyOn(component, "removeIpcFromChip").and.callThrough();
        component.ipcList = [{ ipc: "1RR04333" }, { ipc: "1RR04332" }];
        component.removeIpcFromChip(1);
        expect(component.ipcList).toEqual([{ ipc: "1RR04333" }]);
    });

    it("should call on maxLimitWarning", () => {
        spyOn(component, "maxLimitWarning").and.callThrough();
        component.maxLimitWarning();
        expect(component.addedIpcForm.value).toEqual(EMPTY);
    });

    it("should call on onAddipcToList", () => {
        spyOn(component, "onAddipcToList").and.callThrough();
        const addIpcListHelper: AddIpcListHelper = TestBed.inject(AddIpcListHelper);
        spyOn(addIpcListHelper, "getValidIpcs").and.returnValue(["1RR04333", "1RR04332", "00010000"]);
        component.existingIpcListData = [];
        component.savedIpcListData = [];
        component.onAddipcToList(mockIpcListToBeAdded);
        expect(component.onAddipcToList).toHaveBeenCalled();
    });

    it("should call on onSaveIpcList", () => {
        component.existingIpcListData = [{ ipc: "1RR04333" }] as unknown as ExistingIpcListModel[];
        spyOn(component, "onSaveIpcList").and.callThrough();
        component.onAddingNewIpc.emit(["1RR04333"]);
        component.onSaveIpcList();
        expect(component.ipcList).toEqual([]);
    });

    it("should call on formatipcData", () => {
        component.attributes = [
            {
                prodtypecode: "LIQUID-CONTAINS ALCOHOL",
                description: "FOREST FRUITS",
                ipc: "1RR04333",
            },
        ];
        spyOn(component, "formatipcData").and.callThrough();
        component.savedIpcListData = [];
        component.formatipcData(["1RR04333"], true);
        expect(component.existingIpcListData).toEqual([
            {
                ipc: "1RR04333",
                description: "FOREST FRUITS",
                productType: "LIQUID-CONTAINS ALCOHOL",
                isNewlyAdded: true,
            },
        ]);
    });

    it("should call on onRemoveIpcFromExistingList", () => {
        spyOn(component, "onRemoveIpcFromExistingList").and.callThrough();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any, dot-notation
        spyOn(component["dialog"], "open").and.returnValue({ afterClosed: () => of(true) } as MatDialogRef<any>);
        component.existingIpcListData = [{ ipc: "1RR04333" }, { ipc: "1RR04332" }] as unknown as ExistingIpcListModel[];
        component.onRemoveIpcFromExistingList("1RR04333");
        expect(component.existingIpcListData).toEqual([{ ipc: "1RR04332" }] as unknown as ExistingIpcListModel[]);
    });

    it("should call on onRemoveIpcFromExistingList 1", () => {
        spyOn(component, "onRemoveIpcFromExistingList").and.callThrough();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any, dot-notation
        spyOn(component["dialog"], "open").and.returnValue({ afterClosed: () => of(false) } as MatDialogRef<any>);
        component.existingIpcListData = [{ ipc: "1RR04333" }, { ipc: "1RR04332" }] as unknown as ExistingIpcListModel[];
        component.onRemoveIpcFromExistingList("1RR04333");
        expect(component.existingIpcListData).toEqual([{ ipc: "1RR04333" }, { ipc: "1RR04332" }] as unknown as ExistingIpcListModel[]);
    });

    it("should call on checkForUpdate", () => {
        spyOn(component, "checkForUpdate").and.callThrough();
        component.savedIpcListData = [];
        component.existingIpcListData = [{ ipc: "1RR04333" }, { ipc: "1RR04332" }] as unknown as ExistingIpcListModel[];
        component.checkForUpdate();
        expect(component.isIpcListUpdated).toEqual(true);
    });
});
