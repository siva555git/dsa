import {
    ChangeDetectorRef,
    Component,
    ElementRef,
    EventEmitter,
    HostListener,
    Input,
    Output,
    SimpleChanges,
    ViewChild,
} from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { ADD_IPC_TYPE, COMMON_DIALOG_OLD, IPC_UPLOAD_REPORT } from "@te-shared/constants";
import { UntypedFormControl } from "@angular/forms";
import { AppBroadCastService } from "@te-services/index";
import { filter, forEach, isEqual, map, split, toLower } from "lodash";
import { ToastrService } from "ngx-toastr";
import { EMPTY } from "src/app/app.constant";
import { AddIpcListHelper } from "@te-shared/helpers/add-ipc-list.helper";
import { debounceTime } from "rxjs";
import { SpaceTrimPipe } from "@te-shared/pipes/space-trim/space-trim.pipe";
import { UploadIpcListComponent } from "../upload-ipc-list/upload-ipc-list.component";
import { ExistingIpcListModel, IpcBasicAttributeInfo, NewIpcListModel } from "./models/add-ipc-list.model";
import { ADD_IPC_COLUMN_LIST } from "../base-ipc-layout/base-ipc-layout-constant";
import {
    ADD_IPC_WARNING,
    IPC,
    MAX_ALLOWED_IPCS,
    MAX_DIRECT_IPC_INSERT_COUNT,
    REMOVE_IPC_FROM_LIST,
    STANDARD_IPC_LENGTH,
} from "./add-ipc-list.constant";
import { ConfirmationDialogComponent } from "../confirmation-dialog/confirmation-dialog.component";

@Component({
    selector: "app-add-ipc-list",
    templateUrl: "./add-ipc-list.component.html",
    styleUrls: ["./add-ipc-list.component.scss"],
})
export class AddIpcListComponent {
    public attributes: IpcBasicAttributeInfo[] = [];

    public ipcList: NewIpcListModel[] = [];

    public uploadedIpcList: NewIpcListModel[] = [];

    public addedIpcForm: UntypedFormControl = new UntypedFormControl(EMPTY);

    public searchValue = new UntypedFormControl(EMPTY);

    public existingIpcListData: ExistingIpcListModel[] = [];

    public filteredIpcData: ExistingIpcListModel[] = [];

    public displayColumns: string[] = ADD_IPC_COLUMN_LIST;

    public disableAddIPCbtn = true;

    public isIpcListUpdated = false;

    public isInnerPopupOpened = false;

    public maxAllowedIpcCount = MAX_ALLOWED_IPCS;

    @Output()
    public onAddIpcListdrawerToggle = new EventEmitter<boolean>();

    @Output()
    public onAddingNewIpc = new EventEmitter();

    @Input()
    public savedIpcListData: Array<string>;

    @ViewChild("fileDropRef", { read: ElementRef }) fileDropRef: ElementRef;

    @HostListener("document:keydown.escape", ["$event"]) onKeydownHandler(): void {
        if (!this.isInnerPopupOpened) {
            this.onCancelDrawer();
        }
    }

    constructor(
        private readonly toastrService: ToastrService,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly dialog: MatDialog,
        private readonly addIpcListHelper: AddIpcListHelper,
        private readonly spaceTrim: SpaceTrimPipe,
        private readonly cdr: ChangeDetectorRef,
    ) {}

    /**
     * Method called on component initialization
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    ngOnInit() {
        this.listenIpcEdition();
        this.listenForSearchValueChanges();
    }

    /**
     * Method called on input value changes
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    ngOnChanges(changes: SimpleChanges): void {
        if (changes.savedIpcListData?.currentValue && changes.savedIpcListData?.currentValue?.length > 0) {
            this.addIpcListHelper.fetchIPCDetail([...new Set(this.savedIpcListData)], EMPTY);
        }
    }

    /**
     * Method called after view is initialized
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    ngAfterViewInit(): void {
        this.cdr.detectChanges();
    }

    /**
     * Method to listen search value changes
     * @return {void}
     * @memberof AddIpcListComponent
     */
    public listenForSearchValueChanges(): void {
        this.searchValue.valueChanges.pipe(debounceTime(500)).subscribe((value) => {
            this.searchIPCListData(value);
        });
    }

    /**
     * Method to listen ipc edition
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public listenIpcEdition(): void {
        this.appBroadCastService.addedIpcListInfo.subscribe((result) => {
            if (result) {
                this.attributes.push(...result.attributes);
                if (result.addType === ADD_IPC_TYPE.SINGLE_IPC_UPLOAD) {
                    this.ipcList = this.addIpcListHelper.checkForInvalidIpc(this.ipcList, this.attributes);
                    this.disableAddIPCbtn =
                        this.ipcList?.length > 0 ? this.ipcList?.filter((data) => data.isDuplicate || data.isInvalid)?.length > 0 : true;
                }
                if (result.addType === EMPTY) {
                    this.formatipcData(this.savedIpcListData);
                }
            }
        });
    }

    /**
     * Method to cancel add ipc list drawer
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public onCancelDrawer(): void {
        this.onAddIpcListdrawerToggle.emit(false);
    }

    /**
     * Method to remove ipc from mat chip
     * @param {number} removedIndex
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public removeIpcFromChip(removedIndex: number): void {
        this.ipcList.splice(removedIndex, 1);
        this.disableAddIPCbtn =
            this.ipcList?.length > 0 ? this.ipcList.filter((data) => data.isDuplicate || data.isInvalid)?.length > 0 : true;
    }

    /**
     * Method to get added ipcs
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public getAddedIpc(): void {
        const addedIPC = this.addedIpcForm.value;
        if (addedIPC?.length > STANDARD_IPC_LENGTH) {
            const ipcData = split(addedIPC?.trim(), /[\s,]+/);
            if (ipcData?.length > 0 && ipcData.length + this.ipcList.length <= 30) {
                forEach(ipcData, (ipc) => {
                    this.ipcList.push({ ipc: ipc?.toUpperCase() });
                });
                this.addedIpcForm.setValue(EMPTY);
            } else {
                this.maxLimitWarning();
            }
        } else if (this.ipcList?.length >= MAX_DIRECT_IPC_INSERT_COUNT) {
            this.maxLimitWarning();
        } else if (addedIPC?.length < STANDARD_IPC_LENGTH) {
            this.toastrService.info(ADD_IPC_WARNING.IPC_LENGTH_LESS_THEN_STANDARD);
        } else {
            this.ipcList.push({ ipc: addedIPC.toUpperCase() });
            this.addedIpcForm.setValue(EMPTY);
        }
    }

    /**
     * Method used to throw max limit warning
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public maxLimitWarning(): void {
        this.toastrService.info(ADD_IPC_WARNING.DIRECT_IPC_INSERT_WARNING);
        this.addedIpcForm.setValue(EMPTY);
    }

    /**
     * Method called to validate ipc list
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public checkIPCList(): void {
        if (this.addedIpcForm?.value !== EMPTY) {
            this.getAddedIpc();
        }
        if (this.ipcList?.length > 0) {
            this.ipcList = this.addIpcListHelper.checkForDuplicateAndInvalidIpc(this.ipcList, this.existingIpcListData);
            const ipcList = this.addIpcListHelper.getValidIpcs(this.ipcList);
            if (ipcList?.length > 0) {
                this.addIpcListHelper.fetchIPCDetail([...new Set(ipcList)], ADD_IPC_TYPE.SINGLE_IPC_UPLOAD);
            }
        } else {
            this.disableAddIPCbtn = true;
        }
    }

    /**
     * Method called on to add ipc to list
     * @param {NewIpcListModel[]} ipcList
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public onAddipcToList(ipcList: NewIpcListModel[]): void {
        this.resetIpcListData();
        if (ipcList.length + this.existingIpcListData.length > this.maxAllowedIpcCount) {
            this.toastrService.warning(ADD_IPC_WARNING.MAX_IPC_LIST_REACH);
            return;
        }
        const newAddedIpcList = this.addIpcListHelper.getValidIpcs(ipcList);
        this.formatipcData(newAddedIpcList, true);
    }

    /**
     * Method called on save ipc list
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public onSaveIpcList(): void {
        const newAddedIpcList = map(this.existingIpcListData, IPC);
        this.onAddingNewIpc.emit(newAddedIpcList);
        this.onAddIpcListdrawerToggle.emit(false);
    }

    /**
     * Method to Format Ipc Data
     * @param {Array<string>} ipcList
     * @param {boolean} isNewlyAdded
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public formatipcData(ipcList: Array<string>, isNewlyAdded = false): void {
        ipcList.forEach((data) => {
            const ipcAttributeData = this.attributes?.filter((ipcData) => ipcData.ipc === data);
            if (ipcAttributeData?.length > 0) {
                this.existingIpcListData.push({
                    ipc: data,
                    description: ipcAttributeData[0].description,
                    productType: ipcAttributeData[0].prodtypecode,
                    isNewlyAdded,
                });
            }
        });
        this.checkForUpdate();
        const searchText = this.searchValue.value ?? EMPTY;
        this.searchValue.setValue(searchText);
    }

    /**
     * Method called on bulk file upload
     * @param uploadedFile
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public onUploadBulkIpcData(uploadedFile: File[]): void {
        const uploadIpcListPopupInfo = IPC_UPLOAD_REPORT;
        uploadIpcListPopupInfo.data = {
            uploadedFile,
            existingIpcListData: this.existingIpcListData,
        };
        this.isInnerPopupOpened = true;
        const dialogReference = this.dialog.open(UploadIpcListComponent, uploadIpcListPopupInfo);
        dialogReference.afterClosed().subscribe((uploadedIpcList) => {
            this.isInnerPopupOpened = false;
            this.fileDropRef.nativeElement.value = EMPTY;
            if (uploadedIpcList?.length > 0) {
                this.onAddipcToList(uploadedIpcList);
            }
        });
    }

    /**
     * Method called to remove ipc from existing ipc list
     * @param {string} ipc
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public onRemoveIpcFromExistingList(ipc: string): void {
        const dialogOptions = COMMON_DIALOG_OLD;
        const dialogMessage = REMOVE_IPC_FROM_LIST;
        dialogMessage.message = `Are you sure that you want to delete this IPC ${ipc} from the list? <br> Click yes to proceed.`;
        dialogOptions.data = dialogMessage;
        this.isInnerPopupOpened = true;
        const dialogReference = this.dialog.open(ConfirmationDialogComponent, dialogOptions);
        dialogReference.afterClosed().subscribe((dialogResult) => {
            this.isInnerPopupOpened = false;
            if (!dialogResult) {
                return;
            }
            const removedIndex = this.existingIpcListData?.findIndex((data) => data.ipc === ipc);
            if (removedIndex !== -1) {
                this.existingIpcListData.splice(removedIndex, 1);
            }
            this.checkForUpdate();
            const searchText = this.searchValue.value ?? EMPTY;
            this.searchValue.setValue(searchText);
        });
    }

    /**
     * Method called to check for update
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public checkForUpdate(): void {
        const existingIPCValues = map(this.existingIpcListData, IPC);
        this.isIpcListUpdated = !isEqual(this.savedIpcListData, existingIPCValues);
    }

    /**
     * Method reset ipc list data
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public resetIpcListData() {
        this.ipcList = [];
        this.disableAddIPCbtn = true;
    }

    /**
     * Method to search ipc from a list
     * @param {string} searchValue
     * @returns {void}
     * @memberof AddIpcListComponent
     */
    public searchIPCListData(searchValue: string): void {
        this.filteredIpcData =
            searchValue === EMPTY
                ? [...this.existingIpcListData]
                : filter(
                      this.existingIpcListData,
                      (ipcData) =>
                          toLower(ipcData.ipc).includes(toLower(this.spaceTrim.transform(searchValue))) ||
                          toLower(ipcData.description).includes(toLower(this.spaceTrim.transform(searchValue))) ||
                          toLower(ipcData.productType).includes(toLower(this.spaceTrim.transform(searchValue))),
                  );
        if (this.filteredIpcData?.length > 0) {
            this.filteredIpcData.sort((value1, value2) => {
                if (value1.isNewlyAdded === value2.isNewlyAdded) {
                    return value1.description.localeCompare(value2.description);
                }
                return value1.isNewlyAdded ? -1 : 1;
            });
        }
    }
}
