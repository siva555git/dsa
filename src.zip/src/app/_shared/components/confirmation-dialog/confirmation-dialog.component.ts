/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-classes-per-file */
import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { PERMISSION_CATEGORY_CONSTANT } from "../../constants/experiment-access.constant";
// eslint-disable-next-line import/no-cycle
import { ColumnLayoutComponent } from "../../../master-data/column-layout/column-layout.component";
import { CONFIRMATION_CONST, KEYBOARD_KEYS, MASTER_DATA_CONFIRMATION_MESSAGE, INCREDIENT_SEARCH_REPLACE } from "../../constants/common.constant";

@Component({
    selector: "app-confirmation-dialog",
    templateUrl: "./confirmation-dialog.component.html",
})
export class ConfirmationDialogComponent implements OnInit {
    public dialogMsg: any;

    public member = PERMISSION_CATEGORY_CONSTANT.MEMBER;

    public submitButtonClass: string;

    public title = MASTER_DATA_CONFIRMATION_MESSAGE.title;

    public YES_CONSTANT = CONFIRMATION_CONST.YES;

    public NO_CONSTANT = CONFIRMATION_CONST.NO;
    public ingredientSearchReplace = INCREDIENT_SEARCH_REPLACE;

    constructor(public dialogReference: MatDialogRef<ColumnLayoutComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {}

    ngOnInit(): void {
        this.dialogMsg = this.data;
        this.submitButtonClass = this.dialogMsg.submitBtnClass ?? "fill-button";
        this.dialogReference.keydownEvents().subscribe((event) => {
            if (event.key === KEYBOARD_KEYS.ESCAPE) {
                this.dialogReference.close();
            }
        });
    }

    /**
     * Method to close warning dialog box
     *
     * @memberof ConfirmationDialogComponent
     */
    public onCloseDialog(value: boolean): void {
        if (value && this.dialogMsg?.data?.showCheckBox) {
            this.dialogReference.close({ removeAllExperiments: this.dialogMsg.data?.removeAllExperiments });
        } else {
            this.dialogReference.close(value);
        }
    }
}
