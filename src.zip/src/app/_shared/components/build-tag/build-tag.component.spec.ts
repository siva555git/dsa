/* eslint-disable no-new-object */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";

import { By } from "@angular/platform-browser";
import { MockAppStateService } from "../../../testing/mock-app.state.service";
import { BuildTagComponent } from "./build-tag.component";
import { AppEnvironment } from "../../../../config";
import { AppStateService } from "../../../_services";

// eslint-disable-next-line  max-lines-per-function
describe("BuildTagComponent", () => {
    let component: BuildTagComponent;
    let fixture: ComponentFixture<BuildTagComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [BuildTagComponent],
            providers: [{ provide: AppStateService, useClass: MockAppStateService }],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BuildTagComponent);
        component = fixture.componentInstance;
    });

    it("should create an instance", () => {
        fixture.detectChanges();

        expect(component).toBeTruthy();
        expect(component.options.versionPrefix).toEqual("Version");
        expect(component.options.showEnvOnProd).toBeFalsy();
    });

    xit("should not show environment in production mode by default", () => {
        component.buildEnvironment = AppEnvironment[AppEnvironment.PROD].toUpperCase();
        component.isProduction = true;

        fixture.detectChanges();
        const divElt = fixture.debugElement.query(By.css("div"));
        const spanElt = divElt.query(By.css("span"));

        expect(spanElt).toBeNull();
    });

    xit("should not have span on empty build environment", () => {
        component.buildEnvironment = "";
        component.isProduction = true;
        component.options = {
            versionPrefix: "Version",
            showEnvOnProd: false,
        };
        fixture.detectChanges();
        const divElt = fixture.debugElement.query(By.css("div"));
        const spanElt = divElt.query(By.css("span"));

        expect(spanElt).toBeNull();
    });

    it("options input should set currentOptions", waitForAsync(() => {
        component.options = {
            versionPrefix: "Version",
            showEnvOnProd: false,
        };
        expect(component.options).toEqual({
            versionPrefix: "Version",
            showEnvOnProd: false,
        });
    }));
});
