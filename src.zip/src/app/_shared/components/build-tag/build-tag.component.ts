import { Component, Input, ChangeDetectionStrategy, OnInit } from "@angular/core";

import { find } from "lodash";
import { AppEnvironment } from "../../../../config";
import { AppSettings } from "../../../app.settings";
import { AppStateService } from "../../../_services";
import { BUILD_DEFAULT, TASTE_EDITOR } from "../../constants/common.constant";

export interface BuildTagOptions {
    versionPrefix?: string;
    showEnvOnProd?: boolean;
}

@Component({
    selector: "app-build-tag",
    templateUrl: "./build-tag.component.html",
    styleUrls: ["./build-tag.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BuildTagComponent implements OnInit {
    /**
     *Default options
     *
     * @private
     * @type {BuildTagOptions}
     * @memberof BuildTagComponent
     */
    private defaultOptions: BuildTagOptions = {
        versionPrefix: "Version",
        showEnvOnProd: false,
    };

    private currentOptions = this.defaultOptions;

    public taste = TASTE_EDITOR;

    /**
     *Custom options
     *
     * @memberof BuildTagComponent
     */
    @Input("options")
    set options(value: BuildTagOptions) {
        this.currentOptions = { ...this.currentOptions, ...value };
    }

    /**
     *Current configured options
     *
     * @readonly
     * @type {BuildTagOptions}
     * @memberof BuildTagComponent
     */
    get options(): BuildTagOptions {
        return this.currentOptions;
    }

    public buildEnvironment = (AppEnvironment[AppSettings.Env] || "").toLowerCase();

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public buildVersion: string;

    public isProduction = AppSettings.Env === AppEnvironment.PROD;

    constructor(private readonly appStateService: AppStateService) {}

    public ngOnInit(): void {
        const applicationSettings = this.appStateService.getApplicationSettings();
        if (applicationSettings) {
            const currentBuildVersion = find(applicationSettings.ApplicationSettings, (settings) => {
                return settings.ParameterCode === AppEnvironment[AppSettings.Env];
            });
            this.buildVersion =
                currentBuildVersion && currentBuildVersion.ParameterInString ? currentBuildVersion.ParameterInString : BUILD_DEFAULT;
        }
    }
}
