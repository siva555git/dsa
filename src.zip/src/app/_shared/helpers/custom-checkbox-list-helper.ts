/* eslint-disable sonarjs/no-identical-functions */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable class-methods-use-this */
import { Injectable } from "@angular/core";
import { flattenDeep } from "lodash";
import { ITEMLIST_TYPE } from "../constants/common.constant";
import { ModifiedDetails } from "../models/custom-checkbox-list-model";
import { ProductSearchResponse } from "../../master-data/models/ipc-selection-model";

@Injectable()
export class CustomCheckboxListHelper {
    public itemlistType = ITEMLIST_TYPE.ARRAY_OF_OBJECTS;

    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() {}

    /**
     * Method to handle the hot key selections
     * @param event
     * @param index
     * @param checkboxList
     * @param lastSelected
     * @memberof CustomCheckboxListHelper
     */
    public clickHandler(event: PointerEvent, index: number, checkboxList: Array<any>, lastSelected: number): void {
        if (event && event.ctrlKey) {
            this.crtlSelection(index, lastSelected); // This records this.lastSelected
        } else if (event && event.shiftKey) {
            this.shiftSelection(index, checkboxList, lastSelected);
        } else {
            this.normalSelection(event, index, checkboxList); // As does this call.
        }
    }

    /**
     * Method to handle normal toggle type selections
     * @param event
     * @param index
     * @param checkboxList
     * @memberof CustomCheckboxListHelper
     */
    public normalSelection(event, index: number, checkboxList): void {
        let currentIndex = 0;
        checkboxList.forEach((row: any) => {
            if (index !== currentIndex) {
                row.IsChecked = false;
                row.checkedTrack = false;
            }
            currentIndex += 1;
        });
        checkboxList[index].checkedTrack = true;
    }

    /**
     * This function computes a start and end point for autoselection of rows between this.lastSelected, and the currently clicked row
     * @param index
     * @param checkboxList
     * @param lastSelected
     * @memberof CustomCheckboxListHelper
     */
    public shiftSelection(index: number, checkboxList: Array<any>, lastSelected: number): void {
        const indexA = lastSelected;
        const indexB = index;
        if (indexA > indexB) {
            // Descending order
            this.selectRowsBetween(indexB, indexA, checkboxList);
        } else {
            // Ascending order
            this.selectRowsBetween(indexA, indexB, checkboxList);
        }
    }

    /**
     * Method to handle the ctrl key selection
     * @param index
     * @param lastSelected
     * @memberof CustomCheckboxListHelper
     */
    public crtlSelection(index: number, lastSelected: number): void {
        lastSelected = index;
    }

    /**
     * And this performs the actual selection.
     * @param start
     * @param end
     * @param checkboxList
     * @memberof CustomCheckboxListHelper
     */
    // eslint-disable-next-line sonarjs/cognitive-complexity
    private selectRowsBetween(start: number, end: number, checkboxList: Array<any>): void {
        let currentIndex = 0;
        if (this.itemlistType === ITEMLIST_TYPE.ARRAY_OF_OBJECTS) {
            checkboxList.forEach((row: ProductSearchResponse) => {
                if (currentIndex >= start && currentIndex <= end) {
                    if (!(currentIndex === start || currentIndex === end)) {
                        row.IsChecked = true;
                    }
                    row.checkedTrack = true;
                }
                currentIndex += 1;
            });
        } else {
            checkboxList.forEach((rows: any) => {
                rows.forEach((row: ProductSearchResponse) => {
                    if (currentIndex >= start && currentIndex <= end) {
                        if (!(currentIndex === start || currentIndex === end)) {
                            row.IsChecked = true;
                        }
                        row.checkedTrack = true;
                    }
                    currentIndex += 1;
                });
            });
        }
    }

    /**
     * Method for master checkbox change event
     * @param event
     * @memberof CustomCheckboxListHelper
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types, consistent-return, @typescript-eslint/no-explicit-any
    public masterCheckboxChange(event: any, itemList: Array<any>, masterCheckBox: boolean): ModifiedDetails {
        let isChecked = false;
        let selectedCheckList = [];
        if (event.checked) {
            isChecked = true;
            if (this.itemlistType === ITEMLIST_TYPE.ARRAY_OF_OBJECTS) {
                selectedCheckList = itemList;
            }
        } else {
            masterCheckBox = false;
            selectedCheckList = [];
        }

        if (this.itemlistType === ITEMLIST_TYPE.ARRAY_OF_OBJECTS) {
            itemList.forEach((element) => {
                element.IsChecked = isChecked;
            });
        } else {
            itemList.forEach((items) => {
                items.forEach((item) => {
                    item.IsChecked = isChecked;
                    if (isChecked) {
                        selectedCheckList.push(item);
                    }
                });
            });
        }

        return {
            selectedCheckList,
            masterCheckBox,
        };
    }

    /**
     * Method for checkbox change event
     * @param selectedCheckList
     * @param itemList
     * @param masterCheckBox
     * @memberof CustomCheckboxListHelper
     */
    public onCheckBoxChange(selectedCheckList: Array<any>, itemList: Array<any>): ModifiedDetails {
        let list = itemList;
        if (this.itemlistType !== ITEMLIST_TYPE.ARRAY_OF_OBJECTS) {
            list = flattenDeep(list);
        }
        selectedCheckList = list.filter((item) => item.IsChecked);
        // eslint-disable-next-line @typescript-eslint/naming-convention
        let masterCheckBox = false;
        if (selectedCheckList?.length === list?.length) {
            masterCheckBox = true;
        }
        return {
            selectedCheckList,
            masterCheckBox,
        };
    }
}
