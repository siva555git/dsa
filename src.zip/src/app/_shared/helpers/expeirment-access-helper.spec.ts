/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { MockDialogReference } from "@te-testing/mock-dialog.reference";
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { EXPERIMENT_ACCESS } from "../constants/experiment-access.constant";
import { MockAppStateService } from "../../testing/mock-app.state.service";
import { ExperimentAccessResponseModel } from "../models/experiment-access-model";
import { SecurityHelper } from "../security/helpers/security.helper";
import { AppStateService } from "../../_services/app-state/app.state.service";
import { ExperimentAccessHelper } from "./experiment-access.helper";

describe("ExperimentAccessHelper", () => {
    let service: ExperimentAccessHelper;

    const mockExpList = [
        {
            CreatedBy: 65_820,
            ExpAccessStatus: false,
            ExpCode: "VXV00435AC",
            ExpID: 63_388_299,
            ExpName: "menu check",
            ExperimentStaff: [],
            ExperimentVariant: undefined,
            IPC: undefined,
            IsLocked: "0",
            IsOtherExp: undefined,
            IsPublic: true,
            SharedFrom: undefined,
            SharedTo: undefined,
            checked: true,
            productType: "",
            CreatedByName: "Bala",
        },
    ];

    const mockExperimentAccess = {
        ExperimentAccess: {
            FunctionCategory: [{ AccessFunction: "View bom", CategoryName: "View", Description: undefined, IsActive: true }],
            PermissionCategory: [
                {
                    AccessList: "Member",
                    CategoryName: "View",
                    IsActive: true,
                    IsPermitted: true,
                    Lock: "Unlocked",
                    Ownership: "Creator",
                    Privacy: "Public",
                    AccessFunction: "View bom",
                },
            ],
        },
    };

    const mockExperimentAccessResponse = {
        isPermitted: true,
        AccessDetail: [
            {
                AccessList: "Member",
                CategoryName: "View",
                ExpID: 63_388_299,
                IsPermitted: true,
                Lock: "Unlocked",
                Ownership: "Creator",
                Privacy: "Public",
                Trustee: false,
                AccessFunction: "View bom",
                CreatedByUserName: "Bala",
            },
        ],
    };
    class MockSecurityHelperFunction {
        hasPermission = () => {
            return true;
        };
    }

    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [
                ExperimentAccessHelper,
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: SecurityHelper, useClass: MockSecurityHelperFunction },
                { provide: MatDialogRef, useClass: MockDialogReference },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
                    useValue: { open: () => {} },
                },
            ],
        })));

    beforeEach(() => {
        service = TestBed.inject(ExperimentAccessHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call on getExperimentAccessCheck", () => {
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getExperimentAccessPermission").and.returnValue(mockExperimentAccess);
        spyOn(service, "getExperimentAccessCheck").and.callThrough();
        const data = service.getExperimentAccessCheck(mockExpList, 65_820, EXPERIMENT_ACCESS.VIEW_BOM);
        expect(data).toEqual(mockExperimentAccessResponse as ExperimentAccessResponseModel);
    });

    it("should call on applicationPermissionCheck", () => {
        const mockPayload = {
            AccessList: "Member",
            CategoryName: "View",
            ExpID: 63_388_299,
            Lock: "Unlocked",
            Ownership: "Creator",
            Privacy: "Public",
            Trustee: false,
        };
        spyOn(service, "applicationPermissionCheck").and.callThrough();
        const isPermitted = service.applicationPermissionCheck(mockPayload);
        expect(isPermitted).toBeTruthy();
    });

    it("should call on applicationPermissionCheck", () => {
        const mockPayload = {
            AccessList: "Member",
            CategoryName: "Share",
            ExpID: 63_388_299,
            Lock: "Unlocked",
            Ownership: "Creator",
            Privacy: "Public",
            Trustee: false,
        };
        spyOn(service, "applicationPermissionCheck").and.callThrough();
        const isPermitted = service.applicationPermissionCheck(mockPayload);
        expect(isPermitted).toBeFalsy();
    });

    it("should call on applicationPermissionCheck with trustee", () => {
        const mockPayload = {
            AccessList: "Member",
            CategoryName: "View",
            ExpID: 63_388_299,
            Lock: "Unlocked",
            Ownership: "Creator",
            Privacy: "Public",
            Trustee: true,
            AccessFunction: "Copy to user",
        };
        spyOn(service, "applicationPermissionCheck").and.callThrough();
        const isPermitted = service.applicationPermissionCheck(mockPayload);
        expect(isPermitted).toBeTruthy();
    });

    it("should call on openExperiemntAccessInfoDialog", () => {
        const spy = spyOn(service, "openExperiemntAccessInfoDialog").and.callThrough();
        service.openExperiemntAccessInfoDialog(mockExperimentAccessResponse, 63_388_299);
        expect(spy).toHaveBeenCalled();
    });
});
