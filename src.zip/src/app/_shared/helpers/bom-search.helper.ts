import { ElementRef, Injectable, QueryList, Renderer2, RendererFactory2 } from "@angular/core";
import {
    CartItemModel,
    DisplayValueModel,
    ExpTrusteeModel,
    LastUsedColumnLayoutModel,
    NewOldCartItemModel,
    NewUpdatedCartItemModel,
} from "@te-experiment-editor/models/experiment-editor.model";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { BaseColumnHelper } from "@te-shared/components/base-column-layout/helper/base-column-helper";
import {
    ELEMENT_REF_VALUE,
    MARK_FOR_DELETE_FLAG,
    MARK_FOR_UNDELETE_FLAG,
    STORE_HEADER_WIDTH_MAP,
} from "@te-shared/constants/experiment.constant";
import { findIndex, delay, filter } from "lodash";
import { MatAutocompleteTrigger } from "@angular/material/autocomplete";
import { IS_DELETE } from "@te-experiment-editor/constants/experiment-editor.constant";
import { EMPTY } from "../../app.constant";
import { ExperimentUtil } from "../../experiment-editor/helpers/experiment.util";
import { ColumnLayoutHelper } from "../../master-data/helpers/column.layout.helper";
import { CRITERIA_LIST } from "../components/base-ipc-layout/base-ipc-layout-constant";
import {
    COLUMN_ATTRIBUTE_DISPLAY_LIST,
    COST_ATTRIBUTES,
    DEFAULT_PRODUCT_SEARCH_SORT,
    DIRECT_SORT_COLUMN,
    DIRECT_SORT_COLUMN_WITHKEY,
    NESTED_SORT_COLUMNS,
    NUMRIC_LIMITS,
    SORT_COLUMNS,
    STOCK_UNIT_DISPLAY,
} from "../constants/common.constant";
import { CartItemsModel, DirectColumnModel, NestedColumnModel } from "../models/bom-search.model";
import { BomSearchDialogDataModel } from "../models/dialog.model";
import { SortEventModel } from "../models/experiments.model";
import { AppCacheHelper } from "./app-cache.service";
import { ExperimentBomUtil } from "./experiment-bom.util";
import { TabHelper } from "./tab-helper";

@Injectable()
export class BomSearchHelper {
    private renderer: Renderer2;

    constructor(private readonly appCacheHelper: AppCacheHelper, public readonly tabHelper: TabHelper, rendererFactory: RendererFactory2) {
        // eslint-disable-next-line unicorn/no-null
        this.renderer = rendererFactory.createRenderer(null, null);
    }

    /**
     * Method to get new and updated BOM details
     *
     * @static
     * @param {CartItemModel[]} miniEditorItems
     * @param {BomSearchDialogDataModel} data
     * @param {CartItemModel[]} workspaceItems
     * @return {NewUpdatedCartItemModel}
     * @memberof BomSearchHelper
     */
    public static getNewAndUpdatedBomItems(
        miniEditorItems: CartItemModel[],
        data: BomSearchDialogDataModel,
        workspaceItems: CartItemModel[],
    ): NewUpdatedCartItemModel {
        const addedItems = miniEditorItems.filter((bom) => bom.ExpFormulaID === EMPTY && +bom.IsDelete === MARK_FOR_UNDELETE_FLAG);
        const updatedItems = [];
        if (!data.bomDetails) {
            return { addedItems, updatedItems };
        }
        data.bomDetails.forEach((bom) => {
            const formulaIdKey = ExperimentBomUtil.getFormulaIdKey(data.activeExperiment.ExpCode);
            const bomIndex = findIndex(miniEditorItems, { ExpFormulaID: bom[formulaIdKey] });
            if (
                (bomIndex !== -1 &&
                    (miniEditorItems[bomIndex].IsDelete !== bom.IsDelete ||
                        ExperimentUtil.parseFloatWithGivenDecimals(miniEditorItems[bomIndex].Parts, NUMRIC_LIMITS.DECIMAL_LIMIT) !==
                            ExperimentUtil.parseFloatWithGivenDecimals(bom[data.activeExperiment.ExpCode], NUMRIC_LIMITS.DECIMAL_LIMIT))) ||
                !ExperimentUtil.areElementPositionsSame(miniEditorItems, workspaceItems)
            ) {
                updatedItems.push(miniEditorItems[bomIndex]);
            }
        });
        return { addedItems, updatedItems };
    }

    /**
     * Method to check if either BOM items are added, updated, soft deleted, removed or if position of BOM is changed
     *
     * @memberof BomSearchHelper
     */
    public static isBOMChanged(cartItems: CartItemsModel): boolean {
        const { addedItems, updatedItems, deletedItems, softDeletedItems, cartLists, cartListCopy } = cartItems;
        return (
            [...addedItems, ...updatedItems, ...deletedItems, ...softDeletedItems].length > 0 ||
            !ExperimentUtil.areElementPositionsSame(cartLists, cartListCopy)
        );
    }

    /**
     * Method to get the last used column layout
     *
     * @static
     * @return {*}  {LastUsedColumnLayoutModel[]}
     * @memberof BomSearchHelper
     */
    // eslint-disable-next-line consistent-return
    public static getLastUsedColumnLayout(): LastUsedColumnLayoutModel[] {
        const lastUsedLayout = AppStateService.getLastUsedLColumnLayout();
        if (lastUsedLayout?.length === 0) {
            lastUsedLayout.push(BaseColumnHelper.setDefaultAtrributes());
        }
        if (lastUsedLayout?.length) {
            const lastUsedColumnLayout = ColumnLayoutHelper.updateLastUsedColumnLayout(lastUsedLayout[0]);
            lastUsedColumnLayout[0]?.columnLayoutType?.UserColumnLayout?.forEach((col) => {
                if (col.ColumnName === COLUMN_ATTRIBUTE_DISPLAY_LIST.STOCK) {
                    col.ColumnHeader = col.ColumnHeader.includes(STOCK_UNIT_DISPLAY)
                        ? col.ColumnHeader
                        : `${col.ColumnHeader} ${STOCK_UNIT_DISPLAY}`;
                }
                col.isCost = COST_ATTRIBUTES.includes(col.ColumnName);
            });
            return lastUsedColumnLayout;
        }
    }

    /**
     * Method to sort product search columns
     * @param {SortEventModel} sortEvent
     * @param {DisplayValueModel[]} dynamicColumns
     * @return {DirectColumnModel | NestedColumnModel[]}
     * @memberof BomSearchHelper
     */
    public static sortProductSearch(
        sortEvent: SortEventModel,
        dynamicColumns: DisplayValueModel[],
    ): DirectColumnModel | NestedColumnModel[] {
        if (!sortEvent.direction) return DEFAULT_PRODUCT_SEARCH_SORT;
        const isDirectColumns = DIRECT_SORT_COLUMN.find((directColumns) => directColumns === sortEvent.active);
        if (!isDirectColumns) {
            const columnName = dynamicColumns.find((column) => column.value === sortEvent.active)?.columns;
            return this.sortNestedColumns(sortEvent, columnName);
        }
        const sortKey = DIRECT_SORT_COLUMN_WITHKEY[sortEvent.active];
        return {
            [sortKey]: {
                order: sortEvent.direction,
            },
        };
    }

    /**
     * Method to sort product search columns
     * @param {SortEventModel} sortEvent
     * @param {string} columnName
     * @return {NestedColumnModel[]}
     * @memberof BomSearchHelper
     */
    public static sortNestedColumns(sortEvent: SortEventModel, columnName: string): NestedColumnModel[] {
        const sortEventData = sortEvent;
        let toSortColumn = "";
        const isCost = COST_ATTRIBUTES.find((cost) => cost === columnName);
        if (isCost) {
            toSortColumn = CRITERIA_LIST.COST;
            const splittedCostValue = sortEventData.active.split("/")[0];
            sortEventData.active = splittedCostValue;
        } else {
            toSortColumn = NESTED_SORT_COLUMNS[columnName];
        }
        const sortKey = `${SORT_COLUMNS[toSortColumn].value}.${SORT_COLUMNS[toSortColumn].key}`;
        const matchKey = `${SORT_COLUMNS[toSortColumn].value}.${SORT_COLUMNS[toSortColumn].code}`;
        return [
            {
                [sortKey]: {
                    order: sortEventData.direction,
                    nested: {
                        path: SORT_COLUMNS[toSortColumn].value,
                        filter: {
                            match: {
                                [matchKey]: sortEventData.active,
                            },
                        },
                    },
                },
            },
        ];
    }

    /**
     * Method to focus or select search text box
     *
     * @static
     * @param {ElementRef} searchTextBox
     * @param {boolean} shouldSelect
     * @memberof BomSearchHelper
     */
    public static focusOrSelectTextbox(searchTextBox: ElementRef, shouldSelect: boolean) {
        if (shouldSelect) {
            // eslint-disable-next-line no-unused-expressions
            searchTextBox?.nativeElement.select();
        } else {
            // eslint-disable-next-line no-unused-expressions
            searchTextBox?.nativeElement.focus();
        }
    }

    /**
     * Method to switch page focus to first data row
     *
     * @static
     * @param {QueryList<ElementRef>} dataTable
     * @param {number} selectedRowIndex
     * @memberof BomSearchHelper
     */
    public static focusSelectedRowInTable(dataTable: QueryList<ElementRef>, selectedRowIndex: number) {
        const element = dataTable.first[ELEMENT_REF_VALUE].nativeElement.tBodies[0].rows[selectedRowIndex];
        element.focus();
        element.scrollIntoViewIfNeeded();
    }

    /**
     * Method to filter the category values
     *
     * @param {Array<any>} listToFilter
     * @param {string} keyToCheck
     * @param {string} value
     * @memberof BomSearchHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static filterCategoryValues = (listToFilter: Array<any>, keyToCheck: string, value: string): Array<any> => {
        if (!value) return listToFilter;

        const filterValue = value?.toLowerCase();
        const result = listToFilter.filter((category) => category[keyToCheck]?.toLowerCase().includes(filterValue));
        return result.length === 0 ? [{ [keyToCheck]: "No Matches", disabled: true }] : result;
    };

    /**
     * Method to select Auto-complete option
     *
     * @static
     * @param {MatAutocompleteTrigger} autocompleteTrigger
     * @memberof BomSearchHelper
     */
    public static selectAutocompleteOption(autocompleteTrigger: MatAutocompleteTrigger): void {
        delay(() => {
            // eslint-disable-next-line no-unused-expressions
            autocompleteTrigger?.autocomplete.options.toArray()[0].select();
        }, 0);
    }

    /**
     * Method to store column header width in ngrx store for solution/fema/product search
     * @param {*} tableHeader
     * @param {string} actionFor
     * @return {void}
     * @memberof BomSearchHelper
     */
    public storeColumnLayoutWidth(matTableReference: ElementRef, actionFor: string): void {
        const tableHeader = matTableReference?.nativeElement?.children[0]?.children[0]?.children;
        if (!tableHeader) return;

        let columnHeaders = [];
        // eslint-disable-next-line no-restricted-syntax
        for (const cell of tableHeader) {
            columnHeaders.push({
                headerName: cell.textContent,
                columnWidth: cell.offsetWidth,
            });
        }
        columnHeaders = columnHeaders.filter((header) => header.columnWidth !== 0);
        const currentWorkspace = this.tabHelper.getActiveTab();
        if (STORE_HEADER_WIDTH_MAP[actionFor]) currentWorkspace[STORE_HEADER_WIDTH_MAP[actionFor]] = columnHeaders;

        this.appCacheHelper.storeWorspaceBomSearch([currentWorkspace]);
    }

    /**
     * Method to set last used width in solution/fema/prod search column header
     * @param {*} tableHeader
     * @param {*} renderer
     * @param {string} actionFor
     * @return {void}
     * @memberof BomSearchHelper
     */
    public getColumnHeaderWidth(matTableReference: ElementRef, actionFor: string): void {
        const tableHeader = matTableReference?.nativeElement?.children[0]?.children[0]?.children;
        if (!tableHeader) return;

        this.appCacheHelper.getWorspaceBomSearchFromCache().subscribe((workspace) => {
            const currentWorkspace = this.tabHelper.getActiveTab();
            const matchWorkspace = workspace?.find((data) => data?.UserTabID === currentWorkspace?.UserTabID);
            if (!matchWorkspace) return;

            if (STORE_HEADER_WIDTH_MAP[actionFor]) {
                this.setResizedHeaderWidth(matchWorkspace[STORE_HEADER_WIDTH_MAP[actionFor]], tableHeader);
            }
        });
    }

    // eslint-disable-next-line class-methods-use-this
    public setResizedHeaderWidth(columnHeaders, tableHeader): void {
        // eslint-disable-next-line no-restricted-syntax
        for (const cell of tableHeader) {
            // eslint-disable-next-line no-unused-expressions
            columnHeaders?.forEach((header) => {
                if (header.headerName === cell.textContent) {
                    this.renderer.setStyle(cell, "min-width", `${header.columnWidth}px`);
                    this.renderer.setStyle(cell, "max-width", `${header.columnWidth}px`);
                }
            });
        }
    }

    /**
     * Method to construct new cart object
     * @param {Array<CartItemModel>} cartLists
     * @returns {NewOldCartItemModel}
     */
    public static getNewAndOldBomItems(cartLists: Array<CartItemModel>): NewOldCartItemModel {
        const oldCartItems = filter(cartLists, (cartItem) => cartItem[IS_DELETE] !== MARK_FOR_DELETE_FLAG);
        const newCartItems = filter(cartLists, (cartItem) => cartItem.isNewlyAddedItem);
        return { oldCartItems, newCartItems };
    }

    /** *
     * Method to extract trustee display name
     * @param {ExpTrusteeModel} row
     * @returns {string}
     */
    public static getTrusteeDisplayName(row: ExpTrusteeModel): string {
        if (row?.otherdetails?.trusteeInfo?.displayname) {
            return row?.otherdetails?.trusteeInfo?.displayname || EMPTY;
        }
        return row?.otherdetails?.trusteeInfo?.fullname || EMPTY;
    }
}
