/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from "@angular/core";
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { Observable } from "rxjs";
import { map, take } from "rxjs/operators";
import { TasteEditorDialogModel } from "../models/te-dialog.model";

@Injectable({
    providedIn: "root",
})
export class TasteEditorDialogService {
    constructor(private dialog: MatDialog) {}

    dialogRef: MatDialogRef<any>;

    /**
     * Method to open the Mat Dialog with the passed options
     * @param {$event} componentOrTemplateReference arguments
     * @param {TasteEditorDialogModel} options arguments
     * @memberof TasteEditorDialogService
     */
    public open(componentOrTemplateReference: any, options: TasteEditorDialogModel) {
        // eslint-disable-next-line @typescript-eslint/naming-convention
        const { data, panelClass, width, autoFocus, disableClose } = options;
        this.dialogRef = this.dialog.open(componentOrTemplateReference, {
            panelClass,
            width,
            autoFocus,
            disableClose,
            data: {
                title: data.title,
                message: data.message,
                cancelText: data?.cancelText,
                confirmText: data?.confirmText,
                extraConfirmText: data?.extraConfirmText,
                dialogData: data.dialogData,
            },
        });
    }

    /**
     * Method to handle the dialog confirmation on closing the dialog
     * @memberof TasteEditorDialogService
     */
    public dialogConfirm(): Observable<any> {
        return this.dialogRef.afterClosed().pipe(
            take(1),
            map((data) => {
                return data;
            }),
        );
    }
}
