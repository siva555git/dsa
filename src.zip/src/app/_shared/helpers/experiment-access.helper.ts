import { Injectable } from "@angular/core";
import { every, filter, find, forEach, map } from "lodash";
import { MatDialog } from "@angular/material/dialog";
import { ConfirmationDialogComponent } from "../components/confirmation-dialog/confirmation-dialog.component";
import { EXPERIMENT_ACCESS, PERMISSION_CATEGORY_CONSTANT } from "../constants/experiment-access.constant";
import { APPLICATION_PERMISSIONS, EXPERIMEMT_ACCESS_CATEGORY } from "../security/security.constant";
import { SecurityHelper } from "../security/helpers/security.helper";
import {
    COMMON_EXPERIMENT_ACCESS_DIALOG,
    COOPERATOR_ACCESS,
    EXPERIMENT_ACCESS_NOT_PERMITTED_MSG,
    EXPERIMENT_ACCESS_RESPONSE,
    LOCKED_BY_STATUS,
    USER_ATTRIBUTES,
} from "../constants/common.constant";
import {
    ExperimentAccessModel,
    ExperimentAccessPermissionModel,
    ExperimentAccessResponseModel,
    FunctionCategoryModel,
    PermissionCategoryModel,
} from "../models/experiment-access-model";
import { AppStateService } from "../../_services/app-state/app.state.service";

@Injectable()
export class ExperimentAccessHelper {
    constructor(
        private readonly appState: AppStateService,
        public readonly securityHelper: SecurityHelper,
        private readonly dialog: MatDialog,
    ) {}

    /**
     * Method to generate experiment access check payload
     * @param experimentList
     * @param {number} userID
     * @param {string} accessFunction
     * @returns {ExperimentAccessResponseModel}
     * @memberof ExperimentAccessHelper
     */
    public getExperimentAccessCheck(experimentList, userID: number, accessFunction: string): ExperimentAccessResponseModel {
        const experimentAccessList = [];
        let hasAccess = false;
        const experimentAccessInfo: ExperimentAccessPermissionModel = this.appState.getExperimentAccessPermission();
        const permissionCategory: PermissionCategoryModel[] = experimentAccessInfo.ExperimentAccess.PermissionCategory;
        const functionCategory: FunctionCategoryModel[] = experimentAccessInfo.ExperimentAccess.FunctionCategory;
        const categoryName = find(functionCategory, (category) => category.AccessFunction.toLowerCase() === accessFunction.toLowerCase());
        forEach(experimentList, (expDetail) => {
            hasAccess =
                expDetail?.CreatedBy === userID ||
                (expDetail?.ExperimentStaffDetails &&
                    expDetail?.ExperimentStaffDetails.length > 0 &&
                    map(
                        filter(expDetail?.ExperimentStaffDetails, (exp) => exp.StaffType === COOPERATOR_ACCESS.ACCESSLIST),
                        USER_ATTRIBUTES.USER_ID,
                    ).includes(userID)) ||
                expDetail?.ExpAccessStatus;
            const payload: ExperimentAccessModel = {
                Ownership:
                    expDetail?.CreatedBy === userID ? PERMISSION_CATEGORY_CONSTANT.CREATOR : PERMISSION_CATEGORY_CONSTANT.NOT_CREATOR,
                Lock:
                    expDetail?.IsLocked === LOCKED_BY_STATUS.LOCKED || expDetail?.IsLocked === +LOCKED_BY_STATUS.LOCKED
                        ? PERMISSION_CATEGORY_CONSTANT.LOCKED
                        : PERMISSION_CATEGORY_CONSTANT.UNLOCKED,
                Privacy: expDetail?.IsPublic ? PERMISSION_CATEGORY_CONSTANT.PUBLIC : PERMISSION_CATEGORY_CONSTANT.PRIVATE,
                AccessList: hasAccess ? PERMISSION_CATEGORY_CONSTANT.MEMBER : PERMISSION_CATEGORY_CONSTANT.NOT_MEMBER,
                CategoryName: categoryName ? categoryName.CategoryName : "",
                ExpID: expDetail?.ExpID,
                Trustee: expDetail?.Trustee ? expDetail.Trustee === userID : false,
                AccessFunction: accessFunction,
                CreatedByUserName: expDetail?.CreatedByUser
                    ? `${expDetail.CreatedByUser?.FirstName} ${expDetail.CreatedByUser?.Surname}`
                    : expDetail?.CreatedByName,
            };
            payload.IsPermitted = this.getPermission(payload, permissionCategory);
            experimentAccessList.push(payload);
        });
        const isAllowed = every(experimentAccessList, PERMISSION_CATEGORY_CONSTANT.IS_PERMITTED);
        return { isPermitted: isAllowed, AccessDetail: experimentAccessList };
    }

    /**
     * Method to get experiemnt access permission
     * @param {ExperimentAccessModel} payload
     * @param {PermissionCategoryModel[]} permissionCategory
     * @returns {boolean}
     * @memberof ExperimentAccessHelper
     */
    public getPermission(payload: ExperimentAccessModel, permissionCategory: PermissionCategoryModel[]): boolean {
        if (this.applicationPermissionCheck(payload)) {
            return true;
        }
        return find(permissionCategory, (category) => {
            return (
                category.CategoryName === payload.CategoryName &&
                category.Ownership === payload.Ownership &&
                category.Lock === payload.Lock &&
                category.Privacy === payload.Privacy &&
                category.AccessList === payload.AccessList
            );
        }).IsPermitted;
    }

    /**
     * Method to check application permission
     * @param {ExperimentAccessModel} payload
     * @returns {boolean}
     * @memberof ExperimentAccessHelper
     */
    public applicationPermissionCheck(payload: ExperimentAccessModel): boolean {
        return !!(
            (payload.Trustee &&
                (payload.AccessFunction === EXPERIMENT_ACCESS.COPY_TO_USER ||
                    payload.CategoryName === EXPERIMEMT_ACCESS_CATEGORY.VIEW ||
                    payload.CategoryName === EXPERIMEMT_ACCESS_CATEGORY.COPY)) ||
            (this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.EXPERIMENT_COPY_PERMISSION) &&
                (payload.CategoryName === EXPERIMEMT_ACCESS_CATEGORY.COPY || payload.AccessFunction === EXPERIMENT_ACCESS.COPY_TO_USER)) ||
            (this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.EXPERIMENT_VIEW_PERMISSION) &&
                payload.CategoryName === EXPERIMEMT_ACCESS_CATEGORY.VIEW) ||
            (this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.GLOBAL_EXPERIMENT_PRINT) &&
                payload.CategoryName === EXPERIMEMT_ACCESS_CATEGORY.PRINT)
        );
    }

    /**
     * Method to open experiment access info dialog popup
     * @param {ExperimentAccessResponseModel} accessInfo
     * @param {number} expID
     * @memberof ExperimentAccessHelper
     */
    public openExperiemntAccessInfoDialog(accessInfo: ExperimentAccessResponseModel, expID: number): void {
        const expAccessDetail = find(accessInfo?.AccessDetail, (data) => data.ExpID === expID);
        const dialogOptions = COMMON_EXPERIMENT_ACCESS_DIALOG;
        const dialogMessage = EXPERIMENT_ACCESS_RESPONSE;
        dialogMessage.message = EXPERIMENT_ACCESS_NOT_PERMITTED_MSG;
        dialogMessage.experimentAccessInfo = expAccessDetail;
        dialogOptions.data = dialogMessage;
        this.dialog.open(ConfirmationDialogComponent, dialogOptions);
    }
}
