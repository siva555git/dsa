import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { MockLoggerService } from "../../testing/mock-logger.service";
import { MockAppDataService } from "../../testing/mock-app.data.service";
import { AppBroadCastService, AppDataService } from "../../_services";
import { AgGridUtil } from "./ag-grid-util";
import { mockBomDetailModel, mockCombinePayload, mockGridApiNew } from "../../testing/mock-context-menu.helper";

/* eslint-disable max-lines-per-function */
describe("AgGridUtil", () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: AppBroadCastService,
                    useClass: {},
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
            ],
        });
    });

    it("should call updateGridWithTransaction", () => {
        spyOn(AgGridUtil, "updateGridWithTransaction").and.callThrough();
        AgGridUtil.updateGridWithTransaction(mockGridApiNew, 1, ["Cell1"], ["cell2"], ["cell3"]);
        expect(AgGridUtil.updateGridWithTransaction).toHaveBeenCalled();
    });

    it("should call on getTreeGridKeys", () => {
        spyOn(AgGridUtil, "getTreeGridKeys").and.callThrough();
        const value = "AXA00002AA";
        const key = "_ExpFormulaID";
        AgGridUtil.getTreeGridKeys(value, key);
        expect(AgGridUtil.getTreeGridKeys).toHaveBeenCalled();
    });

    it("should call getGridRowData", () => {
        spyOn(AgGridUtil, "getGridRowData").and.callThrough();
        AgGridUtil.getGridRowData(mockGridApiNew);
        expect(AgGridUtil.getGridRowData).toHaveBeenCalled();
    });

    it("should call getNewlyAddedItemsFromBomDetailsResponse", () => {
        spyOn(AgGridUtil, "getNewlyAddedItemsFromBomDetailsResponse").and.callThrough();
        AgGridUtil.getNewlyAddedItemsFromBomDetailsResponse(mockCombinePayload, mockBomDetailModel);
        expect(AgGridUtil.getNewlyAddedItemsFromBomDetailsResponse).toHaveBeenCalled();
    });

    it("should call getSelectedFolderRowData", () => {
        spyOn(AgGridUtil, "getSelectedFolderRowData").and.callThrough();
        AgGridUtil.getSelectedFolderRowData(mockGridApiNew, "5000185");
        expect(AgGridUtil.getSelectedFolderRowData).toHaveBeenCalled();
    });

    it("should call retainRowFocus", () => {
        spyOn(AgGridUtil, "retainRowFocus").and.callThrough();
        AgGridUtil.retainRowFocus(mockGridApiNew);
        expect(AgGridUtil.retainRowFocus).toHaveBeenCalled();
    });

    it("should call refreshSelectedGridCells", () => {
        spyOn(AgGridUtil, "refreshSelectedGridCells").and.callThrough();
        AgGridUtil.refreshSelectedGridCells(mockGridApiNew, [], [], true);
        expect(AgGridUtil.refreshSelectedGridCells).toHaveBeenCalled();
    });
});
