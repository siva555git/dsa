/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { AppBroadCastService } from "@te-services/index";
import { ExperimentEditorService } from "@te-experiment-editor/helpers/experiment-editor.service";
import { of, throwError } from "rxjs";
import { ToastrService } from "ngx-toastr";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { NGXLogger } from "ngx-logger";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { mockAttributeResponse } from "@te-testing/mock-add-ipc-data";
import { AddIpcListHelper } from "./add-ipc-list.helper";
import { ExperimentApiService } from "./experiment-api.service";

describe("AddIpcListHelper", () => {
    let service: AddIpcListHelper;

    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [
                AddIpcListHelper,
                AppBroadCastService,
                {
                    provide: ExperimentEditorService,
                    useValue: {
                        loadAttributesFromCache: () => {
                            return of([]);
                        },
                    },
                },
                {
                    provide: ExperimentApiService,
                    useValue: {
                        getIpcData: () => {
                            return of([]);
                        },
                    },
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
            ],
        })));

    beforeEach(() => {
        service = TestBed.inject(AddIpcListHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call on fetchIPCDetail", () => {
        const spy = spyOn(service, "fetchIPCDetail").and.callThrough();
        const experimentEditorService: ExperimentEditorService = TestBed.inject(ExperimentEditorService);
        spyOn(experimentEditorService, "loadAttributesFromCache").and.returnValue(
            // eslint-disable-next-line sonarjs/no-duplicate-string
            of([{ ipc: "1RR04333", description: "FOREST FRUIT", prodtypecode: "LIQUID-CONTAINS ALCOHOL" }]),
        );
        const experimentApiService: ExperimentApiService = TestBed.inject(ExperimentApiService);
        spyOn(experimentApiService, "getIpcData").and.returnValue(of([{ ipc: "1RR04332", description: "BERRY KEY", prodtypecode: "KEY" }]));
        service.fetchIPCDetail(["1RR04333", "1RR0332"], "Single ipc upload");
        expect(spy).toHaveBeenCalled();
    });

    // const service = TestBed.inject(AppDataService);
    // spyOn(service, "post").and.returnValue(throwError(() => {}));

    it("should call on fetchIPCDetail 1", () => {
        const spy = spyOn(service, "fetchIPCDetail").and.callThrough();
        const experimentEditorService: ExperimentEditorService = TestBed.inject(ExperimentEditorService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(experimentEditorService, "loadAttributesFromCache").and.returnValue(throwError(() => {}));
        service.fetchIPCDetail(["1RR04333", "1RR0332"], "Single ipc upload");
        expect(spy).toHaveBeenCalled();
    });

    it("should call on fetchIPCDetail 2", () => {
        const spy = spyOn(service, "fetchIPCDetail").and.callThrough();
        const experimentEditorService: ExperimentEditorService = TestBed.inject(ExperimentEditorService);
        spyOn(experimentEditorService, "loadAttributesFromCache").and.returnValue(
            of([{ ipc: "1RR04333", description: "FOREST FRUIT", prodtypecode: "LIQUID-CONTAINS ALCOHOL" }]),
        );
        const experimentApiService: ExperimentApiService = TestBed.inject(ExperimentApiService);
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        spyOn(experimentApiService, "getIpcData").and.returnValue(throwError(() => {}));
        service.fetchIPCDetail(["1RR04333", "1RR0332"], "Bulk ipc upload");
        expect(spy).toHaveBeenCalled();
    });

    it("should call on fetchIPCDetail 3", () => {
        const spy = spyOn(service, "fetchIPCDetail").and.callThrough();
        const experimentEditorService: ExperimentEditorService = TestBed.inject(ExperimentEditorService);
        spyOn(experimentEditorService, "loadAttributesFromCache").and.returnValue(
            of([
                { ipc: "1RR04333", description: "FOREST FRUIT", prodtypecode: "LIQUID-CONTAINS ALCOHOL" },
                { ipc: "1RR04332", description: "BERRY KEY", prodtypecode: "KEY" },
            ]),
        );
        service.fetchIPCDetail(["1RR04333", "1RR0332"], "Bulk ipc upload");
        expect(spy).toHaveBeenCalled();
    });

    it("should call on checkForDuplicateAndInvalidIpc", () => {
        const existingIpcList = [
            {
                ipc: "1RR04333",
                description: "FOREST FRUIT",
                productType: "LIQUID-CONTAINS ALCOHOL",
                isNewlyAdded: false,
            },
        ];
        const mockResponse = [
            {
                ipc: "1RR04333",
                isDuplicate: true,
                isInvalid: false,
            },
            {
                ipc: "00010000",
                isDuplicate: false,
                isInvalid: false,
            },
        ];
        spyOn(service, "checkForDuplicateAndInvalidIpc").and.callThrough();
        const response = service.checkForDuplicateAndInvalidIpc([{ ipc: "1RR04333" }, { ipc: "00010000" }], existingIpcList);
        expect(response).toEqual(mockResponse);
    });

    it("should call on checkForInvalidIpc", () => {
        const mockIpcList = [
            {
                ipc: "1RR04333",
                isDuplicate: true,
                isInvalid: false,
            },
            {
                ipc: "00010000",
                isDuplicate: false,
                isInvalid: false,
            },
        ];
        spyOn(service, "checkForInvalidIpc").and.callThrough();
        const response = service.checkForInvalidIpc(mockIpcList, mockAttributeResponse.attributes);
        expect(response).toEqual(mockIpcList);
    });

    it("should call on getValidIpcs", () => {
        const mockIpcList = [
            {
                ipc: "1RR04333",
                isDuplicate: true,
                isInvalid: false,
            },
            {
                ipc: "00010000",
                isDuplicate: false,
                isInvalid: false,
            },
        ];
        spyOn(service, "getValidIpcs").and.callThrough();
        const response = service.getValidIpcs(mockIpcList);
        expect(response).toEqual(["00010000"]);
    });
});
