import * as moment from "moment";
import { CostAttributes } from "../../experiment-editor/models/column-fields";
import { APPEND_COST_ATTRIBUTES, COOPERATOR_ACCESS, DEFAULT_CURRENCY } from "../constants/common.constant";
import { EXPERIMENT_SUB_OPTIONS } from "../constants/context-menu.constant";
import { CurrencyRateModel } from "../models/currencies-rate-model";
import { ExperimentsModel } from "../models/experiment-bom.model";
import { CooperatorAccessData, RefreshExperimentHeaderModel } from "../models/experiments.model";
import { SelectedRowDataModel } from "../models/selected-row-data.model";

export class SharedExperimentUtil {
    /**
     * Method to generate the refresh experiment header payload, refreshes the experiment header values
     * @param {string} refreshType
     * @param {any} refreshData
     * @returns {RefreshExperimentHeaderModel}
     * @memberof SharedExperimentUtil
     */
    public static createRefreshExperimentHeader(refreshType: string, refreshData): RefreshExperimentHeaderModel {
        return {
            refreshType,
            refreshData,
        };
    }

    /**
     * Method to open from access-coopertor list
     * @param {string} type
     * @param {SelectedRowDataModel} selectedExperiments
     * @returns {CooperatorAccessData}
     * @memberof SharedExperimentUtil
     */
    public static getCooperatorAccessData(type: string, selectedExperiments: SelectedRowDataModel): CooperatorAccessData {
        const accessData: CooperatorAccessData = {
            expId: selectedExperiments.ExpID,
            currentPage: type === EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS ? COOPERATOR_ACCESS.ACCESSLIST : COOPERATOR_ACCESS.COOPERATOR,
            expCode: selectedExperiments.ExpCode,
        };
        return accessData;
    }

    /**
     * Method to find cost attributes
     *
     * @param {string} columnName
     * @returns {CostAttributes}
     * @memberof SharedExperimentUtil
     */
    public static findCostAttributes(columnName: string): CostAttributes {
        const value = APPEND_COST_ATTRIBUTES.find((costValue) => columnName === costValue.costValue);
        return value;
    }

    /**
     * Method to find experiment data
     *
     * @param {ExperimentsModel[]} userTabDetails
     * @param {string} expCode
     * @returns {ExperimentsModel}
     * @memberof SharedExperimentUtil
     */
    public static getExperimentBasedOnExpCode(userTabDetails: ExperimentsModel[], expCode: string): ExperimentsModel {
        return userTabDetails.find((exp) => exp.ExpCode === expCode);
    }

    /**
     * Method to find rate for the selected currency
     *
     * @static
     * @param {string} currencyCode
     * @param {CurrencyRateModel[]} currencyRates
     * @return {*}  {number}
     * @memberof SharedExperimentUtil
     */
    public static getcurrencyRate(currencyCode: string, currencyRates: CurrencyRateModel[]): number {
        const currencyRate = currencyRates.find(
            (rate) => rate.CurrencyFrom === currencyCode && rate.CurrencyTo === DEFAULT_CURRENCY.ColumnValue,
        );
        // eslint-disable-next-line unicorn/prefer-logical-operator-over-ternary
        return Number(currencyRate?.Rate) ? Number(currencyRate?.Rate) : 1;
    }

    /**
     * Format date required for Experiment Cost
     *
     * @param {Date} updatedDate
     * @returns {string}
     * @memberof SharedExperimentUtil
     */
    public static getFormattedDate = (updatedDate: Date): string => {
        return moment(new Date(updatedDate)).format("DD-MMM-yyyy hh:mmA");
    };
}
