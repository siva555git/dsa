import { Injectable } from "@angular/core";
import { BomSearchDialogDataModel } from "@te-shared/models/dialog.model";
import { EXP_ID } from "@te-shared/constants/common.constant";
import { EditionSuggestionProductRow, CartItemModel } from "../../experiment-editor/models/experiment-editor.model";
import { EditionSuggesstionHelper } from "../../experiment-editor/helpers/edition-suggesstion.helper";
import { EMPTY } from "../../app.constant";
import { ExperimentBomUtil } from "./experiment-bom.util";

@Injectable({
    providedIn: "root",
})
export class MiniEditorSuggestionHelper {
    constructor(private readonly editionSuggesstionHelper: EditionSuggesstionHelper) {}

    /**
     * Method to trgger edition suggestion popup
     *
     * @param {EditionSuggestionProductRow} productRow
     * @param {BomSearchDialogDataModel} gridData
     * @param {number} selectedCartItemIndex
     * @param {string} actionFor
     * @param {CartItemModel[]} cartLists
     *
     * @return {void}
     * @memberof MiniEditorSuggestionHelper
     */
    public triggerEditSuggestPopup(
        productRow: EditionSuggestionProductRow,
        gridData: BomSearchDialogDataModel,
        selectedCartItemIndex: number,
        actionFor: string,
        cartLists?: CartItemModel[],
    ): void {
        const editionSuggestionProductRow: EditionSuggestionProductRow = productRow;

        if (productRow?.ExpFormulaID) {
            // find the attribute that has to be presented with Suggestion
            editionSuggestionProductRow.parentAttribute = EditionSuggesstionHelper.findAttributeOnSubCode(
                gridData.attributes,
                editionSuggestionProductRow.SUBCode,
            );

            const activeExperimentBom = ExperimentBomUtil.getTopLevelExperimentByExpIdAndType(
                gridData.activeExperiment.ExpID,
                gridData.bomDetail.Experiments,
                gridData.activeExperiment?.Type,
            );
            editionSuggestionProductRow.suggestedBom = ExperimentBomUtil.getSingleExperimentFormula(
                productRow.ExpFormulaID,
                activeExperimentBom,
            );
        } else {
            editionSuggestionProductRow.parentAttribute = productRow.otherdetails;
            editionSuggestionProductRow.suggestedBom = {
                ExpFormulaID: EMPTY,
                ExpID: gridData[EXP_ID],
                FormulaSeq: selectedCartItemIndex * 10,
                IsDelete: productRow.IsDelete,
                Parts: productRow.Parts,
                SUBCode: productRow.SUBCode,
                SUBType: productRow.SUBType,
            };
        }
        editionSuggestionProductRow.activeExpPlantId = gridData.activeExperiment?.PlantID;
        editionSuggestionProductRow.activeExpSource = gridData.activeExperiment?.SourceFlagCodeID;
        editionSuggestionProductRow.activeExpCode = gridData.activeExperiment?.ExpCode;
        this.editionSuggesstionHelper.openEditionSuggestion(editionSuggestionProductRow, gridData.facility, actionFor, cartLists, gridData);
    }

    /**
     * Method to check whether solution and fema exist
     *
     * @param {CartItemModel} newlyAddedCartItem
     *
     * @return {CartItemModel}
     * @memberof MiniEditorSuggestionHelper
     */
    public static doesSolutionAndFemaExist(newlyAddedCartItem: CartItemModel): CartItemModel {
        const cartItemWithSuggestion = newlyAddedCartItem;
        cartItemWithSuggestion.isFema = EditionSuggesstionHelper.doesFemaExist(newlyAddedCartItem.otherdetails);
        cartItemWithSuggestion.isSolution = EditionSuggesstionHelper.doesSolutionExist(newlyAddedCartItem.otherdetails);
        cartItemWithSuggestion.isEnum = EditionSuggesstionHelper.doesENumExist(newlyAddedCartItem.otherdetails);
        cartItemWithSuggestion.isVariant = EditionSuggesstionHelper.doesVariantExist(newlyAddedCartItem?.otherdetails);
        return cartItemWithSuggestion;
    }
}
