/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { DISPLAY_GRID_DATA } from "../../testing/mock-display-grid.helper";
import { mockActiveExperiment } from "../../testing/mock-ag-grid-data";
import { mockBomDetailExperiments } from "../../testing/mock-context-menu.helper";
import { experimentsFromCart } from "../../testing/mock-update-bom-helper";
import { SearchDrawerHelper } from "./search-drawer.helper";
import { MockAppcacheHelper } from "../../testing/mock-app-cache-helper";
import { AppCacheHelper } from "./app-cache.service";
import { MockTabHelperService } from "../../testing/mock-tabhelper.service";
import { TabHelper } from "./tab-helper";

describe("SearchDrawerHelper", () => {
    let service: SearchDrawerHelper;
    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [
                SearchDrawerHelper,
                {
                    provide: AppCacheHelper,
                    useValue: MockAppcacheHelper,
                },
                {
                    provide: TabHelper,
                    useClass: MockTabHelperService,
                },
            ],
        })));

    beforeEach(() => {
        service = TestBed.inject(SearchDrawerHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    xit("should resolve for isMaxExpExceeds()", () => {
        spyOn(SearchDrawerHelper, "isMaxExpExceeds").and.callThrough();
        SearchDrawerHelper.isMaxExpExceeds(mockBomDetailExperiments, experimentsFromCart);
        expect(SearchDrawerHelper.isMaxExpExceeds).toHaveBeenCalled();
    });

    xit("should resolve for isMaxExpExceeds()", () => {
        spyOn(SearchDrawerHelper, "isMaxExpExceeds").and.callThrough();
        SearchDrawerHelper.isMaxExpExceeds([], experimentsFromCart);
        expect(SearchDrawerHelper.isMaxExpExceeds).toHaveBeenCalled();
    });

    it("should resolve for isAlreadyOpened() true", () => {
        spyOn(SearchDrawerHelper, "isAlreadyOpened").and.callThrough();
        SearchDrawerHelper.isAlreadyOpened(mockActiveExperiment, mockBomDetailExperiments);
        expect(SearchDrawerHelper.isAlreadyOpened).toHaveBeenCalled();
    });

    it("should resolve for isAlreadyOpened() false", () => {
        mockBomDetailExperiments[0].ExpCode = "AXA00003AA";
        spyOn(SearchDrawerHelper, "isAlreadyOpened").and.callThrough();
        SearchDrawerHelper.isAlreadyOpened(mockActiveExperiment, mockBomDetailExperiments);
        expect(SearchDrawerHelper.isAlreadyOpened).toHaveBeenCalled();
    });

    it("should resolve for isAddedInCart() true", () => {
        mockBomDetailExperiments[0].ExpCode = "AXA00003AA";
        spyOn(SearchDrawerHelper, "isAddedInCart").and.callThrough();
        SearchDrawerHelper.isAddedInCart(mockActiveExperiment, experimentsFromCart);
        expect(SearchDrawerHelper.isAddedInCart).toHaveBeenCalled();
    });

    it("should resolve for isAddedInCart() false", () => {
        spyOn(SearchDrawerHelper, "isAddedInCart").and.callThrough();
        SearchDrawerHelper.isAddedInCart(mockActiveExperiment, experimentsFromCart);
        expect(SearchDrawerHelper.isAddedInCart).toHaveBeenCalled();
    });

    it("should resolve for configUnapprovedHeaderColumns()", () => {
        spyOn(SearchDrawerHelper, "configUnapprovedHeaderColumns").and.callThrough();
        const response = SearchDrawerHelper.configUnapprovedHeaderColumns();
        expect(response).toEqual(DISPLAY_GRID_DATA.unApprovedSearchColumns);
    });
});
