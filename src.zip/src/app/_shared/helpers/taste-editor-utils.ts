import { Injectable } from "@angular/core";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { USER_PREFERENCES_TYPES } from "@te-shared/constants";
import { SUBTypes } from "@te-shared/enums";
import { cloneDeep, find, forEach, includes, map } from "lodash";
import { of, Subscription } from "rxjs";
import { distinct } from "rxjs/operators";
import { BOM_DETAILS_CONSTANTS } from "@te-shared/constants/experiment.constant";
import { EMPTY } from "src/app/app.constant";
import { REVIEW_BY_LIST } from "../../creative-review/creative-review.constant";
import { CurrenciesModel } from "../../experiment-editor/models/currencies-model";
import {
    DEFAULT_EXPERIMENT_FOLDER,
    DEFAULT_SPEC_FLASHPOINT,
    EXP_ID,
    FOLDER_DESCRIPTION,
    PATH_URL,
    TITLE_CHANGE_URL_LIST,
} from "../constants/common.constant";
import { BomDetailExperimentsModel } from "../models/experiment-bom.model";
import { FacilitiesModel } from "../models/facilities-model";

@Injectable()
export class TasteEditorUtilClass {
    /**
     * Un subscribe all the subscription list passed in to the function, this function will be called on every component destroy method.
     *
     * @param {Subscription[]} subscriptionList
     * @memberof TasteEditorUtilClass
     * @returns {void}
     */
    public static removeSubscriptions(subscriptionList: Subscription[]): void {
        subscriptionList.forEach((subscription) => {
            // eslint-disable-next-line no-unused-expressions
            subscription?.unsubscribe();
        });
    }

    /**
     * Method to update some activation fields in the loaded tabs response and send notification to the subscribed methods to load the tabs
     * @param {Object} flavorTypes
     * @memberof TasteEditorUtilClass
     * @returns {any}
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static flavourTypesChecked(flavorTypes: any): any {
        const flavors = cloneDeep(flavorTypes);
        forEach(flavors, (flavor) => {
            const listData = flavor;
            listData.checked = false;
        });
        return flavors;
    }

    /**
     * returns the facility based on the costbook code match
     * @param {FacilitiesModel[]} facilitiesDetails
     * @param {string} facilityKey
     * @param {any} facilitiyValue
     * @memberof TasteEditorUtilClass
     * @returns {FacilitiesModel}
     */
    public static getFacilityDetail(facilitiesDetails: FacilitiesModel[], facilityKey: string, facilitiyValue): FacilitiesModel {
        const facilityDetail = find(facilitiesDetails, [facilityKey, facilitiyValue]);
        return facilityDetail;
    }

    /**
     * filters the collection based on the values list. The valuesToFilter contains an array of items, those items are gets filted from the colelctionvalues based on the keyToFilter
     * @param {BomDetailExperimentsModel[]} collectionValues
     * @param {number[]} valuesToFilter
     * @param {string} keyToFilter
     * @memberof TasteEditorUtilClass
     * @returns {BomDetailExperimentsModel}
     */
    public static filterCollectionsBasedOnList(
        collectionValues: BomDetailExperimentsModel[],
        valuesToFilter: number[],
        expFormulaId?: string | boolean,
    ): BomDetailExperimentsModel[] {
        return collectionValues
            .filter((value) => valuesToFilter.includes(value?.BOMType === SUBTypes.PRODUCT ? value[REVIEW_BY_LIST.IPC] : value[EXP_ID]))
            .filter((value) => (expFormulaId ? value[BOM_DETAILS_CONSTANTS.EXP_FORMULA_ID] === expFormulaId : true));
    }

    /**
     * Method to remove duplicate elements in an Array
     *
     * @static
     * @param {Array<unknown>} dataSource
     * @param {string} objectKey
     * @return {*}  {Array<any>}
     * @memberof TasteEditorUtilClass
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getUniqueListBy(dataSource: Array<unknown>, objectKey: string): Array<any> {
        if (!dataSource || dataSource.length === 0) return [];

        if (dataSource.length < 1000) {
            const bindingFunction = (object) => object[objectKey];
            // eslint-disable-next-line func-names
            return dataSource.filter(function (dataObject) {
                return !this.has(bindingFunction(dataObject)) && this.add(bindingFunction(dataObject));
                // eslint-disable-next-line unicorn/no-array-method-this-argument
            }, new Set());
        }

        let finalResult = [];
        of(dataSource)
            .pipe(distinct((item) => item[objectKey]))
            .subscribe((uniqueResult) => {
                finalResult = uniqueResult;
            });
        return finalResult;
    }

    /**
     * Method to check if key is default folder
     *
     * @static
     * @param {string} folderDescription
     * @return {*}  {boolean}
     * @memberof TasteEditorUtilClass
     */
    public static isDefaultFolder(folderDescription: string): boolean {
        return includes(map(DEFAULT_EXPERIMENT_FOLDER, FOLDER_DESCRIPTION), folderDescription);
    }

    /**
     * Method to filter selected currency code
     * @param {string} currencyCode
     * @param {CurrenciesModel[]} currencies
     * @returns {CurrenciesModel}
     * @memberof TasteEditorUtilClass
     */
    public static getCurrencyCode(currencies: CurrenciesModel[], currencyCode: string): CurrenciesModel {
        return currencies.find((currency) => currency.currencycode === currencyCode);
    }

    /**
     * Method to get the user default flashpoint
     * @returns {string}
     * @memberof TasteEditorUtilClass
     */
    public static getUserDefaultFlashpoint(): string {
        const userDefaultPreference = AppStateService.getUserDefaultPreferenceType();
        const userDefaultFlashPoint = find(userDefaultPreference, (data) => data.PrefTypeCode === USER_PREFERENCES_TYPES.FLASHPOINT_CODE);
        return userDefaultFlashPoint?.ColumnValue ?? DEFAULT_SPEC_FLASHPOINT.DEFAULT_VALUE;
    }

    /**
     * Method to get the user default Plant
     * @returns {string}
     * @memberof TasteEditorUtilClass
     */
    public static getUserDefaultplant(): string {
        const userDefaultPreference = AppStateService.getUserDefaultPreferenceType();
        const userDefaultPlant = find(userDefaultPreference, (data) => data.PrefTypeCode === USER_PREFERENCES_TYPES.PLANT_CODE);
        return userDefaultPlant?.ColumnValue ?? EMPTY;
    }

    /**
     * Method to convert the flashpoint values from celsius to Fahrenheit or vice versa
     * @param bomItem
     * @returns {string}
     * @memberof TasteEditorUtilClass
     */
    public static flashPointConversion(bomItem): string {
        let convertedValue = bomItem.value;
        if (bomItem.colDef?.headerName !== DEFAULT_SPEC_FLASHPOINT.COLUMN_NAME && !bomItem.FLASHPOINT) return convertedValue;

        const flashPointValue = bomItem.value || bomItem.FLASHPOINT;
        if (!flashPointValue) return convertedValue;

        const defaultValues = TasteEditorUtilClass.getUserDefaultFlashpoint();
        if (defaultValues === flashPointValue.slice(-1)) {
            return flashPointValue?.slice(0, -1).trim();
        }

        // eslint-disable-next-line unicorn/prefer-native-coercion-functions
        const number = flashPointValue.match(/-?\d+/g).map((element) => Number(element));
        convertedValue =
            flashPointValue.slice(-1) === DEFAULT_SPEC_FLASHPOINT.DEFAULT_VALUE ? number[0] * 1.8 + 32 : (number[0] - 32) * (5 / 9);
        return `${Math.round(convertedValue * 10) / 10}`;
    }

    /**
     * Method to get the current page title for Master Data and Reports Pages
     *
     * @memberof TasteEditorUtilClass
     */
    // eslint-disable-next-line consistent-return
    public static getCurrentPageTitleStatic(url: string): string {
        if (url.includes(PATH_URL.REPORTS)) {
            switch (true) {
                case url.includes(TITLE_CHANGE_URL_LIST.BOM_VIEW_EVENT_REPORT.URL): {
                    return TITLE_CHANGE_URL_LIST.BOM_VIEW_EVENT_REPORT.TITLE;
                }
                case url.includes(TITLE_CHANGE_URL_LIST.GRA_COMPLIANCE_REPORT.URL): {
                    return TITLE_CHANGE_URL_LIST.GRA_COMPLIANCE_REPORT.TITLE;
                }
                default: {
                    return PATH_URL.REPORTS;
                }
            }
        } else if (url.includes(PATH_URL.MASTER_DATA)) {
            switch (true) {
                case url.includes(TITLE_CHANGE_URL_LIST.IPC_SELECTION.URL): {
                    return TITLE_CHANGE_URL_LIST.IPC_SELECTION.TITLE;
                }
                case url.includes(TITLE_CHANGE_URL_LIST.INSTRUCTION.URL): {
                    return TITLE_CHANGE_URL_LIST.INSTRUCTION.TITLE;
                }
                case url.includes(TITLE_CHANGE_URL_LIST.EXPERIMENT_ANALYSIS.URL): {
                    return TITLE_CHANGE_URL_LIST.EXPERIMENT_ANALYSIS.TITLE;
                }
                case url.includes(TITLE_CHANGE_URL_LIST.COLUMN_LAYOUT.URL): {
                    return TITLE_CHANGE_URL_LIST.COLUMN_LAYOUT.TITLE;
                }
                case url.includes(TITLE_CHANGE_URL_LIST.UNAPPROVED.URL): {
                    return TITLE_CHANGE_URL_LIST.UNAPPROVED.TITLE;
                }
                default: {
                    return PATH_URL.MASTER_DATA;
                }
            }
        } else if (url.includes(`/${TITLE_CHANGE_URL_LIST.INTERNAL_SAMPLE_REQUEST.URL}`)) {
            return TITLE_CHANGE_URL_LIST.INTERNAL_SAMPLE_REQUEST.TITLE;
        }
    }
}
