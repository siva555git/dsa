import { Injectable } from "@angular/core";
import { HomeActionContextModel } from "../models/experiment-list.model";

@Injectable()
export class FolderViewHelper {
    /**
     * Method to deSelect the previously selcted folder to update in ngrx store
     * @param {HomeActionContextModel[]} selectedFolders
     * @returns {void}
     * @memberof FolderViewHelper
     */
    public static deSelectPreviouslySelectedFolder(selectedFolders: HomeActionContextModel[]): void {
        selectedFolders.forEach((selectedFolder) => {
            const selectedFolderData = selectedFolder;
            selectedFolderData.selected = false;
        });
    }

    /**
     * Method to form homeContext data to store it in ngrx
     * @param {HomeActionContextModel} folderData
     * @returns {HomeActionContextModel}
     * @memberof FolderViewHelper
     */
    public static formHomeContextData(folderData: HomeActionContextModel): HomeActionContextModel {
        return {
            FolderID: folderData?.FolderID,
            FolderName: folderData?.FolderName,
            filePath: folderData?.filePath ?? [],
            ParentFolderID: folderData?.ParentFolderID,
            selectedCollaborationGroup: folderData?.selectedCollaborationGroup,
        };
    }
}
