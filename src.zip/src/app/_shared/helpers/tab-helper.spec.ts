/* eslint-disable max-lines-per-function */
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { Router } from "@angular/router";
import { NGXLogger } from "ngx-logger";
import { MockExperimentAccessHelper } from "@te-testing/mock-experiment-access.helper";
import { MockAppStateService } from "@te-testing/mock-app.state.service";
import { MockAppcacheHelper } from "@te-testing/mock-app-cache-helper";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { WORKSPACES } from "@te-testing/mock-usertabsdata";
import { Observable, of, throwError } from "rxjs";
import { ExperimentEditorHelper } from "@te-experiment-editor/helpers/experiment-editor.helper";
import { TO_GET_OPEN_TABS } from "@te-shared/constants/common.constant";
import { ToastrService } from "ngx-toastr";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { EMPTY, LOADING_RECENT_WORKSPACE } from "src/app/app.constant";
import { RouterTestingModule } from "@angular/router/testing";
import { MockTabHelperService } from "@te-testing/mock-tabhelper.service";
import { AppSettings } from "src/app/app.settings";
import { TasteEditorDialogModel } from "@te-shared/models/te-dialog.model";
import { MockLoggerService } from "../../testing/mock-logger.service";
import { MockAppDataService } from "../../testing/mock-app.data.service";
import { AppBroadCastService, AppDataService, AppStateService } from "../../_services";
import { TabHelper } from "./tab-helper";
import { ExperimentAccessHelper } from "./experiment-access.helper";
import { AppCacheHelper } from "./app-cache.service";
import { TasteEditorDialogService } from "./te-dialog.service";
import { PayloadHelper } from "./payload-helper";

// eslint-disable-next-line max-lines-per-function
describe("TabHelper", () => {
    const mockRouter = { navigate: jasmine.createSpy("navigate") };
    let service: TabHelper;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule, RouterTestingModule],
            providers: [
                { provide: TabHelper, useClass: MockTabHelperService },
                PayloadHelper,
                AppSettings,
                { provide: ExperimentEditorHelper, useValue: {} },
                { provide: GridApiService, useValue: {} },
                { provide: TasteEditorDialogService, useValue: {} },
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
                {
                    provide: AppBroadCastService,
                    useValue: {
                        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
                        onUpdateAppSpinnerPrompt: () => {},
                        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
                        onTabsActionChange: () => {},
                    },
                },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: Router,
                    useValue: mockRouter,
                },
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                { provide: AppStateService, useClass: MockAppStateService },
                {
                    provide: AppCacheHelper,
                    useClass: MockAppcacheHelper,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
            ],
        });
        service = TestBed.inject(TabHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should close all tabs", () => {
        const appBroadCastService = TestBed.inject(AppBroadCastService);
        const appDataService = TestBed.inject(AppDataService);

        spyOn(appBroadCastService, "onUpdateAppSpinnerPrompt").and.callThrough();
        spyOn(appDataService, "put").and.returnValue(of(true));
        spyOn(service, "setTabConfiguration").and.returnValue(WORKSPACES.WorkSpaces);

        service.closeAllTab(WORKSPACES.WorkSpaces);

        appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
        appDataService.put(`${appDataService.url.updateUserTabIsOpenById}`, [], { IsOpen: 0 });
        service.setTabConfiguration([], 1);
    });

    it("should call on Load ", () => {
        const spy = spyOn(service, "loadWorkSpaces").and.callThrough();
        service.loadWorkSpaces();
        expect(spy).toHaveBeenCalled();
    });

    it("should close all tabs and handle error flow", () => {
        const failureMessage = "Login Failed";
        const appBroadCastService = TestBed.inject(AppBroadCastService);
        const appDataService = TestBed.inject(AppDataService);
        spyOn(appBroadCastService, "onUpdateAppSpinnerPrompt").and.callThrough();
        spyOn(appDataService, "put").and.returnValue(throwError(() => failureMessage));
        const workSpaces = [];

        spyOn(service, "setTabConfiguration").and.returnValue(WORKSPACES.WorkSpaces);
        service.closeAllTab(workSpaces);

        appDataService.put(`${appDataService.url.updateUserTabIsOpenById}`, [], { IsOpen: 0 });
        appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
    });

    it("should return an Observable", () => {
        const appDataService = TestBed.inject(AppDataService);
        spyOn(appDataService, "get").and.returnValue(of(true));

        const result = service.getOpenedTabs();

        appDataService.get(appDataService.url.getUserTabs + TO_GET_OPEN_TABS, []);
        expect(result).toBeInstanceOf(Observable);
    });

    it("should return an empty array if workspaces are not set", () => {
        const recentWorkspaces = service.getRecentWorkspace();
        expect(recentWorkspaces).toEqual([]);
    });

    it("should return dialog options", async () => {
        const appBroadCastService = TestBed.inject(AppBroadCastService);
        const workspaceResponse = { WorkSpace: [] };
        const recentWorkspace = [];
        spyOn(appBroadCastService, "onUpdateAppSpinnerPrompt").and.callThrough();
        spyOn(service, "getOpenedTabs").and.returnValue(of(workspaceResponse));
        spyOn(service, "loadTabs").and.returnValue(await Promise.resolve());
        spyOn(service, "getRecentWorkspace").and.returnValue(recentWorkspace);
        const dialogOptions = await service.getDialogOptions();
        appBroadCastService.onUpdateAppSpinnerPrompt(LOADING_RECENT_WORKSPACE);
        appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
        service.loadTabs(workspaceResponse.WorkSpace);
        expect(dialogOptions).toEqual([] as unknown as TasteEditorDialogModel);
    });
});
