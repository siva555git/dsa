/** Angular Modules */
import { Injectable } from "@angular/core";
import { DEFAULT_BLANK, DEFAULT_COST } from "@te-experiment-editor/constants/experiment-editor.constant";
/* External MOdules */
import { AppStateService } from "@te-services/index";
import { AgGridUtil } from "./ag-grid-util";

@Injectable()
export class CurrencyConversionHelper {
    /**
     * Method to calculate cost value by selected currency's conversion rate
     *
     * @static
     * @param {number} costValue
     * @param {boolean} [isEditor=false]
     * @return {*}  {string}
     * @memberof CurrencyConversionHelper
     */
    public static calculateConversionRate(costValue: number, isEditor = false, isFooterCost = false): string {
        const rate = AppStateService.getConversionRate() ?? 1;
        const conversionRate = Number(1 / Number(rate)).toFixed(3);
        const cost = AgGridUtil.roundOffCost(costValue * Number(conversionRate));
        let convertedValue = cost;
        if (
            (!isFooterCost || (isFooterCost && Number.isNaN(+cost))) &&
            ((!isEditor && Number.isNaN(+cost)) || convertedValue === DEFAULT_COST)
        ) {
            convertedValue = DEFAULT_BLANK;
        }
        return convertedValue;
    }
}
