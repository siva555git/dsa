/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { mockHomeContextData } from "../../testing/mock-home-context";
import { FolderViewHelper } from "./folder-view.helper";

describe("FolderViewHelper", () => {
    let service: FolderViewHelper;
    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [FolderViewHelper],
        })));

    beforeEach(() => {
        service = TestBed.inject(FolderViewHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call deSelectPreviouslySelectedFolder", () => {
        spyOn(FolderViewHelper, "deSelectPreviouslySelectedFolder").and.callThrough();
        FolderViewHelper.deSelectPreviouslySelectedFolder([mockHomeContextData]);
        expect(FolderViewHelper.deSelectPreviouslySelectedFolder).toHaveBeenCalled();
    });

    it("should call formHomeContextData", () => {
        spyOn(FolderViewHelper, "formHomeContextData").and.callThrough();
        FolderViewHelper.formHomeContextData(mockHomeContextData);
        expect(FolderViewHelper.formHomeContextData).toHaveBeenCalled();
    });
});
