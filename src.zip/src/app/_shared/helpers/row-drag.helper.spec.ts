/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { of } from "rxjs";
import { cloneDeep } from "lodash";
import { GridApi, RowNode } from "@ag-grid-community/core";
import { MockExperimentAccessHelper } from "../../testing/mock-experiment-access.helper";
import { MockAppStateService } from "../../testing/mock-app.state.service";
import { ExperimentsModel } from "../models/experiment-bom.model";
import { TreeViewModel } from "../models/experiment-list.model";
import { mockGridApiNew, mockCreatedBomDetails, mockRowDragCallbackParameters, mockGridDataSource } from "../../testing/mock-ag-grid-data";
import { AppBroadCastService, AppStateService } from "../../_services";
import { LOCKED_BY_STATUS } from "../constants";
import { MockGridapiService } from "../../testing/mock-gridapi.service";
import { AgGridUtil } from "./ag-grid-util";
import { AttributeDragManageParameters, AttributeDragValidateParameters } from "../../experiment-editor/models/experiment-editor.model";
import { GridApiService } from "../../experiment-editor/helpers/grid-api-service";
import { RowDragHelper } from "./row-drag.helper";
import { DRAG_EVENT, ROW_DRAG_UP } from "../../experiment-editor/constants/experiment-editor.constant";
import { BOM_DETAILS_CONSTANTS } from "../constants/experiment.constant";
import { ExperimentEditorUtil } from "../../experiment-editor/helpers/experiment-editor.util";
import { ExperimentFolderChild, ExperimentFolderExpanded, ExperimentFolderSelected } from "../enums/experiment.enum";
import { ExperimentBomUtil } from "./experiment-bom.util";
import { ExperimentAccessHelper } from "./experiment-access.helper";

const mockBomDetail = {
    BatchSize: undefined,
    CountryCode: undefined,
    CreatedBy: 47_442,
    CreatedOn: "2021-04-16T14:20:25.381Z",
    ExpCode: "AXA00002AA",
    ExpID: 12_348_048,
    ExpName: undefined,
    ExperimentFormula: [
        {
            CreatedBy: 47_442,
            ExpFormulaID: "50481",
            ExpID: 12_348_048,
            FormulaSeq: 40,
            Instruction: undefined,
            IsDelete: 0,
            Parts: 1,
            SUBCode: "00010000",
            SUBType: "I",
        },
        {
            CreatedBy: 47_442,
            ExpFormulaID: "50487",
            ExpID: 12_348_048,
            FormulaSeq: 100,
            Instruction: undefined,
            IsDelete: 0,
            Parts: 2,
            SUBCode: "00010339",
            SUBType: "I",
        },
        {
            CreatedBy: 47_552,
            ExpFormulaID: "50488",
            ExpID: 12_348_048,
            FormulaSeq: 60,
            Instruction: undefined,
            IsDelete: 0,
            Parts: 2,
            SUBCode: "00020000",
            SUBType: "I",
        },
    ],
    ExperimentStaff: [],
    IPC: undefined,
    IsArchived: "0",
    IsDeleted: "0",
    IsLocked: "0",
    IsPublic: false,
    Level: 0,
    LockedBy: undefined,
    ProductTypeID: undefined,
    BOMType: "E",
    Type: "Experiment",
};

const expFormula = [
    {
        CreatedBy: 47_442,
        ExpFormulaID: "50481",
        ExpID: 12_348_048,
        FormulaSeq: 10,
        Instruction: undefined,
        IsDelete: 0,
        Parts: 1,
        SUBCode: "00010000",
        SUBType: "I",
    },
    {
        CreatedBy: 47_552,
        ExpFormulaID: "50488",
        ExpID: 12_348_048,
        FormulaSeq: 20,
        Instruction: undefined,
        IsDelete: 0,
        Parts: 2,
        SUBCode: "00020000",
        SUBType: "I",
    },
    {
        CreatedBy: 47_442,
        ExpFormulaID: "50487",
        ExpID: 12_348_048,
        FormulaSeq: 30,
        Instruction: undefined,
        IsDelete: 0,
        Parts: 2,
        SUBCode: "00010339",
        SUBType: "I",
    },
];

describe("RowDragHelper", () => {
    let service: RowDragHelper;

    const primaryFolder: TreeViewModel = {
        FolderID: 5_000_185,
        FolderName: "Summa Testing",
        ParentFolderID: 5_000_005,
        filePath: ["SXS2761"],
        expanded: ExperimentFolderExpanded.IS_NOT_EXPANDED,
        hasChild: ExperimentFolderChild.HAS_NO_CHILD,
        selected: ExperimentFolderSelected.IS_NOT_SELECTED,
        tooltip: "",
    };
    const selectedFolder = {
        FolderID: 5_000_454,
        FolderName: "SXS2761",
        ParentFolderID: 5_000_005,
        expanded: "1",
        filePath: ["SXS2761"],
        hasChild: "2",
        selected: "1",
        tooltip: "SXS2761",
    };
    class MockExperimentBomUtil {
        // eslint-disable-next-line @typescript-eslint/no-empty-function, no-empty-function
        public getTopLevelExperimentByExpId = () => {};
    }
    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [
                RowDragHelper,
                AgGridUtil,
                AppBroadCastService,
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: ExperimentBomUtil, useClass: MockExperimentBomUtil },
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                { provide: AppStateService, useClass: MockAppStateService },
            ],
        })));

    beforeEach(() => {
        service = TestBed.inject(RowDragHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call isAttributeRowDragValid invalid 1", () => {
        const mockGridApi = cloneDeep(mockGridApiNew);
        mockGridApi.getSelectedNodes = () => {
            return [];
        };
        const validateParameters: AttributeDragValidateParameters = {
            gridApi: mockGridApi,
            activeExperiment: mockBomDetail as unknown as ExperimentsModel,
            attributeDragDirection: ROW_DRAG_UP,
            event: mockRowDragCallbackParameters,
        };
        spyOn(service, "isAttributeRowDragValid").and.callThrough();
        const response = service.isAttributeRowDragValid(validateParameters);
        expect(response.isValid.value).toBeFalsy();
    });

    it("should call isAttributeRowDragValid invalid 2", () => {
        const mockExp = cloneDeep(mockBomDetail);
        mockExp.IsLocked = LOCKED_BY_STATUS.LOCKED;
        const validateParameters: AttributeDragValidateParameters = {
            gridApi: mockGridApiNew,
            activeExperiment: mockExp as unknown as ExperimentsModel,
            attributeDragDirection: ROW_DRAG_UP,
            event: mockRowDragCallbackParameters,
        };
        spyOn(service, "isAttributeRowDragValid").and.callThrough();
        const response = service.isAttributeRowDragValid(validateParameters);
        expect(response.isValid.value).toBeFalsy();
    });

    it("should call isAttributeRowDragValid invalid 3", () => {
        const validateParameters: AttributeDragValidateParameters = {
            gridApi: mockGridApiNew,
            activeExperiment: undefined,
            attributeDragDirection: ROW_DRAG_UP,
            event: mockRowDragCallbackParameters,
        };
        spyOn(service, "isAttributeRowDragValid").and.callThrough();
        const response = service.isAttributeRowDragValid(validateParameters);
        expect(response.isValid.value).toBeFalsy();
    });

    it("should call isAttributeRowDragValid invalid 4", () => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const mockCreatedBomDetailsNew: any = cloneDeep(mockCreatedBomDetails);
        mockCreatedBomDetailsNew.data = {};
        mockCreatedBomDetailsNew.rowIndex = 1;
        const mockGridApi2 = cloneDeep(mockGridApiNew);
        mockGridApi2.getSelectedNodes = () => {
            return [mockCreatedBomDetailsNew];
        };
        const validateParameters: AttributeDragValidateParameters = {
            gridApi: mockGridApi2,
            activeExperiment: mockBomDetail as unknown as ExperimentsModel,
            attributeDragDirection: ROW_DRAG_UP,
            event: mockRowDragCallbackParameters,
        };
        spyOn(service, "isAttributeRowDragValid").and.callThrough();
        const response = service.isAttributeRowDragValid(validateParameters);
        expect(response.isValid.value).toBeFalsy();
    });

    it("should call isAttributeRowDragValid valid", () => {
        const rowDragCallbackParameters = cloneDeep(mockRowDragCallbackParameters);
        rowDragCallbackParameters.type = DRAG_EVENT.DRAG_MOVING;
        const validateParameters: AttributeDragValidateParameters = {
            gridApi: mockGridApiNew,
            activeExperiment: undefined,
            attributeDragDirection: ROW_DRAG_UP,
            event: rowDragCallbackParameters,
        };
        spyOn(service, "isAttributeRowDragValid").and.callThrough();
        const response = service.isAttributeRowDragValid(validateParameters);
        expect(response.isValid.value).toBeTruthy();
    });

    it("should call updateGridRowsWhenDragging", () => {
        const spy = spyOn(service, "updateGridRowsWhenDragging").and.callThrough();
        service.updateGridRowsWhenDragging(mockGridApiNew, {}, {});
        expect(spy).toHaveBeenCalled();
    });

    it("should call handleAttributeRowDrag valid array", () => {
        const bomDetail = cloneDeep(mockBomDetail);
        const mangeParameters: AttributeDragManageParameters = {
            activeExperiment: bomDetail as unknown as ExperimentsModel,
            baseExpFormulaID: "50481",
            bomDetails: {
                Experiments: [bomDetail],
            },
            rowDragDirection: ROW_DRAG_UP,
            selectedRows: [mockCreatedBomDetails],
        };
        const result = service.handleAttributeRowDrag(mangeParameters);
        expect(result.length).toBeGreaterThan(0);
    });

    it("should call handleAttributeRowDrag empty array", () => {
        const bomDetail = cloneDeep(mockBomDetail);
        bomDetail.ExperimentFormula = expFormula;
        const mangeParameters: AttributeDragManageParameters = {
            activeExperiment: bomDetail as unknown as ExperimentsModel,
            baseExpFormulaID: "50481",
            bomDetails: {
                Experiments: [bomDetail],
            },
            rowDragDirection: ROW_DRAG_UP,
            selectedRows: [mockCreatedBomDetails],
        };
        const result = service.handleAttributeRowDrag(mangeParameters);
        expect(result.length).toBe(0);
    });

    it("should call handleGridChangesForAttributeRowDrag", () => {
        const mockGridApi = cloneDeep(mockGridApiNew);
        mockGridApi.getSelectedNodes = () => {
            return [];
        };
        ExperimentEditorUtil.getRowsBasedOnProperty = () => [{ data: mockGridDataSource[0] }] as unknown as RowNode[];
        const spy = spyOn(service, "handleGridChangesForAttributeRowDrag").and.callThrough();
        service.handleGridChangesForAttributeRowDrag(
            mockGridApi as unknown as GridApi,
            [mockGridDataSource],
            "down",
            BOM_DETAILS_CONSTANTS.EXP_FORMULA_ID,
            "50481",
        );
        expect(spy).toHaveBeenCalled();
    });

    it("should call isMoveInvalid", () => {
        const selectedNode = {
            data: selectedFolder,
            childrenAfterGroup: [{ key: "ABC", data: { FolderID: primaryFolder.ParentFolderID } }],
        };
        const targetNode = { data: primaryFolder, key: "ABC" };
        const isMoveInvalid = service.isFolderRowDragValid(selectedNode as unknown as RowNode, targetNode as unknown as RowNode);
        expect(isMoveInvalid).toBeTruthy();
    });

    xit("should call isFolderWithSameNameAlreadyPresent", () => {
        const isMoveInvalid = service.isFolderWithSameNameAlreadyPresent(
            [primaryFolder],
            primaryFolder.ParentFolderID,
            selectedFolder.FolderName,
        );
        expect(isMoveInvalid).toBeFalsy();
    });

    it("should call areFolderPathsEqual unequal 1", () => {
        const isMoveInvalid = service.areFolderPathsEqual(["abc", "def"], ["abc"]);
        expect(isMoveInvalid).toBeFalsy();
    });

    it("should call areFolderPathsEqual unequal 2", () => {
        const isMoveInvalid = service.areFolderPathsEqual(["abc", "def"], ["abc", "xyz"]);
        expect(isMoveInvalid).toBeFalsy();
    });

    it("should call moveToPath", () => {
        const updateRows = [];
        const selectedNode = { data: selectedFolder };
        service.moveToPath(["abc", "def"], selectedNode as unknown as RowNode, updateRows);
        expect(updateRows.length).toBeGreaterThan(0);
    });
});
