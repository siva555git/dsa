/* eslint-disable max-lines-per-function */
import { TestBed } from "@angular/core/testing";
import { Subscription } from "rxjs/internal/Subscription";
import { mockAttributeParameter, mockFlashPointData } from "@te-testing/mock-ag-grid-data";
import { BomDetailExperimentsModel } from "@te-shared/models/experiment-bom.model";
import { MockAppStateService } from "@te-testing/mock-app.state.service";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { cloneDeep } from "lodash";
import { MockAppcacheHelper } from "../../testing/mock-app-cache-helper";
import { MockGridHelper } from "../../testing/mock-grid-helper";
import { facilities } from "../../testing/mock-data-audit";
import { TasteEditorUtilClass } from "./taste-editor-utils";
import { AppCacheHelper } from "./app-cache.service";
import { mockBomDetailExperiments } from "../../testing/mock-context-menu.helper";
import { BASIC_ROUTES_URL, PATH_URL } from "../constants/common.constant";

describe("TasteEditorUtilClass", () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                {
                    provide: TasteEditorUtilClass,
                    useClass: MockGridHelper,
                },
                {
                    provide: AppCacheHelper,
                    useClass: MockAppcacheHelper,
                },
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
            ],
        });
    });

    it("should create", () => {
        const service: TasteEditorUtilClass = TestBed.inject(TasteEditorUtilClass);
        expect(service).toBeTruthy();
    });

    it("should call flavourTypesChecked ", () => {
        spyOn(TasteEditorUtilClass, "flavourTypesChecked").and.callThrough();
        const flavorTypes = [
            {
                // eslint-disable-next-line id-length
                id: 1,
                name: "Alcohol",
                // eslint-disable-next-line unicorn/no-null
                parentid: null,
                // eslint-disable-next-line unicorn/no-null
                parentname: null,
                checked: true,
            },
        ];
        TasteEditorUtilClass.flavourTypesChecked(flavorTypes);
        expect(TasteEditorUtilClass.flavourTypesChecked).toHaveBeenCalled();
    });

    it("should call on removeSubscriptions", () => {
        spyOn(TasteEditorUtilClass, "removeSubscriptions").and.callThrough();
        const subscription = new Subscription();
        spyOn(subscription, "unsubscribe");
        TasteEditorUtilClass.removeSubscriptions([subscription]);
        expect(TasteEditorUtilClass.removeSubscriptions).toHaveBeenCalled();
    });

    it("should call on getFacilityDetail", () => {
        spyOn(TasteEditorUtilClass, "getFacilityDetail").and.callThrough();
        const facilityKey = "facilitycode";
        const facilitiyValue = "0938";
        TasteEditorUtilClass.getFacilityDetail(facilities, facilityKey, facilitiyValue);
        expect(TasteEditorUtilClass.getFacilityDetail).toHaveBeenCalled();
    });

    it("should call on filterCollectionsBasedOnList", () => {
        spyOn(TasteEditorUtilClass, "filterCollectionsBasedOnList").and.callThrough();
        TasteEditorUtilClass.filterCollectionsBasedOnList(mockBomDetailExperiments as unknown as BomDetailExperimentsModel[], [123_456]);
        expect(TasteEditorUtilClass.filterCollectionsBasedOnList).toHaveBeenCalled();
    });

    it("should call on getUserDefaultFlashpoint when selected flashpoint", () => {
        const mockDefaultData = cloneDeep(mockFlashPointData);
        mockDefaultData.ColumnValue = "F";
        spyOn(AppStateService, "getUserDefaultPreferenceType").and.returnValue([mockDefaultData]);
        const result = TasteEditorUtilClass.getUserDefaultFlashpoint();
        expect(result).toEqual("F");
    });

    it("should call on getUserDefaultFlashpoint when initial default flashpoint", () => {
        const mockDefaultData = cloneDeep(mockFlashPointData);
        mockDefaultData.ColumnValue = undefined;
        spyOn(AppStateService, "getUserDefaultPreferenceType").and.returnValue([mockDefaultData]);
        const result = TasteEditorUtilClass.getUserDefaultFlashpoint();
        expect(result).toEqual("C");
    });

    it("should call on flashPointConversion Fahrenheit to celsius when user default is celsius", () => {
        const mockData = cloneDeep(mockAttributeParameter);
        mockData.value = "32";
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("C");
        const result = TasteEditorUtilClass.flashPointConversion(mockData);
        expect(result).toEqual("0");
    });

    it("should call on flashPointConversion when user default value is same as input value ", () => {
        const mockData = cloneDeep(mockAttributeParameter);
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("C");
        const result = TasteEditorUtilClass.flashPointConversion(mockData);
        expect(result).toEqual("0");
    });

    it("should call on flashPointConversion celsius to Fahrenheit when user default is Fahrenheit", () => {
        const mockData = cloneDeep(mockAttributeParameter);
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("F");
        const result = TasteEditorUtilClass.flashPointConversion(mockData);
        expect(result).toEqual("32");
    });

    it("should call on flashPointConversion when column name is different", () => {
        const mockData = cloneDeep(mockAttributeParameter);
        mockData.value = "LIQUID-CONTAINS ALCOHOL";
        mockData.colDef.headerName = "Product Type";
        spyOn(TasteEditorUtilClass, "getUserDefaultFlashpoint").and.returnValue("F");
        const result = TasteEditorUtilClass.flashPointConversion(mockData);
        expect(result).toEqual("LIQUID-CONTAINS ALCOHOL");
    });

    it("should get current title on bom-view-event-report url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(BASIC_ROUTES_URL.REPORTS);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });

    it("should get current title on gra-compliance-report url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(BASIC_ROUTES_URL.CREATIVE_REVIEW_REPORTS);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });

    it("should get current title on reports default url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(PATH_URL.REPORTS);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });

    it("should get current title on ipc-selection url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(BASIC_ROUTES_URL.MASTER_DATA);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });

    it("should get current title on column-layout url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(BASIC_ROUTES_URL.COMMON_LAYOUT);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });

    it("should get current title on unapproved url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(BASIC_ROUTES_URL.UNAPPROVED);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });

    it("should get current title on experiment-analysis url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(BASIC_ROUTES_URL.BOM_RESTRICTION);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });

    it("should get current title on instruction url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(BASIC_ROUTES_URL.INSTRUCTION);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });

    it("should get current title on default master data url", () => {
        spyOn(TasteEditorUtilClass, "getCurrentPageTitleStatic").and.callThrough();
        TasteEditorUtilClass.getCurrentPageTitleStatic(PATH_URL.MASTER_DATA);
        expect(TasteEditorUtilClass.getCurrentPageTitleStatic).toHaveBeenCalled();
    });
});
