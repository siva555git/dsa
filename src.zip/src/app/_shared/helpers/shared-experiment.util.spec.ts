import { TestBed } from "@angular/core/testing";
import { experimentListRowData } from "../../testing/mock-context-menu.helper";
import { REFRESH_EXPERIMENT_HEADER } from "../../experiment-editor/constants/experiment-editor.constant";
import { EXPERIMENT_SUB_OPTIONS } from "../constants/context-menu.constant";
import { SharedExperimentUtil } from "./shared-experiment.util";

describe("SharedExperimentUtil", () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SharedExperimentUtil],
        });
    });

    it("should create", () => {
        const service: SharedExperimentUtil = TestBed.inject(SharedExperimentUtil);
        expect(service).toBeTruthy();
    });

    it("should call on createRefreshExperimentHeader", () => {
        spyOn(SharedExperimentUtil, "createRefreshExperimentHeader").and.callThrough();
        SharedExperimentUtil.createRefreshExperimentHeader(REFRESH_EXPERIMENT_HEADER.EXPERIMENT_DATA_UPDATE, {});
        expect(SharedExperimentUtil.createRefreshExperimentHeader).toHaveBeenCalled();
    });

    it("should call on getExperimentPrivacyPayload", () => {
        spyOn(SharedExperimentUtil, "getCooperatorAccessData").and.callThrough();
        SharedExperimentUtil.getCooperatorAccessData(EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS, experimentListRowData[0]);
        expect(SharedExperimentUtil.getCooperatorAccessData).toHaveBeenCalled();
    });

    it("should call on getFormattedDate", () => {
        spyOn(SharedExperimentUtil, "getFormattedDate").and.callThrough();
        const updatedDate = new Date();
        SharedExperimentUtil.getFormattedDate(updatedDate);
        expect(SharedExperimentUtil.getFormattedDate).toHaveBeenCalled();
    });
});
