/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable no-param-reassign */
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { forEach, remove, find, orderBy, map, isEqual, delay, filter, cloneDeep } from "lodash";
import * as moment from "moment";
import { NGXLogger } from "ngx-logger";
import { Observable, Subject, lastValueFrom, of, take } from "rxjs";
import { WorkSpaceValidation } from "@te-shared/models/experiments.model";
import { SelectedRowDataModel, WorkSpaceDialogResponse } from "@te-shared/models";
import {
    DESC,
    EXPERIMENT_OPEN_IN_WORKSPACE_CONST,
    EXP_ID_OBJ_KEY,
    IPC_OBJ_KEY,
    WORKSPACE_DIALOG,
    WORKSPACE_DIALOG_BUTTONS,
} from "@te-shared/constants/experiment.constant";
import { WorkspacePopupComponent } from "@te-shared/components/workspace-popup/workspace-popup/workspace-popup.component";
import { TasteEditorDialogModel } from "@te-shared/models/te-dialog.model";
import {
    CREATE_EXPERIMENT_SUGGESTION,
    CREATE_EXP_IN_RECENT_WORKSPACE_LIMIT,
    NEW_EXPERIMENT_IN_WORKSPACE_TITLE,
    NEW_EXP_IN_EXISTING_WORKSPACE_DIALOG_WIDTH,
} from "@te-experiment/experiment.constant";
import { ToastrService } from "ngx-toastr";
import { BomDetailExperimentsModel, ExperimentsModel } from "../models/experiment-bom.model";

import {
    CREATE_EXPERIMENT,
    EXP_FORMULA_LOCATION,
    GET_TABS_FAILURE,
    TAB_ACTIVE,
    TAB_LOCATION,
    WORKSPACE_DETAIL,
    TYPE,
    DATA_TYPE,
} from "../constants/common.constant";
import {
    CREATE_TABS,
    UPDATE_TABS,
    CLOSING_EXPERIMENT,
    EMPTY,
    OPEN_EXPERIMENTS_TAB,
    PLEASE_WAIT,
    UPDATE,
    REMOVE,
    LOADING,
    LOADING_RECENT_WORKSPACE,
} from "../../app.constant";
import { AppBroadCastService, AppDataService, AppStateService } from "../../_services";
import { ADD_TAB, BASIC_ROUTES_URL, EXPERIMENT_ACCESS, LOAD_TABS, REMOVE_TAB, TABS, TO_GET_OPEN_TABS, USER_TAB_ID } from "../constants";
import { IPC_MAPPING, REFRESH_GRID } from "../../experiment-editor/constants/experiment-editor.constant";
import { CreateExperiment } from "../models/create-experiment.model";
import {
    CreateOrUpdateTab,
    TabDetailModel,
    TabSequenceUpdateModel,
    TabsCrudDataModel,
    UserTabExperiments,
    WorkSpaces,
} from "../models/create-tab.model";
import { Experiment } from "../models/experiment.model";
import { WorkSpaceModel } from "../../experiment-editor/models/experiment-editor.model";
// eslint-disable-next-line import/no-cycle
import { ExperimentEditorHelper } from "../../experiment-editor/helpers/experiment-editor.helper";
import { PayloadHelper } from "./payload-helper";
import { GridApiService } from "../../experiment-editor/helpers/grid-api-service";
import { EXPERIMENT, EXPERIMENT_SUB_OPTIONS, LINE_SUB_OPTIONS, PRODUCT } from "../constants/context-menu.constant";
import { ExperimentAccessHelper } from "./experiment-access.helper";
import { AppCacheHelper } from "./app-cache.service";
import { TasteEditorDialogService } from "./te-dialog.service";

@Injectable({
    providedIn: "root",
})
export class TabHelper {
    private createTab: CreateOrUpdateTab;

    private selectedTab: WorkSpaces;

    public workspaces: WorkSpaces[];

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public updatedWorkSpaceDetails = new Subject<any>();

    constructor(
        private readonly appDataService: AppDataService,
        private readonly appBroadCastService: AppBroadCastService,
        private logger: NGXLogger,
        private readonly router: Router,
        private experimentEditorHelper: ExperimentEditorHelper,
        private payloadHelper: PayloadHelper,
        private readonly gridApiService: GridApiService,
        private experimentAccessHelper: ExperimentAccessHelper,
        private appStateService: AppStateService,
        private appCacheHelper: AppCacheHelper,
        private readonly tasteEditorDialogService: TasteEditorDialogService,
        private readonly toastrService: ToastrService,
    ) {}

    /**
     * Method to generate the new tab payload based on the experiments selected
     * @param {Object} selectedExperiments
     * @param {Object} tabDetails
     * @memberof TabHelper
     */
    public generateNewOrUpdateTabPayload(selectedExperiments, tabDetails?): CreateOrUpdateTab {
        this.createTab = {
            TabName: tabDetails ? tabDetails.TabName : selectedExperiments[0].ExpCode || selectedExperiments[0].expCode,
            Sequence: tabDetails ? tabDetails.Sequence : 1, // later need to arrange the sequence
            IsCurrent: tabDetails ? tabDetails.IsCurrent : 1,
            CreatedBy: tabDetails ? tabDetails.CreatedBy : 1,
            UpdatedBy: tabDetails ? tabDetails.UpdatedBy : 1,
            CreatedOn: tabDetails ? tabDetails.CreatedOn : moment().format(),
            UpdatedOn: moment().format(),
            WorkSpaceDetail: this.generateWorkspaceExpDetails(selectedExperiments, tabDetails),
        };
        if (tabDetails) {
            this.createTab.UserTabID = tabDetails.UserTabID;
        }
        return this.createTab;
    }

    /**
     * Method to generate the new tab payload based on the experiments selected
     * @param {ExperimentsModel[]} selectedExperiments
     * @param {Object} tabDetails
     * @memberof TabHelper
     */
    public generateWorkspaceExpDetails = (selectedExperiments: ExperimentsModel[], tabDetails): UserTabExperiments[] => {
        const workspaceDetail = [];
        selectedExperiments.forEach((experiment, index) => {
            const experimentToAdd: UserTabExperiments = {
                ExpID:
                    // eslint-disable-next-line unicorn/no-null
                    experiment.ExpID && experiment.Type !== PRODUCT ? experiment.ExpID : null,
                Sequence: index + 1,
                IsCurrent: 1,
                IPC: experiment.Type === PRODUCT ? experiment.IPC : experiment.code,
            };
            if (!tabDetails || tabDetails.type === REMOVE || !tabDetails.WorkSpaceDetail[index]) {
                workspaceDetail.push(experimentToAdd);
            }
        });
        return workspaceDetail;
    };

    /**
     * Method to get the opened tabs based on user id
     * @memberof TabHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getOpenedTabs(): Observable<any> {
        return this.appDataService.get(this.appDataService.url.getUserTabs + TO_GET_OPEN_TABS, []);
    }

    /**
     * Method to update some activation fields in the loaded tabs response and send notification to the subscribed methods to load the tabs
     * @param {WorkSpaces[]} workSpaces
     * @memberof TabHelper
     */
    public loadTabs(workSpaces: WorkSpaces[]) {
        const currentUrl = this.router.url;
        const userCreatedTabs = this.setTabConfiguration(workSpaces);
        const urlParts = currentUrl.split("/").splice(1);
        let activeTab: WorkSpaces;
        switch (urlParts[0]) {
            case BASIC_ROUTES_URL.HOME.split("/").splice(1)[0]: {
                [activeTab] = TABS;
                break;
            }
            case BASIC_ROUTES_URL.EXPERIMENT_FORMULA_TAB.split("/").splice(1)[0]: {
                activeTab = find(workSpaces, [USER_TAB_ID, +urlParts[2]]);
                break;
            }
            default: {
                [activeTab] = TABS;
                break;
            }
        }
        this.appBroadCastService.onTabsActionChange(this.createTabsCrudModel(LOAD_TABS, userCreatedTabs, activeTab));
    }

    /**
     * Method to call the API service to create the tab based on the payload
     * @param {CreateOrUpdateTab} createTabPayload
     * @memberof TabHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public createTabs(createTabPayload: CreateOrUpdateTab): Observable<any> {
        return this.appDataService.post(this.appDataService.url.createUserTabs, [], createTabPayload);
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public updateTabs(updateTabPayload: CreateOrUpdateTab): Observable<any> {
        return this.appDataService.post(this.appDataService.url.updateUserTabs, [], updateTabPayload);
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public deleteTab(deleteTabPayload: CreateOrUpdateTab): Observable<any> {
        return this.appDataService.post(this.appDataService.url.deleteUserTab, [], deleteTabPayload);
    }

    /**
     * Method to add the tab in the existing tabs by configuring the newly added tab with activation fields
     * @param {number} tabId
     * @memberof TabHelper
     */
    public addTab(tabId: number) {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(OPEN_EXPERIMENTS_TAB);
        this.getOpenTabs(tabId).subscribe({
            next: (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                const userCreatedTabs = this.setTabConfiguration([result], tabId);
                this.appBroadCastService.onTabsActionChange(this.createTabsCrudModel(ADD_TAB, userCreatedTabs, userCreatedTabs[0]));
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * This method is used to close all open tabs in the workspace.
     *
     * @param {WorkSpaces[]} workSpaces - An array of the currently open workspaces.
     */
    public closeAllTab(workSpaces: WorkSpaces[] = []) {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(PLEASE_WAIT);
        const payload = { IsOpen: 0 };
        this.appDataService.put(`${this.appDataService.url.updateUserTabIsOpenById}`, [], payload).subscribe({
            next: (result) => {
                if (result) {
                    const tabIdToActive = TABS[0].UserTabID;
                    remove(workSpaces, (object) => {
                        return object.UserTabID !== -1;
                    });
                    const userCreatedTabs = this.setTabConfiguration(workSpaces, tabIdToActive);
                    this.appBroadCastService.onTabsActionChange(
                        this.createTabsCrudModel(REMOVE_TAB, userCreatedTabs, undefined, tabIdToActive),
                    );
                }
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to remove the tab in the existing tabs
     * @param {number} tabId
     * @param {WorkSpaces[]} workSpaces
     * @memberof TabHelper
     */
    // eslint-disable-next-line default-param-last
    public updateTab(updateType: string, tabId: number, workSpaces: WorkSpaces[] = [], newWorkspaceName = EMPTY, productSearchID?: number) {
        let payload;
        if (updateType === REMOVE_TAB) {
            this.appBroadCastService.onUpdateAppSpinnerPrompt(PLEASE_WAIT);
            payload = { IsOpen: 0 };
        } else {
            payload = productSearchID || productSearchID === 0 ? { ProductSearchID: productSearchID } : { TabName: newWorkspaceName };
        }

        this.appDataService.put(`${this.appDataService.url.updateUserTabIsOpenById}${tabId}`, [], payload).subscribe({
            next: (result) => {
                if (updateType === REMOVE_TAB) {
                    let tabIdToActive;
                    if (result) {
                        tabIdToActive =
                            this.getActiveTab() && this.getActiveTab().UserTabID === tabId
                                ? TABS[0].UserTabID
                                : this.getActiveTab().UserTabID;
                        remove(workSpaces, {
                            UserTabID: tabId,
                        });
                        const userCreatedTabs = this.setTabConfiguration(workSpaces, tabIdToActive);
                        this.appBroadCastService.onTabsActionChange(
                            this.createTabsCrudModel(REMOVE_TAB, userCreatedTabs, undefined, tabIdToActive),
                        );
                    }
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                }
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to Open the selected experiments in the new tab, this will call the create tabs API and then call addTab to add the tab in the existing tabs
     * @param {Object[]} selectedExperiments
     * @memberof TabHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public openExpInNewTab(selectedExperiments: any): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(CREATE_TABS);
        const createTabPayload = this.generateNewOrUpdateTabPayload(selectedExperiments);
        this.createTabs(createTabPayload).subscribe({
            next: (result) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.appBroadCastService.updatedWorkSpace.next({
                    updatedData: result,
                    refreshType: LINE_SUB_OPTIONS.OPEN_IN_NEW_WORKSPACE,
                });
                const tabId = result.UserTabID;
                this.addTab(tabId);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to get the recent workspaces
     *
     * @return {*}  {WorkSpaces[]}
     * @memberof TabHelper
     */
    public getRecentWorkspace() {
        if (!this.workspaces) return [];
        const recentWorkspace = [...this.workspaces];
        recentWorkspace.shift();
        recentWorkspace.sort((workspaceA, workspaceB) => (new Date(workspaceA.UpdatedOn) < new Date(workspaceB.UpdatedOn) ? 1 : -1));
        const updatedWorkspace = recentWorkspace.slice(0, CREATE_EXP_IN_RECENT_WORKSPACE_LIMIT);
        return updatedWorkspace;
    }

    /**
     * Dialog popup for open new experiment in existing workspace
     *
     * @static
     * @memberof TabHelper
     */
    public async getDialogOptions(): Promise<TasteEditorDialogModel> {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING_RECENT_WORKSPACE);
        const workSpaceResponse = await lastValueFrom(this.getOpenedTabs());
        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
        const workSpaceDetails = workSpaceResponse.WorkSpace;
        await this.loadTabs(workSpaceDetails);
        const workspaceDetails = await this.getRecentWorkspace();
        const dialogPayload = JSON.parse(JSON.stringify(WORKSPACE_DIALOG));
        dialogPayload.width = NEW_EXP_IN_EXISTING_WORKSPACE_DIALOG_WIDTH;
        delete dialogPayload.data.extraConfirmText;
        dialogPayload.data.title = NEW_EXPERIMENT_IN_WORKSPACE_TITLE;
        dialogPayload.data.dialogData = [
            {
                workspaceDetails,
                selectedExp: [],
                type: CREATE_EXPERIMENT_SUGGESTION,
                isMulipleBomScreen: false,
            },
        ];
        dialogPayload.autoFocus = false;
        return dialogPayload;
    }

    /**
     *
     * Method to Open the selected experiments in the existing tab
     * @param {WorkSpaceModel[] | WorkSpaceModel} tabDetails
     * @param {ExperimentsModel[]} newExperiment
     * @param {boolean} [isView=false]
     * @memberof TabHelper
     */
    public openExpInExistingTab(tabDetails: WorkSpaceModel[] | WorkSpaceModel, newExperiment: ExperimentsModel[], isView = false): void {
        const selectedExperiments = [...tabDetails[WORKSPACE_DETAIL].map((data) => data.Experiment), ...newExperiment];
        this.appBroadCastService.onUpdateAppSpinnerPrompt(UPDATE_TABS);
        tabDetails[TYPE] = UPDATE;
        const updateTabPayload = this.generateNewOrUpdateTabPayload(selectedExperiments, tabDetails);
        this.updateTabs(updateTabPayload).subscribe({
            next: () => {
                this.gridApiService.getUserColumnLayouts(String(updateTabPayload.UserTabID)).subscribe({
                    next: (updatedUserTabDetails) => {
                        this.appBroadCastService.updatedWorkSpace.next({
                            updatedData: updatedUserTabDetails,
                            refreshType: LINE_SUB_OPTIONS.OPEN_IN_WORKSPACE,
                        });
                        this.experimentEditorHelper.getBomDetails(updatedUserTabDetails, newExperiment, isView);
                    },
                    error: (error) => {
                        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                        this.logger.error(error);
                    },
                });
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to close an experiment in the existing tab
     * @param {ExperimentsModel} deletedExperiment
     * @param {WorkSpaceModel} tabDetails
     * @memberof TabHelper
     */
    public removeExpInTab(deletedExperiment: ExperimentsModel[], tabDetails: WorkSpaceModel[]): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(CLOSING_EXPERIMENT);
        tabDetails[TYPE] = REMOVE;
        const deleteTabPayload = this.generateNewOrUpdateTabPayload(deletedExperiment, tabDetails);
        this.deleteTab(deleteTabPayload).subscribe({
            next: (updatedTabDetails) => {
                this.appBroadCastService.updatedWorkSpace.next({
                    updatedData: updatedTabDetails,
                    refreshType: EXPERIMENT_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT,
                });
                const refreshData = this.payloadHelper.getRefreshDataPayload({ updatedTabDetails }, [], deletedExperiment, []);
                const gridRefreshPayload = this.payloadHelper.createRefreshGridPayload(REFRESH_GRID.CLOSE_EXPERIMENT, refreshData);
                this.appBroadCastService.onRefreshGrid(gridRefreshPayload);
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to get the opened tabs list, loop and get the newly created tab
     * @memberof TabHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getTabResponse(): Observable<any> {
        return this.appDataService.get(this.appDataService.url.getUserTabs + TO_GET_OPEN_TABS, []);
    }

    /**
     * Method to get the newly opened tab details
     * @memberof TabHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getOpenTabs(tabId: number): Observable<any> {
        return this.appDataService.get(this.appDataService.url.getUserTabDetails, [String(tabId)]);
    }

    /**
     * Method to get the recent workspace tabs list
     * @memberof TabHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getRecentTabs(): Observable<any> {
        return this.appDataService.get(this.appDataService.url.getRecentTabs, []);
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public loadWorkSpaces() {
        return of(
            this.getOpenedTabs().subscribe({
                next: (response) => {
                    this.loadTabs(response.WorkSpace);
                },
                error: (error) => {
                    this.logger.error(error);
                    this.toastrService.error(GET_TABS_FAILURE);
                },
            }),
        );
    }

    /**
     * Method to open the tab from the recent workspace list
     * @param {number} tabId
     * @memberof TabHelper
     */
    public openRecentTab(tabId: number) {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(PLEASE_WAIT);
        this.appDataService.put(`${this.appDataService.url.updateUserTabIsOpenById}/${tabId}`, [], { IsOpen: 1, IsCurrent: 1 }).subscribe({
            next: (result) => {
                if (result) {
                    this.getTabResponse().subscribe({
                        next: (resultOfActiveTabs) => {
                            if (resultOfActiveTabs.WorkSpace.length > 0) {
                                // eslint-disable-next-line unicorn/prefer-array-find
                                const tabToActivate = resultOfActiveTabs.WorkSpace.filter(
                                    (opentab: WorkSpaces) => opentab.UserTabID === tabId,
                                );
                                const selectedTab = this.setTabConfiguration([tabToActivate[0]], tabId);
                                this.appBroadCastService.onTabsActionChange(this.createTabsCrudModel(ADD_TAB, selectedTab, selectedTab[0]));
                            } else {
                                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                                this.logger.error(GET_TABS_FAILURE);
                            }
                        },
                        error: (error) => {
                            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                            this.logger.error(error);
                        },
                    });
                }
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to set the activation config like active and location which will help the tabs to navigate and active the tab
     * @param {WorkSpaces[]} workSpaces
     * @param {number} tabIdToActive
     * @memberof TabHelper
     */
    public setTabConfiguration(workSpaces: WorkSpaces[], tabIdToActive?: number): WorkSpaces[] {
        forEach(workSpaces, (tab: WorkSpaces) => {
            tab[TAB_ACTIVE] = this.updateTabActive(tabIdToActive, tab);
            tab[TAB_LOCATION] = this.generateTabLocation(tab.UserTabID);
            return tab;
        });
        return workSpaces;
    }

    /**
     * Method to generate the tab location, which is the routing path to update in the url to route to the module and load the component
     * @param {number} userTabId
     * @memberof TabHelper
     */
    // eslint-disable-next-line class-methods-use-this
    public generateTabLocation(userTabId: number): string {
        if (userTabId === TABS[0].UserTabID) {
            return BASIC_ROUTES_URL.HOME;
        }
        return EXP_FORMULA_LOCATION + userTabId;
    }

    /**
     * Method to return a boolean to indicate whether the tab active status to true or false. Validate the tab passed and return the active status based
     * on the active tab id passed.
     * @param {number} tabIdToActive
     * @param {WorkSpaces} tab

     * @memberof TabHelper
     */
    // eslint-disable-next-line class-methods-use-this
    private updateTabActive(tabIdToActive: number, tab: WorkSpaces): boolean {
        return !!(tabIdToActive && tabIdToActive === tab.UserTabID);
    }

    /**
     * Method to create the data structure for passing the object to do the CRUD operations of the tabs like Load, Add, Update, Remove
     * @param {string} tabAction
     * @param {WorkSpaces[]} tabActionData
     * @param {number} tabIdToActive
     * @memberof TabHelper
     */
    // eslint-disable-next-line class-methods-use-this
    private createTabsCrudModel(
        tabAction: string,
        tabActionData: WorkSpaces[],
        activeTab?: WorkSpaces,
        tabIdToActive?: number,
    ): TabsCrudDataModel {
        return {
            action: tabAction,
            tabIdToActive,
            tabData: tabActionData,
            activeTab,
        };
    }

    /**
     * Method to create the data structure for creating experiments
     * @param {string} experimentAction
     * @param {any} experimentsList
     * @memberof TabHelper
     */
    // eslint-disable-next-line class-methods-use-this, @typescript-eslint/no-explicit-any
    public createExperimentCrudModel(experimentAction: string, experimentsList: any): CreateExperiment {
        return {
            action: experimentAction,
            experiments: experimentsList,
        };
    }

    /**
     * Method to navigate the tab dynamically on adding and opening tabs
     * @param {number} userTabID
     * @memberof TabHelper
     */
    public navigateExperimentTab(userTabID: number): void {
        this.router.navigate([BASIC_ROUTES_URL.EXPERIMENT_FORMULA_TAB, userTabID]);
    }

    /**
     * Method to navigate to home page
     * @param {number} userTabID
     * @memberof TabHelper
     */
    public navigateHome(): void {
        this.router.navigate([BASIC_ROUTES_URL.HOME]);
    }

    /**
     * Method to set the active tab selected
     * @param {WorkSpaces} selectedTab
     * @memberof TabHelper
     */
    public setActiveTab(selectedTab: WorkSpaces, workSpaces: WorkSpaces[]): void {
        TabHelper.setDefaultTabClass(workSpaces);
        TabHelper.setTabStyling(selectedTab, true);
        this.selectedTab = selectedTab;
        this.workspaces = workSpaces;
    }

    /**
     * Method to get the active tab selected
     * @memberof TabHelper
     */
    public getActiveTab(): WorkSpaces {
        return this.selectedTab;
    }

    /**
     * Method to add or remove the tab class based on the page
     * @memberof TabHelper
     * @param {WorkSpaces} tabToActive
     * @param {boolean} isActive
     */
    public static setTabStyling(tabToActive: WorkSpaces, isActive: boolean): void {
        if (tabToActive.TabName === "Home") {
            tabToActive.class = isActive ? "experiment-home experiment-home-active" : "experiment-home";
        } else {
            // eslint-disable-next-line no-lonely-if
            tabToActive.class = isActive ? "experiment-data-lists experiment-data-lists-active" : "experiment-data-lists";
        }
    }

    /**
     * Method to clear the current tab class and set to default classes
     * @memberof TabHelper
     * @param {WorkSpaces[]} workSpaces
     */
    public static setDefaultTabClass(workSpaces: WorkSpaces[]): void {
        forEach(workSpaces, (tab) => {
            if (tab.TabName === "Home") {
                tab.class = "experiment-home";
            } else {
                tab.IsCurrent = "0";
                tab.class = "experiment-data-lists";
            }
        });
    }

    /**
     * Method to open newly created experiment in tab
     * @param {Experiment} experiment
     * @returns {void}
     * @memberof TabHelper
     */
    public openNewlyCreatedExpInTab(experimentList: Experiment[]): void {
        const createExperimentInTab = this.createExperimentCrudModel(CREATE_EXPERIMENT, experimentList);
        this.appBroadCastService.onExperimentCreated(createExperimentInTab);
    }

    /**
     * Method to open the experiment when it clicked in the text of experiment
     * @param {ExperimentsModel | BomDetailExperimentsModel} data
     * @param {WorkSpaceValidation} workSpaceDetails
     * @returns {void}
     * @memberof TabHelper
     */
    public onExpTextClick(data: ExperimentsModel | BomDetailExperimentsModel, workSpaceDetails?: WorkSpaceValidation): void {
        const selectedExperiments = [];
        const userDetails = this.appStateService.getCurrentUser();
        selectedExperiments.push(data);
        const isVersionPermitted = this.experimentAccessHelper.getExperimentAccessCheck(
            selectedExperiments,
            Number(userDetails.sapempid),
            EXPERIMENT_ACCESS.OPEN_EXPERIMEMT_IN_WORKSPACE,
        );
        if (isVersionPermitted?.isPermitted) {
            this.openExperimentInBomScreen(selectedExperiments, workSpaceDetails.isWorkSpaceDetailRequired, workSpaceDetails.workspace);
        } else {
            this.experimentAccessHelper.openExperiemntAccessInfoDialog(isVersionPermitted, data?.ExpID);
        }
    }

    /**
     * Method to open the selected experiment in the bom screen listen to the edit bom, select experiment in the list events
     * @param {SelectedRowDataModel[]} selectedExp
     * @param {boolean} isWorkSpaceDetailRequired
     * @param {WorkSpaces[]} workspace
     * @param {WorkSpaces[]} filteredWorkspace
     * @param {string} type
     * @param {boolean} isMulipleBomScreen
     * @memberof TabHelper
     */
    // eslint-disable-next-line sonarjs/cognitive-complexity
    public openExperimentInBomScreen(
        selectedExp: SelectedRowDataModel[],
        // eslint-disable-next-line default-param-last
        isWorkSpaceDetailRequired = false,
        workspaces?: WorkSpaces[],
        filteredWorkspace?: WorkSpaces[],
        type = EXPERIMENT,
        isMulipleBomScreen = false,
    ): void {
        if (isWorkSpaceDetailRequired) {
            this.createNewWorkSpace(selectedExp);
        } else {
            let workSpace = [];
            if (isMulipleBomScreen) {
                const ipcValues = [];
                workSpace = orderBy(workspaces, EXPERIMENT_OPEN_IN_WORKSPACE_CONST.SEQUENCE, DESC);
                forEach(selectedExp, (expData) => {
                    if (expData.IPC) ipcValues.push(expData.IPC);
                });
                if (ipcValues.length > 0) {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
                    this.getAttributeDetails(ipcValues, selectedExp, type, isMulipleBomScreen, workSpace);
                } else {
                    this.handleOpenBomDialogPopup(selectedExp, type, isMulipleBomScreen, workSpace);
                }
            } else {
                const workSpaceDetails = this.getWorkspaceDetails(type, workspaces, selectedExp, filteredWorkspace);
                if (workSpaceDetails && workSpaceDetails.length > 0) {
                    workSpace = orderBy(workSpaceDetails, EXPERIMENT_OPEN_IN_WORKSPACE_CONST.SEQUENCE, DESC);
                } else {
                    this.createNewWorkSpace(selectedExp);
                    return;
                }
                this.handleOpenBomDialogPopup(selectedExp, type, isMulipleBomScreen, workSpace);
            }
        }
    }

    /**
     * Method to get Attributes detail
     * @param {any[]} ipcValues
     * @param {SelectedRowDataModel[]} selectedExp
     * @param {string} type
     * @param {boolean} isMulipleBomScreen
     * @param {any[]} workSpace
     * @returns {void}
     * @memberof TabHelper
     */
    private getAttributeDetails(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        ipcValues: any[],
        selectedExp: SelectedRowDataModel[],
        type: string,
        isMulipleBomScreen: boolean,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        workSpace: any[],
    ): void {
        this.appCacheHelper.getAttributesFromCache(ipcValues).subscribe((ipcResult) => {
            let attributes = ipcResult;
            const cachedIPCs = map(ipcResult, IPC_MAPPING);
            if (isEqual(cachedIPCs, ipcValues)) {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.mapProductInfo(selectedExp, attributes, type, isMulipleBomScreen, workSpace);
            } else {
                const apiPayload = this.createPayload(ipcValues, cachedIPCs);
                this.gridApiService
                    .loadAttributesFromAPI(apiPayload)
                    .pipe(take(1))
                    .subscribe((attributesFromApi) => {
                        attributes = [...attributes, ...attributesFromApi];
                        this.mapProductInfo(selectedExp, attributes, type, isMulipleBomScreen, workSpace);
                        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    });
            }
        });
    }

    /**
     * Method to open the selected experiment in the bom screen listen to the edit bom, select experiment in the list events
     * @param {SelectedRowDataModel[]} selectedExp
     * @returns {void}
     * @memberof TabHelper
     */
    public createNewWorkSpace(selectedExp: SelectedRowDataModel[]): void {
        delay(() => {
            const createExperimentInTab = this.createExperimentCrudModel(CREATE_EXPERIMENT, selectedExp);
            this.appBroadCastService.onExperimentCreated(createExperimentInTab);
        }, 0);
    }

    /**
     * Method to handle open bom dialog popup
     * @param {SelectedRowDataModel[]} selectedExp
     * @param {String} type
     * @param {boolean} isMulipleBomScreen
     * @param {WorkSpaces[]} workSpace
     * @returns {void}
     * @memberof TabHelper
     */
    public handleOpenBomDialogPopup(
        selectedExp: SelectedRowDataModel[],
        // eslint-disable-next-line default-param-last
        type = EXPERIMENT,
        // eslint-disable-next-line default-param-last
        isMulipleBomScreen = false,
        workSpace?: WorkSpaces[],
    ): void {
        this.tasteEditorDialogService.open(
            WorkspacePopupComponent,
            this.getWorkSpaceDetailsPayload(workSpace, type, selectedExp, isMulipleBomScreen),
        );
        this.tasteEditorDialogService.dialogConfirm().subscribe((value) => {
            if (isMulipleBomScreen) {
                const selectedRows = cloneDeep(value.selectedRows);
                this.onProcessWorkspaceDialog(value, type, selectedRows);
            } else {
                this.onProcessWorkspaceDialog(value, type, selectedExp);
            }
        });
    }

    /**
     * Method to get workspace details based on product and experiment
     *
     * @param {string} type
     * @param {WorkSpaces[]} workspaces
     * @param {SelectedRowDataModel[]} selectedExp
     * @param {WorkSpaces[]} [filteredWorkspace]
     * @return {WorkSpaces[]}
     * @memberof TabHelper
     */
    public getWorkspaceDetails(
        type: string,
        workspaces: WorkSpaces[],
        selectedExp: SelectedRowDataModel[],
        filteredWorkspace?: WorkSpaces[],
    ): WorkSpaces[] {
        if (filteredWorkspace) return filteredWorkspace;
        let key = IPC_OBJ_KEY;
        if (type === EXPERIMENT) {
            key = EXP_ID_OBJ_KEY;
        }
        const workSpaceDetails = filter(workspaces, (workSpace) => {
            return find(workSpace.WorkSpaceDetail, (details) => details[key] === selectedExp[0][key]);
        });
        return workSpaceDetails as unknown as WorkSpaces[];
    }

    /**
     * Method to map product info
     * @param {SelectedRowDataModel[]} selectedExp
     * @param {any} ipcResult
     * @param {String} type
     * @param {boolean} isMulipleBomScreen
     * @param {WorkSpaces[]} workSpace
     * @returns {void}
     * @memberof TabHelper
     */
    public mapProductInfo(
        selectedExp: SelectedRowDataModel[],
        ipcResult,
        // eslint-disable-next-line default-param-last
        type = EXPERIMENT,
        // eslint-disable-next-line default-param-last
        isMulipleBomScreen = false,
        workSpace?: WorkSpaces[],
    ): void {
        forEach(selectedExp, (expData) => {
            if (expData.IPC) {
                const productDetails = find(ipcResult, (productData) => productData.ipc === String(expData.IPC));
                Object.assign(expData, {
                    description: productDetails?.description,
                    bomright: productDetails?.bomright,
                    isbom: productDetails?.isbom,
                });
            }
        });
        this.handleOpenBomDialogPopup(selectedExp, type, isMulipleBomScreen, workSpace);
    }

    /**
     * Method to create payload
     *
     * @param {string[]} ipcValues
     * @param {string[]} cachedIPCs
     * @memberof TabHelper
     */
    private createPayload = (ipcValues: string[], cachedIPCs: string[]) => {
        const missingIPCs = ipcValues.filter((payloadIPC) => !cachedIPCs.includes(payloadIPC));
        const apiPayload = {
            payload: {
                filter: { ipcs: missingIPCs },
                from: 0,
                recordcount: 10,
            },
            plantInfo: [],
            landingPageAudit: true,
        };
        return apiPayload;
    };

    /**
     * Method to get dialog data
     *
     * @param {workspaceDetails} TasteEditorDialogModel
     *
     * @return {TasteEditorDialogModel}
     * @memberof TabHelper
     */
    private getWorkSpaceDetailsPayload(workspaceDetails, type, selectedExp, isMulipleBomScreen): TasteEditorDialogModel {
        const dialogPayload = JSON.parse(JSON.stringify(WORKSPACE_DIALOG));

        if (type === PRODUCT) {
            dialogPayload.data.title = EXPERIMENT_OPEN_IN_WORKSPACE_CONST.WORKSPACE_PRODUCT_DIALOG_TITLE;
        }
        if (type === EXPERIMENT && selectedExp?.length === 1 && !isMulipleBomScreen) {
            dialogPayload.data.title = `${selectedExp[0]?.ExpCode} already open in`;
        }
        if (isMulipleBomScreen) {
            dialogPayload.data.title = EXPERIMENT_OPEN_IN_WORKSPACE_CONST.OPEN_MULTIPLE_EXPERIMENT_BOM;
        }

        dialogPayload.data.dialogData = [
            {
                workspaceDetails,
                selectedExp,
                type,
                isMulipleBomScreen,
            },
        ];
        dialogPayload.autoFocus = false;
        return dialogPayload;
    }

    /**
     * Method to process the workspace dialog response
     *
     * @param {WorkSpaceDialogResponse} dialogResponse
     * @param {string} type
     * @param {SelectedRowDataModel[]} selectedExp
     * @memberof TabHelper
     */
    public onProcessWorkspaceDialog(dialogResponse: WorkSpaceDialogResponse, type: string, selectedExp: SelectedRowDataModel[]): void {
        if (type === PRODUCT) this.appBroadCastService.onWorkspaceDialogResponse(dialogResponse);
        if (
            typeof dialogResponse !== DATA_TYPE.STRING &&
            typeof dialogResponse !== DATA_TYPE.BOOLEAN &&
            dialogResponse?.type === WORKSPACE_DIALOG_BUTTONS.OPEN_IN_NEW_WORKSPACE
        ) {
            this.createNewWorkSpace(selectedExp);
        } else if (
            typeof dialogResponse !== DATA_TYPE.STRING &&
            typeof dialogResponse !== DATA_TYPE.BOOLEAN &&
            dialogResponse?.type === WORKSPACE_DIALOG_BUTTONS.OPEN_IN_MOST_RECENT_WORKSPACE
        ) {
            if (selectedExp?.length > 0) {
                AppStateService.setExpToBeActiveInWorkSpace(selectedExp[0].ExpCode);
            }
            this.appBroadCastService.getWorkSpaceDetails(dialogResponse?.workSpaceDetail);
        }
    }

    /**
     * Method to update Tab Sequence
     * @param {TabSequenceUpdateModel} updateTabPayload
     * @returns {TabDetailModel[]}
     * @memberof TabHelper
     */
    public updateTabSequence(updateTabPayload: TabSequenceUpdateModel): Observable<TabDetailModel[]> {
        return this.appDataService.post(this.appDataService.url.updateUserTabSequence, [], updateTabPayload);
    }
}
