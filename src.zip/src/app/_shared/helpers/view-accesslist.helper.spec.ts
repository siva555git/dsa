/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { accessListTreeData, restrictedUseValues } from "@te-testing/mock-view-access-list-component";
import { RestrictedUsageListTreeView } from "@te-shared/components/product-data/models/product-data.model";
import { ViewAccessListHelper } from "./view-accesslist.helper";
import { MockAppcacheHelper } from "../../testing/mock-app-cache-helper";
import { AppCacheHelper } from "./app-cache.service";
import { MockTabHelperService } from "../../testing/mock-tabhelper.service";
import { TabHelper } from "./tab-helper";

describe("ViewAccessListHelper", () => {
    let service: ViewAccessListHelper;
    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [
                ViewAccessListHelper,
                {
                    provide: AppCacheHelper,
                    useValue: MockAppcacheHelper,
                },
                {
                    provide: TabHelper,
                    useClass: MockTabHelperService,
                },
            ],
        })));

    beforeEach(() => {
        service = TestBed.inject(ViewAccessListHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call on getSecurityGroupNames()", () => {
        const restrictedUseValue = restrictedUseValues;
        const spy = spyOn(ViewAccessListHelper, "getSecurityGroupNames").and.callThrough();
        ViewAccessListHelper.getSecurityGroupNames(restrictedUseValue.restrictedUse);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getAccessListUsers()", () => {
        const restrictedUseValue = restrictedUseValues;
        const spy = spyOn(ViewAccessListHelper, "getAccessListUsers").and.callThrough();
        ViewAccessListHelper.getAccessListUsers(restrictedUseValue.restrictedUse);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on createTreeStructure", () => {
        spyOn(ViewAccessListHelper, "getParentFlagCode").and.returnValue(["INHERITED RESTRICTED USE", "TECHICAL FLAVORISTS"]);
        const spy = spyOn(ViewAccessListHelper, "createTreeStructure").and.callThrough();
        ViewAccessListHelper.createTreeStructure([accessListTreeData] as unknown as RestrictedUsageListTreeView[]);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getParentFlagCode", () => {
        const spy = spyOn(ViewAccessListHelper, "getParentFlagCode").and.callThrough();
        ViewAccessListHelper.getParentFlagCode(
            accessListTreeData as unknown as RestrictedUsageListTreeView[],
            accessListTreeData as unknown as RestrictedUsageListTreeView,
            [],
        );
        expect(spy).toHaveBeenCalled();
    });
});
