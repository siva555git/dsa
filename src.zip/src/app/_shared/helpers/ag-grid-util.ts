/* eslint-disable angular/document-service */
import { findIndex, forEach, sortBy } from "lodash";
import { GridApi, RowNode, RowDataTransaction, RefreshCellsParams } from "@ag-grid-community/core";
import { EMPTY } from "../../app.constant";
import { BomDetailsModel, ExperimentsModel } from "../models/experiment-bom.model";
import { InstructionNewItem, SelectedRowDataModel } from "../models/selected-row-data.model";
import { UserColumnLayoutType } from "../../master-data/models/column-layout.model";
import { COST_ATTRIBUTES, INDEX, KEYBOARD_KEYS, PARTS_PERCENTAGE, NUMRIC_LIMITS, BOM_TYPE, GET_TOP_LEVEL_NODES } from "../constants";
import { ExplodeCombineModel } from "../../experiment-editor/models/explode-combine-model";

export class AgGridUtil {
    /**
     * Method to update grid with transaction.
     * This will selectively add, update or remove rowData using transaction instead of regenerating the entire grid
     * @param addItems, removeItems, updateItems, addIndex
     * @param resultCallBack
     * @returns {void}
     * @memberof AgGridUtil
     */
    public static updateGridWithTransaction(
        gridApi: GridApi,
        addIndex?: number | null,
        addItems?: unknown[] | null,
        removeItems?: unknown[] | null,
        updateItems?: unknown[] | null,
        resultCallBack?,
    ): void {
        const transactionObject: RowDataTransaction = {};
        if (addIndex >= 0 && addItems?.length > 0) {
            transactionObject.addIndex = addIndex;
        }
        if (addItems?.length > 0) {
            transactionObject.add = addItems;
        }
        if (removeItems?.length > 0) {
            transactionObject.remove = removeItems;
        }
        if (updateItems?.length > 0) {
            transactionObject.update = updateItems;
        }
        gridApi.applyTransactionAsync(transactionObject, resultCallBack);
    }

    /**
     * Method to return the Key to access the field in the formatted aggrid
     *
     * @param {string} value arguments
     * @param {string} key arguments
     * @memberof AgGridUtil
     */

    public static getTreeGridKeys(value: string, key: string): string {
        // eslint-disable-next-line unicorn/prefer-spread
        return value.concat(key);
    }

    /**
     * Method to retain row focus after soft deleted bom item using del key from keyboard
     * @param  {gridApi} gridApi
     * @memberof AgGridUtil
     */
    public static retainRowFocus(gridApi: GridApi): void {
        const cell = gridApi.getFocusedCell();
        if (cell) {
            gridApi.setFocusedCell(cell.rowIndex, cell.column);
        }
    }

    /**
     * Method to refresh particular cell for the particular column in grid
     * @static
     * @param {GridApi} gridApi
     * @param {*} selectedRow
     * @param {string[]} expCode
     * @param {boolean} [useGridApiNodeForSelection=true]
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static refreshSelectedGridCells(gridApi: GridApi, selectedRow: any, expCode: string[], useGridApiNodeForSelection = true): void {
        const refreshSelectedCellPayload: RefreshCellsParams = {
            force: true,
            columns: expCode,
            rowNodes: useGridApiNodeForSelection ? gridApi.getSelectedNodes() : selectedRow,
        };
        gridApi.refreshCells(refreshSelectedCellPayload);
    }

    /**
     * Get the selected row data with index when instructions are hidden in grid
     * @param {GridApi} gridApi
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getFirstSelectedRowData(gridApi: GridApi): any {
        const selectedRowNodes = gridApi.getSelectedNodes();
        const firstRow = [];
        if (selectedRowNodes.length > 0) {
            const firstSelectedRow = selectedRowNodes[0];
            gridApi.forEachNode((rowNode, index) => {
                if (rowNode.id === firstSelectedRow.id) {
                    // eslint-disable-next-line no-param-reassign
                    rowNode.data.index = index;
                    firstRow.push(rowNode.data);
                }
            });
        }
        return firstRow;
    }

    /**
     * Method to get the entire grid data / rownode based on boolean value
     * @param {GridApi} gridApi
     * @param {false} isNode
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getGridRowData(gridApi: GridApi, isNode = false): any {
        const gridData = [];
        gridApi.forEachNode((rowData: RowNode) => {
            gridData.push(isNode ? rowData : rowData.data);
        });
        return gridData;
    }

    /**
     * Method to get the level based row node
     * @param {GridApi} gridApi
     * @param {false} isNode
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getGridRowDataBasedOnLevel(gridApi: GridApi, level: number, isNode = false): any {
        const gridData = [];
        gridApi.forEachNode((rowData: RowNode) => {
            if (rowData?.level === level) {
                gridData.push(isNode ? rowData : rowData.data);
            }
        });
        return gridData;
    }

    /**
     * Method to get the selected row data
     * @param {GridApi} agGridEvent
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getSelectedFolderRowData(agGridEvent: GridApi, selectedFolderId: string): any {
        return agGridEvent.getRowNode(selectedFolderId);
    }

    /**
     * Get the selected row data with index when instructions are not hidden in grid
     *
     * @static
     * @param {GridApi} gridApi
     * @param {RowNode[]} [rowNodeList]
     * @return {*}  {*}
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getSelectedRows(gridApi: GridApi, rowNodeList?: RowNode[]): any {
        let rowNodes = rowNodeList ?? gridApi.getSelectedNodes();
        if (!rowNodeList && rowNodes?.length === 0) {
            rowNodes = this.getSelectedNodeList(gridApi);
        }
        const selectedRows = [];
        if (rowNodes?.length > 0) {
            forEach(rowNodes, (node: RowNode) => {
                if (rowNodeList && !node.isSelected()) return;
                const desiredRowNode = node;
                desiredRowNode.data.index = node.rowIndex;
                selectedRows.push(desiredRowNode.data);
            });
        }
        return this.arrangeRows(selectedRows);
    }

    /**
     * Get the current page selected row data
     * @param {GridApi} gridApi
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getCurrentPageSelectedRows(gridApi: GridApi): any {
        return this.getSelectedRows(gridApi, gridApi.getRenderedNodes());
    }

    /**
     * Select the chosen row(s) in grid
     * @param agGridEvent
     * @param cell
     * @memberof AgGridUtil
     */
    public static selectRows(agGridEvent, rowNode: RowNode): void {
        const { event, api } = agGridEvent;
        const gridApi: GridApi = api ?? agGridEvent;
        if (event && event.shiftKey && (event.key === KEYBOARD_KEYS.UP_ARROW || event.key === KEYBOARD_KEYS.DOWN_ARROW)) {
            gridApi.forEachNode((node) => {
                if (node.id !== rowNode.id) return;

                if (node.isSelected()) {
                    agGridEvent.node.setSelected(false);
                } else {
                    node.setSelected(true);
                }
            });
        } else if (rowNode) {
            gridApi.forEachNode((node) => {
                node.setSelected(node.rowIndex === rowNode.rowIndex);
            });
        }
    }

    /**
     * Focus the given row index in grid
     * @param agGridEvent
     * @param {number} rowIndex
     * @memberof AgGridUtil
     */
    public static focusNewRow(agGridEvent: GridApi, rowIndex: number): void {
        agGridEvent.ensureIndexVisible(rowIndex);
    }

    /**
     * Get the index to insert row data in grid
     * @param gridApi
     * @param selectedRows
     * @memberof AgGridUtil
     */
    public static getRowIndexForInsertion(gridApi, selectedRows, activeExpFormulaKey): number {
        // Get last index based on active experiment instead of overall top level nodes last index when no rows selected
        return selectedRows.length > 0
            ? selectedRows[0].index + 1
            : gridApi
                  ?.getModel()
                  .getTopLevelNodes()
                  ?.filter((topNode) => topNode.data[activeExpFormulaKey])?.length;
    }

    /**
     * Method to check selected instructions are in the added items for adding new instruction from the line items
     *
     * @static
     * @param {Array<InstructionNewItem>} items
     * @return {*}  {boolean}
     * @memberof AgGridUtil
     */
    public static isAllItemsAreInstructions(items: Array<InstructionNewItem>): boolean {
        return items.every((item) => item.SUBType === BOM_TYPE.INSTRUCTION);
    }

    /**
     * Get the index to insert row data in grid when instruction only selected
     *
     * @static
     * @param {*} gridApi
     * @param {*} selectedRows
     * @return {*}  {number}
     * @memberof AgGridUtil
     */
    public static getIndexForMultipleInstruction(gridApi: GridApi, selectedRows: SelectedRowDataModel[], activeExpFormulaKey): number {
        return selectedRows.length > 0
            ? selectedRows[0].index
            : gridApi
                  ?.getModel()
                  [GET_TOP_LEVEL_NODES]()
                  ?.filter((topNode) => topNode.data[activeExpFormulaKey])?.length;
    }

    /**
     * Focus, Highlight and Select newly inserted row(s) in Edit mode
     * @param agGridEvent
     * @param {number} insertRowIndex
     * @param {string} colId
     * @memberof AgGridUtil
     */
    public static highlightAndSelectNewRows(agGridEvent: GridApi, insertRowIndex: number, colId: string): void {
        AgGridUtil.focusNewRow(agGridEvent, insertRowIndex);
        AgGridUtil.selectRows(agGridEvent, agGridEvent.getModel().getRow(insertRowIndex));
        AgGridUtil.startEditing(agGridEvent, insertRowIndex, colId);
    }

    /**
     * Enter edit state for a cell
     * @param agGridEvent
     * @param {number} cellIndex
     * @param {string} colId
     * @memberof AgGridUtil
     */
    public static startEditing(agGridEvent, cellIndex: number, colId: string): void {
        const api = agGridEvent.api ?? agGridEvent;
        api.startEditingCell({
            rowIndex: cellIndex,
            colKey: colId,
        });
    }

    /**
     * Method to form the row data
     * @param {ExperimentsModel} rowInfo
     * @returns {*}
     * @memberof AgGridUtil
     */
    public static selectedRowInfo(rowInfo: ExperimentsModel): SelectedRowDataModel {
        return {
            ExpID: rowInfo.ExpID,
            ExpCode: rowInfo.ExpCode,
            checked: true,
            CreatedBy: rowInfo.CreatedBy,
            IPC: rowInfo.IPC,
            productType: rowInfo.ProductTypeID,
            ExpName: rowInfo.ExpName,
            ExperimentVariant: rowInfo.ExperimentVariant,
            IsPublic: rowInfo.IsPublic,
            IsLocked: rowInfo.IsLocked,
            ExpAccessStatus: rowInfo.ExpAccessStatus ?? false,
            IsOtherExp: rowInfo.IsOtherExp,
            SharedTo: rowInfo.SharedTo,
            SharedFrom: rowInfo.SharedFrom,
            ExperimentStaffDetails: rowInfo.ExperimentStaffDetails,
            MappedFolderID: rowInfo.MappedFolderID,
            Yield: rowInfo.Yield,
            Trustee: rowInfo.Trustee,
            Comment: rowInfo.Comment,
            ExperimentNote: rowInfo.ExperimentNote,
            TaskID: rowInfo.TaskID || rowInfo.Task,
            UseLevel: rowInfo.UseLevel,
        };
    }

    /**
     * Method to get only cost columns
     *
     *
     * @memberof AgGridUtil
     */
    public static getCostColumn(rawAttributeColumns: UserColumnLayoutType[]): UserColumnLayoutType[] {
        return rawAttributeColumns.filter(
            (column) =>
                column.isCost || COST_ATTRIBUTES.find((item) => item === column.ColumnName) || column.ColumnName === PARTS_PERCENTAGE,
        );
    }

    /**
     * Method to form the row data
     * @param {number} partsValueToRoundOff
     * @returns {string}}
     * @memberof AgGridUtil
     */
    public static roundOff(partsValueToRoundOff: number): string {
        return Number(partsValueToRoundOff).toFixed(NUMRIC_LIMITS.DECIMAL_LIMIT);
    }

    /**
     * Method to get newly added items  Details response
     * request
     * {BomDetailsModel} response
     * @memberof AgGridUtil
     */
    public static getNewlyAddedItemsFromBomDetailsResponse = (request: ExplodeCombineModel, response: BomDetailsModel) => {
        const insertedData = [];
        const bomDetailsIndex = findIndex(response.Experiments, { ExpID: request.bomItems[0].ExpID });
        response.Experiments[bomDetailsIndex].ExperimentFormula.forEach((bomItem) => {
            const bomIndex = findIndex(request.bomItems, { ExpFormulaID: bomItem.ExpFormulaID });
            if (bomIndex === -1) {
                insertedData.push(bomItem);
            }
        });
        return insertedData;
    };

    /**
     * Method to expand row data if row is collapsed
     * @param {GridApi} agGridEvent
     * @returns {void}
     * @memberof AgGridUtil
     */
    public static expandAllCollapsedRowData(agGridEvent: GridApi): void {
        agGridEvent.forEachNode((rowData: RowNode) => {
            if (!rowData.expanded) {
                agGridEvent.expandAll();
            }
        });
    }

    /**
     * Method to get only cost columns
     * @param {UserColumnLayoutType} rawAttributeColumns
     * @param {string} displayName
     * @return {UserColumnLayoutType[]}
     * @memberof AgGridUtil
     */
    public static checkAttributeHeaderHasCostColumn(
        rawAttributeColumns: UserColumnLayoutType[],
        displayName: string,
    ): UserColumnLayoutType[] {
        return rawAttributeColumns.filter((column) =>
            COST_ATTRIBUTES.find((item) => item === column.ColumnName && displayName === column.ColumnHeader),
        );
    }

    /**
     * Method to arrange selectedRows according to ascendeing order of their indices
     *
     * @static
     * @param {Array<any>} selectedRows
     * @return {*}  {Array<any>}
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static arrangeRows(selectedRows: Array<any>): Array<any> {
        return sortBy(selectedRows, INDEX);
    }

    /**
     * Method to round off cost
     * @param {number} cost
     * @returns {string}}
     * @memberof AgGridUtil
     */
    public static roundOffCost(cost: number): string {
        return Number(cost).toFixed(2);
    }

    /**
     * Method to round off stock
     * @param {number} stock
     * @returns {string}}
     * @memberof AgGridUtil
     */
    public static roundOffStock(stock: number): string {
        return Number(stock).toFixed(2);
    }

    /**
     * Method to show and hide the loading template in the AG grid
     * @param gridApi
     * @returns {void}
     * @memberof AgGridUtil
     */
    public static showHideNoRowTemplate(gridApi: GridApi): void {
        if (gridApi.getDisplayedRowCount() > 0) {
            gridApi.hideOverlay();
        } else if (gridApi.getDisplayedRowCount() === 0) {
            gridApi.showNoRowsOverlay();
        }
    }

    /**
     * Mehtod to copy ranges for Grid API
     * @param { GridApi} gridApi
     * @return {void}
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line class-methods-use-this
    public static onCopyToClipboard(gridApi: GridApi): void {
        const { rowIndex, column } = gridApi.getFocusedCell();
        const row = gridApi.getDisplayedRowAtIndex(rowIndex);
        const cellValue = row?.data[column.getColDef()?.field] || EMPTY;
        // create textarea to set data
        const textarea = document.createElement("textarea");
        // Add cellValue to textarea
        textarea.textContent = cellValue;
        // Add to document body
        document.body.append(textarea);
        // Create range and selection to copy data to clipboard
        const selection = document.getSelection();
        const range = document.createRange();
        range.selectNodeContents(textarea);
        range.selectNode(textarea);
        selection.removeAllRanges();
        selection.addRange(range);
        // Run browser copy command
        document.execCommand("copy");
        selection.removeAllRanges();
        textarea.remove();
        // Clear focus from grid
        gridApi.clearFocusedCell();
    }

    /**
     * Method to get the selected Nodes
     * @param {number} gridApi
     * @memberof AgGridUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getSelectedNodeList(gridApi: GridApi): any {
        const selectedNodes = [];
        gridApi.forEachNode((node) => {
            if (node.isSelected()) {
                selectedNodes.push(node);
            }
        });
        return selectedNodes;
    }
}
