/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable import/no-unresolved */
import { Injectable } from "@angular/core";
import { Store } from "@ngrx/store";
import { cloneDeep, each } from "lodash";
import { Observable } from "rxjs";
import { take } from "rxjs/operators";
import { forkJoin } from "rxjs/internal/observable/forkJoin";
import { WorkSpaces } from "@te-shared/models/create-tab.model";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { AppDataService } from "../../_services/app-data/app.data.service";
import { BomAttributes } from "../models/attributes-model";
import * as fromActions from "../../experiment-editor/store/actions/attribute.actions";
import * as fromReducer from "../../experiment-editor/store/reducers/attributes.reducer";
import * as flavorTypesActions from "../../experiment-editor/store/actions/flavor-types.actions";
import * as flavorTypesReducer from "../../experiment-editor/store/reducers/flavor-types.reducer";
import * as productTypesActions from "../../experiment-editor/store/actions/product-types.actions";
import * as technologyActions from "../../experiment-editor/store/actions/technology.actions";
import * as productTypesReducer from "../../experiment-editor/store/reducers/product-types.reducer";
import * as plantAndSourceActions from "../../experiment-editor/store/actions/plant-and-source.actions";
import * as currenciesRatesActionTypes from "../../experiment-editor/store/actions/currencies-rate.actions";
import * as plantAndSourceReducer from "../../experiment-editor/store/reducers/plant-and-source.reducers";
import * as bomSearchActions from "../../experiment-editor/store/actions/bom-search.actions";
import * as bomSearchReducer from "../../experiment-editor/store/reducers/bom-search.reducers";
import * as facilitiesActions from "../../experiment-editor/store/actions/facilities.actions";
import * as facilitiesReducer from "../../experiment-editor/store/reducers/facilities.reducer";
import * as costActions from "../master-data/store/actions/cost.actions";
import * as costReducer from "../master-data/store/reducers/cost.reducer";
import * as specActions from "../master-data/store/actions/specs.action";
import * as specReducers from "../master-data/store/reducers/specs.reducer";
import * as flagActions from "../master-data/store/actions/flags.action";
import * as flagReducers from "../master-data/store/reducers/flags.reducers";
import * as flavorClassesActions from "../master-data/store/actions/flavor-classes.actions";
import * as flavorClassesReducers from "../master-data/store/reducers/flavor-classes.reducers";
import * as currenciesReducer from "../../experiment-editor/store/reducers/currencies.reducer";
import * as currenciesActions from "../../experiment-editor/store/actions/currencies.actions";
import * as currenciesRateReducer from "../../experiment-editor/store/reducers/currencies-rates.reducer";
import * as rememberHomeContextActions from "../master-data/store/actions/remember-home-context.actions";
import * as rememberHomeContextReducer from "../master-data/store/reducers/remember-home-context.reducers";
import * as editSuggestionActions from "../../experiment-editor/store/actions/edit-suggestion.action";
import * as editSuggestionReducer from "../../experiment-editor/store/reducers/edit-suggestion.reducer";
import * as uomDetailsActionsTypes from "../master-data/store/actions/uom-details.actions";
import * as uomDetailsReducer from "../master-data/store/reducers/uom-details.reducer";
import * as technologyReducer from "../../experiment-editor/store/reducers/technology.reducer";
import { TasteEditorAppState } from "../taste-editor-app-state";
import { API, DEFAULT_MASTER_DATA_COUNT, FRAG_TYPE, PRODUCT_TYPE, STORE } from "../constants/common.constant";
import { HomeActionContextModel } from "../models/experiment-list.model";

@Injectable({
    providedIn: "root",
})
export class AppCacheHelper {
    constructor(private store: Store<TasteEditorAppState>,
        private readonly appDataService: AppDataService,
        public readonly securityHelper: SecurityHelper,
    ) { }

    /**
     * Method to store the attributes in cache
     * @param {any} attributesResponse
     * @memberof AppCacheHelper
     */
    public storeAttributesInCache(attributesResponse) {
        this.store.dispatch(new fromActions.LoadAttributesSuccess({ bomAttributes: cloneDeep(attributesResponse) }));
    }

    /**
     * Method to store static datas in cache
     * @param defaultDataResponse
     * @memberof AppCacheHelper
     */
    public storeDefaultDataInCache(defaultDataResponse) {
        if (defaultDataResponse && defaultDataResponse.length === DEFAULT_MASTER_DATA_COUNT) {
            const {
                0: flavorTypes,
                1: productTypes,
                2: facilities,
                3: plantsAndSources,
                4: costs,
                5: specs,
                6: flags,
                7: flavorClasses,
                8: currencies,
                9: currenciesRate,
                10: uomDetails,
                11: technology,
            } = defaultDataResponse;
            this.store.dispatch(new flavorTypesActions.LoadFlavortypesSuccess({ flavorTypes: cloneDeep(flavorTypes) }));
            this.store.dispatch(new productTypesActions.LoadProductTypesSuccess({ productTypes: cloneDeep(productTypes) }));
            this.store.dispatch(new facilitiesActions.LoadFacilitiesSuccess({ facilities: cloneDeep(facilities) }));
            this.store.dispatch(new plantAndSourceActions.LoadPlantAndSourceSuccess({ plantAndSource: cloneDeep(plantsAndSources) }));
            this.store.dispatch(new costActions.LoadCostSuccess({ cost: cloneDeep(costs) }));
            this.store.dispatch(new specActions.LoadSpecsSuccess({ specs: cloneDeep(specs) }));
            this.store.dispatch(new flagActions.LoadFlagsSuccess({ flags: cloneDeep(flags) }));
            this.store.dispatch(new flavorClassesActions.LoadFlavorClassesSuccess({ flavorClasses: cloneDeep(flavorClasses) }));
            this.store.dispatch(new currenciesActions.LoadCurrenciesSuccess({ currencies: cloneDeep(currencies) }));
            this.store.dispatch(new currenciesRatesActionTypes.LoadCurrenciesRatesSuccess({ currenciesrates: cloneDeep(currenciesRate) }));
            this.store.dispatch(new uomDetailsActionsTypes.LoadUOMSuccess({ uomDetails: cloneDeep(uomDetails) }));
            this.store.dispatch(new technologyActions.LoadTechnologySuccess({ technology: cloneDeep(technology) }));
        }
    }

    /**
     * Method to check static datas exists in cache
     * @memberof AppCacheHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getDefaultDataStoreCount(): Observable<any> {
        return new Observable((observer) => {
            const requestedURL = [
                this.store.select(flavorTypesReducer.flavorTypesCount).pipe(take(1)),
                this.store.select(productTypesReducer.productTypesCount).pipe(take(1)),
                this.store.select(facilitiesReducer.facilitiesCount).pipe(take(1)),
                this.store.select(plantAndSourceReducer.plantAndSourceCount).pipe(take(1)),
                this.store.select(costReducer.costCount).pipe(take(1)),
                this.store.select(specReducers.specsCount).pipe(take(1)),
                this.store.select(flagReducers.flagsCount).pipe(take(1)),
                this.store.select(flavorClassesReducers.flavorClassesCount).pipe(take(1)),
                this.store.select(currenciesReducer.currenciesCount).pipe(take(1)),
                this.store.select(currenciesRateReducer.currenciesRateCount).pipe(take(1)),
                this.store.select(uomDetailsReducer.uomCount).pipe(take(1)),
                this.store.select(technologyReducer.technologyCount).pipe(take(1)),
            ];
            forkJoin(requestedURL).subscribe({
                next: (response) => {
                    if (response && response.length === DEFAULT_MASTER_DATA_COUNT) {
                        const object = {
                            flavorTypes: response[0],
                            productTypes: response[1],
                            facilities: response[2],
                            plantsAndSources: response[3],
                            costs: response[4],
                            specs: response[5],
                            flags: response[6],
                            flavorClasses: response[7],
                            currencies: response[8],
                            currenciesRate: response[9],
                            uomDetails: response[10],
                            technology: response[11],
                        };
                        observer.next(object);
                        observer.complete();
                    }
                },
                error: (error) => {
                    observer.error(error);
                },
            });
        });
    }

    /**
     * Method to get the default data from store if it exists else fetch from API
     * @param staticDataCounts
     * @memberof AppCacheHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getDefaultData(staticDataCounts): Observable<any> {
        return new Observable((observer) => {
            const { requestUrl, type } = this.prepareStaticDataRequestUrl(staticDataCounts);
            forkJoin(requestUrl as Array<Observable<any>>).subscribe({
                next: (response) => {
                    response[1] = response[1].flat(1).filter((e, i) => response[1].flat(1).findIndex(a => a.prodtypecode === e.prodtypecode) === i);
                    if (type === API) {
                        this.storeDefaultDataInCache(response);
                    }
                    observer.next(response);
                    observer.complete();
                },
                error: (error) => {
                    observer.error(error);
                },
            });
        });
    }

    /**
     * Prepare the url for store or API to fetch data
     * @param staticDataCounts
     * @memberof AppCacheHelper
     */
    public prepareStaticDataRequestUrl(staticDataCounts) {
        const requestUrl = [];
        let type = STORE;
        each(staticDataCounts, (value, key) => {
            if (value === 0) {
                type = API;
            }
            requestUrl.push(this.getValueFromStoreOrApi(key, type));
        });
        return { requestUrl, type };
    }

    /**
     * Method to get the values for store or api url based on the store count
     * @param key
     * @param type
     * @memberof AppCacheHelper
     */
    public getValueFromStoreOrApi(key, type) {
        const storeType = {
            flavorTypes: this.store.select(flavorTypesReducer.selectAllFlavorTypes).pipe(take(1)),
            productTypes: this.store.select(productTypesReducer.selectAllProductTypes).pipe(take(1)),
            facilities: this.store.select(facilitiesReducer.selectAllFacilities).pipe(take(1)),
            plantsAndSources: this.store.select(plantAndSourceReducer.selectAllPlantAndSource).pipe(take(1)),
            costs: this.store.select(costReducer.selectAllCost).pipe(take(1)),
            specs: this.store.select(specReducers.selectAllSpecs).pipe(take(1)),
            flags: this.store.select(flagReducers.selectAllFlags).pipe(take(1)),
            flavorClasses: this.store.select(flavorClassesReducers.selectAllFlavorClasses).pipe(take(1)),
            currencies: this.store.select(currenciesReducer.selectAllCurrencies).pipe(take(1)),
            currenciesRate: this.store.select(currenciesRateReducer.selectAllCurrenciesRate).pipe(take(1)),
            uomDetails: this.store.select(uomDetailsReducer.selectAllUom).pipe(take(1)),
            technology: this.store.select(technologyReducer.selectAllTechnology).pipe(take(1)),
        };
        const apiType = {
            flavorTypes: this.appDataService.get(this.appDataService.url.getFlavorTypes, []),
            productTypes:
                this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION) === false
                    ? this.appDataService.get(this.appDataService.url.getProductTypes, [PRODUCT_TYPE])
                    : this.getAllProductTypes(),
            facilities: this.appDataService.get(this.appDataService.url.getFacilities, []),
            plantsAndSources: this.appDataService.get(this.appDataService.url.getPlantsAndSources, []),
            costs: this.appDataService.get(this.appDataService.url.getCostBooks, []),
            specs: this.appDataService.get(this.appDataService.url.getSpecs, []),
            flags: this.appDataService.get(this.appDataService.url.getFlags, []),
            flavorClasses: this.appDataService.get(this.appDataService.url.getFlavorClass, []),
            currencies: this.appDataService.get(this.appDataService.url.getCurrencies, []),
            currenciesRate: this.appDataService.get(this.appDataService.url.getCurrencyRate, []),
            uomDetails: this.appDataService.get(this.appDataService.url.getUOMDetails, []),
            technology: this.appDataService.get(this.appDataService.url.getSapTechnology, []),
        };
        if (type === "store") {
            return storeType[key];
        }
        return apiType[key];
    }

    getAllProductTypes(): Observable<any>{
        const requestedURL: [Observable<any>, Observable<any>] = [
            this.appDataService.get(this.appDataService.url.getProductTypes, [PRODUCT_TYPE]),
            this.appDataService.get(this.appDataService.url.getProductTypes, [FRAG_TYPE]),
        ];
        return forkJoin(requestedURL);
    }

    /**
     * Get the attributes from the Cache
     * @param {any} ipcList arguments
     * @memberof AppCacheHelper
     */
    public getAttributesFromCache(ipcList): Observable<BomAttributes[]> {
        return new Observable((observer) => {
            this.store
                .select(fromReducer.selectAttributesByIPC({ ipcs: ipcList }))
                .pipe(take(1))
                .subscribe({
                    next: (data) => {
                        observer.next(data);
                        observer.complete();
                    },
                    error: (error) => {
                        observer.error(error);
                    },
                });
        });
    }

    /**
     * Method to store home actions
     * @param {HomeActionContextModel} homeContext
     * @memberof AppCacheHelper
     */
    public storeHomeContext(homeContext: HomeActionContextModel[]) {
        this.store.dispatch(new rememberHomeContextActions.LoadRememberHomeContextSuccess({ homeContext: cloneDeep(homeContext) }));
    }

    /**
     * Method to store workspace accessed with bom search
     * @param {WorkSpaces} workspace
     * @memberof AppCacheHelper
     */
    public storeWorspaceBomSearch(workspace: WorkSpaces[]): void {
        this.store.dispatch(new bomSearchActions.ShowBomSearch({ bomSearch: cloneDeep(workspace) }));
    }

    /**
     * Method to store latest used tab in edit suggestion
     * @param {number} tab
     * @memberof AppCacheHelper
     */
    public storeLatestTab(tabIndex: any): void {
        this.store.dispatch(new editSuggestionActions.ShowActiveTab(tabIndex));
    }
    /**
     * Get last used tab from cache
     * @return {*}  {Observable<any>}
     * @memberof AppCacheHelper
     */

    public getLatestTab(): Observable<any> {
        return new Observable((observer) => {
            this.store
                .select(editSuggestionReducer.selectTabs)
                .pipe(take(1))
                .subscribe({
                    next: (data) => {
                        observer.next(data);
                        observer.complete();
                    },
                    error: (error) => {
                        observer.error(error);
                    },
                });
        });
    }

    /**
     * Method to get state data of workspace accessed with bom search
     * @returns {Observable<WorkSpaces[]>}
     * @memberof AppCacheHelper
     */
    public getWorspaceBomSearchFromCache(): Observable<WorkSpaces[]> {
        return new Observable((observer) => {
            this.store
                .select(bomSearchReducer.selectAllWorkspaces)
                .pipe(take(1))
                .subscribe({
                    next: (data) => {
                        observer.next(data);
                        observer.complete();
                    },
                    error: (error) => {
                        observer.error(error);
                    },
                });
        });
    }

    /**
     * Get home action context from cache
     * @returns {Observable<HomeActionContextModel[]>}
     * @memberof AppCacheHelper
     */
    public getHomeContextFromCache(): Observable<HomeActionContextModel[]> {
        return new Observable((observer) => {
            this.store
                .select(rememberHomeContextReducer.selectAllRememberHomeContext)
                .pipe(take(1))
                .subscribe({
                    next: (data) => {
                        observer.next(data);
                        observer.complete();
                    },
                    error: (error) => {
                        observer.error(error);
                    },
                });
        });
    }
}
