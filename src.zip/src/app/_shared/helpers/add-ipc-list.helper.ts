import { Injectable } from "@angular/core";
import { ExperimentEditorService } from "@te-experiment-editor/helpers/experiment-editor.service";
import { forEach, map } from "lodash";
import { AppBroadCastService } from "@te-services/index";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { EMPTY, LOADING } from "src/app/app.constant";
import { ADD_IPC_TYPE } from "@te-shared/constants";
import { ExistingIpcListModel, IpcBasicAttributeInfo, NewIpcListModel } from "@te-shared/components/add-ipc-list/models/add-ipc-list.model";
import { ExperimentApiService } from "./experiment-api.service";

@Injectable()
export class AddIpcListHelper {
    constructor(
        private readonly appBroadCastService: AppBroadCastService,
        public experimentEditorService: ExperimentEditorService,
        private experimentApiService: ExperimentApiService,
        private readonly toastrService: ToastrService,
        private logger: NGXLogger,
    ) {}

    /**
     * Method called to fetch ipc details
     * @param {ipcList: Array<string>} ipcList
     * @param {string} addType
     * @returns {void}
     * @memberof AddIpcListHelper
     */
    public fetchIPCDetail(ipcList: Array<string>, addType: string): void {
        const attributes = [];
        if (addType === ADD_IPC_TYPE.BULK_IPC_UPLOAD) this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.experimentEditorService.loadAttributesFromCache(ipcList).subscribe({
            next: (attributesFromCache) => {
                if (attributesFromCache?.length > 0) {
                    forEach(attributesFromCache, (attributeData) => {
                        const { ipc, description, prodtypecode } = attributeData;
                        attributes.push({ ipc, description, prodtypecode });
                    });
                }
                if (attributes.length < ipcList.length) {
                    const payload = {
                        ipcList,
                        isProductTypeNeeded: true,
                    };
                    this.experimentApiService.getIpcData(payload).subscribe({
                        next: (response) => {
                            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                            attributes.push(...response);
                            this.appBroadCastService.addedIpcListValue({ attributes, addType });
                        },
                        error: (error) => {
                            this.toastrService.error("Error occurred");
                            this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                            this.logger.error(error);
                        },
                    });
                } else {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.appBroadCastService.addedIpcListValue({ attributes, addType });
                }
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method for checking duplicate and invalid ipc data
     * @param {NewIpcListModel[]} newAddedIpcListValue
     * @param {ExistingIpcListModel[]} existingIpcList
     * @returns {NewIpcListModel[]}
     * @memberof AddIpcListHelper
     */
    public checkForDuplicateAndInvalidIpc(
        newAddedIpcListValue: NewIpcListModel[],
        existingIpcList: ExistingIpcListModel[],
    ): NewIpcListModel[] {
        const ipcListValues = newAddedIpcListValue.map((data) => data.ipc);
        forEach(newAddedIpcListValue, (ipcData, index) => {
            const isIpcAlreadyExist = existingIpcList?.filter((ipcInfo) => ipcInfo.ipc === ipcData.ipc);
            Object.assign(ipcData, {
                isDuplicate: ipcListValues.indexOf(ipcData.ipc) !== index || isIpcAlreadyExist?.length > 0,
                isInvalid: ipcData?.ipc?.length < 8 || ipcData?.ipc?.length > 8,
            });
        });
        return newAddedIpcListValue;
    }

    /**
     * Method for checking Invalid ipc
     * @param {NewIpcListModel[]} newAddedIpcListValue
     * @param {IpcBasicAttributeInfo[]} attributes
     * @returns {NewIpcListModel[]}
     * @memberof AddIpcListHelper
     */
    public checkForInvalidIpc(newAddedIpcListValue: NewIpcListModel[], attributes: IpcBasicAttributeInfo[]): NewIpcListModel[] {
        forEach(newAddedIpcListValue, (ipcData) => {
            if (!ipcData?.isDuplicate && !ipcData?.isInvalid) {
                const isAttributeInfoExist = attributes?.filter((attributesInfo) => attributesInfo.ipc === ipcData.ipc);
                Object.assign(ipcData, {
                    isInvalid: isAttributeInfoExist?.length === 0,
                });
            }
        });
        return newAddedIpcListValue;
    }

    /**
     * Method to get valid ipcs
     * @param {NewIpcListModel[]} ipcListData
     * @returns {Array<string>}
     * @memberof AddIpcListHelper
     */
    public getValidIpcs(ipcListData: NewIpcListModel[]): Array<string> {
        const ipcList = map(
            ipcListData?.filter((ipcData) => !ipcData.isDuplicate && !ipcData.isInvalid),
            "ipc",
        );
        return ipcList;
    }
}
