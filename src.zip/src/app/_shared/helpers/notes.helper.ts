/* eslint-disable class-methods-use-this */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { DATE_RANGE_DROPDOWN_NOTES, NOTES_TYPES } from "../constants/common.constant";
import { NotesResponse, AddNotes } from "../models/notes.model";
import { AppBroadCastService, AppDataService, AppStateService } from "../../_services";
import { CooperatorUserModel, MultipleNotificationExpDetail } from "../models/cooperator-access.model";
import { ExperimentsModel } from "../models/experiment-bom.model";
import { REFRESH_EXPERIMENT_HEADER } from "../../experiment-editor/constants/experiment-editor.constant";
import { SharedExperimentUtil } from "./shared-experiment.util";

@Injectable()
export class NotesHelper {
    public auditInfoSub$ = new BehaviorSubject([]);

    public expNoteSub$ = new BehaviorSubject<ExperimentsModel>({} as ExperimentsModel);

    public auditInfoArray = [];

    public experimentId = "";

    public updateLimitSub$ = new BehaviorSubject([]);

    public updateLoadingSub$ = new BehaviorSubject([]);

    public clearSearchSub$ = new BehaviorSubject({});

    constructor(
        private readonly appDataService: AppDataService,
        private readonly appStateService: AppStateService,
        private readonly appBroadCastService: AppBroadCastService,
    ) {}

    /**
     * Publish current experiment Id data
     *
     * @memberof NotesHelper
     */
    public publishExpId(activeExperiment: ExperimentsModel): void {
        this.experimentId = String(activeExperiment.ExpID);
        this.expNoteSub$.next(activeExperiment);
    }

    /**
     * Publish Add Notes
     * @param {{ ExpNoteID: string }} addNotePayload
     * @returns {void}
     * @memberof NotesHelper
     */
    public publishAddedNotes(addNotePayload): void {
        const notesRefreshData = SharedExperimentUtil.createRefreshExperimentHeader(REFRESH_EXPERIMENT_HEADER.NOTES_UPDATE, addNotePayload);
        this.appBroadCastService.onRefreshExperimentHeader(notesRefreshData);
    }

    /**
     * Method to format experiment notes to merge with experiment object
     * @param {NotesResponse[]} experimentNotes
     * @returns {void}
     * @memberof NotesHelper
     */
    public updateAddedNotes(experimentNotes: NotesResponse[]): void {
        const formattedExperimentNotes = experimentNotes.map((notes) => {
            return { ExpNoteID: notes.ExpNoteID };
        });
        const experimentUpdate = [
            {
                ExperimentNote: formattedExperimentNotes,
            },
        ];
        this.publishAddedNotes(experimentUpdate);
    }

    /**
     * Publish updated limit
     *
     * @memberof NotesHelper
     */
    public updateLimit(limit: any): void {
        this.updateLimitSub$.next(limit);
    }

    /**
     * Publish loading status
     *
     * @memberof NotesHelper
     */
    public updateLoading(isLoading: any): void {
        this.updateLoadingSub$.next(isLoading);
    }

    /**
     * Publish default loading value
     *
     * @memberof NotesHelper
     */
    public clearSearch(): void {
        const searchText = "";
        const defaultFilterValue = DATE_RANGE_DROPDOWN_NOTES[2].allTime;
        this.clearSearchSub$.next({ searchText, defaultFilterValue });
    }

    /**
     * Method to process of opening Notes drawer
     * @param {ExperimentsModel} activeExperiment
     * @returns {void}
     * @memberof NotesHelper
     */
    public processOfOpeningNotes(activeExperiment: ExperimentsModel): void {
        this.updateLimit(50);
        this.updateLoading(true);
        this.publishExpId(activeExperiment);
        this.clearSearch();
    }

    /**
     * Method to call api for get experiment
     * @param {string} payload
     * @memberof NoteDrawerComponent
     */
    public getExperimentNotesByExpId(payload: { ExpId: string; limit: number }): Observable<NotesResponse> {
        return this.appDataService.post(this.appDataService.url.getExperimentNotes, [], payload);
    }

    /**
     * Method to call api to update the privacy
     * @param {*} payload
     * @memberof NotesHelper
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public updateNotes(payload: any): Observable<NotesResponse> {
        return this.appDataService.put(this.appDataService.url.updateExperimentNotes, [payload.ExpNoteID], payload);
    }

    /**
     * Method to call api to save notes
     * @param {AddNotes} addNotePayload
     * @memberof NotesHelper
     */
    public saveNotes(addNotePayload: AddNotes): Observable<NotesResponse> {
        return this.appDataService.post(this.appDataService.url.addNotes, [], addNotePayload);
    }

    /**
     * Method to delete the notes of the experiment
     * @param {*} payload
     * @memberof NotesHelper
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public deleteNotes(payload): Observable<any> {
        return this.appDataService.post(this.appDataService.url.deleteExperimentNotes, [], payload);
    }

    /**
     * Method to call api for get experiment
     * @param {string} notesId
     * @memberof NoteDrawerComponent
     */
    public getExperimentNotesById(notesId: string): Observable<NotesResponse> {
        return this.appDataService.get(this.appDataService.url.getExperimentNotesById, [notesId]);
    }

    /**
     * Method to Create the payload for notes
     *
     * @param {string} notesDesc
     * @param {number} expId
     * @returns {AddNotes}
     * @memberof NotesHelper
     */
    public createPayloadNote(notesDesc: string, expId: number, isUser = false): AddNotes {
        return {
            ExpID: expId,
            Description: notesDesc,
            NoteType: isUser ? NOTES_TYPES.USER : NOTES_TYPES.SYSTEM,
            IsPrivate: isUser ? "0" : "1",
        };
    }

    /**
     * Method to create multiple payload for notes
     *
     * @param {CooperatorUserModel[]} userDetails
     * @param {{ expCode: string; expId: number }} expDetails
     * @returns {AddNotes[]}
     * @memberof NotesHelper
     */
    public createMultiplePayloadNotification(
        expDetails: MultipleNotificationExpDetail,
        notesDesc: string,
        userDetails?: CooperatorUserModel[],
    ): AddNotes[] {
        const notesPayload = [];
        if (userDetails?.length > 0) {
            userDetails.forEach((users) => {
                const noteDesc = this.createEventDescriptionForNotes(expDetails, users);
                notesPayload.push(this.createPayloadNote(noteDesc, expDetails.expId));
            });
        } else {
            notesPayload.push(this.createPayloadNote(notesDesc, expDetails.expId, !!notesDesc));
        }
        return notesPayload;
    }

    /**
     * Method to create the description for event notes
     *
     * @returns {string}
     * @memberof NotesHelper
     */
    public createEventDescriptionForNotes(expDetails: { expCode: string; expId: number }, users: CooperatorUserModel): string {
        const currentUser = this.appStateService.getCurrentUser();
        return `Experiment ${expDetails.expCode} shared to ${users.firstName} ${users.surName} by ${currentUser.fullname}`;
    }

    /**
     * Method to filter experiments notes without deleted note.
     * @param {any} experimentNotesList
     * @param {NotesResponse} expNotes
     * @returns {any}
     *
     * @memberof NotesHelper
     */
    public getUnDeletedExprimentNotes(expNotes: NotesResponse, experimentNotesList: any = []): any {
        return experimentNotesList.filter((item) => item.ExpNoteID !== expNotes.ExpNoteID);
    }
}
