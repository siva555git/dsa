/* eslint-disable max-lines */
import { TestBed } from "@angular/core/testing";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { HttpClient, HttpHandler } from "@angular/common/http";
import { OAuthService, UrlHelperService, OAuthLogger } from "angular-oauth2-oidc";
import { cloneDeep } from "lodash";
// eslint-disable-next-line import/no-unresolved
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { Router } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { MockExperimentAccessHelper } from "../../testing/mock-experiment-access.helper";
import { SelectedRowDataModel } from "../models/selected-row-data.model";
import { ExperimentsModel } from "../models/experiment-bom.model";
import {
    MENU_LIST_FORMULA,
    LINE_SUB_OPTIONS,
    EXPERIMENT_SUB_OPTIONS,
    EXPERIMENT_TYPE_CONTEXT_MENU,
    MENU_LIST,
    EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU,
    SUB_MENU_LIST,
    OTHER_USER_EXP_MENU_CHANGE,
} from "../constants/context-menu.constant";
import { MockAppStateService } from "../../testing/mock-app.state.service";
import { MockLoggerService } from "../../testing/mock-logger.service";
import { AppBroadCastService, AppDataService, AppStateService } from "../../_services";
import { ExperimentColumnHelper } from "../../experiment-editor/helpers/experiment-column-helper";
import { ExperimentEditorService } from "../../experiment-editor/helpers/experiment-editor.service";
import { UpdateBomHelper } from "../../experiment-editor/helpers/update-bom.helper";
import { AgGridUtil } from "./ag-grid-util";
import { ContextMenuHelper } from "./context-menu-helper";
import { MockExperimentEditorService } from "../../testing/mock-experiment-editor.service";
import { MockToastrService } from "../../testing/mock-toastr.service";
import { MockGridapiService } from "../../testing/mock-gridapi.service";
import { GridApiService } from "../../experiment-editor/helpers/grid-api-service";
import { ExperimentEditorHelper } from "../../experiment-editor/helpers/experiment-editor.helper";
import { MockExperimentFormula } from "../../testing/mock-experiment-formula.helper";
import {
    contextMenuData,
    mockGridDataSource,
    mockActiveExperiment,
    mockExperimentFormula,
    experimentListRowData,
    mockUsertab,
    mockSelectedGridData,
} from "../../testing/mock-context-menu.helper";
import { BOM_TYPE } from "../constants";
import { ExperimentHelper } from "./experiment-helper";
import { SecurityHelper } from "../security/helpers/security.helper";
import { ExperimentAccessHelper } from "./experiment-access.helper";

// eslint-disable-next-line max-lines-per-function
describe("ContextMenuHelper", () => {
    const mockRouter = { navigate: jasmine.createSpy("navigate") };
    beforeEach(() =>
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            providers: [
                ContextMenuHelper,
                AppBroadCastService,
                AppDataService,
                HttpClient,
                HttpHandler,
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                { provide: ExperimentHelper, useClass: MockExperimentHelper },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: GridApiService, useClass: MockGridapiService },
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                { provide: ExperimentColumnHelper, useClass: MockExperimentFormula },
                { provide: ExperimentEditorService, useClass: MockExperimentEditorService },
                UpdateBomHelper,
                AgGridUtil,
                { provide: ExperimentEditorHelper, useValue: {} },
                SecurityHelper,
                { provide: ExperimentAccessHelper, useClass: MockExperimentAccessHelper },
                { provide: Router, useValue: mockRouter },
            ],
        }),
    );

    it("should create", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        expect(service).toBeTruthy();
    });

    it("should call on getMenuDisableInfo", () => {
        const expList = [
            {
                CreatedBy: 65_820,
                ExpAccessStatus: false,
                ExpID: 63_388_299,
                ExperimentStaff: [],
                IsLocked: "0",
                IsOtherExp: undefined,
                IsPublic: true,
            },
        ];
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        const isDisabled = service.getMenuDisableInfo(expList, 65_820, "View bom");
        expect(isDisabled).toBeFalsy();
    });

    it("should call singleExperimentBasedMenuDisable", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", globaluserid: "axb1234", sapempid: 65_820 });
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "getMenuDisableInfo").and.returnValue(true);
        service.singleExperimentBasedMenuDisable(contextMenuDataCopy, "View bom");
        expect(service.singleExperimentBasedMenuDisable).toBeTruthy();
    });

    it("should call disableDeleteVariant ", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = undefined;
        contextMenuDataCopy.selectedExperiments = [];
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableDeleteVariant").and.callThrough();
        service.disableDeleteVariant(contextMenuDataCopy);
        expect(service.disableDeleteVariant).toBeTruthy();
    });

    it("should call disableOtherMenu 1", () => {
        const selectedExp = [{ ExpID: 65_678_901 }];
        spyOn(ContextMenuHelper, "disableOtherMenu").and.callThrough();
        const isDisabled = ContextMenuHelper.disableOtherMenu(MENU_LIST.REVISE, selectedExp as SelectedRowDataModel[]);
        expect(isDisabled).toEqual(true);
    });

    it("should call disableOtherMenu 2", () => {
        const selectedExp = [];
        spyOn(ContextMenuHelper, "disableOtherMenu").and.callThrough();
        const isDisabled = ContextMenuHelper.disableOtherMenu(LINE_SUB_OPTIONS.RESEQUENCE, selectedExp as SelectedRowDataModel[]);
        expect(isDisabled).toEqual(true);
    });

    it("should call disableExperimentAccessEditBom ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(true);
        spyOn(ContextMenuHelper, "isProduct").and.returnValue(true);
        service.disableExperimentAccessEditBom(contextMenuData);
        expect(service.disableExperimentAccessEditBom).toBeTruthy();
    });

    it("should call disableExperimentAccessEditBom ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(ContextMenuHelper, "isProduct").and.returnValue(false);
        service.disableExperimentAccessEditBom(contextMenuData);
        expect(service.disableExperimentAccessEditBom).toBeTruthy();
    });

    it("should call disableCooperatorFromEditBom ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(true);
        spyOn(ContextMenuHelper, "isProduct").and.returnValue(true);
        service.disableCooperatorFromEditBom(contextMenuData);
        expect(service.disableCooperatorFromEditBom).toBeTruthy();
    });

    it("should call disableCooperatorFromEditBom ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(ContextMenuHelper, "isProduct").and.returnValue(false);
        service.disableCooperatorFromEditBom(contextMenuData);
        expect(service.disableCooperatorFromEditBom).toBeTruthy();
    });

    it("should call disableApplyFactor 1", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.selectedRow = [];
        contextMenuDataCopy.isOtherExp = true;
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(true);
        spyOn(ContextMenuHelper, "doAllRowsdHaveSameBomType").and.returnValue(true);
        spyOn(ContextMenuHelper, "areRowsMarkedForDelete").and.returnValue(false);
        spyOn(service, "disableApplyFactor").and.callThrough();
        service.disableApplyFactor(contextMenuDataCopy);
        expect(service.disableApplyFactor).toBeTruthy();
    });

    it("should call disableApplyFactor 2", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        service.disableApplyFactor(contextMenuDataCopy);
        expect(service.disableApplyFactor).toBeTruthy();
    });

    it("should call disableFillPartsMenu 1", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(true);
        spyOn(ContextMenuHelper, "areRowsMarkedForDelete").and.returnValue(true);
        spyOn(service, "disableFillPartsMenu").and.callThrough();
        service.disableFillPartsMenu(contextMenuData);
        expect(service.disableFillPartsMenu).toBeTruthy();
    });

    it("should call disableFillPartsMenu 2", () => {
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_820 });
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(ContextMenuHelper, "areRowsMarkedForDelete").and.returnValue(true);
        service.disableFillPartsMenu(contextMenuData);
        expect(service.disableFillPartsMenu).toBeTruthy();
    });

    it("should call disableScalePartsMenu ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.rowData = [];
        contextMenuDataCopy.selectedRow = [];
        contextMenuDataCopy.activeExperiment = mockActiveExperiment;
        spyOn(service, "disableScalePartsMenu").and.callThrough();
        service.disableScalePartsMenu(contextMenuDataCopy);
        expect(service.disableScalePartsMenu).toBeTruthy();
    });

    it("should call disableViewProductData ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        spyOn(service, "disableViewProductData").and.callThrough();
        contextMenuDataCopy.selectedRow = [];
        service.disableViewProductData(contextMenuDataCopy);
        expect(service.disableViewProductData).toHaveBeenCalled();
    });

    it("should call disableSortMenu ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        spyOn(service, "disableSortMenu").and.callThrough();
        contextMenuDataCopy.selectedRow = [];
        service.disableSortMenu(contextMenuDataCopy);
        expect(service.disableSortMenu).toHaveBeenCalled();
    });

    it("should call disableSortMenu ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableSortMenu").and.callThrough();
        service.disableSortMenu(contextMenuData);
        expect(service.disableSortMenu).toHaveBeenCalled();
    });

    it("should call disableLineHeader ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableLineHeader").and.callThrough();
        service.disableLineHeader(contextMenuData);
        expect(service.disableLineHeader).toHaveBeenCalled();
    });

    it("should call disableLineHeader ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        spyOn(service, "disableLineHeader").and.callThrough();
        contextMenuDataCopy.selectedRow = [];
        service.disableLineHeader(contextMenuDataCopy);
        expect(service.disableLineHeader).toHaveBeenCalled();
    });

    it("should call disableLockHeader ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(service, "disableLockHeader").and.callThrough();
        service.disableLockHeader(contextMenuData);
        expect(service.disableLockHeader).toBeTruthy();
    });

    it("should call disableOpenHeader 1", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = undefined;
        contextMenuData.selectedExperiments = [];
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_820 });
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        service.disableOpenHeader(contextMenuData);
        expect(service.disableOpenHeader).toBeTruthy();
    });

    it("should call disableOpenHeader 2", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = undefined;
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_820 });
        contextMenuData.selectedExperiments = [{ ExpID: 6_578_907 }] as SelectedRowDataModel[];
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        service.disableOpenHeader(contextMenuData);
        expect(service.disableOpenHeader).toBeTruthy();
    });

    it("should call disableCombineExp ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(service, "disableCombineExp").and.callThrough();
        service.disableCombineExp(contextMenuData);
        expect(service.disableCombineExp).toBeTruthy();
    });

    it("tests edit experiment ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(MENU_LIST_FORMULA.OPEN_HEADER, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test lock", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(MENU_LIST_FORMULA.LOCK, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });
    it("test lock", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(MENU_LIST.LOCK, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test line ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(MENU_LIST_FORMULA.LINE, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test experiment ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(MENU_LIST_FORMULA.EXPERIMENT, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test sort ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(LINE_SUB_OPTIONS.SORT, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test scale parts", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = mockActiveExperiment;
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(EXPERIMENT_SUB_OPTIONS.SCALE_PARTS, contextMenuDataCopy);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test delete ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test fill parts ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(LINE_SUB_OPTIONS.FILL_PARTS, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test cooperators ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(EXPERIMENT_SUB_OPTIONS.COOPERATORS, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test variant ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(EXPERIMENT_SUB_OPTIONS.VARIANTS, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test delete variant", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(EXPERIMENT_SUB_OPTIONS.DELETE_VARINT, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test experiment access ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });
    it("test apply factor", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(LINE_SUB_OPTIONS.APPLY_FACTOR, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("test from exp", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("tests view experiment ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(MENU_LIST_FORMULA.VIEW_EXPERIMENT, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("tests experiment ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        contextMenuData.isOtherExp = true;
        contextMenuData.selectedExperiments = [];
        service.disableContextMenus(MENU_LIST.EXPERIMENT, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("tests edit bom ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(MENU_LIST.EDIT_EXPERIMENT_BOM, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("tests view bom ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(OTHER_USER_EXP_MENU_CHANGE.VIEW_BOM, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("tests experiment ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(MENU_LIST.EXPERIMENT, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("tests explode ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(LINE_SUB_OPTIONS.EXPLODE, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("tests view product data ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(LINE_SUB_OPTIONS.VIEW_PRODUCT_DATA, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("tests delete all", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextMenus").and.callThrough();
        service.disableContextMenus(LINE_SUB_OPTIONS.DELETE_ALL, contextMenuData);
        expect(service.disableContextMenus).toHaveBeenCalled();
    });

    it("should call getContextMenuItems ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "getContextMenuItems").and.callThrough();
        service.getContextMenuItems();
        expect(service.getContextMenuItems).toHaveBeenCalled();
    });

    it("should call getContextMenuItemsFolder ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "getContextMenuItemsFolder").and.callThrough();
        service.getContextMenuItemsFolder();
        expect(service.getContextMenuItemsFolder).toHaveBeenCalled();
    });

    it("should call callmenu MENU_LIST_FORMULA.EDIT_EXPERIMENT", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(MENU_LIST_FORMULA.OPEN_HEADER);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu  MENU_LIST_FORMULA.LOCK", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(MENU_LIST_FORMULA.LOCK);
        expect(service.callMenu).toHaveBeenCalled();
    });
    it("should call callmenu  MENU_LIST_FORMULA.LOCK", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(MENU_LIST.LOCK);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu LINE_SUB_OPTIONS.DELETE ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu LINE_SUB_OPTIONS.FILL_PARTS", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(LINE_SUB_OPTIONS.FILL_PARTS);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_SUB_OPTIONS.SCALE_PARTS ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_SUB_OPTIONS.SCALE_PARTS);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_SUB_OPTIONS.COOPERATORS", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_SUB_OPTIONS.COOPERATORS);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu MENU_LIST_FORMULA.EXPERIMENT_ACCESS ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu MENU_LIST.VIEW_EXPERIMENT", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(MENU_LIST.VIEW_EXPERIMENT);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu LINE_SUB_OPTIONS.SORT ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(LINE_SUB_OPTIONS.SORT);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu LINE_SUB_OPTIONS.APPLY_FACTOR", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(LINE_SUB_OPTIONS.APPLY_FACTOR);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_SUB_OPTIONS.VARIANTS ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_SUB_OPTIONS.VARIANTS);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_SUB_OPTIONS.DELETE_VARINT", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_SUB_OPTIONS.DELETE_VARINT);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_FOLDER ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_FOLDER);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu MENU_LIST.EDIT_EXPERIMENT_BOM ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(MENU_LIST.EDIT_EXPERIMENT_BOM);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu EXPERIMENT_SUB_OPTIONS.NOTES ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(EXPERIMENT_SUB_OPTIONS.NOTES);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu SUB_MENU_LIST.EXPERIMENT.NOTES ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(SUB_MENU_LIST.EXPERIMENT.NOTES);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu LINE_SUB_OPTIONS.EXPLODE ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu(LINE_SUB_OPTIONS.EXPLODE);
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call callmenu", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "callMenu").and.callThrough();
        service.callMenu("");
        expect(service.callMenu).toHaveBeenCalled();
    });

    it("should call isExpLocked", () => {
        spyOn(ContextMenuHelper, "isExpLocked").and.callThrough();
        ContextMenuHelper.isExpLocked(mockActiveExperiment);
        expect(ContextMenuHelper.isExpLocked).toHaveBeenCalled();
    });

    it("should call doAllRowsdHaveSameBomType", () => {
        spyOn(ContextMenuHelper, "doAllRowsdHaveSameBomType").and.callThrough();
        ContextMenuHelper.doAllRowsdHaveSameBomType(mockGridDataSource, BOM_TYPE.INSTRUCTION);
        expect(ContextMenuHelper.doAllRowsdHaveSameBomType).toHaveBeenCalled();
    });

    it("should call disableMarkForDelete ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(true);
        spyOn(ContextMenuHelper, "doAllRowsdHaveSameBomType").and.returnValue(true);
        spyOn(ContextMenuHelper, "filterSelectedRow").and.returnValue([]);
        spyOn(service, "disableToggleDelete").and.callThrough();
        service.disableToggleDelete(contextMenuData);
        expect(service.disableToggleDelete).toBeTruthy();
    });

    it("should call disableMarkForDelete 1", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(ContextMenuHelper, "filterSelectedRow").and.returnValue([]);
        spyOn(service, "disableToggleDelete").and.callThrough();
        service.disableToggleDelete(contextMenuData);
        expect(service.disableToggleDelete).toBeTruthy();
    });

    it("should call disableExplode", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(service, "disableExplode").and.callThrough();
        const isDisabled = service.disableExplode(contextMenuData);
        expect(isDisabled).toBeTruthy();
    });

    it("should call isOtherExp", () => {
        spyOn(ContextMenuHelper, "isOtherExp").and.callThrough();
        ContextMenuHelper.isOtherExp(mockActiveExperiment);
        expect(ContextMenuHelper.isOtherExp).toHaveBeenCalled();
    });

    it("should call disableCombine to check the line combine submenu", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(service, "disableCombine").and.callThrough();
        const isDisabled = service.disableCombine(contextMenuData);
        expect(isDisabled).toBeTruthy();
    });

    it("should call isManyRowsSelected", () => {
        spyOn(ContextMenuHelper, "isManyRowsSelected").and.callThrough();
        ContextMenuHelper.isManyRowsSelected(mockGridDataSource);
        expect(ContextMenuHelper.isManyRowsSelected).toHaveBeenCalled();
    });

    it("should call doSelectedRowsHaveActiveExpParts", () => {
        spyOn(ContextMenuHelper, "doSelectedRowsHaveActiveExpParts").and.callThrough();
        ContextMenuHelper.doSelectedRowsHaveActiveExpParts(mockGridDataSource, mockActiveExperiment);
        expect(ContextMenuHelper.doSelectedRowsHaveActiveExpParts).toHaveBeenCalled();
    });

    it("should call areRowsMarkedForDelete", () => {
        spyOn(ContextMenuHelper, "areRowsMarkedForDelete").and.callThrough();
        ContextMenuHelper.areRowsMarkedForDelete(contextMenuData);
        expect(ContextMenuHelper.areRowsMarkedForDelete).toHaveBeenCalled();
    });

    it("should call disableEditBom 1", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.selectedExperiments = [];
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_878 });
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableEditBom").and.callThrough();
        service.disableEditBom(contextMenuDataCopy);
        expect(service.disableEditBom).toBeTruthy();
    });

    it("should call disableEditBom 2", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.selectedExperiments = [{ ExpID: 6_578_901 }] as SelectedRowDataModel[];
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_878 });
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "getMenuDisableInfo").and.returnValue(false);
        spyOn(service, "disableEditBom").and.callThrough();
        service.disableEditBom(contextMenuDataCopy);
        expect(service.disableEditBom).toBeTruthy();
    });

    it("should call disableResequence", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(true);
        spyOn(ContextMenuHelper, "filterSelectedRow").and.returnValue([]);
        spyOn(service, "disableResequence").and.callThrough();
        service.disableResequence(contextMenuData);
        expect(service.disableResequence).toBeTruthy();
    });

    it("should call disableEditOrDeleteFolder ", () => {
        spyOn(ContextMenuHelper, "disableEditOrDeleteFolder").and.callThrough();
        ContextMenuHelper.disableEditOrDeleteFolder(contextMenuData);
        expect(ContextMenuHelper.disableEditOrDeleteFolder).toHaveBeenCalled();
    });

    it("should call disableOpenInNewWorkspace ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableOpenInNewWorkspace").and.callThrough();
        service.disableOpenInNewWorkspace(contextMenuData);
        expect(service.disableOpenInNewWorkspace).toHaveBeenCalled();
    });

    it("should call disableOpenInWorkspace ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableOpenInWorkspace").and.callThrough();
        service.disableOpenInWorkspace(contextMenuData);
        expect(service.disableOpenInWorkspace).toHaveBeenCalled();
    });

    it("should call hasDuplicateExperiments ", () => {
        const expCodeLists = ["NXX00001AA", "NXX00002AA"];
        spyOn(ContextMenuHelper, "hasDuplicateExperiments").and.callThrough();
        ContextMenuHelper.hasDuplicateExperiments(expCodeLists);
        expect(ContextMenuHelper.hasDuplicateExperiments).toHaveBeenCalled();
    });

    it("should call toValidateGridData ", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = mockActiveExperiment;
        spyOn(ContextMenuHelper, "toValidateGridData").and.callThrough();
        ContextMenuHelper.toValidateGridData(contextMenuDataCopy);
        expect(ContextMenuHelper.toValidateGridData).toHaveBeenCalled();
    });

    it("should call disableSendToIffman ", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableSendToIffman").and.callThrough();
        service.disableSendToIffman(contextMenuDataCopy);
        expect(service.disableSendToIffman).toHaveBeenCalled();
    });

    it("should call disableReviseExperiment ", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = mockActiveExperiment;
        contextMenuDataCopy.userTabInfo = mockUsertab;
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        contextMenuDataCopy.selectedExperiments = [];
        service.disableReviseExperiment(contextMenuDataCopy);
        expect(service.disableReviseExperiment).toBeTruthy();
    });

    it("should call checkSelectedRowHasProdOrExp", () => {
        spyOn(ContextMenuHelper, "checkSelectedRowHasProdOrExp").and.callThrough();
        ContextMenuHelper.checkSelectedRowHasProdOrExp(mockGridDataSource);
        expect(ContextMenuHelper.checkSelectedRowHasProdOrExp).toHaveBeenCalled();
    });

    it("should call disableAllContextMenu", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableAllContextMenu").and.callThrough();
        service.disableAllContextMenu(contextMenuData);
        expect(service.disableAllContextMenu).toHaveBeenCalled();
    });

    it("should call collaborationGroupContextSubMenuDisable", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "collaborationGroupContextSubMenuDisable").and.callThrough();
        service.collaborationGroupContextSubMenuDisable(contextMenuData.menu);
        expect(service.collaborationGroupContextSubMenuDisable).toHaveBeenCalled();
    });

    it("should call collaborationGroupContextMenuDisable", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "collaborationGroupContextMenuDisable").and.callThrough();
        service.collaborationGroupContextMenuDisable(contextMenuDataCopy);
        expect(service.collaborationGroupContextMenuDisable).toHaveBeenCalled();
    });

    it("should call disableRemoveExpFromCollaborationGroup", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableRemoveExpFromCollaborationGroup").and.callThrough();
        service.disableRemoveExpFromCollaborationGroup(contextMenuData.menu);
        expect(service.disableRemoveExpFromCollaborationGroup).toHaveBeenCalled();
    });

    it("should call disableLineage", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(service, "disableLineage").and.callThrough();
        service.disableLineage(contextMenuDataCopy);
        expect(service.disableLineage).toBeTruthy();
    });

    it("should call disableCollaborationGroupContextMenuIfNotOwnedByUser", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableCollaborationGroupContextMenuIfNotOwnedByUser").and.callThrough();
        service.disableCollaborationGroupContextMenuIfNotOwnedByUser(contextMenuDataCopy);
        expect(service.disableCollaborationGroupContextMenuIfNotOwnedByUser).toHaveBeenCalled();
    });

    it("should call disableCollaborationGroupContextMenuIfNotOwnedByUser", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableCollaborationGroupContextMenuIfNotOwnedByUser").and.callThrough();
        const isEnabled = service.disableCollaborationGroupContextMenuIfNotOwnedByUser(contextMenuDataCopy);
        expect(isEnabled).toBeTruthy();
    });

    it("should call areSelectedExperimentsOwnedByUser", () => {
        const experimentListRowDataCopy = cloneDeep(experimentListRowData);
        spyOn(ContextMenuHelper, "areSelectedExperimentsOwnedByUser").and.callThrough();
        ContextMenuHelper.areSelectedExperimentsOwnedByUser(experimentListRowDataCopy);
        expect(ContextMenuHelper.areSelectedExperimentsOwnedByUser).toHaveBeenCalled();
    });

    it("should call checkProductIsBom", () => {
        const mockExperimentFormulaCopy = cloneDeep(mockExperimentFormula);
        spyOn(ContextMenuHelper, "checkProductIsBom").and.callThrough();
        ContextMenuHelper.checkProductIsBom([mockExperimentFormulaCopy]);
        expect(ContextMenuHelper.checkProductIsBom).toHaveBeenCalled();
    });

    it("should call doRowsSelectedHavProductOrExpBomType ", () => {
        const mockExperimentFormulaCopy = cloneDeep(mockExperimentFormula);
        spyOn(ContextMenuHelper, "doRowsSelectedHavProductOrExpBomType").and.callThrough();
        ContextMenuHelper.doRowsSelectedHavProductOrExpBomType([mockExperimentFormulaCopy]);
        expect(ContextMenuHelper.doRowsSelectedHavProductOrExpBomType).toHaveBeenCalled();
    });

    it("should call disableCopyToUser", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.selectedExperiments = [];
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        service.disableCopyToUser(contextMenuDataCopy);
        expect(service.disableCopyToUser).toBeTruthy();
    });

    it("should call disableNotes", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_878 });
        contextMenuDataCopy.activeExperiment = undefined;
        contextMenuDataCopy.selectedExperiments = [];
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        service.disableNotes(contextMenuDataCopy, "TASTEEDITOR-EXPERIMENT-NOTES");
        expect(service.disableNotes).toBeTruthy();
    });

    it("should call disableNotes", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_878 });
        contextMenuDataCopy.activeExperiment = undefined;
        contextMenuDataCopy.selectedExperiments = [{ ExpID: 6_587_989 }] as SelectedRowDataModel[];
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(service, "disableNotes").and.callThrough();
        service.disableNotes(contextMenuDataCopy, "TASTEEDITOR-EXPERIMENT-NOTES");
        expect(service.disableNotes).toBeTruthy();
    });

    it("should call disableCreateFolder", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        spyOn(ContextMenuHelper, "disableCreateFolderAndCreateCollaborationGroup").and.callThrough();
        ContextMenuHelper.disableCreateFolderAndCreateCollaborationGroup(contextMenuDataCopy);
        expect(ContextMenuHelper.disableCreateFolderAndCreateCollaborationGroup).toHaveBeenCalled();
    });

    it("should call disableCollaborationGroup", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = undefined;
        contextMenuDataCopy.selectedExperiments = [];
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableCollaborationGroup").and.callThrough();
        service.disableCollaborationGroup(contextMenuDataCopy);
        expect(service.disableCollaborationGroup).toBeTruthy();
    });

    it("should call disableCreateReview 2", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = undefined;
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "getMenuDisableInfo").and.returnValue(false);
        spyOn(service, "disableCreateReview").and.callThrough();
        service.disableCreateReview(contextMenuDataCopy, "CREATIVE_REVIEW");
        expect(service.disableCreateReview).toBeTruthy();
    });

    it("should call contextMenuDisable", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = mockActiveExperiment;
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "contextMenuDisable").and.callThrough();
        service.contextMenuDisable(contextMenuDataCopy);
        expect(service.contextMenuDisable).toHaveBeenCalled();
    });

    it("should call disableContextSubmenu", () => {
        const menuName = "Product";
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "disableContextSubmenu").and.callThrough();
        service.disableContextSubmenu(contextMenuDataCopy.menu, contextMenuDataCopy, menuName);
        expect(service.disableContextSubmenu).toHaveBeenCalled();
    });

    it("should call disableExperimentMenu 1", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment.Type = "Product";
        contextMenuDataCopy.selectedExperiments = [];
        spyOn(service, "disableExperimentMenu").and.callThrough();
        const isEnabled = service.disableExperimentMenu(contextMenuDataCopy);
        expect(isEnabled).toBeTruthy();
    });

    xit("should call disableExperimentMenu 2", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment.Type = "Experiment";
        contextMenuDataCopy.selectedExperiments = [];
        spyOn(service, "disableExperimentMenu").and.callThrough();
        const isEnabled = service.disableExperimentMenu(contextMenuDataCopy);
        expect(isEnabled).toBeFalsy();
    });

    xit("should call disableAuditMenu", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        contextMenuDataCopy.activeExperiment = undefined;
        contextMenuDataCopy.selectedExperiments = [];
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(service, "disableAuditMenu").and.callThrough();
        const isEnabled = service.disableAuditMenu(contextMenuDataCopy);
        expect(isEnabled).toBeFalsy();
    });

    it("should call disableAuditMenu", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(true);
        spyOn(service, "disableAuditMenu").and.callThrough();
        const isEnabled = service.disableAuditMenu(contextMenuDataCopy);
        expect(isEnabled).toBeTruthy();
    });

    xit("should call modifycontextMenu", () => {
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        spyOn(ContextMenuHelper, "modifyEditorContextMenu").and.callThrough();
        const isEnabled = ContextMenuHelper.modifyEditorContextMenu(contextMenuDataCopy);
        expect(isEnabled).toEqual(contextMenuDataCopy);
    });

    it("should call disableSetInstructionMenu", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        const contextMenuDataCopy = cloneDeep(contextMenuData);
        spyOn(service, "disableSetInstructionMenu").and.callThrough();
        contextMenuDataCopy.selectedExperiments = [];
        const isEnabled = service.disableSetInstructionMenu(contextMenuDataCopy);
        expect(isEnabled).toBeTruthy();
    });

    xit("should call disableQuickInsertAndInsert 1", () => {
        const activeExperiment = { IsLocked: "1", CreatedBy: 65_876 };
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_878 });
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "getMenuDisableInfo").and.returnValue(false);
        spyOn(service, "disableQuickInsertAndInsert").and.callThrough();
        const isEnabled = service.disableQuickInsertAndInsert(activeExperiment as ExperimentsModel);
        expect(isEnabled).toBeFalsy();
    });

    xit("should call disableQuickInsertAndInsert 2", () => {
        const activeExperiment = { IsLocked: "0", CreatedBy: 65_876, Type: "Experiment" };
        const appState: AppStateService = TestBed.inject(AppStateService);
        spyOn(appState, "getCurrentUser").and.returnValue({ fullname: "Test User", sapempid: 65_876 });
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "getMenuDisableInfo").and.returnValue(true);
        spyOn(service, "disableQuickInsertAndInsert").and.callThrough();
        const isEnabled = service.disableQuickInsertAndInsert(activeExperiment as ExperimentsModel);
        expect(isEnabled).toBeTruthy();
    });

    it("should call getExpFormulaID ", () => {
        const activeExperiment = { ExpCode: "RXR00002AA" };
        const isEnabled = ContextMenuHelper.getExpFormulaID(mockSelectedGridData, activeExperiment as ExperimentsModel);
        expect(isEnabled).toBeFalsy();
    });

    it("should call getBlankInstruction ", () => {
        const activeExperiment = { ExpCode: "RXR00002AA" };
        const isEnabled = ContextMenuHelper.getBlankInstruction(mockSelectedGridData, activeExperiment as ExperimentsModel);
        expect(isEnabled).toEqual(mockSelectedGridData[1]);
    });

    it("should call getExpFormulaID ", () => {
        const activeExperiment = { ExpCode: "RXR00002AA" };
        const isEnabled = ContextMenuHelper.getActiveInactiveInstructions(mockSelectedGridData, activeExperiment as ExperimentsModel);
        expect(isEnabled).toEqual(mockSelectedGridData[0]);
    });

    it("should call disablePrintScreen ", () => {
        const service: ContextMenuHelper = TestBed.inject(ContextMenuHelper);
        spyOn(service, "singleExperimentBasedMenuDisable").and.returnValue(false);
        spyOn(service, "disablePrintScreen").and.callThrough();
        service.disablePrintScreen(contextMenuData);
        expect(service.disablePrintScreen).toBeTruthy();
    });
});
