import { EXPERIMENT, PRODUCT } from "@te-shared/constants/context-menu.constant";
import { SUBTypes } from "@te-shared/enums";
import { Decimal } from "decimal.js";
import { each, find, has, filter, concat, cloneDeep, forEach } from "lodash";
import { BOM_TYPE } from "../constants/common.constant";
import { BOM_DETAILS_CONSTANTS, MARK_FOR_DELETE_FLAG } from "../constants/experiment.constant";
import { BomDetailExperimentsModel, BomDetailsModel, ExperimentFormulaModel, ExperimentsModel } from "../models/experiment-bom.model";

export class ExperimentBomUtil {
    /**
     * Method to map the rounding value based on the input
     * @param {number} valueToRound
     * @returns {*}
     * @memberof ExperimentBomUtil
     */
    public static getDecimalRounding(valueToRound: number): number {
        const decimalValueMap = {
            0: Decimal.ROUND_UP,
            1: Decimal.ROUND_DOWN,
            2: Decimal.ROUND_CEIL,
            3: Decimal.ROUND_FLOOR,
            4: Decimal.ROUND_HALF_UP,
        };
        return decimalValueMap[valueToRound] || Decimal.ROUND_HALF_UP;
    }

    /**
     * Method to return the top level bom details experiments. In the bom items API call sub experiments also included so this method will
     * return the top level which are available opened in the tab
     * @param {BomDetailsModel} bomDetails
     * @returns {BomDetailExperimentsModel[]}
     * @memberof ExperimentBomUtil
     */
    public static getTopLevelExperiments(bomDetails: BomDetailsModel): BomDetailExperimentsModel[] {
        return filter(bomDetails.Experiments, (item) => {
            return item.Level === 0;
        });
    }

    /**
     * Method to get All Line Item Entries In BomDetail By SubCode
     * @param {string} targetSubCode
     * @param {BomDetailsModel} bomDetails
     * @returns {ExperimentFormulaModel[]}
     * @memberof ExperimentBomUtil
     */
    public static getAllLineItemEntriesInBomDetailBySubCode(targetSubCode: string, bomDetails: BomDetailsModel): ExperimentFormulaModel[] {
        const topLevelExperiments = this.getTopLevelExperiments(bomDetails);
        const filteredData = [];
        forEach(topLevelExperiments, (experiment) => {
            const experimentFormula = filter(experiment.ExperimentFormula, (expFormula) => expFormula.SUBCode === targetSubCode);
            if (experimentFormula?.length > 0) {
                forEach(experimentFormula, (formulaDetail) => {
                    // eslint-disable-next-line no-param-reassign
                    formulaDetail.parentExpCode = experiment.ExpCode;
                    filteredData.push(formulaDetail);
                });
            }
        });
        return filteredData;
    }

    /**
     * Method to get top level experiment by expid.
     * @param {number | string} expIdOrIpc
     * @param {BomDetailExperimentsModel[]} bomDetailExperiments
     * @param {boolean} experimentLevel
     * @memberof ExperimentBomUtil
     */
    public static getTopLevelExperimentByExpId(
        expIdOrIpc: number | string,
        bomDetailExperiments: BomDetailExperimentsModel[],
        experimentLevel = false,
    ): BomDetailExperimentsModel {
        const currentExperiment = find(bomDetailExperiments, (item: BomDetailExperimentsModel) => {
            return (item.ExpID === expIdOrIpc || item.IPC === expIdOrIpc) && (experimentLevel || item.Level === 0);
        });
        return currentExperiment;
    }

    /**
     * Method to get top level experiment by expid or IPC with respect to activeExp Type.
     * @param {number | string} expIdOrIpc
     * @param {BomDetailExperimentsModel[]} bomDetailExperiments
     * @param {boolean} experimentLevel
     * @param {string} type
     * @memberof ExperimentBomUtil
     */
    public static getTopLevelExperimentByExpIdAndType(
        expIdOrIpc: number | string,
        bomDetailExperiments: BomDetailExperimentsModel[],
        type?: string,
        experimentLevel = false,
    ): BomDetailExperimentsModel {
        const currentExperiment = find(bomDetailExperiments, (item: BomDetailExperimentsModel) => {
            return (
                ((item.BOMType === SUBTypes.EXPERIMENT && type === EXPERIMENT && item.ExpID === expIdOrIpc) ||
                    (item.BOMType === SUBTypes.PRODUCT && type === PRODUCT && item.IPC === expIdOrIpc)) &&
                (experimentLevel || item.Level === 0)
            );
        });
        return currentExperiment;
    }

    /**
     * Method to get mark for deleted bom items from  active experiment
     * @param {BomDetailsModel} bomDetails
     * @param {ExperimentsModel} activeExperiment
     * @returns {ExperimentFormulaModel[]}
     * @memberof ExperimentBomUtil
     */
    public static findMarkForDeleteBomItems(bomDetails: BomDetailsModel, activeExperiment: ExperimentsModel): ExperimentFormulaModel[] {
        const experiment = ExperimentBomUtil.getTopLevelExperimentByExpIdAndType(
            activeExperiment?.ExpID,
            bomDetails?.Experiments,
            activeExperiment?.Type,
        );
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const markForDeleteBomData: any = experiment?.ExperimentFormula.filter(
            (ingredient) => ingredient.IsDelete === MARK_FOR_DELETE_FLAG,
        );
        return markForDeleteBomData;
    }

    /**
     * Method to get the Formula Id binding key for the current ExpCode
     *
     * @static
     * @param {string} expCode
     * @return {*}  {string}
     * @memberof ExperimentBomUtil
     */
    public static getFormulaIdKey = (expCode: string): string => `${expCode}_ExpFormulaID`;

    /**
     * Method to get the Formula deleted info for the current ExpCode
     *
     * @static
     * @param {string} expCode
     * @return {*}  {string}
     * @memberof ExperimentBomUtil
     */
    public static getFormulaIsDeleteKey = (expCode: string): string => `${expCode}_IsDeleted`;

    /**
     * Method to get the CostUpdatedOn binding key for the current ExpCode
     *
     * @static
     * @param {string} expCode
     * @return {*}  {string}
     * @memberof ExperimentBomUtil
     */
    public static getCostUpdatedOnKey = (expCode: string): string => `${expCode}_MNCUpdatedOn`;

    /**
     * Method to get the tooltipMsg
     *
     * @static
     * @param {string} expCode
     * @return {*}  {string}
     * @memberof ExperimentBomUtil
     */
    public static getToolTipKey = (expCode: string): string => `${expCode}_ToolTipMsg`;

    /**
     * Method to get the bom details in the experiment by passing the expFormula id, expCode to the bom details array.
     * @param {BomDetailExperimentsModel[]} bomDetailExperiments
     * @param {string} expCode
     * @returns {BomDetailExperimentsModel}
     * @memberof ExperimentBomUtil
     */
    public static getExperimentForumla(bomDetailExperiments: BomDetailExperimentsModel[], expCode: string): BomDetailExperimentsModel {
        const expCodeKey = BOM_DETAILS_CONSTANTS.EXP_CODE;
        const experimentBomDetail = find(bomDetailExperiments, [expCodeKey, expCode]);
        return experimentBomDetail;
    }

    /**
     * Method to get the bom details in the experiment by passing the expFormula id, expCode to the bom details array.
     * @param {BomDetailExperimentsModel[]} bomDetailExperiments
     * @param {string} expCode
     * @returns {BomDetailExperimentsModel}
     * @memberof ExperimentBomUtil
     */
    public static getTopLevelExperimentForumla(
        bomDetailExperiments: BomDetailExperimentsModel[],
        expCode: string,
    ): BomDetailExperimentsModel {
        const experimentBomDetail = find(bomDetailExperiments, (bomDetail) => bomDetail.ExpCode === expCode && bomDetail.Level === 0);
        return experimentBomDetail;
    }

    /**
     * Method to get experiment formula detail at all level
     * @param bomDetailExperiments
     * @param expCode
     * @returns {BomDetailExperimentsModel[]}
     * @memberof ExperimentBomUtil
     */
    public static getAllLevelExpFormulaDetail(
        bomDetailExperiments: BomDetailExperimentsModel[],
        expCode: string,
    ): BomDetailExperimentsModel[] {
        const expCodeKey = BOM_DETAILS_CONSTANTS.EXP_CODE;
        const experimentBomDetail = filter(bomDetailExperiments, [expCodeKey, expCode]);
        return experimentBomDetail;
    }

    /**
     * Method to get bom details by exp formula id
     * @param {BomDetailsModel} bomDetails
     * @param {string} expCode
     * @param  {string} expFormulaID
     * @returns {ExperimentFormulaModel}
     * @memberof ExperimentBomUtil
     */
    public static getBomDetailsByExpFormulaID(
        currentExpFormulaID: string,
        parentExpCode: string,
        bomDetails: BomDetailsModel,
        activeExpCode?: string,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        currentExpData?: any,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        parentExpData?: any,
    ): ExperimentFormulaModel {
        const currentExpGridDataSource = currentExpData;
        const experiment = ExperimentBomUtil.getExperimentForumla(bomDetails?.Experiments, parentExpCode);
        const lineItemBomInfo = ExperimentBomUtil.getSingleExperimentFormula(currentExpFormulaID, experiment);
        const bomInfo = cloneDeep(lineItemBomInfo);
        const isDeleteKey = ExperimentBomUtil.getFormulaIsDeleteKey(activeExpCode);
        if (parentExpData && !currentExpGridDataSource[isDeleteKey] && Object.keys(currentExpGridDataSource).includes(activeExpCode)) {
            currentExpGridDataSource[isDeleteKey] =
                parentExpData[isDeleteKey] === MARK_FOR_DELETE_FLAG ? MARK_FOR_DELETE_FLAG : bomInfo?.IsDelete;
        }
        if (bomInfo) {
            bomInfo.IsDelete = currentExpGridDataSource ? currentExpGridDataSource[isDeleteKey] : bomInfo.IsDelete;
        }
        return bomInfo;
    }

    /**
     * Method to get single experiment formula values using formulaId
     * @param {BomDetailExperimentsModel} experimentBomDetail
     * @param {string} expFomulaId
     * @returns {ExperimentFormulaModel}
     * @memberof ExperimentBomUtil
     */
    public static getSingleExperimentFormula(expFomulaId: string, experimentBomDetail: BomDetailExperimentsModel): ExperimentFormulaModel {
        return find(experimentBomDetail?.ExperimentFormula, [BOM_DETAILS_CONSTANTS.EXP_FORMULA_ID, expFomulaId]);
    }

    /**
     * Method to get the item availability in the grid
     *
     * @static
     * @param {any} gridData
     * @param {any} exceptCurrentExp
     * @param {any} cartItem
     * @returns {boolean}
     * @memberof ExperimentBomUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getItemAvailabityFromGrid(gridData: any, exceptCurrentExp: any, cartItem: any): boolean {
        let isAvailableItems = false;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        each(gridData, (data: any) => {
            find(exceptCurrentExp, (expID) => {
                if (
                    has(data, expID) && // UNAPPROVED DOUBT
                    ((data.SUBCode === cartItem.SUBCode && data.SUBType === BOM_TYPE.PRODUCT) ||
                        (data.ipc === cartItem.ipc ? cartItem.ipc : cartItem.code && data.SUBType === BOM_TYPE.EXPERIMENT) ||
                        (data.Instruction === cartItem.instruction && data.SUBType === BOM_TYPE.INSTRUCTION) ||
                        (data.SUBCode === cartItem.SUBCode && data.SUBType === BOM_TYPE.UNAPPROVED))
                ) {
                    isAvailableItems = true;
                }
            });
            return !cartItem.showAvailabiltyWarning;
        });
        return isAvailableItems;
    }

    /**
     * Method to find experiment by subCode
     * @param {string} subCode
     * @param {BomDetailExperimentsModel[]} experiments
     * @returns {BomDetailExperimentsModel}
     * @memberof ExperimentBomUtil
     */
    public static getExperimentBySubCode(
        subCode: string,
        experiments: BomDetailExperimentsModel[],
        type = BOM_TYPE.EXPERIMENT,
    ): BomDetailExperimentsModel {
        const experimentRow: BomDetailExperimentsModel = find(experiments, (experiment: BomDetailExperimentsModel) =>
            type === BOM_TYPE.PRODUCT ? subCode === experiment.IPC : +subCode === experiment.ExpID,
        );
        return experimentRow;
    }

    /**
     * Method to return the given level of bom details experiments.
     *
     * @static
     * @param {number} level
     * @param {BomDetailsModel} bomDetails
     * @param {number} [expID]
     * @return {*}  {BomDetailExperimentsModel[]}
     * @memberof ExperimentBomUtil
     */
    public static getExperimentsForLevel(level: number, bomDetails: BomDetailsModel, expID?: number): BomDetailExperimentsModel[] {
        return bomDetails.Experiments.filter((experiment) => {
            const isExpIdMatching = expID ? experiment.ExpID === expID : true;
            return experiment.Level === level && isExpIdMatching;
        });
    }

    /**
     * Method to get exp access list status for level 1 bom experiments.
     * @param {string} subCode
     * @param {BomDetailsModel} bomDetails
     * @returns {boolean}
     * @memberof ExperimentBomUtil
     */
    public static getExpAcessListStatus(subCode: string, bomDetails: BomDetailsModel): boolean {
        const experimentRow = this.getExperimentsForLevel(1, bomDetails, +subCode);
        return experimentRow?.length > 0 ? experimentRow[0]?.ExpAccessStatus : true;
    }

    /**
     * Method to get list of expcodes present in workspace and select row experiment
     * @param  selectedGridRows
     * @returns {Array<string>}
     * @memberof ExperimentBomUtil
     */
    public static getSelectedRowExpCodeList(selectedGridRows): Array<string> {
        return selectedGridRows.map((gridRow) => gridRow.ipc);
    }

    /**
     * Method to get experiment formula for top level experiments
     * @param {BomDetailExperimentsModel[]} openedExperiments
     * @returns {ExperimentFormulaModel[]}
     * @memberof ExperimentBomUtil
     */
    public static getExpFormulaForTopLevelExp(openedExperiments: BomDetailExperimentsModel[]): ExperimentFormulaModel[] {
        let topLevelExpFormula = [];
        openedExperiments.forEach((experiment) => {
            const experimentFormula = ExperimentBomUtil.getExperimentForumla(openedExperiments, experiment.ExpCode)?.ExperimentFormula;
            if (experimentFormula) topLevelExpFormula = concat(topLevelExpFormula, experimentFormula);
        });
        return topLevelExpFormula;
    }

    /**
     * Method to get active instruction experiments
     * @param {any} selectedRow
     * @param {ExperimentsModel} activeExperiment
     * @param {BomDetailsModel} bomDetails
     * @returns {ExperimentFormulaModel}
     * @memberof ExperimentBomUtil
     */
    public static getActiveInstruction(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        selectedRow: any,
        activeExperiment: ExperimentsModel,
        bomDetails: BomDetailsModel,
    ): ExperimentFormulaModel {
        const bom = ExperimentBomUtil.getBomDetailsByExpFormulaID(
            selectedRow[`${activeExperiment?.ExpCode}_ExpFormulaID`],
            activeExperiment?.ExpCode,
            bomDetails,
        );
        return bom?.IsDelete === 0 && bom;
    }

    /**
     * Get to get formula detail from Bom detail with ExpFormulaID
     * @param {BomDetailsModel} bomDetail
     * @param {string} formulaID
     * @param {number} bomLevel
     * @returns {ExperimentFormulaModel}
     * @memberof ExperimentBomUtil
     */
    public static getBOMFormulaByExpFormulaID(bomDetail: BomDetailsModel, formulaID: string, bomLevel?: number): ExperimentFormulaModel {
        let parentbomInfo;
        forEach(bomDetail.Experiments, (data) => {
            if (data.Level === bomLevel) {
                parentbomInfo = find(data.ExperimentFormula, (expFormula) => expFormula.ExpFormulaID === formulaID) ?? parentbomInfo;
            }
        });
        return parentbomInfo;
    }

    /**
     * Method to exclude level based Experiments.
     *
     * @static
     * @param {number} level
     * @param {BomDetailsModel} bomDetails
     * @param {number} [expID]
     * @return {*}  {BomDetailExperimentsModel[]}
     * @memberof ExperimentBomUtil
     */
    public static getBasedOnLevel(level: number, bomDetails: BomDetailsModel): BomDetailExperimentsModel[] {
        return bomDetails.Experiments.filter((experiment) => {
            return experiment.Level === level;
        });
    }
}
