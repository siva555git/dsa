/* eslint-disable max-lines */
import { Injectable } from "@angular/core";
import { Observable, Subscription } from "rxjs";
import { ToastrService } from "ngx-toastr";
import { cloneDeep, every, filter, find, forEach, includes, map, pullAll, toLower, uniqBy } from "lodash";
import { MatDialog } from "@angular/material/dialog";
import { UntypedFormArray, UntypedFormControl, UntypedFormGroup, ValidationErrors } from "@angular/forms";
import { NGXLogger } from "ngx-logger";
import { MatAutocomplete } from "@angular/material/autocomplete";
import { Router } from "@angular/router";
import { CreateSampleComponent } from "@te-shared/components/create-sample/create-sample.component";
import { AppEnvironment } from "src/config/app.environment";
import { SAMPLE_TYPE } from "@te-shared/constants/print-sample.constant";
import { MENU_LIST_FORMULA, PRODUCT } from "@te-shared/constants/context-menu.constant";
import { DetailedCostingPayload, DetailedCostingPreparePayloadModel } from "@te-shared/models";
import { SUBTypes } from "@te-shared/enums";
import { AddFavoriteItem, AddFavoritesModel } from "../../experiment-editor/models/add-favorites.model";
import { CooperatorUserModel, UsersListSearchPayload } from "../models/cooperator-access.model";
import {
    BATCHSIZE_VALIDATION,
    CREATE_EXP_VALIDATION,
    DISPLAY_EXPERIMENT_SOURCE,
    FORM_CONTROL_NAME,
    UOM_DATA,
    KEYWORD_SIZE,
} from "../../experiment/experiment.constant";
import { COLUMN_VALUE_KEY, REFRESH_EXPERIMENT_HEADER } from "../../experiment-editor/constants/experiment-editor.constant";
import { AttributeColumnHelper } from "../../experiment-editor/helpers/attribute-column-helper";
import { BomAttributes, ProductAllocationModel } from "../models/attributes-model";
import {
    ExperimentHeaderModel,
    ExperimentTasteHelperModel,
    ValidateExperimentHeaders,
    ValidateUserInputModel,
    VariantDetailModel,
} from "../models/experiments.model";
import {
    BomDetailExperimentsModel,
    BomDetailsModel,
    ExperimentFormulaModel,
    ExperimentsModel,
    FlashPointResponse,
    FlexPalletModel,
} from "../models/experiment-bom.model";
import { AppBroadCastService, AppDataService, AppStateService } from "../../_services";
import {
    BASIC_ROUTES_URL,
    COMMON_DIALOG,
    COMMON_DIALOG_OLD,
    COSTING_KEY_VALUES,
    CREATE_SAMPLE_POPUP,
    ES_RESPONSE,
    EXPERIMENT,
    EXPERIMENT_PRIVACY_UPDATE,
    FMP_CONST,
    INSTRUCTION_INFO,
    INSTRUCTION_SEARCH,
    PLANT_ID,
    PRODUCT_PROCUREMENT_TYPE,
    REVISE_EXPERIMENT_COPIES,
    SLIDE_PANEL_DIALOG,
    UOM_VALUES,
    USER_PLANT_ALLOCATION_ISSUE,
    YIELD_VALUES,
} from "../constants";
import { UPDATING_EXPERIMENT, EMPTY, FOLDERS_LOADING, LOADING, PLM_NUTRITION_CALCULATOR_URL } from "../../app.constant";
import { ExperimentFromExperimentPayload, ExperimentPrivacyPayload, ReviseExperimentPayload } from "../models/create-experiment.model";
// eslint-disable-next-line import/no-cycle
import { DialogHelper } from "./dialog-helper";
import { FacilitiesModel } from "../models/facilities-model";
import { PlantAndSourceModel } from "../models/plant-and-source.model";
import { ExperimentApiService } from "./experiment-api.service";
import { SharedExperimentUtil } from "./shared-experiment.util";
import { ProductTypesModel } from "../models/product-types.model";
import { ReviewSelectedRowDataModel } from "../../creative-review/models/creative-review.model";
import { UserCollaborationExpPayload } from "../models/user-collaboration-group.model";
// eslint-disable-next-line import/no-cycle
import { ConfirmationDialogComponent } from "../components/confirmation-dialog/confirmation-dialog.component";
import { FlavorTypesModel } from "../models/flavor-types-model";
import { SelectedRowDataModel } from "../models/selected-row-data.model";
import { PrivacyUpdateResponse, TreeViewModel, ExperimentDetails } from "../models/experiment-list.model";
import { TasteEditorUtilClass } from "./taste-editor-utils";
import { ViewMembershipComponent } from "../components/view-membership/view-membership.component";

@Injectable()
export class ExperimentHelper {
    public experimentHelperSubscriptions: Subscription[] = [];

    constructor(
        private readonly appDataService: AppDataService,
        public appBroadCastService: AppBroadCastService,
        private readonly toastrService: ToastrService,
        private readonly dialogHelper: DialogHelper,
        private readonly appStateService: AppStateService,
        private readonly experimentApiService: ExperimentApiService,
        public readonly dialog: MatDialog,
        private readonly logger: NGXLogger,
        public router: Router,
    ) {}

    /**
     * Method to ge the ipc by ipc id
     *
     * @param {string} ipc
     * @returns {Observable<any>}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getProductInfoByIpc(ipc: string): Observable<any> {
        return this.appDataService.get(this.appDataService.url.getProductByIpc, [ipc], undefined, true);
    }

    /**
     * Method to get the FMP prediction from FMP service via TE API
     *
     * @param {string} expID
     * @param {HttpParams} payload
     * @return {*}  {Observable<any>}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getFMPMaxDosage(expID: string, payload: any, version?: string): Observable<any> {
        const VERSION = version ?? FMP_CONST.VERSION.V1;
        return this.appDataService.get(this.appDataService.url.getFMPMaxDosage, [VERSION, expID], payload);
    }

    /**
     * Method to get the prediction value for experiment
     *
     * @param {*} payload
     * @return {*}  {Observable<any>}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getFMPPrediction(payload): Observable<any> {
        return this.appDataService.post(this.appDataService.url.getFMPPrediction, [], payload);
    }

    /**
     *
     *
     * @param {*} payload
     * @return {*}  {Observable<FlashPointPrediction[]>}
     * @memberof ExperimentHelper
     */
    public getFlashPointPrediction(payload): Observable<FlashPointResponse> {
        return this.appDataService.post(this.appDataService.url.getFlashPointPrediction, [], payload);
    }

    /**
     * Method to check the top level ipc is there
     *
     * @param {BomDetailsModel} bomDetails
     * @param {ExperimentsModel} activeExperiment
     * @return {*}  {boolean}
     * @memberof ExperimentHelper
     */
    public isExperimentHavingBom(bomDetails: BomDetailsModel, activeExperiment: ExperimentsModel): boolean {
        if (activeExperiment?.ExpID === null || activeExperiment?.Type === PRODUCT) return false;
        const ipc = bomDetails?.Experiments?.find((experiment) => {
            return (
                experiment.ExpCode === activeExperiment.ExpCode &&
                experiment.Level === 0 &&
                experiment.ExperimentFormula?.filter(
                    (expFormula) =>
                        (expFormula.SUBType === SUBTypes.PRODUCT || expFormula.SUBType === SUBTypes.EXPERIMENT) &&
                        expFormula.IsDelete === 0,
                ).length > 0
            );
        });
        return !!ipc;
    }

    /**
     *Method to get keyword by ipc
     * @param {string} ipc
     * @return {*}  {Observable<any>}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getKeywordInfoByIpc(ipc: string): Observable<any> {
        const requestedUrl = `${this.appDataService.url.getKeywordByIpc}?from=${KEYWORD_SIZE.FROM}&size=${KEYWORD_SIZE.SIZE}&IPC=${ipc}`;
        return this.appDataService.get(requestedUrl, [ipc], undefined, true);
    }

    /**
     * Method to calculate working cost currency change
     * @param {ExperimentsModel} activeExperiment
     * @param {BomAttributes[]} attributes
     * @returns {VariantDetailModel}
     * @memberof ExperimentHelper
     */
    public static getVariantUserData(activeExperiment: ExperimentsModel, attributes: BomAttributes[]): VariantDetailModel {
        const varaintData: VariantDetailModel = { userName: "", globalUserId: "", ipcDescription: "" };
        if (activeExperiment.ExperimentVariant && activeExperiment.ExperimentVariant.User !== undefined) {
            varaintData.userName = `${activeExperiment.ExperimentVariant.User.FirstName} ${activeExperiment.ExperimentVariant.User.Surname}`;
            varaintData.globalUserId = activeExperiment.ExperimentVariant.User.GlobalUserID;
            varaintData.ipcDescription = AttributeColumnHelper.getIPCDescription(attributes, activeExperiment.ExperimentVariant.RootIPC);
        }
        return varaintData;
    }

    /**
     * Method to update the privacy
     * @param {ExperimentPrivacyPayload} payload
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public privacyUpdate(payload: ExperimentPrivacyPayload): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(UPDATING_EXPERIMENT);
        this.experimentApiService.updateExperimentsPrivacy(payload).subscribe({
            next: (response: PrivacyUpdateResponse) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                if (response?.isESResponseFlag) {
                    this.toastrService.success(EXPERIMENT_PRIVACY_UPDATE.PRIVACY_UPDATE_SUCCESS);
                } else {
                    this.toastrService.success(`${EXPERIMENT_PRIVACY_UPDATE.PRIVACY_UPDATE_SUCCESS},${ES_RESPONSE.ES_RESPONSE_ERROR}`);
                    this.logger.info(`${EXPERIMENT_PRIVACY_UPDATE.PRIVACY_UPDATE_SUCCESS},${ES_RESPONSE.ES_RESPONSE_ERROR}`);
                }
                const experimentCode = [];
                payload.updateColumns.forEach((column) => experimentCode.push(column.ExpCode));
                const refreshExperimentHeader = SharedExperimentUtil.createRefreshExperimentHeader(
                    REFRESH_EXPERIMENT_HEADER.EXPERIMENT_PRIVACY_UPDATE,
                    payload.updateColumns,
                );
                this.appBroadCastService.onRefreshExperimentHeader(refreshExperimentHeader);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.toastrService.error(error);
            },
        });
    }

    /**
     * Method to invoke creative review dialog
     * @param {ReviewSelectedRowDataModel[]} selectedExperiments
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public openCreativeReviewDialog(selectedExperiments: ReviewSelectedRowDataModel[]): void {
        this.dialogHelper.onOpenCreativeReviewDialog(selectedExperiments);
    }

    /**
     * Method to get plant info based on facilities
     *
     * @param {ExperimentHeaderModel} expHeader
     * @returns {*}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line class-methods-use-this, @typescript-eslint/no-explicit-any
    public getPlantInfoBasedOnFacilities(expHeader: ExperimentHeaderModel): any {
        const plantSources = cloneDeep(expHeader.plantsAndSources);
        // eslint-disable-next-line consistent-return
        return filter(plantSources, (plantSource: PlantAndSourceModel) => {
            const selectedFacility = find(expHeader.facilities, (facility: FacilitiesModel) => {
                return plantSource.PlantID.toLowerCase() === facility.facilitycode.toLowerCase();
            });
            if (selectedFacility) {
                plantSource.plantCode = selectedFacility.costbookcode ?? undefined;
                plantSource.displayValue = selectedFacility.displayValue ?? undefined;
                return plantSource;
            }
        });
    }

    /**
     * Method to check other user experiment
     *
     * @param {string} expCode
     * @returns {boolean}
     * @memberof ExperimentHelper
     */
    public checkForOtherUserExperiment(expCode: string): boolean {
        let isOtherUserExpID = false;
        if (expCode) {
            const userDetails = this.appStateService.getCurrentUser();
            const userInitial = userDetails?.initials.toLowerCase();
            const userExpInitial = expCode?.slice(0, 3).toLowerCase();
            isOtherUserExpID = userExpInitial !== userInitial && expCode?.length === 10;
        }
        return isOtherUserExpID;
    }

    /**
     * Method to get plant and sources check
     *
     * @param {ExperimentHeaderModel} expHeader
     * @returns {any}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getPlantAndSources(expHeader: ExperimentHeaderModel): any {
        const plantsAndSources = this.getPlantInfoBasedOnFacilities(expHeader);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const sourceFlags = TasteEditorUtilClass.getUniqueListBy(plantsAndSources, PLANT_ID).filter((plantDetails: any) => {
            return plantDetails.plantCode === expHeader.experimentToAudit.PlantID;
        });
        return sourceFlags;
    }

    /**
     * Method to get plant and sources check
     * @param modifiedColLayoutTpeId
     * @param layoutTypes
     * @returns {any}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static getLayoutTypeBasedOnID(layoutTypes, modifiedColLayoutTpeId): any {
        const layoutType = find(layoutTypes, (element) => element.ColumnLayoutTypeID === modifiedColLayoutTpeId);
        return layoutType;
    }

    /**
     * Method to get the product types based on default plant
     * @param {ProductTypesModel} productTypes
     * @param {string} previousProduct
     * @returns {ProductTypesModel}
     * @memberof ExperimentHelper
     */
    public static defaultProductTypeBasedOnPlant(productTypes: ProductTypesModel[], productTypeID: string): ProductTypesModel {
        const selectedProduct = find(productTypes, (product) => toLower(product.prodtypecode) === toLower(productTypeID));
        return selectedProduct;
    }

    /**
     * Method to check whether Folder got subfolders
     * @param {number} selectedParentFolderID
     * @param {any} experimentFolders
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public isFolderEmpty(selectedParentFolderID: number, experimentFolders: any): boolean {
        const subfolders = experimentFolders?.filter((folder) => folder.ParentFolderID === selectedParentFolderID);
        return subfolders ? subfolders.length === 0 : false;
    }

    /**
     * Method to convert the yield value to percentage with two decimal.
     *
     * @param {number} yieldValue
     * @return {*}  {string}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line class-methods-use-this
    public convertYieldToPercentage(yieldValue: number): string {
        return (yieldValue * 100).toFixed(2);
    }

    /**
     * Method to call the API service to remove experiment from Collaboration group
     * @param {UserCollaborationExpPayload} removeExpFromPayload
     * @return { status: string }
     * @memberof ExperimentHelper
     */
    public removeExpFromCollaborationGroup(
        removeExpFromPayload: UserCollaborationExpPayload,
    ): Observable<{ status: string; isESResponseFlag: boolean }> {
        return this.appDataService.post(this.appDataService.url.removeExpFromCollaborationGroup, [], removeExpFromPayload);
    }

    /**
     * Find facility based on plant
     * @param {PlantAndSourceModel[]} plantsAndSourcesDetail
     * @param {FacilitiesModel[]} facilitiesDetail
     * @memberof ExperimentHelper
     * @returns {Promise<PlantAndSourceModel[]>}
     */
    public filterFacilityForPlants(
        plantsAndSourcesDetail: PlantAndSourceModel[],
        facilitiesDetail: FacilitiesModel[],
    ): PlantAndSourceModel[] {
        const plantInfoBasedOnFacilities: ExperimentHeaderModel = {
            plantsAndSources: plantsAndSourcesDetail,
            facilities: facilitiesDetail,
        };
        // eslint-disable-next-line consistent-return
        return this.getPlantInfoBasedOnFacilities(plantInfoBasedOnFacilities);
    }

    /**
     * Method to get revise experiment payload
     * @param {ReviseExperimentPayload} reviseInfo
     * @returns {ExperimentFromExperimentPayload}
     * @memberof ExperimentHelper
     */
    public getReviseExperimentPayload(reviseInfo: ReviseExperimentPayload): ExperimentFromExperimentPayload {
        const isPrivateModel = this.appStateService.getPrivacyModelInfo();

        const reviseExpPayload: ExperimentFromExperimentPayload = {
            ExpID: reviseInfo.sourceExpID,
            ExpFolderID: reviseInfo.selectedFolderID,
            NumberOfCopies: REVISE_EXPERIMENT_COPIES,
            IsVersion: reviseInfo?.isOwnExp,
            AddVariant: true,
            ExpCode: reviseInfo.sourceExpCode,
            ExpSource: DISPLAY_EXPERIMENT_SOURCE.E,
            IsPublic: !isPrivateModel,
            IsCopyAllNotes: reviseInfo.isOwnExp,
            isOtherUserExp: !reviseInfo.isOwnExp,
            CollaborationGroupID: reviseInfo.CollaborationGroupID,
            IsRevise: reviseInfo.IsRevise,
            TaskID: reviseInfo?.TaskID,
            isChainSeries: reviseInfo?.isChainSeries,
        };
        return reviseExpPayload;
    }

    /**
     * Method to check selected experiment owner ship
     * @param {SelectedRowDataModel[]} selectedExperiments
     * @returns {boolean}
     * @memberof ExperimentHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public isSelectedExperimentsOwned(selectedExperiments: any): boolean {
        const userDetails = this.appStateService.getCurrentUser();
        const isExperimentsOwned =
            selectedExperiments?.length > 0 ? every(selectedExperiments, { CreatedBy: Number(userDetails.sapempid) }) : false;
        return isExperimentsOwned;
    }

    /**
     * Method to validate plant source and product
     * @param {ValidateUserInputModel} input
     * @returns {ValidateExperimentHeaders}
     * @memberof ExperimentHelper
     */
    public static validateUserInput(input: ValidateUserInputModel): ValidateExperimentHeaders {
        let isValid = true;
        let response = "";
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const validPlant = input.dropDownValues?.find((dataEle: any) => {
            return dataEle[input.validateKey] === input.form.value;
        });
        if (!validPlant && input.form.value) {
            input.form.setErrors({ message: CREATE_EXP_VALIDATION.INVALID });
            response = input.toasterMessage;
            isValid = false;
        }

        return {
            value: isValid,
            errorMessage: response,
            formControlName: input.formControlName,
        };
    }

    /** Method to open confirmation popup if the user doesn't have user plant allocation
     * @param {string} functionName
     * @param {string} userID
     * @memberof ExperimentHelper
     */
    public openConfirmationPopup(functionName: string, userID: string): void {
        const dialogOptionsDetail = COMMON_DIALOG_OLD;
        const dialogMessage = USER_PLANT_ALLOCATION_ISSUE;
        dialogMessage.message = `Cannot perform function: ${functionName}`;
        dialogMessage.subMesssage = `No plant allocation exists for user ${userID}`;
        dialogOptionsDetail.data = dialogMessage;
        this.dialog.open(ConfirmationDialogComponent, dialogOptionsDetail);
    }

    /**
     * Method to validate batch size range min 0 / max 32267
     * @param {FormControl} control
     * @returns {ValidationErrors | null}
     * @memberof ExperimentHelper
     */
    public batchSizeValidation = (control: UntypedFormControl): ValidationErrors | null => {
        if (
            control.value !== "" &&
            (+control.value <= BATCHSIZE_VALIDATION.MIN_RANGE || +control.value > BATCHSIZE_VALIDATION.MAX_RANGE) &&
            control.value !== null
        ) {
            return { isInvalid: true };
        }
        // eslint-disable-next-line unicorn/no-null
        return null;
    };

    public validateYieldAndUseLevel = (yieldInput: string, isUseLevelInput: boolean): string => {
        let givenValue = yieldInput;
        const uomYield = isUseLevelInput ? UOM_VALUES : YIELD_VALUES;
        if (+givenValue >= uomYield.MIN && +givenValue <= uomYield.MAX) {
            givenValue = Number(givenValue)?.toFixed(uomYield.DECIMAL_LENGTH);
        } else if (+givenValue < uomYield.MIN || givenValue === ".") {
            givenValue = Number(uomYield.MIN)?.toFixed(uomYield.DECIMAL_LENGTH);
        } else if (+givenValue > uomYield.MAX) {
            givenValue = Number(uomYield.MAX)?.toFixed(uomYield.DECIMAL_LENGTH);
        }
        return givenValue;
    };

    /**
     * Method to create experiment taste model
     * @param {FlavorTypesModel} selectedTaste
     * @param {FormGroup} experimentForm
     * @param {FormArray} experimentTaste
     * @param {FlavorTypesModel[]} selectedFlavors
     * @param {FlavorTypesModel[]} filteredSelectedFlavors
     * @param {FormGroup} expTasteForm
     * @returns {ExperimentTasteHelperModel}
     * @memberof ExperimentHelper
     */
    public static createExperimentTasteModel(
        selectedTaste: FlavorTypesModel,
        experimentForm: UntypedFormGroup,
        experimentTaste: UntypedFormArray,
        selectedFlavors: FlavorTypesModel[],
        filteredSelectedFlavors?: FlavorTypesModel[],
        expTasteForm?: UntypedFormGroup,
    ): ExperimentTasteHelperModel {
        return {
            selectedTaste,
            experimentForm,
            experimentTaste,
            selectedFlavors,
            filteredSelectedFlavors,
            expTasteForm,
        };
    }

    /**
     * Method to remove taste from mat chip
     * @param {ExperimentTasteHelperModel} experimentTasteHelper
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public static removeExpTaste(experimentTasteHelper: ExperimentTasteHelperModel): void {
        const experimentTasteHelperData = experimentTasteHelper;
        const { selectedFlavors, selectedTaste, experimentForm, experimentTaste } = experimentTasteHelperData;
        experimentTasteHelperData.filteredSelectedFlavors = [];
        const index = selectedFlavors.indexOf(selectedTaste);
        if (index >= 0) {
            selectedFlavors.splice(index, 1);
        }
        experimentTaste.removeAt(index);
        experimentForm.patchValue({ IsTasteUpdated: true });
    }

    /**
     * Method to remove taste from mat chip
     * @param {ExperimentTasteHelperModel} experimentTasteHelper
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public static addExperimentTaste(experimentTasteHelper: ExperimentTasteHelperModel): void {
        const { selectedTaste, experimentForm, experimentTaste, expTasteForm } = experimentTasteHelper;
        expTasteForm.setValue({ FlavourTypeID: selectedTaste.id });
        experimentTaste.push(expTasteForm);
        experimentForm.patchValue({ IsTasteUpdated: true });
    }

    /**
     * Method to select taste from search drop down
     * @param {ExperimentTasteHelperModel} experimentTasteHelper
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public static onSelectingFlavours(experimentTasteHelper: ExperimentTasteHelperModel): void {
        const experimentTasteHelperData = experimentTasteHelper;
        const { selectedFlavors, selectedTaste, experimentTaste } = experimentTasteHelperData;
        experimentTasteHelperData.filteredSelectedFlavors = [];
        selectedFlavors.push(selectedTaste);
        experimentTaste.clear();
    }

    /**
     * Method to remove duplicate taste from list
     * @param {FlavorTypesModel[]} flavourList
     * @param {FlavorTypesModel[]} selectedFlavors
     * @returns {FlavorTypesModel[]}
     * @memberof ExperimentHelper
     */
    public static removeDuplicateFlavoursFromList(
        flavourList: FlavorTypesModel[],
        selectedFlavors: FlavorTypesModel[],
    ): FlavorTypesModel[] {
        let list;
        if (selectedFlavors?.length > 0) {
            list = pullAll(flavourList, selectedFlavors);
        }
        return list || flavourList;
    }

    /**
     * Method to fill the auto complete list
     * @param {FlavorTypesModel[]} selectedFlavors
     * @param {string} searchValue
     * @param {FlavorTypesModel[]} filteredSelectedFlavors
     * @param {FlavorTypesModel[]} flavorTypes
     * @returns {FlavorTypesModel[]}
     *  @memberof ExperimentHelper
     */
    public static getflavorsBySearch(
        selectedFlavors: FlavorTypesModel[],
        searchValue: string,
        flavorTypes: FlavorTypesModel[],
    ): FlavorTypesModel[] {
        const filteredSelectedFlavor = filter(flavorTypes, (flavorType) => {
            return includes(flavorType?.name?.toLowerCase(), searchValue?.toLowerCase());
        });
        return this.removeDuplicateFlavoursFromList(filteredSelectedFlavor, selectedFlavors);
    }

    /**
     * Method to clear working cost on updating header
     *
     * @param {SelectedRowDataModel[]} selectedExperiments
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public clearWorkingCost(selectedExperiments: SelectedRowDataModel[]): void {
        this.experimentApiService.clearWorkingCost(selectedExperiments[0].ExpID).subscribe({
            // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
            next: () => {},
            error: (error) => {
                this.toastrService.error(error);
            },
        });
    }

    /**
     * Method to get the user list
     * @param {UsersListSearchPayload} payLoad
     * @returns {Observable<Array<CooperatorUserModel>>}
     * @memberof ExperimentHelper
     */
    public getUsersListSearch(payload: UsersListSearchPayload): Observable<Array<CooperatorUserModel>> {
        return this.appDataService.post(`${this.appDataService.url.getUsersListSearch}?includeCurrentUser=true`, [], payload);
    }

    /**
     * Method to get open view membership popup
     * @param {ExperimentsModel | SelectedRowDataModel | BomDetailExperimentsModel} activeExperiment
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public openViewMemberShipPopup(
        activeExperiment: ExperimentsModel | SelectedRowDataModel | BomDetailExperimentsModel,
        selectedFolderId?: number,
    ): void {
        const dialogOptions = COMMON_DIALOG;
        dialogOptions.data = {
            expId: activeExperiment.ExpID,
            experimentName: activeExperiment.ExpName,
            expCode: activeExperiment.ExpCode,
            selectedFolderID: selectedFolderId,
        };
        this.experimentHelperSubscriptions.push(
            this.dialog
                .open(ViewMembershipComponent, dialogOptions)
                .afterClosed()
                .subscribe((experimentDetails: ExperimentDetails) => {
                    if (!experimentDetails) {
                        return;
                    }
                    if (
                        (selectedFolderId === experimentDetails.SelectedCollaborationGroup?.CollaborationGroupID ||
                            selectedFolderId === experimentDetails.FolderID) &&
                        this.router.url === BASIC_ROUTES_URL.HOME
                    ) {
                        AppStateService.setRedirectedExperimentDetails(experimentDetails);
                        this.appBroadCastService.checkHomeUrl(true);
                    } else {
                        this.appBroadCastService.onExperimentRedirectionInfo(experimentDetails);
                    }
                    this.router.navigateByUrl(BASIC_ROUTES_URL.HOME);
                }),
        );
    }

    /**
     * Method to open Create Request Sheet
     * @param {ExperimentsModel | SelectedRowDataModel | BomDetailExperimentsModel} activeExperiment
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public openCreateSampleModel(activeExperiment: ExperimentsModel | SelectedRowDataModel | BomDetailExperimentsModel): void {
        const dialogOptions = CREATE_SAMPLE_POPUP;
        dialogOptions.data = {
            expId: activeExperiment.ExpID,
            experimentName: activeExperiment.ExpName,
            expCode: activeExperiment.ExpCode,
            yield: activeExperiment.Yield,
            notes: activeExperiment.ExperimentNote,
            Comment: activeExperiment.Comment,
            heading: CREATE_SAMPLE_POPUP.heading,
            type: SAMPLE_TYPE.MAKE_SAMPLE,
        };
        this.dialog.open(CreateSampleComponent, CREATE_SAMPLE_POPUP);
    }

    /**
     * Method to open attribute analysis
     * @param activeExperiment
     * @returns {Observable<Array<AddFavoritesModel>>}
     * @memberof ExperimentHelper
     */
    public openAttributeAnalysis(activeExperiment: ExperimentsModel | SelectedRowDataModel | BomDetailExperimentsModel, component): void {
        const slidePanel = cloneDeep(SLIDE_PANEL_DIALOG);
        slidePanel.data = { ipc: activeExperiment.ExpCode };
        this.dialog.open(component, slidePanel);
    }

    /**
     * Method to get Favorite Instructions list
     * @param searchCriteria
     * @returns {Observable<Array<AddFavoritesModel>>}
     * @memberof ExperimentHelper
     */
    public getFavoriteInstructions(searchCriteria): Observable<Array<AddFavoritesModel>> {
        return this.appDataService.post(this.appDataService.url.getInstructionList, [], searchCriteria);
    }

    /**
     * Method to add Favorite Instructions
     * @param payLoad
     * @returns {Observable<Array<AddFavoriteItem>>}
     * @memberof ExperimentHelper
     */
    public addFavoriteInstructions(payLoad): Observable<Array<AddFavoriteItem>> {
        return this.appDataService.post(this.appDataService.url.Favourites, [], payLoad);
    }

    /**
     * Method to get experiment folders
     *
     * @return {*}  {Observable<TreeViewModel[]>}
     * @memberof ExperimentHelper
     */
    public fetchAllExpFolders(isTrustee = false): Observable<TreeViewModel[]> {
        return new Observable((observer) => {
            if (!isTrustee) {
                const expFolders = AppStateService.getExpFolderList() ?? [];
                if (expFolders.length > 0) {
                    observer.next(expFolders);
                    observer.complete();
                    return;
                }
            }
            this.appBroadCastService.onUpdateAppSpinnerPrompt(FOLDERS_LOADING);
            this.experimentApiService.getAllExperimentFolders(isTrustee).subscribe({
                next: (response) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    if (!response || !response.ExperimentFolders) {
                        return;
                    }
                    observer.next(this.formatExpFolders(response.ExperimentFolders, isTrustee));
                    observer.complete();
                },
                error: (error) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.logger.error(error);
                },
            });
        });
    }

    /**
     * Method to create folder structure
     *
     * @private
     * @param {Array<TreeViewModel>} experimentFolders
     * @return {*}  {Array<TreeViewModel>}
     * @memberof ExperimentHelper
     */
    private formatExpFolders(experimentFolders: Array<TreeViewModel>, isTrustee: boolean): Array<TreeViewModel> {
        experimentFolders.forEach((experimentFolder) => {
            if (!experimentFolder) return;

            const expFolder = experimentFolder;
            const expFolderId = [];
            expFolderId.push(expFolder.FolderID.toString());
            const parentFolderId = [];
            if (expFolder.ParentFolderID) {
                const datas = this.getParentFolderName(experimentFolders, expFolder, parentFolderId);
                expFolderId.push(...datas);
                expFolder.filePath = expFolderId.reverse();
            } else {
                expFolder.filePath = expFolderId;
            }
        });

        // eslint-disable-next-line no-unused-expressions
        !isTrustee && AppStateService.setExpFolderList(experimentFolders);

        return experimentFolders;
    }

    /**
     * Method to get the parent folderId for the existing folder
     *
     * @private
     * @param {Array<TreeViewModel>} experimentFolders
     * @param {TreeViewModel} expFolder
     * @param {Array<string>} parentFolderId
     * @return {*}  {Array<string>}
     * @memberof ExperimentHelper
     */
    private getParentFolderName(
        experimentFolders: Array<TreeViewModel>,
        expFolder: TreeViewModel,
        parentFolderId: Array<string>,
    ): Array<string> {
        const parentFolder = experimentFolders.find((folder) => folder.FolderID === expFolder.ParentFolderID);
        parentFolderId.push(parentFolder.FolderID.toString());
        if (!parentFolder?.ParentFolderID) {
            return parentFolderId;
        }
        return this.getParentFolderName(experimentFolders, parentFolder, parentFolderId);
    }

    /**
     * Method to set dropdowm default slection in experiemnt header
     * @param {MatAutocomplete} matAutoCompleteValue
     * @param {any} formValue
     * @param {string} headerField
     * @returns {void}
     */
    public defaultOptionSelection = (matAutoCompleteValue: MatAutocomplete, formValue: string | number, headerField: string): void => {
        let formData = formValue;
        if (formData && headerField === FORM_CONTROL_NAME.UOM) {
            const uomData = UOM_DATA;
            formData = find(uomData, (uom) => {
                return uom.value === formData;
            }).value;
        }
        // eslint-disable-next-line no-unused-expressions
        find(matAutoCompleteValue?.options.toArray(), (matOption) => matOption?.value === formData)?.select();
    };

    /**
     * Method to get create experiment from product payload
     * @param {ReviseExperimentPayload} reviseInfo
     * @returns {ExperimentFromExperimentPayload}
     * @memberof ExperimentHelper
     */
    public getCreateExpFromProductPayload(product: ReviseExperimentPayload): ExperimentFromExperimentPayload {
        const isPrivateModel = this.appStateService.getPrivacyModelInfo();
        const expFromProductPayload: ExperimentFromExperimentPayload = {
            ExpFolderID: product.selectedFolderID,
            NumberOfCopies: REVISE_EXPERIMENT_COPIES,
            AddVariant: false,
            ExpSource: DISPLAY_EXPERIMENT_SOURCE.P,
            IsPublic: !isPrivateModel,
            IsCopyAllNotes: false,
            ipc: product.sourceExpCode,
            IsRevise: false,
        };
        return expFromProductPayload;
    }

    /**
     * Method to add favorite instruction
     * @param selectedRows
     * @memberof ExperimentHelper
     */
    public addFavoriteInstruction(selectedRows): void {
        const payLoad: AddFavoriteItem[] = map(selectedRows, (rowInfo) => {
            return {
                PrefTypeCode: INSTRUCTION_SEARCH.FAV_INSTRUCTION,
                ColumnValue: rowInfo.ingredientName,
                IsChecked: true,
            };
        });
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.addFavoriteInstructions(payLoad).subscribe({
            next: () => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.toastrService.success(INSTRUCTION_INFO.ADD_TO_FAVORITE_SUCCESS);
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.toastrService.error(INSTRUCTION_INFO.ADD_TO_FAVORITE_FAILED);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to fetch recently used product types
     *
     * @param {ProductTypesModel[]} productTypes
     * @return {*}  {Observable<ProductTypesModel[]>}
     * @memberof ExperimentHelper
     */
    public fetchRecentlyUsedProductTypes(productTypes: ProductTypesModel[]): Observable<ProductTypesModel[]> {
        return new Observable((observer) => {
            this.experimentApiService.getRecenltyUsedProductTypes().subscribe((response) => {
                if (response) {
                    const recentlyUsedProductTypes = uniqBy(response, COLUMN_VALUE_KEY)
                        .map((types) => {
                            const recentlyUsedProduct = productTypes?.find((productType) => {
                                return productType.prodtypecode === types[COLUMN_VALUE_KEY] && types[COLUMN_VALUE_KEY] !== EMPTY;
                            });
                            if (recentlyUsedProduct) {
                                return { ...recentlyUsedProduct, isRecentlyUsed: true };
                            }
                            return recentlyUsedProduct;
                        })
                        // eslint-disable-next-line unicorn/prefer-native-coercion-functions
                        .filter((product) => product);
                    observer.next(recentlyUsedProductTypes);
                    observer.complete();
                }
            });
        });
    }

    /**
     * Method to destroy subscriptions
     * @returns {void}
     * @memberof ExperimentHelper
     */
    ngOnDestroy(): void {
        TasteEditorUtilClass.removeSubscriptions(this.experimentHelperSubscriptions);
    }

    /**
     * Method to get flex pallet information
     * @param {FlexPalletModel} payLoad
     * @returns {Array<ExperimentFormulaModel>}
     * @memberof ExperimentHelper
     */
    public getFlexPalletData(payLoad: FlexPalletModel): Observable<Array<ExperimentFormulaModel>> {
        return this.appDataService.post(this.appDataService.url.getFlexPalletInfo, [], payLoad);
    }

    /**
     * Method to invoke review list dialog
     * @param {ReviewSelectedRowDataModel[]} selectedExperiments
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public openReviewListDialog(selectedExperiments: ReviewSelectedRowDataModel[]): void {
        this.dialogHelper.openReviewListDialog(selectedExperiments);
    }

    /**
     * Method to open plm nutrition calculator
     * @param {selectedExperiment}
     * @param {number} environment
     * @returns {void}
     * @memberof ExperimentHelper
     */
    public openPLMNutritionCalculator(selectedExperiment, environment, type?: string): void {
        const plmCalcURL = this.getPLMCalculatorURL(environment);
        const modifiedURL =
            type === MENU_LIST_FORMULA.PRODUCT
                ? `${plmCalcURL}&MATNR=${selectedExperiment?.IPC}#`
                : `${plmCalcURL}&EXP_NUM=${selectedExperiment?.ExpID}&SRC=TasteEditor#`;
        // eslint-disable-next-line angular/window-service
        window.open(modifiedURL, "_blank");
    }

    /**
     * Method to get PLM Nutrition Calculator URL
     * @param {number} environment
     * @returns {string}
     * @memberof ExperimentHelper
     */
    public getPLMCalculatorURL(environment): string {
        let SAP_PLM_NUTRITION_URL;
        // eslint-disable-next-line unicorn/prefer-switch
        if (environment === AppEnvironment.DEV || environment === AppEnvironment.LOCAL) {
            SAP_PLM_NUTRITION_URL = PLM_NUTRITION_CALCULATOR_URL.DEV;
        } else if (environment === AppEnvironment.QAS) {
            SAP_PLM_NUTRITION_URL = PLM_NUTRITION_CALCULATOR_URL.QAS;
        } else if (environment === AppEnvironment.PROD) {
            SAP_PLM_NUTRITION_URL = PLM_NUTRITION_CALCULATOR_URL.PROD;
        }
        return SAP_PLM_NUTRITION_URL;
    }

    /**
     * Method to get Detailed Costing payload
     * @param {DetailedCostingPreparePayloadModel} detailedCostPayload
     * @returns {DetailedCostingPayload}
     * @memberof ExperimentHelper
     */
    public getDetailedCostingPayload(detailedCostPayload: DetailedCostingPreparePayloadModel): DetailedCostingPayload {
        let selectedType: string;
        let selectedProductTechDetail: ProductAllocationModel;
        let productDetails: BomAttributes;
        const userAllocatedPlantInfo = [];
        const { selectedItem, plantAndSourceInfo, facilityInfo, attributesInfo, isLandingPage, isZeroPartsExist } = detailedCostPayload;
        if (isLandingPage) {
            selectedType = EXPERIMENT;
        } else {
            selectedType = selectedItem.Type === COSTING_KEY_VALUES.EXPERIMENT ? EXPERIMENT : PRODUCT;
        }
        if (selectedType === EXPERIMENT) {
            forEach(plantAndSourceInfo, (plantInfoValue) => {
                const plantDetail = facilityInfo.find((facility) => facility.facilitycode === plantInfoValue.PlantID);
                if (plantDetail) {
                    userAllocatedPlantInfo.push(plantDetail);
                }
            });
        }
        if (selectedType === PRODUCT) {
            productDetails = attributesInfo.find((product) => product.ipc === selectedItem.IPC);
            selectedProductTechDetail = productDetails.productallocation
                ? productDetails.productallocation.find(
                      (details) =>
                          details.procurementtype.toLowerCase() === PRODUCT_PROCUREMENT_TYPE.TYPE_X ||
                          details.procurementtype.toLowerCase() === PRODUCT_PROCUREMENT_TYPE.TYPE_MAKE,
                  )
                : undefined;
        }
        const data = this.getDetailedCostingFormatedPayload(
            detailedCostPayload,
            selectedType,
            userAllocatedPlantInfo,
            selectedProductTechDetail,
            productDetails,
            isZeroPartsExist,
        );
        return data;
    }

    /**
     * Method to get Detailed Costing Formated Payload
     * @param {DetailedCostingPreparePayloadModel} detailedCostPayload
     * @param {string} selectedType
     * @param {FacilitiesModel[]} userAllocatedPlantInfo
     * @param {ProductAllocationModel} selectedProductTechDetail
     * @param {BomAttributes} productDetails
     * @param {boolean} isZeroPartsExist
     * @returns {DetailedCostingPayload}
     * @memberof ExperimentHelper
     */
    private getDetailedCostingFormatedPayload(
        detailedCostPayload: DetailedCostingPreparePayloadModel,
        selectedType: string,
        userAllocatedPlantInfo?: FacilitiesModel[],
        selectedProductTechDetail?: ProductAllocationModel,
        productDetails?: BomAttributes,
        isZeroPartsExist = false,
    ): DetailedCostingPayload {
        const { selectedItem, facilityInfo, productType } = detailedCostPayload;
        const userDetails = this.appStateService.getCurrentUser();
        return {
            // eslint-disable-next-line unicorn/no-null
            expID: selectedType === EXPERIMENT ? selectedItem.ExpID.toString() : null,
            // eslint-disable-next-line unicorn/no-null
            ipc: selectedType === PRODUCT ? selectedItem.IPC.toString() : null,
            plant: selectedType === PRODUCT ? selectedProductTechDetail?.facilitycostbookcode : selectedItem?.PlantID,
            facilitycode:
                selectedType === PRODUCT
                    ? find(facilityInfo, (plant) => plant.costbookcode === selectedProductTechDetail?.facilitycostbookcode)?.facilitycode
                    : find(facilityInfo, (plant) => plant.costbookcode === selectedItem?.PlantID)?.facilitycode,
            currencycode: AppStateService.getCurrencyValue(),
            userID: userDetails?.globaluserid,
            description: selectedItem?.ExpName,
            userAllocatedPlant: userAllocatedPlantInfo,
            technologyID:
                selectedType === PRODUCT
                    ? productDetails?.[COSTING_KEY_VALUES.TECHNOLOGY]?.[0]?.[COSTING_KEY_VALUES.TECHNOLOGYID]
                    : find(productType, (product) => product.prodtypecode === selectedItem?.ProductTypeID)?.PTtechnologyID,
            batchSize:
                selectedType === PRODUCT
                    ? selectedProductTechDetail?.[COSTING_KEY_VALUES.BATCHSIZE_KEY_IN_PRODUCT]
                    : selectedItem?.BatchSize,
            isZeroPartsExist,
        };
    }

    /**
     * Method to check whether selected experiment has zero parts values
     * @param {string} expID
     * @returns {boolean}
     * @memberof ExperimentHelper
     */
    public allowDetailCost(expID: string): Observable<boolean> {
        return this.experimentApiService.allowCosting(expID);
    }
}
