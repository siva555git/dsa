/* eslint-disable max-classes-per-file */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { cloneDeep } from "lodash";
import { ExperimentBomUtil } from "./experiment-bom.util";
import { ColumnLayoutHelper } from "../../master-data/helpers/column.layout.helper";
import { ExperimentUtil } from "../../experiment-editor/helpers/experiment.util";
import { BaseColumnHelper } from "../components/base-column-layout/helper/base-column-helper";
import { AppStateService } from "../../_services/app-state/app.state.service";
import { BomSearchHelper } from "./bom-search.helper";
import { MockAppStateService } from "../../testing/mock-app-state-service";
import { mockDynamicColumnData, mockSortEventData } from "../../testing/mock-experiment-editor.helper";

describe("BomSearchHelper", () => {
    let service: BomSearchHelper;
    class MockExperimentBomUtil {
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        public getTopLevelExperimentByExpId = () => {};
    }

    class MockSearchDrawer {
        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        public storeColumnLayoutWidth = () => {};

        // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
        public getColumnHeaderWidth = () => {};
    }

    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [
                {
                    provide: BomSearchHelper,
                    useClass: MockSearchDrawer,
                },
                { provide: ExperimentBomUtil, useClass: MockExperimentBomUtil },
                ColumnLayoutHelper,
                ExperimentUtil,
                BaseColumnHelper,
                { provide: AppStateService, useClass: MockAppStateService },
            ],
        })));

    beforeEach(() => {
        service = TestBed.inject(BomSearchHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call sortProductSearch for direct columns ", () => {
        spyOn(BomSearchHelper, "sortProductSearch").and.callThrough();
        BomSearchHelper.sortProductSearch(mockSortEventData, [mockDynamicColumnData]);
        expect(BomSearchHelper.sortProductSearch).toHaveBeenCalled();
    });

    it("should call sortProductSearch for indirect columns ", () => {
        const sortEventData = cloneDeep(mockSortEventData);
        sortEventData.active = "BAFL";
        spyOn(BomSearchHelper, "sortNestedColumns").and.returnValue([]);
        spyOn(BomSearchHelper, "sortProductSearch").and.callThrough();
        BomSearchHelper.sortProductSearch(sortEventData, [mockDynamicColumnData]);
        expect(BomSearchHelper.sortProductSearch).toHaveBeenCalled();
    });

    it("should call sortProductSearch => if sort removed ", () => {
        const sortEventData = cloneDeep(mockSortEventData);
        sortEventData.direction = "";
        spyOn(BomSearchHelper, "sortProductSearch").and.callThrough();
        BomSearchHelper.sortProductSearch(sortEventData, [mockDynamicColumnData]);
        expect(BomSearchHelper.sortProductSearch).toHaveBeenCalled();
    });

    it("should call sortNestedColumns for CostPerKg", () => {
        const sortEventData = cloneDeep(mockSortEventData);
        sortEventData.active = "BAFL/Kg";
        spyOn(BomSearchHelper, "sortNestedColumns").and.callThrough();
        BomSearchHelper.sortNestedColumns(mockSortEventData, "CostPerKg");
        expect(BomSearchHelper.sortNestedColumns).toHaveBeenCalled();
    });

    it("should call sortNestedColumns for other than CostPerKg", () => {
        const sortEventData = cloneDeep(mockSortEventData);
        sortEventData.active = "DENSITY, 20/20 (PD03)";
        spyOn(BomSearchHelper, "sortNestedColumns").and.callThrough();
        BomSearchHelper.sortNestedColumns(mockSortEventData, "Spec");
        expect(BomSearchHelper.sortNestedColumns).toHaveBeenCalled();
    });
});
