import { Injectable } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { AppBroadCastService } from "@te-services/index";
import {
    CANCEL,
    CLOSE,
    CR_POPUP,
    FLASHPOINT_PDS_CONSTANT,
    HEAT_UNIT,
    REVIEW_COMPARISON_POPUP,
    SHOW_BOM_BOS_COMPARISON,
    SLIDE_PDS_DIALOG,
} from "@te-shared/constants";
import { each } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
// import { CreativeReviewComponent } from "../../creative-review-mfe/creative-review/creative-review.component";
import { CreativeReviewComponent } from "src/app/creative-review/creative-review.component";
import { ProductDataComponent } from "../../product-data/product-data.component";
import { EMPTY, REVIEW_COMPARISON } from "../../app.constant";
import { NO_REVIEWS, REVIEW_BY_LIST } from "../../creative-review/creative-review.constant";
import { CreativeReviewHelper } from "../../creative-review/helpers/creative-review-helper";
import { ComparisonDialogComponent } from "../../creative-review/review-comparison/comparison-dialog/comparison-dialog.component";
// eslint-disable-next-line import/no-cycle
import { ReviewSelectionDialogComponent } from "../../creative-review/review-comparison/review-selection-dialog/review-selection-dialog.component";
import { ReviewHistoryPayload, ReviewSelectedRowDataModel } from "../../creative-review/models/creative-review.model";
import {
    CreativeReviewDialogDataModel,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    CreativeReviewMFEDialogDataModel,
    ReviewComparisonDialogDataModel,
    ReviewComparisonDialogRequestDataModel,
} from "../models/dialog.model";
import { TasteEditorUtilClass } from "./taste-editor-utils";

@Injectable()
export class DialogHelper {
    public isCRDialogOpened = false;

    constructor(
        public readonly dialog: MatDialog,
        public readonly creativeReviewHelper: CreativeReviewHelper,
        private readonly logger: NGXLogger,
        private appBroadCastService: AppBroadCastService,
        private toastrService: ToastrService,
    ) {}

    /**
     * Method to open creative review dialog
     * @param { ReviewSelectedRowDataModel[] } data
     * @returns {void}
     */
    public onOpenCreativeReviewDialog(data: ReviewSelectedRowDataModel[]): void {
        if (this.isCRDialogOpened) return;
        /**
         * creative review MFE changes - need for MFE integ
         */
        // const dialogData: CreativeReviewMFEDialogDataModel = {
        //     selectedExperiments: data,
        //     selectedTab: this.appBroadCastService.selectedTabName,
        // };
        /**
         * creative review MFE changes - need to remove afterwards
         */
        const dialogData: CreativeReviewDialogDataModel = {
            selectedExperiments: data,
        };

        const dialogOptions = CR_POPUP;
        dialogOptions.data = dialogData;
        this.isCRDialogOpened = true;
        this.dialog
            .open(CreativeReviewComponent, dialogOptions)
            .afterClosed()
            .subscribe(() => {
                this.isCRDialogOpened = false;
            });
    }

    /**
     * Method to open view product
     * @param {string} ipc
     * @memberof DialogHelper
     */
    public onOpenViewProductDialog(ipc: string): void {
        const slidePanel = SLIDE_PDS_DIALOG;
        const flashPointUOMValue = TasteEditorUtilClass.getUserDefaultFlashpoint();
        const costBookDetails = TasteEditorUtilClass.getUserDefaultplant();
        slidePanel.data = {
            ipc,
            currency: AppStateService.getCurrencyValue(),
            currencyConversionRate: AppStateService.getConversionRate(),
            currencyDecimal: 2,
            flashpointType:
                flashPointUOMValue === HEAT_UNIT.Farenheit ? FLASHPOINT_PDS_CONSTANT.Farenheit : FLASHPOINT_PDS_CONSTANT.Celcius,
            costBookCode: costBookDetails,
        };
        this.dialog.open(ProductDataComponent, slidePanel);
    }

    /**
     *  Method to open review list
     * @param { ReviewSelectedRowDataModel[] } data
     * @returns {void}
     */
    public openReviewListDialog(data: ReviewSelectedRowDataModel[]): void {
        if (this.isCRDialogOpened) return;
        const reviewPayloadData: ReviewHistoryPayload = {
            expIds: [],
            ipcs: [],
            isDisplayAllReviews: false,
        };
        const experimentList = data;
        each(experimentList, (dataValue) => {
            if (dataValue.type === REVIEW_BY_LIST.EXPERIMENTS) {
                reviewPayloadData.expIds.push(dataValue.selectedID);
            } else {
                reviewPayloadData.ipcs.push(dataValue.selectedID);
            }
        });
        this.appBroadCastService.onUpdateAppSpinnerPrompt(REVIEW_COMPARISON);
        this.creativeReviewHelper.getReviewLists(reviewPayloadData).subscribe({
            next: (response) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                if (response && response?.data?.length > 0) {
                    const dialogData: CreativeReviewDialogDataModel = {
                        selectedExperiments: data,
                        submitText: SHOW_BOM_BOS_COMPARISON,
                        cancelText: CANCEL,
                        reviews: response.data,
                    };
                    const dialogOptions = REVIEW_COMPARISON_POPUP;
                    dialogOptions.data = dialogData;
                    this.isCRDialogOpened = true;
                    this.dialog
                        .open(ReviewSelectionDialogComponent, dialogOptions)
                        .afterClosed()
                        .subscribe(() => {
                            this.isCRDialogOpened = false;
                        });
                } else {
                    this.toastrService.info(NO_REVIEWS);
                }
            },
            error: (error) => {
                this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                this.logger.error(error);
            },
        });
    }

    /**
     * Method to open comparison dialog for BOM/BOS
     * @param { ReviewComparisonDialogRequestDataModel } data
     * @returns {void}
     */
    public openReviewComparisonDialog(data: ReviewComparisonDialogRequestDataModel): void {
        const dialogData: ReviewComparisonDialogDataModel = {
            selectedReviews: data.review,
            rawData: data.rawData,
            activeFormula: data.activeFormula,
            selectedExperiments: data.selectedExperiments,
            cancelText: CLOSE,
        };
        const dialogOptions = REVIEW_COMPARISON_POPUP;
        dialogOptions.data = dialogData;
        this.isCRDialogOpened = true;
        this.dialog
            .open(ComparisonDialogComponent, dialogOptions)
            .afterClosed()
            .subscribe(() => {
                this.isCRDialogOpened = false;
            });
    }
}
