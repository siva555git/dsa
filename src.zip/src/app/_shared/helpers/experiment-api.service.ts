import { Injectable } from "@angular/core";
import { forkJoin, Observable } from "rxjs";
import { CurrencyRateModel } from "@te-shared/models/currencies-rate-model";
import { IpcBasicAttributeInfo } from "@te-shared/components/add-ipc-list/models/add-ipc-list.model";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import {
    RecentlyUsedExpInSearch,
    ProductSearchList,
    RecentlyViewedPayload,
    RecentlyViewExperiment,
    ExperimentReturnFromAPI,
} from "../models/experiments.model";
import { SUBTypes } from "../enums";
import { AppDataService } from "../../_services/app-data/app.data.service";
import { Experiment, ExperimentListFilterPayload, TreeViewModel } from "../models";
import { PRODUCT_TYPE } from "../constants/common.constant";

import {
    AddWorkingCostPayload,
    BatchSizePayload,
    BatchSizeResponse,
    ExperimentPrivacyPayload,
    PrivacyStatusResponse,
    WorkingCostPayload,
    WorkingCostResponse,
} from "../models/create-experiment.model";
import { ExperimentsModel } from "../models/experiment-bom.model";
import { SearchCriteria } from "../models/search-criteria.model";
import { CollaborationGroupListModel, ViewCollaborationFolderModel } from "../models/user-collaboration-group.model";
import { ProductTypesModel, RecentlyUsedProductTypesModel } from "../models/product-types.model";
import { ProductSearchResponse } from "../../master-data/models/ipc-selection-model";

@Injectable()
export class ExperimentApiService {
    constructor(private readonly appDataService: AppDataService, private readonly securityHelper: SecurityHelper) {}

    /**
     * @memberof ExperimentApiService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getDefaultData(): Observable<any> {
        return new Observable((observer) => {
            const requestedURL = [
                this.appDataService.get(this.appDataService.url.getFlavorTypes, []),
                this.appDataService.get(this.appDataService.url.getProductTypes, [PRODUCT_TYPE]),
                this.appDataService.get(this.appDataService.url.getFacilities, []),
                this.appDataService.get(this.appDataService.url.getPlantsAndSources, []),
                this.appDataService.get(this.appDataService.url.getCurrencies, []),
                this.appDataService.get(this.appDataService.url.getCurrencyRate, []),
                this.appDataService.get(this.appDataService.url.getUOMDetails, []),
            ];
            forkJoin(requestedURL).subscribe({
                next: (response) => {
                    if (response && response.length === 5) {
                        observer.next(response);
                        observer.complete();
                    }
                },
                error: (error) => {
                    observer.error(error);
                },
            });
        });
    }

    /**
     * Method to get working cost
     * @param {WorkingCostPayload} payload
     * @returns {Observable<WorkingCostResponse>}
     * @memberof ExperimentApiService
     */
    public getWorkingCost(payload: WorkingCostPayload): Observable<WorkingCostResponse[]> {
        return this.appDataService.post(this.appDataService.url.getWorkingCost, [], [payload]);
    }

    /**
     * Method to add working cost
     * @param {AddWorkingCostPayload} workingCostPayload
     * @returns {Observable<void>}
     * @memberof ExperimentApiService
     */
    public addWorkingCost(workingCostPayload: AddWorkingCostPayload): Observable<void> {
        return this.appDataService.post(this.appDataService.url.addWorkingCost, [], workingCostPayload);
    }

    /**
     * Method to clear the working cost
     *
     * @param {number} expID
     * @return {*}  {Observable<void>}
     * @memberof ExperimentApiService
     */
    public clearWorkingCost(expID: number): Observable<void> {
        return this.appDataService.post(this.appDataService.url.clearWorkingCost, [expID.toString()], []);
    }

    /**
     * Method to get the Product types by plant ID
     * @param {string} plantID
     * @returns {Observable<ProductTypesModel[]>}
     * @memberof ExperimentApiService
     */
    public getProductTypes(plantID: string, divisioncode: string): Observable<ProductTypesModel[]> {
        return this.appDataService.get(this.appDataService.url.getProductTypesByCode, [
            this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION)
                ? divisioncode.charAt(0).toUpperCase() + divisioncode.slice(1).toLowerCase()
                : PRODUCT_TYPE,
            plantID,
        ]);
    }

    /**
     * Method to get the batch size by batch details
     * @param {BatchSizePayload} batchDetails
     * @returns {BatchSizeResponse[]}
     * @memberof ExperimentApiService
     */
    public getBatchSize(batchDetails: BatchSizePayload): Observable<BatchSizeResponse[]> {
        return this.appDataService.post(this.appDataService.url.getBatchSize, [], batchDetails);
    }

    /**
     * Method to get currency rate
     * @memberof ExperimentApiService
     */
    public getCurrencyRate(): Observable<CurrencyRateModel[]> {
        return this.appDataService.get(this.appDataService.url.getCurrencyRate, []);
    }

    /**
     * Method to get the experiments by ids
     * @param {string} expId
     * @memberof ExperimentApiService
     */
    public getExperimentById(expId: string): Observable<Experiment> {
        return this.appDataService.get(this.appDataService.url.getExperimentById, [expId]);
    }

    /**
     * Method to update experiment privacy
     *
     * @param {ExperimentPrivacyPayload} payLoad
     * @returns {Observable<PrivacyStatusResponse>}
     * @memberof ExperimentApiService
     */
    public updateExperimentsPrivacy(payLoad: ExperimentPrivacyPayload): Observable<PrivacyStatusResponse> {
        return this.appDataService.post(this.appDataService.url.updateExperimentsPrivacy, [], payLoad);
    }

    /**
     * Method to get the bomdetails in the grid
     * @param {SearchCriteria} payload
     * @memberof ExperimentApiService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public searchExperiment(payload: SearchCriteria): Observable<any> {
        return this.appDataService.post(this.appDataService.url.searchExperiment, [], payload);
    }

    /**
     * Method to get the Global users Experiment list
     * @param {ExperimentListFilterPayload} payload
     * @memberof ExperimentApiService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public globalExperimentSearch(payload: ExperimentListFilterPayload): Observable<any> {
        return this.appDataService.post(this.appDataService.url.globalExperimentSearch, [], payload);
    }

    /* Method to get the experiments by Code
     * @param {string} payload
     * @memberof ExperimentApiService
     */
    public getExperimentByCode(expCode: string): Observable<ExperimentsModel> {
        return this.appDataService.get(this.appDataService.url.getExperimentByCode, [expCode]);
    }

    /**
     * Method to get the all other experiments from API
     * @param {ExperimentListFilterPayload} payload
     * @memberof ExperimentApiService
     */
    public searchAllOtherExperiment(payload: ExperimentListFilterPayload): Observable<ExperimentReturnFromAPI> {
        return this.appDataService.post(this.appDataService.url.allothersearchExperiment, [], payload);
    }

    /**
     * Method to get all experiments from API
     * @param {ExperimentListFilterPayload} payload
     * @memberof ExperimentApiService
     */
    public getAllMyExperiments(payload: ExperimentListFilterPayload): Observable<ExperimentReturnFromAPI> {
        return this.appDataService.post(this.appDataService.url.getExperiments, [], payload);
    }

    /**
     * Method to get all Trustee experiments from API
     * @param {ExperimentListFilterPayload} payload
     * @memberof ExperimentApiService
     */
    public getAllTrusteeExperiment(payload: ExperimentListFilterPayload): Observable<ExperimentReturnFromAPI> {
        return this.appDataService.post(this.appDataService.url.getTrusteeExperiment, [], payload);
    }

    /**
     * Method to get the experimentByFolders from API
     * @param {ExperimentListFilterPayload} payload
     * @memberof ExperimentApiService
     */
    public getExperimentByFolderId(payload: ExperimentListFilterPayload): Observable<ExperimentReturnFromAPI> {
        return this.appDataService.post(this.appDataService.url.getExperimentByFolderId, [], payload);
    }

    /**
     * Method to get the colloborationExperiments from API
     * @param {ExperimentListFilterPayload} payload
     * @memberof ExperimentApiService
     */
    public getCollaborationExperiments(payload: ExperimentListFilterPayload): Observable<ExperimentReturnFromAPI> {
        return this.appDataService.post(this.appDataService.url.getCollaborationGroupListExperiments, [], payload);
    }

    /**
     * Method to get the sharedExperiments from API
     * @param {ExperimentListFilterPayload} payload
     * @memberof ExperimentApiService
     */
    public getSharedExperiments(payload: ExperimentListFilterPayload): Observable<ExperimentReturnFromAPI> {
        return this.appDataService.post(this.appDataService.url.getSharedExperiments, [], payload);
    }

    /**
     * Method to lock the experiment
     * @param {boolean} isResend
     * @param {number} expId
     * @memberof ExperimentApiService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public sendExperimentToIFFman(isResend: boolean, expId: number): Observable<any> {
        const payload = { expId };
        return this.appDataService.post(`${this.appDataService.url.sendExpToIffman}${"?isresend="}${isResend}`, [], payload);
    }

    /**
     * Method to lock the experiment
     * @param {number} expId
     * @memberof ExperimentApiService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public sendExpFormulaToIFFman(expId: number): Observable<any> {
        const payload = { expId };
        return this.appDataService.post(this.appDataService.url.sendExpFormulaToIffman, [], payload);
    }

    /**
     * Method to fetch recently used list from api
     *
     * @param {SUBTypes} subtype
     * @param {RecentlyViewedModel} payload
     * @return {*}  {Observable<RecentlyUsedExpInSearch>}
     * @memberof ExperimentApiService
     */
    public getRecentlyUsed(
        subtype: SUBTypes,
        payload: RecentlyViewedPayload,
        isBomSearch = true,
    ): Observable<RecentlyUsedExpInSearch | ProductSearchList> {
        let requestedUrl;
        if (subtype === SUBTypes.EXPERIMENT) {
            requestedUrl = `${this.appDataService.url.recentlyUsedExp}?isBomSearch=${isBomSearch}`;
        } else if (subtype === SUBTypes.PRODUCT) {
            requestedUrl = `${this.appDataService.url.recentlyUsedProduct}?isBomSearch=${isBomSearch}`;
            const isEncapsulationAccess = this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION);
            if (payload?.esPayload) {
                payload.esPayload["isEncapsulationUser"] = isEncapsulationAccess;
            } else {
                payload["isEncapsulationUser"] = isEncapsulationAccess;
            }
        }

        return this.appDataService.post(requestedUrl, [], payload);
    }

    /**
     * Method to fetch recently used list from api
     *
     * @param {number} limit
     * @param {number} skip
     * @return {*}  {Observable<RecentlyViewExperiment>}
     * @memberof ExperimentApiService
     */
    public getRecentlyUsedExperiment(payload: ExperimentListFilterPayload): Observable<RecentlyViewExperiment> {
        const requestedUrl = this.appDataService.url.getRecentlyUsedExp;
        return this.appDataService.post(requestedUrl, [], payload);
    }

    /**
     * Method to get user collaboration groups
     *
     * @return {*}  {Observable<Array<CollaborationGroupListModel>>}
     * @memberof ExperimentApiService
     */
    public getCollaborationsGroup(): Observable<Array<CollaborationGroupListModel>> {
        return this.appDataService.get(this.appDataService.url.getCollaborationGroupList, []);
    }

    /**
     * Method to get user collaboration group Experiments
     *
     * @param {number} searchCollaborationValue
     * @param {SearchCriteria} searchCriteria
     * @return {*}  {Observable<RecentlyUsedExpInSearch>}
     * @memberof ExperimentApiService
     */
    public getCollaborationsGroupExperiments(
        searchCollaborationValue: number,
        searchCriteria: SearchCriteria,
    ): Observable<RecentlyUsedExpInSearch> {
        return this.appDataService.post(
            this.appDataService.url.getSearchedCollaborationGroupListExperiments,
            [searchCollaborationValue],
            searchCriteria,
        );
    }

    /**
     * Method to get search exp folder tree data
     * @return {*}  {Observable<TreeViewModel[]>}
     * @memberof ExperimentApiService
     */
    public getSearchExpFolders(): Observable<TreeViewModel[]> {
        return this.appDataService.get(this.appDataService.url.getSearchExpFolderView, []);
    }

    /**
     * Method to get child folders by parent folder id
     * @param {number} folderId
     * @return {*}  {Observable<TreeViewModel[]>}
     * @memberof ExperimentApiService
     */
    public getSearchExpChildFolders(folderId: Array<string>): Observable<TreeViewModel[]> {
        return this.appDataService.get(this.appDataService.url.getChildFoldersByParentId, folderId);
    }

    /**
     * Method to fetch the experiment folder of current user
     * @return {*}  {Observable<any>}
     * @memberof ExperimentApiService
     */

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getAllExperimentFolders(isTrustee?: boolean): Observable<any> {
        const requestUrl = isTrustee
            ? `${this.appDataService.url.experimentFolder}?isTrustee=${isTrustee}`
            : `${this.appDataService.url.experimentFolder}`;
        return this.appDataService.get(requestUrl, []);
    }

    /**
     * Method to get the product by sales number
     * @return {*}  {Observable<any>}
     * @memberof ExperimentApiService
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getProductBySalesNumber(salescode: string): Observable<any> {
        const isEncapsulationAccess = this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION);
        const queryParameters = `isEncapsulationUser=${isEncapsulationAccess}`;
        return this.appDataService.get(`${this.appDataService.url.getProductBySalesNumber}?${queryParameters}`, [salescode]);
    }

    /**
     * Method to get get Product Search Criteria
     *
     * @return {*}  {Observable<any>}
     * @memberof ExperimentApiService
     */
    public getProductSearchCriteria(): Observable<ProductSearchResponse[]> {
        return this.appDataService.get(this.appDataService.url.getProductSearchCriteria, []);
    }

    /**
     * Method to get collboration group and folder data based on experimentId
     *
     * @param {number} expId
     * @return {*}  {Observable<any>}
     * @memberof ExperimentApiService
     */
    public getCollaborationAndFolderInfo(expId: number): Observable<Array<ViewCollaborationFolderModel>> {
        return this.appDataService.get(this.appDataService.url.getCollaborationAndFolderInfoByExpID, [String(expId)]);
    }

    /**
     * Method to get recently user product types
     *
     * @return {*}  {Observable<any>}
     * @memberof ExperimentApiService
     */
    public getRecenltyUsedProductTypes(): Observable<Array<RecentlyUsedProductTypesModel>> {
        return this.appDataService.get(this.appDataService.url.recentlyUsedProductType, []);
    }

    /**
     * Method to get working cost info
     * @param {} payload
     * @memberof ExperimentApiService
     */
    public getWorkingCostInfo(payload): Observable<WorkingCostResponse[]> {
        return this.appDataService.post(this.appDataService.url.getWorkingCostInfo, [], payload);
    }

    /**
     * Method to check whether costing is allowed are not
     * @param {string} expId
     * @param {boolean} isFlagCheckNeeded
     * @returns {boolean}
     * @memberof ExperimentApiService
     */
    public allowCosting(expId: string, isFlagCheckNeeded = false): Observable<boolean> {
        return this.appDataService.get(`${this.appDataService.url.allowCosting}/${expId}/${isFlagCheckNeeded}`, []);
    }

    /**
     * Method to get the Product types by plant ID
     * @param {ipcList: Array<string>; isProductTypeNeeded: boolean} payload
     * @returns {Observable<any>}
     * @memberof ExperimentApiService
     */
    public getIpcData(payload: { ipcList: Array<string>; isProductTypeNeeded: boolean }): Observable<IpcBasicAttributeInfo[]> {
        return this.appDataService.post(this.appDataService.url.getIPCData, [], payload);
    }
}
