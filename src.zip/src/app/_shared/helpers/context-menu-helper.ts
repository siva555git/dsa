/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable class-methods-use-this */
/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
/* eslint-disable lines-between-class-members */
import { Injectable } from "@angular/core";
import { filter, find, forEach, includes } from "lodash";
import { Subject } from "rxjs";
import { EXPERIMENT_ACCESS } from "../constants/experiment-access.constant";
import { GRID_DATA_SOURCE_CONSTANTS, SELECTED_ROW_LENGTH, SORT_ORDER } from "../../experiment-editor/constants/experiment-editor.constant";
import { AppStateService } from "../../_services/app-state/app.state.service";
import {
    ACCESS_DENIED_EXPERIMENT_MENU_LIST,
    BOM_TYPE,
    COLLABORATION_FOLDER_ID,
    EXPERIMENT_COPY_VALUES_FOR_FIELD,
    IS_LANDING_OR_EDITOR_PAGE,
    LOCKED_BY_STATUS,
    MAX_EXPORPRO_OPEN_LENGTH,
    USER_COLLABORATION_GROUP,
    WORKSPACE_DETAIL,
} from "../constants/common.constant";
import {
    COMBINE_SUB_OPTIONS,
    DISABLE_CONTEXT_MENU,
    DISABLE_FORMULA_CONTEXT_MENU,
    EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU,
    EXPERIMENT_SUB_OPTIONS,
    PRODUCT_SUB_OPTIONS,
    WORKSPACE_SUB_OPTIONS,
    EXPERIMENT_TYPE_CONTEXT_MENU,
    LINE_SUB_OPTIONS,
    MENU_LIST,
    MENU_LIST_FORMULA,
    OTHER_USER_EXP_MENU_CHANGE,
    PRODUCT,
    SUB_MENU_LIST,
    EXPERIMENT,
    CR_CSS,
    BOM_LINE_CSS,
    PRODUCT_ICON_HTML,
    LINEAGE_ICON_HTML,
    NOTES_ICON_HTML,
    NOTES_CSS,
    VARIANT_CSS,
    CR_REVIEW_ICON_HTML,
    CR_HISTORY_ICON_HTML,
    ADD_FAV_ICON_HTML,
    EXP_ACCESS_CSS,
    FROM_EXP_ICON_HTML,
    CREATE_OPTION_CSS,
    INSTRUCTION_ON_ICON_HTML,
    EDIT_EXPERIMENT_CSS,
    HIDE_INSTRUCTIONS_ICON_HTML,
    DEFAULT_MENU,
    INSTRUCTION_LIST,
    UNAPPROVED,
    INSTRUCTION_EDIT,
    CR_CAMPARISION_ICON_HTML,
    AUDIT_EYE_ICON,
    PLM_NUTRITION_CALULATOR_ICON_HTML,
    VIEW_MEMBERSHIP_ICON,
    ATTRIBUTE_ANALYSIS_ICON,
    BOM_REPLACE_CSS_CLASS,
    BOM_COMPARE_ICON,
} from "../constants/context-menu.constant";
import { SUBTypes } from "../enums";
import { ContextMenuDataHelper, ExperimentFormulaContextMenuModel, ExperimentsModel } from "../models/experiment-bom.model";
import { SelectedRowDataModel } from "../models/selected-row-data.model";
import { SecurityHelper } from "../security/helpers/security.helper";

import { AgGridUtil } from "./ag-grid-util";
import { ExperimentBomUtil } from "./experiment-bom.util";
import { TasteEditorUtilClass } from "./taste-editor-utils";
import { ExperimentAccessHelper } from "./experiment-access.helper";
import { WorkSpaceModel } from "../../experiment-editor/models/experiment-editor.model";
// eslint-disable-next-line import/named
import { ExperimentUtil } from "../../experiment-editor/helpers/experiment.util";
import { ContextMenuInterface } from "../../master-data/models/unapproved.model";
import { APPLICATION_PERMISSIONS } from "../security/security.constant";

@Injectable()
export class ContextMenuHelper {
    public editExperimentSub$ = new Subject<unknown>();
    public fillPartsSub$ = new Subject<unknown>();
    public scalePartsSub$ = new Subject<unknown>();
    public lockExperimentSub$ = new Subject<unknown>();
    public sortSub$ = new Subject<unknown>();
    public audit$ = new Subject<string>();
    public accessCooperator$ = new Subject<string>();
    public experimentAccess$ = new Subject<string>();
    public lockExpSub$ = new Subject<unknown>();
    public applyFactorSub$ = new Subject<unknown>();
    public insertSub$ = new Subject<unknown>();
    public quickinsertSub$ = new Subject<unknown>();
    public deletepermanentlySub$ = new Subject<unknown>();
    public experimentVariantSub$ = new Subject<unknown>();
    public deleteVariantSub$ = new Subject<unknown>();
    public fromExpSub$ = new Subject<unknown>();
    public editBomSub$ = new Subject<unknown>();
    public notesSub$ = new Subject<unknown>();
    public markAsPrivateSub$ = new Subject<unknown>();
    public reviewHistorySub$ = new Subject<unknown>();
    public detailedCostingSub$ = new Subject<unknown>();
    public explodeSubExperimentOrProductSub$ = new Subject<unknown>();
    public viewProductData$ = new Subject<unknown>();
    public viewProductDataProductSubMenu$ = new Subject<unknown>();
    public combineIntoNewExperimentSub$ = new Subject<unknown>();
    public markForDeleteOrUnDeleteSub$ = new Subject<string>();
    public hardDeleteSub$ = new Subject<string>();
    public createFolder$ = new Subject<unknown>();
    public deleteFolder$ = new Subject<unknown>();
    public editCollaborationGroupSub$ = new Subject<unknown>();
    public deleteCollaborationGroupSub$ = new Subject<unknown>();
    public resequenceSub$ = new Subject<string>();
    public lineageSub$ = new Subject<string>();
    public combineDuplicates$ = new Subject<string>();
    public copytoUserSub$ = new Subject<string>();
    public collaborationGroupSub$ = new Subject<string>();
    public sendToIFFmanSub$ = new Subject<string>();
    public openExpInWorkspace$ = new Subject<string>();
    public triggerOpenExpInWorkspaceDialog$ = new Subject<string>();
    public dropExperiment$ = new Subject<string>();
    public columnLayout$ = new Subject<string>();
    public userCollaborationGroup$ = new Subject<string>();
    public removeExpFromCollaborationGroup$ = new Subject<string>();
    public lineItemsEditHeader$ = new Subject<unknown>();
    public recostSub$ = new Subject<unknown>();
    public reviseExperimentSub$ = new Subject<unknown>();
    public toggleInstructionSub$ = new Subject<unknown>();
    public showHideMiniHeader$ = new Subject<string>();
    public showHideInstructions$ = new Subject<string>();
    public showHideDeletedItems$ = new Subject<string>();
    public showHideBomCompare$ = new Subject<string>();
    public viewMemberShip$ = new Subject<string>();
    private maxWSOpenExpLength = MAX_EXPORPRO_OPEN_LENGTH;
    public viewCollaborationGroupSub$ = new Subject<string>();
    public printSampleSheetSub$ = new Subject<string>();
    public attributeAnalysisSub$ = new Subject<string>();
    public addToFavorite$ = new Subject<string>();
    public updateInstructionSub$ = new Subject<string>();
    public copyRangeSubject$ = new Subject<string>();
    public deleteInstructionSub$ = new Subject<string>();
    public unapprovedEditSubject$ = new Subject<string>();
    public leaveCollaborationGroupSub$ = new Subject<string>();
    public copyFocusedCell$ = new Subject<string>();
    public plmNutritionCalculation$ = new Subject<string>();

    constructor(
        private readonly appState: AppStateService,
        public readonly securityHelper: SecurityHelper,
        public readonly experimentAccessHelper: ExperimentAccessHelper,
    ) {}

    public getContextMenuItems = () => {
        return [
            {
                name: MENU_LIST.EDIT_EXPERIMENT_BOM,
                action: () => this.callMenu(MENU_LIST.EDIT_EXPERIMENT_BOM),
                icon: '<span class="ag-context-icon icon-bom-edits"></span>',
                context: IS_LANDING_OR_EDITOR_PAGE.Landing,
            },
            {
                name: MENU_LIST.EDIT_MULTIPLE_EXPERIMENT_BOM,
                action: () => this.callMenu(MENU_LIST.EDIT_MULTIPLE_EXPERIMENT_BOM),
                icon: '<span class="ag-context-icon iconset-multiple-bom"></span>',
                context: IS_LANDING_OR_EDITOR_PAGE.Landing,
            },
            {
                name: MENU_LIST_FORMULA.OPEN_HEADER,
                action: () => this.callMenu(MENU_LIST_FORMULA.OPEN_HEADER),
                cssClasses: ["ag-edit-header ag-seperator"],
                icon: '<span class="ag-context-icon icon-edit-header"></span>',
            },
            {
                name: MENU_LIST_FORMULA.REVISE,
                action: () => this.callMenu(MENU_LIST_FORMULA.REVISE),
                cssClasses: ["ag-revise"],
                icon: '<span class="ag-context-icon icon-revise-check"></span>',
            },
            {
                name: MENU_LIST_FORMULA.DETAILED_COST,
                action: () => this.callMenu(MENU_LIST_FORMULA.DETAILED_COST),
                cssClasses: ["ag-revise"],
                icon: '<span class="ag-context-icon icon-Detailed-Costing"></span>',
            },
            {
                name: MENU_LIST.EXPERIMENT,
                icon: FROM_EXP_ICON_HTML,
                subMenu: [
                    {
                        name: EXPERIMENT_SUB_OPTIONS.AUDIT,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.AUDIT),
                        cssClasses: [AUDIT_EYE_ICON],
                        icon: '<span class="ag-context-icon icon-audit-eye-icon"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS),
                        cssClasses: [EXP_ACCESS_CSS],
                        icon: '<span class="ag-context-icon icon-experiment-access"></span>',
                        context: IS_LANDING_OR_EDITOR_PAGE.Landing,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS),
                        cssClasses: [AUDIT_EYE_ICON],
                        icon: ATTRIBUTE_ANALYSIS_ICON,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.ADD_TO_COLLABORATION_GROUP,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.ADD_TO_COLLABORATION_GROUP),
                        icon: '<span class="ag-context-icon icon-add-to-collobaration-group"></span>',
                        context: IS_LANDING_OR_EDITOR_PAGE.Landing,
                    },
                    {
                        name: MENU_LIST_FORMULA.REMOVE_EXPERIMENT,
                        action: () => this.callMenu(MENU_LIST_FORMULA.REMOVE_EXPERIMENT),
                        cssClasses: [EXP_ACCESS_CSS],
                        icon: '<span class="ag-context-icon icon-remove"></span>',
                        context: IS_LANDING_OR_EDITOR_PAGE.Landing,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.CREATIVE_REVIEW,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.CREATIVE_REVIEW),
                        icon: CR_REVIEW_ICON_HTML,
                    },
                    {
                        name: SUB_MENU_LIST.EXPERIMENT.REVIEW_COMPARISON,
                        action: () => this.callMenu(SUB_MENU_LIST.EXPERIMENT.REVIEW_COMPARISON),
                        icon: CR_CAMPARISION_ICON_HTML,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.REVIEW_HISTORY,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.REVIEW_HISTORY),
                        icon: CR_HISTORY_ICON_HTML,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.COOPERATORS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.COOPERATORS),
                        icon: '<span class="ag-context-icon icon-Cooperators"></span>',
                    },
                    {
                        name: SUB_MENU_LIST.EXPERIMENT.LINEAGE,
                        action: () => this.callMenu(SUB_MENU_LIST.EXPERIMENT.LINEAGE),
                        icon: LINEAGE_ICON_HTML,
                    },
                    {
                        name: SUB_MENU_LIST.EXPERIMENT.NOTES,
                        action: () => this.callMenu(SUB_MENU_LIST.EXPERIMENT.NOTES),
                        icon: '<span class="ag-context-icon icon-Notes"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR),
                        cssClasses: ["ag-plm"],
                        icon: PLM_NUTRITION_CALULATOR_ICON_HTML,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.VARIANTS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.VARIANTS),
                        icon: '<span class="ag-context-icon icon-Variant"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.VIEW_MEMBERSHIP,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.VIEW_MEMBERSHIP),
                        cssClasses: [VARIANT_CSS],
                        icon: VIEW_MEMBERSHIP_ICON,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.DELETE_VARINT,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.DELETE_VARINT),
                        cssClasses: [VARIANT_CSS],
                        icon: '<span class=" ag-context-icon icon-delete-variant"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.SEND_TO_IFFMAN,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.SEND_TO_IFFMAN),
                        cssClasses: [NOTES_CSS],
                        icon: NOTES_ICON_HTML,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.PRINT_SAMPLE_SHEET,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.PRINT_SAMPLE_SHEET),
                        cssClasses: [NOTES_CSS],
                        icon: '<span class="ag-context-icon iconset-lab-outline"></span>',
                    },
                ],
                context: IS_LANDING_OR_EDITOR_PAGE.Landing,
            },
            {
                name: MENU_LIST.CREATEEXPERIMENT,
                icon: '<span class="ag-context-icon icon-create-exp"></span>',
                subMenu: [
                    {
                        name: EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT,
                        action: () => this.callMenu(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT),
                        icon: FROM_EXP_ICON_HTML,
                    },
                    {
                        name: MENU_LIST.COPY_TO_USER,
                        action: () => this.callMenu(MENU_LIST.COPY_TO_USER),
                        icon: '<span class="ag-context-icon icon-copy-to-user"></span>',
                    },
                ],
                context: IS_LANDING_OR_EDITOR_PAGE.Landing,
            },
            {
                name: MENU_LIST.LOCK,
                action: () => this.callMenu(MENU_LIST.LOCK),
                cssClasses: ["ag-bom-lock ag-seperator"],
                icon: '<span class="ag-context-icon icon-bom-lock"></span>',
                context: IS_LANDING_OR_EDITOR_PAGE.Landing,
            },

            {
                name: MENU_LIST_FORMULA.LINE,
                cssClasses: [BOM_LINE_CSS],
                icon: '<span class="ag-context-icon icon-bom-line"></span>',
                subMenu: [
                    {
                        name: LINE_SUB_OPTIONS.ATTRIBUTE_ANALYSIS,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.ATTRIBUTE_ANALYSIS),
                        cssClasses: [NOTES_CSS],
                        icon: ATTRIBUTE_ANALYSIS_ICON,
                    },
                    {
                        name: LINE_SUB_OPTIONS.EDIT_HEADER,
                        action: () => this.lineItemsEditHeader$.next({ refreshType: LINE_SUB_OPTIONS.EDIT_HEADER, refreshData: undefined }),
                        cssClasses: [EDIT_EXPERIMENT_CSS],
                        icon: '<span class="ag-context-icon icon-edit-header"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.INSERT,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.INSERT),
                        cssClasses: ["ag-quick-search-inactive"],
                        icon: '<span class="ag-context-icon icon-insert_lines"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.SET_INSTRUCTION_OFF,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.SET_INSTRUCTION_OFF),
                        cssClasses: [EDIT_EXPERIMENT_CSS],
                        icon: '<span class="ag-context-icon icon-instruction-off"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.QUICK_INSERT,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.QUICK_INSERT),
                        cssClasses: ["ag-quick-search-inactive"],
                        icon: '<span class="ag-context-icon icon-quick-search-inactive"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.VIEW_PRODUCT_DATA,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.VIEW_PRODUCT_DATA),
                        cssClasses: ["ag-product-data"],
                        icon: PRODUCT_ICON_HTML,
                    },
                    {
                        name: LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE),
                        cssClasses: ["ag-experiment-delete"],
                        icon: '<span class="ag-context-icon icon-undelete"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.DELETE_ALL,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.DELETE_ALL),
                        cssClasses: [VARIANT_CSS],
                        icon: '<span class="ag-context-icon icon-delete-variant"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.COMBINE,
                        cssClasses: ["ag-bom-combine"],
                        icon: '<span class="ag-context-icon icon-bom-combine"></span>',
                        subMenu: [
                            {
                                name: COMBINE_SUB_OPTIONS.DUPLICATES,
                                action: () => this.callMenu(COMBINE_SUB_OPTIONS.DUPLICATES),
                                cssClasses: ["ag-BOM-ingredient"],
                                icon: '<span class="ag-context-icon icon-doc-multi-sel"></span>',
                            },
                            {
                                name: COMBINE_SUB_OPTIONS.INTO_NEW_EXPERIMENT,
                                action: () => this.callMenu(COMBINE_SUB_OPTIONS.INTO_NEW_EXPERIMENT),
                                cssClasses: ["ag-bom-From-Experiment"],
                                icon: '<span class="ag-context-icon icon-bom-From-Experiment"></span>',
                            },
                        ],
                    },
                    {
                        name: LINE_SUB_OPTIONS.EXPLODE,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.EXPLODE),
                        cssClasses: ["ag-icon-bom-explode"],
                        icon: '<span class="ag-context-icon icon-bom-explode"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.APPLY_FACTOR,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.APPLY_FACTOR),
                        cssClasses: ["ag-bom-apply-factor"],
                        icon: '<span class="ag-context-icon icon-bom-apply-factor"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.FILL_PARTS,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.FILL_PARTS),
                        cssClasses: ["ag-bom-fill-parts"],
                        icon: '<span class="ag-context-icon icon-bom-fill-parts"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.SORT,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.SORT),
                        cssClasses: [NOTES_CSS],
                        icon: NOTES_ICON_HTML,
                    },
                    {
                        name: LINE_SUB_OPTIONS.RESEQUENCE,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.RESEQUENCE),
                        cssClasses: ["ag-bom-resequence"],
                        icon: '<span class="ag-context-icon icon-bom-resequence"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.OPEN_IN_WORKSPACE,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.OPEN_IN_WORKSPACE),
                        cssClasses: [BOM_REPLACE_CSS_CLASS],
                        icon: '<span class="ag-context-icon icon-open-in-bom"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.OPEN_IN_NEW_WORKSPACE,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.OPEN_IN_NEW_WORKSPACE),
                        cssClasses: [BOM_REPLACE_CSS_CLASS],
                        icon: '<span class="ag-context-icon icon-tab-square"></span>',
                    },
                    {
                        name: LINE_SUB_OPTIONS.VIEW_MEMBERSHIP,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.VIEW_MEMBERSHIP),
                        cssClasses: [BOM_REPLACE_CSS_CLASS],
                        icon: VIEW_MEMBERSHIP_ICON,
                    },
                    {
                        name: LINE_SUB_OPTIONS.ADD_TO_FAVOURITES,
                        action: () => this.callMenu(LINE_SUB_OPTIONS.ADD_TO_FAVOURITES),
                        cssClasses: ["ag-add-to-fav"],
                        icon: ADD_FAV_ICON_HTML,
                    },
                ],
                context: IS_LANDING_OR_EDITOR_PAGE.Editor,
            },
            {
                name: MENU_LIST_FORMULA.EXPERIMENT,
                cssClasses: ["ag-From-Experiment ag-seperator"],
                icon: FROM_EXP_ICON_HTML,
                subMenu: [
                    {
                        name: EXPERIMENT_SUB_OPTIONS.AUDIT,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.AUDIT),
                        cssClasses: [AUDIT_EYE_ICON],
                        icon: '<span class="ag-context-icon icon-audit-eye-icon"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS),
                        cssClasses: [EXP_ACCESS_CSS],
                        icon: '<span class="ag-context-icon icon-experiment-access"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS),
                        cssClasses: [AUDIT_EYE_ICON],
                        icon: ATTRIBUTE_ANALYSIS_ICON,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.ADD_TO_COLLABORATION_GROUP,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.ADD_TO_COLLABORATION_GROUP),
                        icon: '<span class="ag-context-icon icon-add-to-collobaration-group"></span>',
                        context: IS_LANDING_OR_EDITOR_PAGE.Landing,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.CREATIVE_REVIEW,
                        action: () => this.callMenu(SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW),
                        cssClasses: [CR_CSS],
                        icon: CR_REVIEW_ICON_HTML,
                    },
                    {
                        name: SUB_MENU_LIST.EXPERIMENT.REVIEW_COMPARISON,
                        action: () => this.callMenu(SUB_MENU_LIST.EXPERIMENT.REVIEW_COMPARISON),
                        cssClasses: [CR_CSS],
                        icon: CR_CAMPARISION_ICON_HTML,
                    },
                    {
                        name: SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY,
                        action: () => this.callMenu(SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY),
                        cssClasses: [CR_CSS],
                        icon: CR_HISTORY_ICON_HTML,
                    },
                    {
                        name: SUB_MENU_LIST.EXPERIMENT.COOPERATORS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.COOPERATORS),
                        cssClasses: ["ag-Cooperators"],
                        icon: '<span class="ag-context-icon icon-Cooperators"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.LINEAGE,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.LINEAGE),
                        cssClasses: ["ag-lineage"],
                        icon: LINEAGE_ICON_HTML,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.SCALE_PARTS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.SCALE_PARTS),
                        cssClasses: ["ag-bom-scale-parts"],
                        icon: '<span class="ag-context-icon icon-bom-scale-parts"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.NOTES,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.NOTES),
                        cssClasses: [NOTES_CSS],
                        icon: NOTES_ICON_HTML,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR),
                        cssClasses: ["ag-plm"],
                        icon: PLM_NUTRITION_CALULATOR_ICON_HTML,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.VARIANTS,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.VARIANTS),
                        cssClasses: [VARIANT_CSS],
                        icon: '<span class="ag-context-icon icon-Variant"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.DELETE_VARINT,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.DELETE_VARINT),
                        cssClasses: [VARIANT_CSS],
                        icon: '<span class="ag-context-icon icon-delete-variant"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.SEND_TO_IFFMAN,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.SEND_TO_IFFMAN),
                        cssClasses: [NOTES_CSS],
                        icon: NOTES_ICON_HTML,
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.PRINT_SAMPLE_SHEET,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.PRINT_SAMPLE_SHEET),
                        cssClasses: [NOTES_CSS],
                        icon: '<span class="ag-context-icon iconset-lab-outline"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.RECOST,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.RECOST),
                        cssClasses: [NOTES_CSS],
                        icon: '<span class="ag-context-icon icon-recost"></span>',
                    },
                    {
                        name: EXPERIMENT_SUB_OPTIONS.VIEW_MEMBERSHIP,
                        action: () => this.callMenu(EXPERIMENT_SUB_OPTIONS.VIEW_MEMBERSHIP),
                        cssClasses: [BOM_REPLACE_CSS_CLASS],
                        icon: VIEW_MEMBERSHIP_ICON,
                    },
                ],
                context: IS_LANDING_OR_EDITOR_PAGE.Editor,
            },
            {
                name: MENU_LIST_FORMULA.PRODUCT,
                cssClasses: [BOM_LINE_CSS],
                icon: '<span class="ag-context-icon icon-new-product""></span>',
                subMenu: [
                    {
                        name: PRODUCT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS,
                        action: () => this.callMenu(PRODUCT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS),
                        cssClasses: [NOTES_CSS],
                        icon: ATTRIBUTE_ANALYSIS_ICON,
                    },
                    {
                        name: SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW,
                        action: () => this.callMenu(SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW),
                        cssClasses: [CR_CSS],
                        icon: CR_REVIEW_ICON_HTML,
                    },
                    {
                        name: SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY,
                        action: () => this.callMenu(SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY),
                        cssClasses: [CR_CSS],
                        icon: CR_HISTORY_ICON_HTML,
                    },
                    {
                        name: PRODUCT_SUB_OPTIONS.LINEAGE,
                        action: () => this.callMenu(PRODUCT_SUB_OPTIONS.LINEAGE),
                        cssClasses: ["ag-lineage"],
                        icon: LINEAGE_ICON_HTML,
                    },
                    {
                        name: PRODUCT_SUB_OPTIONS.VARIANT,
                        action: () => this.callDoubleOccurenceMenu(PRODUCT_SUB_OPTIONS.VARIANT),
                        cssClasses: ["ag-icon-product-data"],
                        icon: PRODUCT_ICON_HTML,
                    },
                    {
                        name: PRODUCT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR,
                        action: () => this.callMenu(PRODUCT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR),
                        cssClasses: ["ag-plm"],
                        icon: PLM_NUTRITION_CALULATOR_ICON_HTML,
                    },
                ],
                context: IS_LANDING_OR_EDITOR_PAGE.Editor,
            },
            {
                name: MENU_LIST_FORMULA.WORKSPACE,
                cssClasses: [BOM_LINE_CSS],
                icon: '<span class="ag-context-icon icon-open-in-bom"></span>',
                subMenu: [
                    {
                        name: WORKSPACE_SUB_OPTIONS.COLUMN_LAYOUT,
                        action: () => this.callMenu(WORKSPACE_SUB_OPTIONS.COLUMN_LAYOUT),
                        cssClasses: ["ag-item-column-line"],
                        icon: '<span class="ag-context-icon icon-item-column-line"></span>',
                    },
                    {
                        name: WORKSPACE_SUB_OPTIONS.OPEN_EXPERIMENT_OR_PRODUCT,
                        action: () => this.callMenu(WORKSPACE_SUB_OPTIONS.OPEN_EXPERIMENT_OR_PRODUCT),
                        cssClasses: ["ag-open-experiment"],
                        icon: '<span class="ag-context-icon icon-open-experiment"></span>',
                    },
                    {
                        name: WORKSPACE_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT,
                        action: () => this.callMenu(WORKSPACE_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT),
                        cssClasses: ["ag-highlight-off"],
                        icon: '<span class="ag-context-icon icon-highlight-off"></span>',
                    },
                    {
                        name: WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON,
                        action: () => this.callMenu(WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON),
                        cssClasses: [EDIT_EXPERIMENT_CSS],
                        icon: BOM_COMPARE_ICON[WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON],
                    },
                    {
                        name: WORKSPACE_SUB_OPTIONS.SHOW_INSTRUCTIONS,
                        // Drag - Drop - AG-GRID upgrade Issue
                        action: () => this.callMenu(WORKSPACE_SUB_OPTIONS.SHOW_INSTRUCTIONS),
                        cssClasses: ["ag-instructions-active"],
                        icon: '<span class="ag-context-icon icon-instructions-active"></span>',
                    },
                    {
                        name: WORKSPACE_SUB_OPTIONS.SHOW_MINI_HEADER,
                        action: () => this.callMenu(WORKSPACE_SUB_OPTIONS.SHOW_MINI_HEADER),
                        cssClasses: ["ag-icon-mini-header"],
                        icon: '<span class="ag-context-icon icon-mini-header"></span>',
                    },
                    {
                        name: WORKSPACE_SUB_OPTIONS.SHOW_DELETED_ITEMS,
                        // Drag - Drop - AG-GRID upgrade Issue
                        action: () => this.callMenu(WORKSPACE_SUB_OPTIONS.SHOW_DELETED_ITEMS),
                        cssClasses: ["ag-instructions-active"],
                        icon: '<span class="ag-context-icon icon-instructions-active"></span>',
                    },
                ],
                context: IS_LANDING_OR_EDITOR_PAGE.Editor,
            },
            {
                name: MENU_LIST_FORMULA.LOCK,
                action: () => this.callMenu(MENU_LIST_FORMULA.LOCK),
                cssClasses: ["ag-bom-lock ag-seperator"],
                icon: '<span class="ag-context-icon icon-bom-lock"></span>',
                context: IS_LANDING_OR_EDITOR_PAGE.Editor,
            },
            {
                name: DEFAULT_MENU.COPY.NAME,
                action: () => this.callMenu(DEFAULT_MENU.COPY.NAME),
                icon: '<span class="ag-context-icon iconset-content_copy_outline"></span>',
            },
        ];
    };

    /**
     * Method to enable context menu items based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @memberof ContextMenuHelper
     */
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    public getContextMenuInstruction = () => {
        return [
            {
                name: INSTRUCTION_LIST.EDIT,
                action: () => this.callMenu(INSTRUCTION_EDIT),
                cssClasses: ["ag-instruction-edit"],
                icon: '<span class="ag-context-icon icon-experiment-Edit-Folder"></span>',
            },
            {
                name: INSTRUCTION_LIST.DELETE,
                action: () => this.callMenu(INSTRUCTION_LIST.DELETE),
                cssClasses: ["ag-instruction-delete"],
                icon: '<span class="ag-context-icon icon-experiment-delete"></span>',
            },
        ];
    };

    public getContextMenuItemsFolder = () => {
        return [
            {
                name: MENU_LIST.CREATE_EXPERIMENT,
                cssClasses: [CREATE_OPTION_CSS],
            },
            {
                name: EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH,
                action: () => this.callMenu(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH),
                icon: '<span class="ag-context-icon icon-create-experiment-strie"></span>',
            },
            {
                name: EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT,
                action: () => this.callMenu(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT),
                icon: '<span class="ag-context-icon icon-create-experiemnt-form"></span>',
            },
            {
                name: EXPERIMENT_TYPE_CONTEXT_MENU.FROM_PRODUCT,
                action: () => this.callMenu(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_PRODUCT),
                icon: PRODUCT_ICON_HTML,
            },
            {
                name: MENU_LIST.CREATE_FOLDER,
                cssClasses: [CREATE_OPTION_CSS],
            },
            {
                name: EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_FOLDER,
                action: () => this.callMenu(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_FOLDER),
                icon: '<span class="ag-context-icon icon-create-experiment-create-folder"></span>',
            },
            {
                name: EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_FOLDER,
                action: () => this.callMenu(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_FOLDER),
                icon: '<span class="ag-context-icon icon-edit-folder"><span class="path1"></span><span class="path2"></span></span>',
            },
            {
                name: EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_FOLDER,
                action: () => this.callMenu(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_FOLDER),
                icon: '<span class="ag-context-icon icon-experiment-delete"></span>',
            },
            {
                name: MENU_LIST.COLLABORATION_GROUP,
                cssClasses: [CREATE_OPTION_CSS],
            },
            {
                name: MENU_LIST.NEW_COLLABORATION_GROUP,
                action: () => this.callMenu(MENU_LIST.NEW_COLLABORATION_GROUP),
                icon: '<span class="ag-context-icon iconset-new-collaboration"></span>',
            },
            {
                name: EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_COLLABORATION_GROUP,
                action: () => this.callMenu(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_COLLABORATION_GROUP),
                icon: '<span class="ag-context-icon iconset-new-collaboration"></span>',
            },
            {
                name: MENU_LIST.VIEW_COLLABORATION_GROUP,
                action: () => this.callMenu(MENU_LIST.VIEW_COLLABORATION_GROUP),
                icon: '<span class="ag-context-icon iconset-view-collaboration"></span>',
            },
            {
                name: EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_COLLABORATION_GROUP,
                action: () => this.callMenu(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_COLLABORATION_GROUP),
                icon: '<span class="ag-context-icon iconset-edit-collaboration"></span>',
            },
            {
                name: MENU_LIST.DELETE_COLLABORATION_GROUP,
                action: () => this.callMenu(MENU_LIST.DELETE_COLLABORATION_GROUP),
                icon: '<span class="ag-context-icon iconset-delete-collaboration"></span>',
            },
            {
                name: MENU_LIST.LEAVE_COLLABORATION_GROUP,
                action: () => this.callMenu(MENU_LIST.LEAVE_COLLABORATION_GROUP),
                icon: '<span class="ag-context-icon iconset-leave-collaboration"></span>',
            },
        ];
    };

    public callMenu(menuName: string): void {
        const contextMenuMap = {
            [EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH]: () => this.editExperimentSub$.next(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH),
            [MENU_LIST_FORMULA.OPEN_HEADER]: () => this.editExperimentSub$.next(MENU_LIST_FORMULA.OPEN_HEADER),
            [MENU_LIST_FORMULA.LOCK]: () => this.lockExpSub$.next(MENU_LIST_FORMULA.LOCK),
            [MENU_LIST.LOCK]: () => this.lockExpSub$.next(MENU_LIST.LOCK),
            [LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE]: () => this.markForDeleteOrUnDeleteSub$.next(LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE),
            [LINE_SUB_OPTIONS.DELETE_ALL]: () => this.hardDeleteSub$.next(LINE_SUB_OPTIONS.DELETE_ALL),
            [LINE_SUB_OPTIONS.FILL_PARTS]: () => this.fillPartsSub$.next(LINE_SUB_OPTIONS.FILL_PARTS),
            [EXPERIMENT_SUB_OPTIONS.SCALE_PARTS]: () => this.scalePartsSub$.next(EXPERIMENT_SUB_OPTIONS.SCALE_PARTS),
            [EXPERIMENT_SUB_OPTIONS.AUDIT]: () => this.audit$.next(EXPERIMENT_SUB_OPTIONS.AUDIT),
            [EXPERIMENT_SUB_OPTIONS.COOPERATORS]: () => this.accessCooperator$.next(EXPERIMENT_SUB_OPTIONS.COOPERATORS),
            [EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS]: () => this.accessCooperator$.next(EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS),
            [MENU_LIST.VIEW_EXPERIMENT]: () => this.editExperimentSub$.next(MENU_LIST.VIEW_EXPERIMENT),
            [LINE_SUB_OPTIONS.INSERT]: () => this.insertSub$.next(LINE_SUB_OPTIONS.INSERT),
            [LINE_SUB_OPTIONS.QUICK_INSERT]: () => this.quickinsertSub$.next(LINE_SUB_OPTIONS.QUICK_INSERT),
            [LINE_SUB_OPTIONS.APPLY_FACTOR]: () => this.applyFactorSub$.next(LINE_SUB_OPTIONS.APPLY_FACTOR),
            [LINE_SUB_OPTIONS.SORT]: () => this.sortSub$.next(LINE_SUB_OPTIONS.SORT),
            [EXPERIMENT_SUB_OPTIONS.VARIANTS]: () => this.experimentVariantSub$.next(EXPERIMENT_SUB_OPTIONS.VARIANTS),
            [EXPERIMENT_SUB_OPTIONS.DELETE_VARINT]: () => this.deleteVariantSub$.next(EXPERIMENT_SUB_OPTIONS.DELETE_VARINT),
            [EXPERIMENT_SUB_OPTIONS.RECOST]: () => this.recostSub$.next(EXPERIMENT_SUB_OPTIONS.RECOST),
            [EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT]: () => this.fromExpSub$.next(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT),
            [EXPERIMENT_TYPE_CONTEXT_MENU.FROM_PRODUCT]: () => this.fromExpSub$.next(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_PRODUCT),
            [MENU_LIST.COPY_TO_USER]: () => this.copytoUserSub$.next(MENU_LIST.COPY_TO_USER),
            [MENU_LIST.NEW_COLLABORATION_GROUP]: () => this.collaborationGroupSub$.next(MENU_LIST.NEW_COLLABORATION_GROUP),
            [MENU_LIST.EDIT_EXPERIMENT_BOM]: () => this.editBomSub$.next(MENU_LIST.EDIT_EXPERIMENT_BOM),
            [EXPERIMENT_SUB_OPTIONS.NOTES]: () => this.notesSub$.next(EXPERIMENT_SUB_OPTIONS.NOTES),
            [SUB_MENU_LIST.EXPERIMENT.NOTES]: () => this.notesSub$.next(SUB_MENU_LIST.EXPERIMENT.NOTES),
            [SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW]: () => this.reviewHistorySub$.next(SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW),
            [SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY]: () => this.reviewHistorySub$.next(SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY),
            [LINE_SUB_OPTIONS.EXPLODE]: () => this.explodeSubExperimentOrProductSub$.next(LINE_SUB_OPTIONS.EXPLODE),
            [LINE_SUB_OPTIONS.VIEW_PRODUCT_DATA]: () => this.viewProductData$.next(LINE_SUB_OPTIONS.VIEW_PRODUCT_DATA),
            [COMBINE_SUB_OPTIONS.INTO_NEW_EXPERIMENT]: () =>
                this.combineIntoNewExperimentSub$.next(COMBINE_SUB_OPTIONS.INTO_NEW_EXPERIMENT),
            [EXPERIMENT_SUB_OPTIONS.LINEAGE]: () => this.lineageSub$.next(EXPERIMENT_SUB_OPTIONS.LINEAGE),
            [PRODUCT_SUB_OPTIONS.LINEAGE]: () => this.lineageSub$.next(PRODUCT_SUB_OPTIONS.LINEAGE),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_FOLDER]: () => this.createFolder$.next(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_FOLDER),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_FOLDER]: () =>
                this.deleteFolder$.next(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_FOLDER),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_COLLABORATION_GROUP]: () =>
                this.deleteCollaborationGroupSub$.next(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_COLLABORATION_GROUP),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_COLLABORATION_GROUP]: () =>
                this.editCollaborationGroupSub$.next(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_COLLABORATION_GROUP),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_COLLABORATION_GROUP]: () =>
                this.collaborationGroupSub$.next(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_COLLABORATION_GROUP),
            [LINE_SUB_OPTIONS.RESEQUENCE]: () => this.resequenceSub$.next(LINE_SUB_OPTIONS.RESEQUENCE),
            [COMBINE_SUB_OPTIONS.DUPLICATES]: () => this.combineDuplicates$.next(COMBINE_SUB_OPTIONS.DUPLICATES),
            [EXPERIMENT_SUB_OPTIONS.SEND_TO_IFFMAN]: () => this.sendToIFFmanSub$.next(EXPERIMENT_SUB_OPTIONS.SEND_TO_IFFMAN),
            [WORKSPACE_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT]: () =>
                this.dropExperiment$.next(WORKSPACE_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT),
            [LINE_SUB_OPTIONS.OPEN_IN_NEW_WORKSPACE]: () => this.openExpInWorkspace$.next(LINE_SUB_OPTIONS.OPEN_IN_NEW_WORKSPACE),
            [LINE_SUB_OPTIONS.OPEN_IN_WORKSPACE]: () => this.openExpInWorkspace$.next(LINE_SUB_OPTIONS.OPEN_IN_WORKSPACE),
            [MENU_LIST_FORMULA.REMOVE_EXPERIMENT]: () => this.removeExpFromCollaborationGroup$.next(MENU_LIST_FORMULA.REMOVE_EXPERIMENT),
            [WORKSPACE_SUB_OPTIONS.OPEN_EXPERIMENT_OR_PRODUCT]: () =>
                this.triggerOpenExpInWorkspaceDialog$.next(WORKSPACE_SUB_OPTIONS.OPEN_EXPERIMENT_OR_PRODUCT),
            [WORKSPACE_SUB_OPTIONS.SHOW_INSTRUCTIONS]: () => this.showHideInstructions$.next(WORKSPACE_SUB_OPTIONS.SHOW_INSTRUCTIONS),
            [WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON]: () => this.showHideBomCompare$.next(WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON),
            [WORKSPACE_SUB_OPTIONS.SHOW_MINI_HEADER]: () => this.showHideMiniHeader$.next(WORKSPACE_SUB_OPTIONS.SHOW_MINI_HEADER),
            [WORKSPACE_SUB_OPTIONS.SHOW_DELETED_ITEMS]: () => this.showHideDeletedItems$.next(WORKSPACE_SUB_OPTIONS.SHOW_DELETED_ITEMS),
            [WORKSPACE_SUB_OPTIONS.COLUMN_LAYOUT]: () => this.columnLayout$.next(WORKSPACE_SUB_OPTIONS.COLUMN_LAYOUT),
            [EXPERIMENT_SUB_OPTIONS.ADD_TO_COLLABORATION_GROUP]: () =>
                this.userCollaborationGroup$.next(EXPERIMENT_SUB_OPTIONS.ADD_TO_COLLABORATION_GROUP),
            [MENU_LIST_FORMULA.REVISE]: () => this.reviseExperimentSub$.next(MENU_LIST_FORMULA.REVISE),
            [LINE_SUB_OPTIONS.SET_INSTRUCTION_OFF]: () => {
                this.toggleInstructionSub$.next(LINE_SUB_OPTIONS.SET_INSTRUCTION_OFF);
            },
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_FOLDER]: () =>
                this.createFolder$.next(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_FOLDER),
            [LINE_SUB_OPTIONS.VIEW_MEMBERSHIP]: () => this.viewMemberShip$.next(LINE_SUB_OPTIONS.VIEW_MEMBERSHIP),
            [EXPERIMENT_SUB_OPTIONS.VIEW_MEMBERSHIP]: () => this.viewMemberShip$.next(EXPERIMENT_SUB_OPTIONS.VIEW_MEMBERSHIP),
            [LINE_SUB_OPTIONS.SORT]: () => this.sortSub$.next(LINE_SUB_OPTIONS.SORT),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.VIEW_COLLABORATION_GROUP]: () =>
                this.viewCollaborationGroupSub$.next(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.VIEW_COLLABORATION_GROUP),
            [EXPERIMENT_SUB_OPTIONS.PRINT_SAMPLE_SHEET]: () => this.printSampleSheetSub$.next(EXPERIMENT_SUB_OPTIONS.PRINT_SAMPLE_SHEET),
            [EXPERIMENT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS]: () => this.attributeAnalysisSub$.next(MENU_LIST_FORMULA.EXPERIMENT),
            [PRODUCT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS]: () => this.attributeAnalysisSub$.next(MENU_LIST_FORMULA.PRODUCT),
            [LINE_SUB_OPTIONS.ATTRIBUTE_ANALYSIS]: () => this.attributeAnalysisSub$.next(MENU_LIST_FORMULA.LINE),
            [LINE_SUB_OPTIONS.ADD_TO_FAVOURITES]: () => this.addToFavorite$.next(LINE_SUB_OPTIONS.ADD_TO_FAVOURITES),
            [INSTRUCTION_EDIT]: () => this.updateInstructionSub$.next(INSTRUCTION_EDIT),
            [DEFAULT_MENU.COPY.NAME]: () => this.copyRangeSubject$.next(DEFAULT_MENU.COPY.NAME),
            [INSTRUCTION_LIST.DELETE]: () => this.deleteInstructionSub$.next(INSTRUCTION_LIST.DELETE),
            [UNAPPROVED.EDIT]: () => this.unapprovedEditSubject$.next(UNAPPROVED.EDIT),
            [SUB_MENU_LIST.EXPERIMENT.REVIEW_COMPARISON]: () => this.reviewHistorySub$.next(SUB_MENU_LIST.EXPERIMENT.REVIEW_COMPARISON),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.LEAVE_COLLABORATION_GROUP]: () =>
                this.leaveCollaborationGroupSub$.next(EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.LEAVE_COLLABORATION_GROUP),
            [MENU_LIST.EDIT_MULTIPLE_EXPERIMENT_BOM]: () => this.editBomSub$.next(MENU_LIST.EDIT_MULTIPLE_EXPERIMENT_BOM),
            [EXPERIMENT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR]: () => this.plmNutritionCalculation$.next(MENU_LIST_FORMULA.EXPERIMENT),
            [PRODUCT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR]: () => this.plmNutritionCalculation$.next(MENU_LIST_FORMULA.PRODUCT),
            [MENU_LIST_FORMULA.DETAILED_COST]: () => this.detailedCostingSub$.next(MENU_LIST_FORMULA.DETAILED_COST),
        };
        if (contextMenuMap[menuName]) {
            contextMenuMap[menuName]();
        }
    }

    /**
     * Method to disable menus
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @memberof ContextMenuHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public contextMenuDisable(_contextMenuDataHelper: ContextMenuDataHelper): any {
        const { menu } = _contextMenuDataHelper;
        forEach(menu, (menuElement) => {
            const element = menuElement;
            if (this.disableContextMenus(element.name, _contextMenuDataHelper)) {
                element.disabled = true;
            } else {
                if (element.subMenu) {
                    this.disableContextSubmenu(element.subMenu, _contextMenuDataHelper, element.name);
                }
                element.disabled = false;
            }
        });
        return menu;
    }

    /**
     * Method to disable sub menus
     * @param {any} subMenu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {void}
     * @memberof ContextMenuHelper
     */
    public disableContextSubmenu(
        subMenu: ExperimentFormulaContextMenuModel[],
        _contextMenuDataHelper: ContextMenuDataHelper,
        mainMenu: string,
    ): void {
        forEach(subMenu, (sub) => {
            const element = sub;
            if (mainMenu === MENU_LIST_FORMULA.PRODUCT && sub.name === PRODUCT_SUB_OPTIONS.LINEAGE) {
                element.disabled = false;
            } else if (this.disableContextMenus(sub.name, _contextMenuDataHelper)) {
                element.disabled = true;
            } else if (sub.subMenu) {
                this.disableContextSubmenu(sub.subMenu, _contextMenuDataHelper, sub.name);
            }
        });
    }

    /**
     * Method to enable/disable context menu items based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @memberof ContextMenuHelper
     */
    public disableContextMenus(menuName: string, _contextMenuDataHelper: ContextMenuDataHelper): boolean {
        const { activeExperiment, selectedExperiments, userTabInfo } = _contextMenuDataHelper;
        const disabedMenusMap = {
            [MENU_LIST_FORMULA.OPEN_HEADER]: () => this.disableOpenHeader(_contextMenuDataHelper),
            [MENU_LIST_FORMULA.LOCK]: () =>
                this.disableLockHeader(_contextMenuDataHelper) || this.disableOpenHeader(_contextMenuDataHelper),
            [MENU_LIST.LOCK]: () => this.disableLockHeader(_contextMenuDataHelper) || this.disableOpenHeader(_contextMenuDataHelper),
            [MENU_LIST_FORMULA.LINE]: () => this.disableLineHeader(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.SCALE_PARTS]: () => this.disableScalePartsMenu(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE]: () => this.disableToggleDelete(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.DELETE_ALL]: () => this.disableDeleteAllMenu(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.FILL_PARTS]: () => this.disableFillPartsMenu(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.COOPERATORS]: () => this.disableCooperatorFromEditBom(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.VARIANTS]: () => this.disableVariant(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.EXPERIMENT_ACCESS]: () => this.disableExperimentAccessEditBom(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.DELETE_VARINT]: () => this.disableDeleteVariant(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.APPLY_FACTOR]: () => this.disableApplyFactor(_contextMenuDataHelper),
            [EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT]: () => this.disableFromExperiment(_contextMenuDataHelper),
            [MENU_LIST.EDIT_EXPERIMENT_BOM]: () => this.disableEditBom(_contextMenuDataHelper),
            [OTHER_USER_EXP_MENU_CHANGE.VIEW_BOM]: () => this.disableEditBom(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.NOTES]: () => this.disableNotes(_contextMenuDataHelper, APPLICATION_PERMISSIONS.EXPERIMENT_NOTES),
            [SUB_MENU_LIST.EXPERIMENT.NOTES]: () => this.disableNotes(_contextMenuDataHelper, APPLICATION_PERMISSIONS.EXPERIMENT_NOTES),
            [LINE_SUB_OPTIONS.EXPLODE]: () => this.disableExplode(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.VIEW_PRODUCT_DATA]: () => this.disableViewProductData(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.COMBINE]: () => this.disableCombine(_contextMenuDataHelper),
            [COMBINE_SUB_OPTIONS.INTO_NEW_EXPERIMENT]: () => this.disableCombineExp(_contextMenuDataHelper),
            [SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW]: () => this.disableCreateReview(_contextMenuDataHelper, menuName),
            [EXPERIMENT_SUB_OPTIONS.LINEAGE]: () => this.disableLineage(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.RESEQUENCE]: () => this.disableResequence(_contextMenuDataHelper),
            [MENU_LIST.COPY_TO_USER]: () => this.disableCopyToUser(_contextMenuDataHelper),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_FOLDER]: () => ContextMenuHelper.disableEditOrDeleteFolder(_contextMenuDataHelper),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_FOLDER]: () => ContextMenuHelper.disableEditOrDeleteFolder(_contextMenuDataHelper),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_FOLDER]: () =>
                ContextMenuHelper.disableCreateFolderAndCreateCollaborationGroup(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.SEND_TO_IFFMAN]: () => this.disableSendToIffman(_contextMenuDataHelper),
            [EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.NEW_COLLABORATION_GROUP]: () =>
                ContextMenuHelper.disableCreateFolderAndCreateCollaborationGroup(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.OPEN_IN_NEW_WORKSPACE]: () => this.disableOpenInNewWorkspace(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.OPEN_IN_WORKSPACE]: () => this.disableOpenInWorkspace(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT]: () =>
                this.disableNotes(_contextMenuDataHelper, APPLICATION_PERMISSIONS.CLOSE_PRODUCT_EXPERIMENTS),
            [MENU_LIST.ADD_TO_COLLABORATION_GROUP]: () => this.disableCollaborationGroup(_contextMenuDataHelper),
            [MENU_LIST_FORMULA.REMOVE_EXPERIMENT]: () => this.disableRemoveExpFromCollaborationGroup(_contextMenuDataHelper),
            [MENU_LIST.EDIT_COLLABORATION_GROUP]: () => this.disableCollaborationGroupContextMenuIfNotOwnedByUser(_contextMenuDataHelper),
            [MENU_LIST.DELETE_COLLABORATION_GROUP]: () => this.disableCollaborationGroupContextMenuIfNotOwnedByUser(_contextMenuDataHelper),
            [MENU_LIST_FORMULA.REVISE]: () => this.disableReviseExperiment(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.SET_INSTRUCTION_ON]: () => this.disableSetInstructionMenu(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.SET_INSTRUCTION_OFF]: () => this.disableSetInstructionMenu(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.ADD_TO_COLLABORATION_GROUP]: () => this.disableCollaborationGroup(_contextMenuDataHelper),
            [MENU_LIST_FORMULA.PRODUCT]: () => this.disableProductMenu(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.AUDIT]: () => this.disableAuditMenu(_contextMenuDataHelper),
            [MENU_LIST_FORMULA.EXPERIMENT]: () => this.disableExperimentMenu(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.QUICK_INSERT]: () => this.disableQuickInsertAndInsert(activeExperiment),
            [LINE_SUB_OPTIONS.INSERT]: () => this.disableQuickInsertAndInsert(activeExperiment),
            [COMBINE_SUB_OPTIONS.DUPLICATES]: () => this.disableCombineDuplicates(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.REVIEW_HISTORY]: () => this.disableCreateReview(_contextMenuDataHelper, menuName),
            [LINE_SUB_OPTIONS.EDIT_HEADER]: () => this.disableLineOpenHeader(_contextMenuDataHelper),
            [WORKSPACE_SUB_OPTIONS.OPEN_EXPERIMENT_OR_PRODUCT]: () => this.isOpenedExpExceeds(userTabInfo),
            [WORKSPACE_SUB_OPTIONS.DROP_EXPERIMENT_OR_PRODUCT]: () => this.isExperimentActive(activeExperiment),
            [WORKSPACE_SUB_OPTIONS.SHOW_MINI_HEADER]: () => this.isExperimentActive(activeExperiment),
            [WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON]: () => this.disableBomCompareMenu(activeExperiment, userTabInfo),
            [WORKSPACE_SUB_OPTIONS.HIDE_BOM_COMPARISON]: () => this.disableBomCompareMenu(activeExperiment, userTabInfo),
            [LINE_SUB_OPTIONS.VIEW_MEMBERSHIP]: () => this.disableViewMemberShip(_contextMenuDataHelper, MENU_LIST_FORMULA.LINE),
            [EXPERIMENT_SUB_OPTIONS.VIEW_MEMBERSHIP]: () =>
                this.disableViewMemberShip(_contextMenuDataHelper, MENU_LIST_FORMULA.EXPERIMENT),
            [WORKSPACE_SUB_OPTIONS.SHOW_MINI_HEADER]: () => this.disableMiniHeader(activeExperiment),
            [MENU_LIST.CREATEEXPERIMENT]: () => this.disableCreate(_contextMenuDataHelper),
            [LINE_SUB_OPTIONS.SORT]: () => this.disableSortMenu(_contextMenuDataHelper),
            [PRODUCT_SUB_OPTIONS.VARIANT]: () => ContextMenuHelper.disableVariantMenu(_contextMenuDataHelper),
            [MENU_LIST.LEAVE_COLLABORATION_GROUP]: () => !this.disableCollaborationGroupContextMenuIfNotOwnedByUser(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.PRINT_SAMPLE_SHEET]: () => this.disablePrintScreen(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS]: () =>
                this.disableAttributeAnalysis(_contextMenuDataHelper, MENU_LIST_FORMULA.EXPERIMENT),
            [PRODUCT_SUB_OPTIONS.ATTRIBUTE_ANALYSIS]: () =>
                this.disableAttributeAnalysis(_contextMenuDataHelper, MENU_LIST_FORMULA.PRODUCT),
            [LINE_SUB_OPTIONS.ATTRIBUTE_ANALYSIS]: () => this.disableAttributeAnalysis(_contextMenuDataHelper, MENU_LIST_FORMULA.LINE),
            [LINE_SUB_OPTIONS.ADD_TO_FAVOURITES]: () => this.disableAddToFavorites(_contextMenuDataHelper),
            [DEFAULT_MENU.COPY.NAME]: () => this.disableCopyMenu(_contextMenuDataHelper),
            [SUB_MENU_LIST.EXPERIMENT.REVIEW_COMPARISON]: () => this.disableBomAndBosReviewComparison(_contextMenuDataHelper),
            [MENU_LIST.EDIT_MULTIPLE_EXPERIMENT_BOM]: () => this.disableEditMultipleBom(_contextMenuDataHelper),
            [EXPERIMENT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR]: () => this.disablePLMNutritionCalc(_contextMenuDataHelper),
            [PRODUCT_SUB_OPTIONS.PLM_NUTRITION_CALCULATOR]: () => this.disablePLMNutritionCalc(_contextMenuDataHelper),
            // newly added disable functionality for access permission
            [MENU_LIST_FORMULA.WORKSPACE]: () => !this.checkAccessPermission(APPLICATION_PERMISSIONS.WORKSPACE_MENU),
            [EXPERIMENT_SUB_OPTIONS.RECOST]: () => !this.checkAccessPermission(APPLICATION_PERMISSIONS.RECOST),
            [WORKSPACE_SUB_OPTIONS.COLUMN_LAYOUT]: () => !this.checkAccessPermission(APPLICATION_PERMISSIONS.BOM_COLUMN_LAYOUT),
            [WORKSPACE_SUB_OPTIONS.HIDE_INSTRUCTIONS]: () => !this.checkAccessPermission(APPLICATION_PERMISSIONS.VIEW_INSTRUCTION),
            [WORKSPACE_SUB_OPTIONS.SHOW_DELETED_ITEMS]: () => !this.checkAccessPermission(APPLICATION_PERMISSIONS.VIEW_DELETED_BOM_ITEMS),
            [PRODUCT_SUB_OPTIONS.LINEAGE]: () => !this.checkAccessPermission(APPLICATION_PERMISSIONS.TASTEDITOR_LINEAGE),
            [MENU_LIST_FORMULA.DETAILED_COST]: () => this.disableDetailedCost(_contextMenuDataHelper),
        };

        const isDisabled = disabedMenusMap[menuName]
            ? disabedMenusMap[menuName]()
            : ContextMenuHelper.disableOtherMenu(menuName, selectedExperiments);

        return isDisabled;
    }

    /**
     * Method to diable variant menu based on condition
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static disableVariantMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        const { activeExperiment, userTabInfo } = _contextMenuDataHelper;
        if (activeExperiment?.Type === PRODUCT) {
            const data = ExperimentUtil.findExperiment(
                ExperimentUtil.getExperimentsInTab(userTabInfo[WORKSPACE_DETAIL]),
                activeExperiment.ExpCode,
            );
            if (data[0]?.productvariant?.length > 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * Method to enable/disable Create Review
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableCreateReview(_contextMenuDataHelper: ContextMenuDataHelper, menuName: string): boolean {
        const reviewPermission =
            menuName === SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW
                ? APPLICATION_PERMISSIONS.CREATIVE_REVIEW
                : APPLICATION_PERMISSIONS.REVIEW_HISTORY;
        if (this.checkAccessPermission(reviewPermission)) {
            const userDetails = this.appState.getCurrentUser();
            const { activeExperiment, selectedExperiments } = _contextMenuDataHelper;
            if (!activeExperiment && !selectedExperiments) {
                return true;
            }
            if (!activeExperiment && selectedExperiments?.length > 0) {
                const isDisabled = this.getMenuDisableInfo(
                    selectedExperiments,
                    Number(userDetails.sapempid),
                    EXPERIMENT_ACCESS.VIEW_CREATIVE_REVIEW,
                );
                return isDisabled;
            }
            return false;
        }
        return true;
    }

    /**
     * Method to diable collabration group menu based on condition
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableCollaborationGroup(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.ADD_TO_COLLABORATION)) {
            const userDetails = this.appState.getCurrentUser();
            const { selectedExperiments, activeExperiment } = _contextMenuDataHelper;
            if (selectedExperiments?.length > 0 || activeExperiment) {
                const expList = activeExperiment ? [activeExperiment] : selectedExperiments;
                const isDisabled = this.getMenuDisableInfo(
                    expList,
                    Number(userDetails.sapempid),
                    EXPERIMENT_ACCESS.ADD_TO_COLLABORATION_GROUP,
                );
                if (!isDisabled && activeExperiment && activeExperiment?.Type !== EXPERIMENT) {
                    return true;
                }
                return isDisabled;
            }
            return true;
        }
        return true;
    }

    /**
     * Method to disable product Menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableProductMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.PRODUCT_MENU)) {
            const { activeExperiment } = _contextMenuDataHelper;
            return !(activeExperiment?.Type === PRODUCT);
        }
        return true;
    }

    /**
     * Method to enable/disable Edit Folder and Delete Folder context menus
     *
     * @static
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public static disableEditOrDeleteFolder(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        const { selectedRow } = _contextMenuDataHelper;
        const isDisabled = selectedRow ? !selectedRow.ParentFolderID : false;
        return isDisabled;
    }

    /**
     * Method to enable/disable Create New Folder option
     *
     * @static
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public static disableCreateFolderAndCreateCollaborationGroup(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        const { selectedRow } = _contextMenuDataHelper;
        const isDisabled = TasteEditorUtilClass.isDefaultFolder(selectedRow?.FolderName);
        return isDisabled;
    }

    /**
     * Method to enable/disable drop experiment or product
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableNotes(_contextMenuDataHelper: ContextMenuDataHelper, accessPermission: string): boolean {
        if (this.checkAccessPermission(accessPermission)) {
            const { activeExperiment, selectedExperiments } = _contextMenuDataHelper;
            const userDetails = this.appState.getCurrentUser();
            if (!activeExperiment && (selectedExperiments?.length === 0 || selectedExperiments?.length > 1)) {
                return true;
            }
            const functionName =
                (activeExperiment && activeExperiment.CreatedBy === Number(userDetails.sapempid)) ||
                (selectedExperiments && selectedExperiments[0]?.CreatedBy === Number(userDetails.sapempid))
                    ? EXPERIMENT_ACCESS.ADD_NOTE
                    : EXPERIMENT_ACCESS.VIEW_NOTE;
            return this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, functionName);
        }
        return true;
    }

    /**
     * Method to enable/disable edit bom
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableEditBom(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.OPEN_BOM)) {
            const userDetails = this.appState.getCurrentUser();
            const { selectedExperiments } = _contextMenuDataHelper;
            if (selectedExperiments?.length === 0 || selectedExperiments?.length > 1) {
                return true;
            }
            return this.getMenuDisableInfo(
                selectedExperiments,
                Number(userDetails.sapempid),
                EXPERIMENT_ACCESS.OPEN_EXPERIMEMT_IN_WORKSPACE,
            );
        }
        return true;
    }

    /**
     * Method to enable/disable from experiment
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableFromExperiment(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.CREATE_FROM_EXPERIMENT)) {
            const { selectedExperiments } = _contextMenuDataHelper;
            const userDetails = this.appState.getCurrentUser();
            if (selectedExperiments && !ContextMenuHelper.isManyRowsSelected(selectedExperiments)) {
                const accessFunction =
                    selectedExperiments[0].CreatedBy === Number(userDetails.sapempid)
                        ? EXPERIMENT_ACCESS.CREATE_EXP_FROM_EXP_NEW_VERSION
                        : EXPERIMENT_ACCESS.CREATE_EXP_FROM_EXP_NO_NEW_VERSION;
                return this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, accessFunction);
            }
            return true;
        }
        return true;
    }

    /**
     * Method to enable/disable Line item open header
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @memberof ContextMenuHelper
     */
    public disableLineOpenHeader(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPERIMENT_HEADER)) {
            const { selectedRow, bomDetails } = _contextMenuDataHelper;
            const userDetails = this.appState.getCurrentUser();
            if (
                !ContextMenuHelper.isManyRowsSelected(selectedRow) &&
                ContextMenuHelper.doAllRowsdHaveSameBomType(selectedRow, SUBTypes.EXPERIMENT)
            ) {
                const selectedExp = find(bomDetails.Experiments, (expData) => expData.ExpCode === selectedRow[0]?.ipc);
                return this.getMenuDisableInfo([selectedExp], Number(userDetails.sapempid), EXPERIMENT_ACCESS.VIEW_HEADER);
            }
            return true;
        }
        return true;
    }

    /**
     * Method to enable/disable context edit header based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableOpenHeader(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPERIMENT_HEADER)) {
            const { activeExperiment, selectedExperiments } = _contextMenuDataHelper;
            const userDetails = this.appState.getCurrentUser();
            if (
                (!activeExperiment && (selectedExperiments?.length === 0 || selectedExperiments?.length > 1)) ||
                (activeExperiment && ContextMenuHelper.isProduct(activeExperiment))
            ) {
                return true;
            }
            const functionName =
                (activeExperiment &&
                    activeExperiment.CreatedBy === Number(userDetails.sapempid) &&
                    activeExperiment.IsLocked !== LOCKED_BY_STATUS.LOCKED) ||
                (selectedExperiments &&
                    selectedExperiments[0]?.CreatedBy === Number(userDetails.sapempid) &&
                    selectedExperiments[0].IsLocked !== LOCKED_BY_STATUS.LOCKED)
                    ? EXPERIMENT_ACCESS.EDIT_HEADER
                    : EXPERIMENT_ACCESS.VIEW_HEADER;
            return this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, functionName);
        }
        return true;
    }

    /**
      Method to enable/disable context menu delete all based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableDeleteAllMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.BOM_DELETE_PERMANENTLY)) {
            const { bomDetails, activeExperiment } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.DELETE_ALL);
            const bomItems = ExperimentBomUtil.findMarkForDeleteBomItems(bomDetails, activeExperiment);
            if (!isDisabled && bomItems?.length <= 0) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable Copy To User
     *
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disableCopyToUser(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.COPY_EXPERIMENT_TO_USER)) {
            const { selectedExperiments } = _contextMenuDataHelper;
            const isMenuDisabled = selectedExperiments ? selectedExperiments.length !== 1 : true;
            if (!isMenuDisabled) {
                const userDetails = this.appState.getCurrentUser();
                const isDisabled = this.getMenuDisableInfo(
                    selectedExperiments,
                    Number(userDetails.sapempid),
                    EXPERIMENT_ACCESS.COPY_TO_USER,
                );
                return isDisabled;
            }
            return isMenuDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable context lock based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disableLockHeader(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPERIMENT_LOCK)) {
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.LOCK);
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to check whether natural order is applied or not
     *
     * @static
     * @param {ExperimentsModel} activeExperiment
     * @return {*} {boolean}
     * @memberof ContextMenuHelper
     */
    public static checkForNaturalOrderSort(activeExperiment: ExperimentsModel): boolean {
        if (
            ContextMenuHelper.isOtherExp(activeExperiment) ||
            ContextMenuHelper.isExpLocked(activeExperiment) ||
            ContextMenuHelper.isProduct(activeExperiment)
        ) {
            return !!activeExperiment.IsAppliedNaturalOrder;
        }
        return false;
    }

    /**
     * Method to enable/disable context line based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disableLineHeader(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.LINE_MENU)) {
            const { selectedRow, activeExperiment } = _contextMenuDataHelper;
            return !!(
                !activeExperiment ||
                (activeExperiment && selectedRow.length === 0 && ContextMenuHelper.checkForNaturalOrderSort(activeExperiment))
            );
        }
        return true;
    }

    /**
     * Method to enable/disable sort based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {boolean}
     * @memberof ContextMenuHelper
     */
    public disableSortMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.SORTBY_NATURAL_ORDER)) {
            const { activeExperiment, rowData } = _contextMenuDataHelper;
            return !!(!activeExperiment || rowData.length < 0 || activeExperiment.IsAppliedNaturalOrder);
        }
        return true;
    }

    /**
     * Method to enable/disable add to favorite menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {boolean}
     * @memberof ContextMenuHelper
     */
    public disableAddToFavorites(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.ADD_INSTRUCTION_TO_FAVORITES)) {
            const { selectedRow } = _contextMenuDataHelper;
            const isDisabled =
                ContextMenuHelper.isManyRowsSelected(selectedRow) ||
                (selectedRow?.length === 1 && selectedRow[0].SUBType !== BOM_TYPE.INSTRUCTION);
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable context scale parts based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {boolean}
     * @memberof ContextMenuHelper
     */
    public disableScalePartsMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.SCALE_PARTS)) {
            const { activeExperiment } = _contextMenuDataHelper;
            return !!(
                !activeExperiment ||
                ContextMenuHelper.isProduct(activeExperiment) ||
                ContextMenuHelper.isExpLocked(activeExperiment) ||
                ContextMenuHelper.isOtherExp(activeExperiment)
            );
        }
        return true;
    }

    /**
     * Method to disable/enable detailed costing
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableDetailedCost(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        let isDisabledbyAccess = true;
        const { activeExperiment } = _contextMenuDataHelper;
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.DETAILED_COSTING)) {
            if (activeExperiment && activeExperiment?.Type === PRODUCT) return false;
            isDisabledbyAccess = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.VIEW_COST);
        }
        return isDisabledbyAccess;
    }

    /**
     * Method to disable line item edit header based on condition
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static disableLineEditHeader(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        const { selectedRow, isOtherExp } = _contextMenuDataHelper;
        const isDisabled =
            selectedRow.length > SELECTED_ROW_LENGTH ||
            selectedRow[0]?.SUBType === BOM_TYPE.INSTRUCTION ||
            selectedRow[0]?.SUBType === BOM_TYPE.UNAPPROVED ||
            (isOtherExp && selectedRow.length > SELECTED_ROW_LENGTH);
        return isDisabled;
    }

    /**
     * Method to enable/disable context delete menu based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    // eslint-disable-next-line consistent-return
    public disableToggleDelete(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.BOM_DELETE_UNDELETE)) {
            const { selectedRow, activeExperiment } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.DELETE_LINE);
            const selectedValue = ContextMenuHelper.filterSelectedRow(selectedRow, activeExperiment);
            if (
                !isDisabled &&
                (ContextMenuHelper.doAllRowsdHaveSameBomType(selectedRow, BOM_TYPE.INSTRUCTION) ||
                    selectedValue.length === 0 ||
                    selectedValue === undefined)
            ) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable context Fill parts based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableFillPartsMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.FILL_PARTS)) {
            const { selectedRow } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.FILL_PARTS);
            const isBomDeleted = ContextMenuHelper.areRowsMarkedForDelete(_contextMenuDataHelper, LINE_SUB_OPTIONS.FILL_PARTS);
            if (!isDisabled && (isBomDeleted || selectedRow.length > 1 || selectedRow[0]?.SUBType === BOM_TYPE.INSTRUCTION)) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable context Fill parts based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableApplyFactor(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.APPLY_FACTOR)) {
            const { selectedRow } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.APPLY_FACTOR);
            if (
                !isDisabled &&
                (ContextMenuHelper.doAllRowsdHaveSameBomType(selectedRow, BOM_TYPE.INSTRUCTION) ||
                    ContextMenuHelper.areRowsMarkedForDelete(_contextMenuDataHelper))
            ) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable menu based on BOM Type
     *
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disableExplode(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPLODE_EXPERIMENT)) {
            const { selectedRow, activeExperiment, bomDetails } = _contextMenuDataHelper;
            const userDetails = this.appState.getCurrentUser();
            if (
                !ContextMenuHelper.isOtherExp(activeExperiment) &&
                !ContextMenuHelper.isManyRowsSelected(selectedRow) &&
                ContextMenuHelper.doSelectedRowsHaveActiveExpParts(selectedRow, activeExperiment) &&
                ContextMenuHelper.doRowsSelectedHavProductOrExpBomType(selectedRow) &&
                !ContextMenuHelper.areRowsMarkedForDelete(_contextMenuDataHelper) &&
                !ContextMenuHelper.checkProductIsBom(selectedRow)
            ) {
                const selectedExp = find(bomDetails.Experiments, (expData) => expData.ExpCode === selectedRow[0]?.ipc);
                const isDisable =
                    selectedRow[0].SUBType === BOM_TYPE.EXPERIMENT
                        ? this.getMenuDisableInfo(
                              [selectedExp],
                              Number(userDetails.sapempid),
                              EXPERIMENT_ACCESS.EXPLODE_INTERMEDIATE_EXPERIMENT,
                          )
                        : false;
                return isDisable;
            }
            return true;
        }
        return true;
    }

    /**
     * Method to enable/disable menu based on sub Type
     *
     * @static
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disableViewProductData(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.PRODUCT_DATA)) {
            const { selectedRow } = _contextMenuDataHelper;
            return !!(
                ContextMenuHelper.isManyRowsSelected(selectedRow) ||
                (selectedRow && selectedRow.length === 1 && selectedRow[0].SUBType !== SUBTypes.PRODUCT)
            );
        }
        return true;
    }

    /**
     * Method to disable Combine Experiment menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disableCombineExp(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        const { selectedRow, activeExperiment } = _contextMenuDataHelper;
        const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.COMBINE_INTO_NEW_EXPERIMENT);
        if (
            (!isDisabled && selectedRow.length === 0) ||
            ContextMenuHelper.doSelectedRowsHaveInactiveExpParts(selectedRow, activeExperiment)
        ) {
            return true;
        }
        return isDisabled;
    }

    /**
     * Method to check other user Experiment
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static isOtherExp = (activeExperiment: ExperimentsModel): boolean => {
        const isConditionSatisfied = !activeExperiment || activeExperiment?.IsOtherExp || ContextMenuHelper.isExpLocked(activeExperiment);
        return isConditionSatisfied;
    };

    /**
     * Method to check combine line sub menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableCombine = (_contextMenuDataHelper: ContextMenuDataHelper): boolean => {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.COMBINE_EXPERIMENT)) {
            const { activeExperiment } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.COMBINE_DUPLICATES);
            return !!(isDisabled && (ContextMenuHelper.isProduct(activeExperiment) || ContextMenuHelper.isOtherExp(activeExperiment)));
        }
        return true;
    };

    /**
     * Method to check Row selection
     * @param {any} selectedRows
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static isManyRowsSelected = (selectedRows: Array<any>): boolean => {
        const isConditionSatisfied = selectedRows?.length > 1 || selectedRows?.length === 0;
        return isConditionSatisfied;
    };

    /**
     * Method to disable menu for view membership
     * @param {Array<any>} selectedRows
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableViewMemberShip = (_contextMenuDataHelper: ContextMenuDataHelper, type: string): boolean => {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.VIEW_MEMBERSHIP)) {
            const { activeExperiment, selectedRow, selectedExperiments } = _contextMenuDataHelper;
            if (type === MENU_LIST_FORMULA.EXPERIMENT) {
                return !!(!activeExperiment && (selectedExperiments?.length === 0 || selectedExperiments?.length > 1));
            }
            if (type === MENU_LIST_FORMULA.LINE && selectedRow?.length === 1) {
                return selectedRow?.length > 1 || selectedRow?.length === 0 || selectedRow[0].SUBType !== BOM_TYPE.EXPERIMENT;
            }
        }
        return true;
    };

    /**
     * Method to check Active Experiment parts in selected Experiment
     * @param {any} selectedRows
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static doSelectedRowsHaveActiveExpParts = (selectedRows, activeExperiment: ExperimentsModel): boolean => {
        const selectedValue = find(selectedRows, (data) => {
            return data[activeExperiment.ExpCode] !== undefined;
        });
        const isConditionSatisfied = selectedValue !== undefined;
        return isConditionSatisfied;
    };

    /**
     * Method to check whether selected experiment is product
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static isProduct = (activeExperiment: ExperimentsModel): boolean => {
        const isConditionSatisfied = activeExperiment?.Type === PRODUCT;
        return isConditionSatisfied;
    };

    /** Method to disable menu if inactive BOMs are selected
     * @static
     * @param selectedRows
     * @param {ExperimentsModel} activeExperiment
     * @return {boolean}
     * @memberof ContextMenuHelper
     */
    public static doSelectedRowsHaveInactiveExpParts = (selectedRows, activeExperiment: ExperimentsModel): boolean => {
        const selectedValue = find(selectedRows, (data) => {
            return data[activeExperiment?.ExpCode] === undefined;
        });
        const isConditionSatisfied = selectedValue !== undefined;
        return isConditionSatisfied;
    };

    /** Method to check whether experiment is locked
     * @static
     * @param {ExperimentsModel} activeExperiment
     * @return {boolean}
     * @memberof ContextMenuHelper
     */
    public static isExpLocked = (activeExperiment: ExperimentsModel): boolean => {
        return activeExperiment?.IsLocked === LOCKED_BY_STATUS.LOCKED;
    };

    /**
     * Method to check whether selected experiment is active
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public isExperimentActive = (activeExperiment: ExperimentsModel): boolean => {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.CLOSE_PRODUCT_EXPERIMENTS)) {
            return !activeExperiment;
        }
        return true;
    };

    /**
     * Method to check whether opened experiments in workspace length is equal to max experiments can be opened
     * @param {WorkSpaceModel} userTabDetails
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public isOpenedExpExceeds = (userTabDetails: WorkSpaceModel): boolean => {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.OPEN_PRODUCT)) {
            if (userTabDetails) {
                return userTabDetails.WorkSpaceDetail.length >= MAX_EXPORPRO_OPEN_LENGTH;
            }
            return true;
        }
        return true;
    };

    /**
     * Method to check whether selected rows are product or experiment
     * @param selectedRows
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static doRowsSelectedHavProductOrExpBomType = (selectedRows): boolean => {
        const isConditionSatisfied = selectedRows.every(
            (data) => data.SUBType === BOM_TYPE.EXPERIMENT || data.SUBType === BOM_TYPE.PRODUCT,
        );
        return isConditionSatisfied;
    };

    /**
     * * Method to check whether selected rows are same as of argument bomtype
     * @param selectedRows
     * @param bomType
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static doAllRowsdHaveSameBomType = (selectedRows: Array<any>, bomType: string): boolean => {
        const isConditionSatisfied = selectedRows.every((data) => data.SUBType === bomType);
        return isConditionSatisfied;
    };

    /**
     * Method to check whether ingredient have isbom true or false
     * @param selectedRows
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static checkProductIsBom = (selectedRows): boolean => {
        return selectedRows.length === 1 && selectedRows[0].SUBType === BOM_TYPE.PRODUCT && !selectedRows[0].isBom;
    };

    /**
     * Method to check mark for deleted rows
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @param {string} type
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static areRowsMarkedForDelete = (_contextMenuDataHelper: ContextMenuDataHelper, type?: string): boolean => {
        const { selectedRow, activeExperiment, bomDetails } = _contextMenuDataHelper;
        const isConditionSatisfied = selectedRow.every((data) =>
            data[activeExperiment?.ExpCode] === undefined &&
            type !== MENU_LIST_FORMULA.LINE &&
            type !== LINE_SUB_OPTIONS.FILL_PARTS &&
            type !== EXPERIMENT_SUB_OPTIONS.SCALE_PARTS
                ? true
                : ExperimentBomUtil.getBomDetailsByExpFormulaID(
                      data[`${activeExperiment?.ExpCode}_ExpFormulaID`],
                      activeExperiment?.ExpCode,
                      bomDetails,
                  )?.IsDelete === 1,
        );
        return isConditionSatisfied;
    };

    /**
     * Method to enable/disable cooperators if experiment is shared
     * @param {SelectedRowDataModel[]} selectedExperiments
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static areSelectedExperimentsOwnedByUser(selectedExperiments: SelectedRowDataModel[]): boolean {
        return selectedExperiments.every((experiment) => experiment.SharedFrom === undefined);
    }

    /**
     * Method to enable/disable cooperators menu based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableCooperatorFromEditBom(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.COOPERATORS)) {
            const { activeExperiment } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.VIEW_COOPERATOR);
            if (!isDisabled && ContextMenuHelper.isProduct(activeExperiment)) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable cooperators menu based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableVariant(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPERIMENT_VARIANTS)) {
            const { activeExperiment } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.ADD_VARIANT);
            if (!isDisabled && ContextMenuHelper.isProduct(activeExperiment)) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable Experiment access menu based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableExperimentAccessEditBom(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPERIMENT_ACCESS)) {
            const { activeExperiment } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.ADD_TO_ACCESS_LIST);
            if (!isDisabled && ContextMenuHelper.isProduct(activeExperiment)) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable unused menu based on conditions
     * @param {string} menuName
     * @param {SelectedRowDataModel[]} selectedExperiments
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static disableOtherMenu(menuName: string, selectedExperiments?: SelectedRowDataModel[]): boolean {
        const isDisabled =
            (selectedExperiments?.length === 0 && includes(DISABLE_FORMULA_CONTEXT_MENU, menuName)) ||
            (selectedExperiments && includes(DISABLE_CONTEXT_MENU, menuName));
        return isDisabled;
    }

    /**
     * Method to disable delete variant menu based on condition
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableDeleteVariant(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.DELETE_VARIANT)) {
            const { activeExperiment, selectedExperiments } = _contextMenuDataHelper;
            if (activeExperiment?.ExperimentVariant || (selectedExperiments?.length === 1 && selectedExperiments[0].ExperimentVariant)) {
                return this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.DELETE_VARIANT);
            }
            return true;
        }
        return true;
    }

    /**
     * Method to disable send to iffman menu based on condition
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableSendToIffman(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.RESEND_FORMULA_TO_IFFMAN)) {
            const { activeExperiment, selectedExperiments } = _contextMenuDataHelper;
            const currentUser = this.appState.getCurrentUser();
            return !(
                (activeExperiment &&
                    !ContextMenuHelper.isProduct(activeExperiment) &&
                    ContextMenuHelper.isExpLocked(activeExperiment) &&
                    !activeExperiment.IsOtherExp) ||
                (selectedExperiments?.length === 1 &&
                    selectedExperiments[0].IsLocked === LOCKED_BY_STATUS.LOCKED &&
                    selectedExperiments[0].CreatedBy === Number(currentUser.sapempid))
            );
        }
        return true;
    }

    /**
     * Method to filter selected row
     * @param selectedRow
     * @param {ExperimentsModel} activeExperiment
     * @memberof ContextMenuHelper
     */
    public static filterSelectedRow(selectedRow, activeExperiment: ExperimentsModel): any {
        const filteredRow = filter(selectedRow, (data) => {
            return data[activeExperiment?.ExpCode] !== undefined;
        });
        return filteredRow;
    }

    /**
     * Method to enable/disable lineage from experiment list page
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableLineage(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.TASTEDITOR_LINEAGE)) {
            return this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.VIEW_LINEAGE);
        }
        return true;
    }

    /**
     * Method to enable/disable resequence menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableResequence(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.RESEQUENCE)) {
            const { activeExperiment, rowData, sortState } = _contextMenuDataHelper;
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.RESEQUENCE);
            const selectedValue = ContextMenuHelper.filterSelectedRow(rowData, activeExperiment);
            if (!isDisabled && (selectedValue?.length === 0 || sortState === SORT_ORDER.ORGINAL)) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to enable/disable open in open in workspace menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableOpenInWorkspace(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.OPEN_IN_WORKSPACE)) {
            const { activeExperiment, bomDetails, selectedRow } = _contextMenuDataHelper;
            const openedExperiments = ExperimentBomUtil.getTopLevelExperiments(bomDetails);
            const expCodeLists = [
                ...openedExperiments.map((element) => element.ExpCode),
                ...ExperimentBomUtil.getSelectedRowExpCodeList(selectedRow),
            ];
            const totalExpCount = Number(openedExperiments?.length) + Number(selectedRow?.length);
            return !!(
                !activeExperiment ||
                !ContextMenuHelper.checkSelectedRowHasProdOrExp(selectedRow) ||
                openedExperiments?.length === MAX_EXPORPRO_OPEN_LENGTH ||
                totalExpCount > MAX_EXPORPRO_OPEN_LENGTH ||
                ContextMenuHelper.hasDuplicateExperiments(expCodeLists)
            );
        }
        return true;
    }

    /**
     * Method to enable/disable open in open new workspace menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableOpenInNewWorkspace(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.OPEN_IN_NEW_WORKSPACE)) {
            const { selectedRow } = _contextMenuDataHelper;
            const expCodeLists = ExperimentBomUtil.getSelectedRowExpCodeList(selectedRow);
            return !!(
                !ContextMenuHelper.checkSelectedRowHasProdOrExp(selectedRow) ||
                selectedRow?.length > MAX_EXPORPRO_OPEN_LENGTH ||
                ContextMenuHelper.hasDuplicateExperiments(expCodeLists)
            );
        }
        return true;
    }

    /**
     * Method to find duplicate experiment exist in workspace
     * @param {Array<string>} expCodeLists
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static hasDuplicateExperiments(expCodeLists: Array<string>): boolean {
        return new Set(expCodeLists).size !== expCodeLists.length;
    }

    /**
     * Method to filter the grid data which is not deleted and not an instruction
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @memberof ContextMenuHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static toValidateGridData(_contextMenuDataHelper: ContextMenuDataHelper): any {
        const { activeExperiment, bomDetails, rowData } = _contextMenuDataHelper;
        let response = [];
        if (activeExperiment && bomDetails && rowData) {
            const expFormulaIDKey = AgGridUtil.getTreeGridKeys(activeExperiment?.ExpCode, GRID_DATA_SOURCE_CONSTANTS.EXP_FORMULA_ID_KEY);
            response = filter(rowData, (selectedRecord) => {
                const isValidRecord =
                    ExperimentBomUtil.getBomDetailsByExpFormulaID(selectedRecord[expFormulaIDKey], activeExperiment?.ExpCode, bomDetails)
                        ?.IsDelete !== 1 && selectedRecord.SUBType !== SUBTypes.INSTRUCTION;
                return isValidRecord;
            });
        }
        return response;
    }

    /**
     * Method to disable remove experiment menu from context menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableRemoveExpFromCollaborationGroup(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.REMOVE_EXPERIMENT)) {
            const userDetails = this.appState.getCurrentUser();
            const { selectedExperiments, collaborationGroupList, selectedFolderID } = _contextMenuDataHelper;
            const isDisabled = this.getMenuDisableInfo(
                selectedExperiments,
                Number(userDetails.sapempid),
                EXPERIMENT_ACCESS.REMOVE_FROM_COLLABORATION_GROUP,
            );
            return !(
                selectedFolderID === COLLABORATION_FOLDER_ID &&
                selectedExperiments.length > 0 &&
                (!isDisabled ||
                    (collaborationGroupList?.UserCollaborationGroupMapped &&
                        Number(collaborationGroupList?.UserCollaborationGroupMapped[0]?.IsOwnedGroup) ===
                            USER_COLLABORATION_GROUP.IS_OWNED_GROUP))
            );
        }
        return true;
    }

    /**
     * Method to disable collaboration group's experiment list context menu
     *
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @memberof ContextMenuHelper
     */
    public collaborationGroupContextMenuDisable = (_contextMenuDataHelper: ContextMenuDataHelper): unknown => {
        const userDetails = this.appState.getCurrentUser();
        const { menu, collaborationGroupList, selectedExperiments } = _contextMenuDataHelper;
        const otherUserExperiments = selectedExperiments.filter((experiment) => experiment.CreatedBy !== Number(userDetails.sapempid));
        forEach(menu, (menuDetail) => {
            const data = menuDetail;
            data.disabled =
                data.name === MENU_LIST_FORMULA.REMOVE_EXPERIMENT &&
                (otherUserExperiments.length === 0 ||
                    Number(collaborationGroupList.UserCollaborationGroupMapped[0].IsOwnedGroup) === USER_COLLABORATION_GROUP.IS_OWNED_GROUP)
                    ? false
                    : !ACCESS_DENIED_EXPERIMENT_MENU_LIST.includes(data.name);
            if (data.subMenu) {
                this.collaborationGroupContextSubMenuDisable(data.subMenu);
            }
        });
        return menu;
    };

    /**
     * Method to check the validation for edit and delete collaboration menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @memberof ContextMenuHelper
     * @returns {boolean}
     */
    public disableCollaborationGroupContextMenuIfNotOwnedByUser(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        const collaborationList = _contextMenuDataHelper;
        const userDetails = this.appState.getCurrentUser();
        return collaborationList?.collaborationGroupList?.CreatedByUser?.UserID !== Number(userDetails?.sapempid);
    }

    /**
     * Method to disable context sub menu on selecting experiment with no access
     * @param {ExperimentFormulaContextMenuModel[]} subMenu
     * @memberof ContextMenuHelper
     */
    public collaborationGroupContextSubMenuDisable = (subMenu: ExperimentFormulaContextMenuModel[]): void => {
        forEach(subMenu, (menu) => {
            const menuData = menu;
            menuData.disabled = !ACCESS_DENIED_EXPERIMENT_MENU_LIST.includes(menu.name);
        });
    };

    /**
     * Method to disable revise experiment
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableReviseExperiment(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPERIMENT_REVISE)) {
            let isDisabled = true;
            const userDetails = this.appState.getCurrentUser();
            const { activeExperiment, selectedExperiments, userTabInfo } = _contextMenuDataHelper;
            if (activeExperiment && activeExperiment?.Type === PRODUCT && userTabInfo?.WorkSpaceDetail.length < MAX_EXPORPRO_OPEN_LENGTH) {
                return false;
            }
            const expDetail = activeExperiment ?? selectedExperiments[0];
            if (expDetail) {
                const accessFunctionName =
                    expDetail.CreatedBy === Number(userDetails.sapempid)
                        ? EXPERIMENT_ACCESS.REVISE_EXPERIMENT
                        : EXPERIMENT_ACCESS.CREATE_EXP_FROM_EXP_NO_NEW_VERSION;
                isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, accessFunctionName);
                if (
                    !isDisabled &&
                    !selectedExperiments &&
                    activeExperiment &&
                    (userTabInfo?.WorkSpaceDetail.length >= MAX_EXPORPRO_OPEN_LENGTH || activeExperiment.IPC !== null)
                ) {
                    return true;
                }
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to disable all context menu options
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @memberof ContextMenuHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public disableAllContextMenu(_contextMenuDataHelper: ContextMenuDataHelper): any {
        const { menu } = _contextMenuDataHelper;
        forEach(menu, (menuElement) => {
            const menuData = menuElement;
            if (menuData.name === MENU_LIST_FORMULA.WORKSPACE) {
                this.disableContextSubmenu(menuData.subMenu, _contextMenuDataHelper, menuData.name);
            }
            menuData.disabled = menuData.name !== MENU_LIST_FORMULA.WORKSPACE;
        });
        return menu;
    }

    /**
     * Method to check whether selected rows are product or experiment
     * @param selectedRows
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public static checkSelectedRowHasProdOrExp = (selectedRows): boolean => {
        const isConditionSatisfied = selectedRows.some((data) => data.SUBType === BOM_TYPE.EXPERIMENT || data.SUBType === BOM_TYPE.PRODUCT);
        return isConditionSatisfied;
    };

    /**
     * Method to modify line items set instructions on/ set instructions off option
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {ContextMenuDataHelper}
     *
     * @memberof ContextMenuHelper
     */
    public static modifyEditorContextMenu(
        _contextMenuDataHelper: ContextMenuDataHelper,
        shouldModifyLineInstructionMenu = false,
    ): ContextMenuDataHelper {
        const { menu, shouldHideInstructions, shouldHideMiniHeader, isHideDeletedItems, selectedRow, canShowBomCompare } =
            _contextMenuDataHelper;

        this.toggleBomCompareMenu(menu, canShowBomCompare);

        if (!isHideDeletedItems) {
            const workSpaceMenu = menu
                .find((menuElement) => menuElement.name === MENU_LIST_FORMULA.WORKSPACE)
                .subMenu.find((menuDetail) => menuDetail.name === WORKSPACE_SUB_OPTIONS.SHOW_DELETED_ITEMS);
            workSpaceMenu.name = WORKSPACE_SUB_OPTIONS.HIDE_DELETED_ITEMS;
        }
        if (shouldModifyLineInstructionMenu && selectedRow && selectedRow.length > 0) {
            const workSpaceMenu = menu
                .find((menuElement) => menuElement.name === MENU_LIST_FORMULA.LINE)
                .subMenu.find((menuDetail) => menuDetail.name === LINE_SUB_OPTIONS.SET_INSTRUCTION_OFF);
            workSpaceMenu.name = LINE_SUB_OPTIONS.SET_INSTRUCTION_ON;
            workSpaceMenu.icon = INSTRUCTION_ON_ICON_HTML;
        }

        menu.find((menuElement) => menuElement.name === MENU_LIST_FORMULA.WORKSPACE).subMenu.forEach((menuDetail) => {
            if (menuDetail.name !== WORKSPACE_SUB_OPTIONS.SHOW_INSTRUCTIONS && menuDetail.name !== WORKSPACE_SUB_OPTIONS.SHOW_MINI_HEADER) {
                return;
            }
            if (menuDetail.name === WORKSPACE_SUB_OPTIONS.SHOW_INSTRUCTIONS && !shouldHideInstructions) {
                const contextMenu = menuDetail;
                contextMenu.name = WORKSPACE_SUB_OPTIONS.HIDE_INSTRUCTIONS;
                contextMenu.icon = HIDE_INSTRUCTIONS_ICON_HTML;
            } else if (menuDetail.name === WORKSPACE_SUB_OPTIONS.SHOW_MINI_HEADER && shouldHideMiniHeader) {
                const contextMenu = menuDetail;
                contextMenu.name = WORKSPACE_SUB_OPTIONS.HIDE_MINI_HEADER;
            }
        });
        return _contextMenuDataHelper;
    }

    /**
     * Method to update the icon and name forbom compare
     *
     * @private
     * @static
     * @param {*} menu
     * @param {*} canShowBomCompare
     * @memberof ContextMenuHelper
     */
    private static toggleBomCompareMenu(menu, canShowBomCompare: boolean): void {
        // Modify the workspace item for the show/hide bom compare
        const workspaceMenu = menu
            .find((menuElement) => menuElement.name === MENU_LIST_FORMULA.WORKSPACE)
            .subMenu.find(
                (menuDetail) =>
                    menuDetail.name === WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON ||
                    menuDetail.name === WORKSPACE_SUB_OPTIONS.HIDE_BOM_COMPARISON,
            );
        if (workspaceMenu?.name) {
            if (canShowBomCompare === false) {
                workspaceMenu.name = WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON;
                workspaceMenu.icon = BOM_COMPARE_ICON[WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON];
            } else {
                workspaceMenu.name = WORKSPACE_SUB_OPTIONS.HIDE_BOM_COMPARISON;
                workspaceMenu.icon = BOM_COMPARE_ICON[WORKSPACE_SUB_OPTIONS.HIDE_BOM_COMPARISON];
            }
        }
    }

    /**
     * Method to enable/disable in set instructions on/set instructions off
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     *
     * @memberof ContextMenuHelper
     */
    public disableSetInstructionMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.VIEW_INSTRUCTION)) {
            const { selectedRow, activeExperiment } = _contextMenuDataHelper;
            if (selectedRow?.length === 0) {
                return true;
            }
            return !!(
                !ContextMenuHelper.doAllRowsdHaveSameBomType(selectedRow, BOM_TYPE.INSTRUCTION) ||
                ContextMenuHelper.isExpLocked(activeExperiment) ||
                ContextMenuHelper.isOtherExp(activeExperiment) ||
                (selectedRow.length > 1 &&
                    ContextMenuHelper.getActiveInactiveInstructions(selectedRow, activeExperiment) &&
                    ContextMenuHelper.getBlankInstruction(selectedRow, activeExperiment))
            );
        }
        return true;
    }

    /**
     * Method to disable or not show/hide bom compare
     *
     * @param {ExperimentsModel} activeExperiment
     * @param {WorkSpaceModel} userTabInfo
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disableBomCompareMenu(activeExperiment: ExperimentsModel, userTabInfo: WorkSpaceModel): boolean {
        return userTabInfo?.WorkSpaceDetail?.length === 1 || !activeExperiment;
    }

    /**
     * Method to disable audit menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableAuditMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPERIMENT_AUDIT)) {
            return this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.VIEW_AUDIT);
        }
        return true;
    }

    /**
     * Method to disable Experiemnt menu
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableExperimentMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.EXPERIMENT_MENU)) {
            const { activeExperiment, selectedExperiments } = _contextMenuDataHelper;
            return !(activeExperiment?.Type === EXPERIMENT || selectedExperiments?.length > 0);
        }
        return true;
    }

    /**
     * Method called when a same menu exists with two different functionality
     * @param {string} menuName
     * @memberof ContextMenuHelper
     */
    public callDoubleOccurenceMenu(menuName: string): void {
        if (menuName === PRODUCT_SUB_OPTIONS.VARIANT) {
            this.viewProductDataProductSubMenu$.next(EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH);
        }
    }

    /**
     * Method to disable quick insert and insert menu in edit bom screen
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableQuickInsertAndInsert(activeExperiment: ExperimentsModel): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.QUICK_BOM_INSERT)) {
            const userDetails = this.appState.getCurrentUser();
            const isDisabled = this.getMenuDisableInfo(
                [activeExperiment],
                Number(userDetails.sapempid),
                EXPERIMENT_ACCESS.INSERT_EXPERIMENT,
            );
            if (!isDisabled && activeExperiment.Type === PRODUCT) {
                return true;
            }
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to disable combine duplicates
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableCombineDuplicates(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        return this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.COMBINE_DUPLICATES);
    }

    /**
     * Method to disable menu based on function
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @param {string} functionName
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public singleExperimentBasedMenuDisable(_contextMenuDataHelper: ContextMenuDataHelper, functionName: string): boolean {
        const userDetails = this.appState.getCurrentUser();
        const { selectedExperiments, activeExperiment } = _contextMenuDataHelper;
        const expList = activeExperiment ? [activeExperiment] : selectedExperiments;
        if (expList?.length === 1) {
            const isDisabled = this.getMenuDisableInfo(expList, Number(userDetails.sapempid), functionName);
            return isDisabled;
        }
        return true;
    }

    /**
     * Method to get experiment access info
     * @param expList
     * @param {number} userID
     * @param {string} functionName
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public getMenuDisableInfo(expList, userID: number, functionName: string): boolean {
        const accessResponse = this.experimentAccessHelper.getExperimentAccessCheck(expList, userID, functionName);
        return !accessResponse?.isPermitted;
    }

    /**
     * Method to check instruction IsDelete
     * @param {ContextMenuDataHelper} contextMenuHelper
     * @returns {boolean}
     */
    public static checkInstructionIsDelete(contextMenuHelper: ContextMenuDataHelper): boolean {
        return contextMenuHelper?.selectedRow?.length &&
            this.getExpFormulaID(contextMenuHelper.selectedRow, contextMenuHelper.activeExperiment)
            ? this.areRowsMarkedForDelete(contextMenuHelper)
            : true;
    }

    /**
     * Method to check instruction is active/inactive or blank for that experiment
     * @param {any} selectedRows
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
    public static getExpFormulaID(selectedRows: any, activeExperiment: ExperimentsModel): boolean {
        return selectedRows.every((selectedRow) => selectedRow[ExperimentBomUtil.getFormulaIdKey(activeExperiment?.ExpCode)]);
    }

    /**
     * Method to find blank instruction from selected record
     * @param {any} selectedRows
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
    public static getBlankInstruction(selectedRows: any, activeExperiment: ExperimentsModel): any {
        return find(selectedRows, (selectedRow) => !selectedRow[ExperimentBomUtil.getFormulaIdKey(activeExperiment?.ExpCode)]);
    }

    /**
     * Method to find active/inactive instruction from selected record
     * @param {any} selectedRows
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
    public static getActiveInactiveInstructions(selectedRows: any, activeExperiment: ExperimentsModel): any {
        return find(selectedRows, (selectedRow) => selectedRow[ExperimentBomUtil.getFormulaIdKey(activeExperiment?.ExpCode)]);
    }

    /**
     * Method to diable create
     * @param {ContextMenuDataHelper} contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableCreate(contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.CREATE_EXPERIMENTS)) {
            const { selectedExperiments } = contextMenuDataHelper;
            return (
                selectedExperiments?.length !== 1 ||
                (this.disableFromExperiment(contextMenuDataHelper) && this.disableCopyToUser(contextMenuDataHelper))
            );
        }
        return true;
    }

    /**
     * Method to diable mini header
     * @param {ExperimentsModel} activeExperiment
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableMiniHeader(activeExperiment: ExperimentsModel): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.MINI_HEADER)) {
            return !activeExperiment || activeExperiment.Type === PRODUCT;
        }
        return true;
    }

    /**
     * Method to disable copy menu based on column selected
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     */
    public disableCopyMenu(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.TASTEEDITOR_COPY_TEXT)) {
            const { columnId } = _contextMenuDataHelper;
            const fields = EXPERIMENT_COPY_VALUES_FOR_FIELD.map((field) => field.toLowerCase());
            return columnId ? !fields.includes(columnId.toLowerCase()) : true;
        }
        return true;
    }

    /**
     * Method to enable/disable context lock based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disablePrintScreen(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        const { selectedExperiments, activeExperiment } = _contextMenuDataHelper;
        const expList = activeExperiment ? [activeExperiment] : selectedExperiments;
        const isLocked = !!(expList[0]?.IsLocked === LOCKED_BY_STATUS.LOCKED || (expList[0]?.IsLocked as any) === +LOCKED_BY_STATUS.LOCKED);
        if (isLocked && this.checkAccessPermission(APPLICATION_PERMISSIONS.MAKE_SAMPLE)) {
            const isDisabled = this.singleExperimentBasedMenuDisable(_contextMenuDataHelper, EXPERIMENT_ACCESS.PRINT_SCREEN);
            // eslint-disable-next-line unicorn/explicit-length-check
            return !!(isDisabled && (selectedExperiments ? selectedExperiments.length >= 1 : true));
        }
        return true;
    }

    /**
     * Method to enable/disable context lock based on conditions
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @return {*}  {boolean}
     * @memberof ContextMenuHelper
     */
    public disableAttributeAnalysis(_contextMenuDataHelper: ContextMenuDataHelper, type: string): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.ATTRIBUTE_ANALYSIS)) {
            const { activeExperiment, selectedRow, selectedExperiments } = _contextMenuDataHelper;
            if (type === MENU_LIST_FORMULA.PRODUCT && activeExperiment && ContextMenuHelper.isProduct(activeExperiment)) {
                return false;
            }
            if (type === MENU_LIST_FORMULA.EXPERIMENT) {
                return !!(!activeExperiment && (selectedExperiments?.length === 0 || selectedExperiments?.length > 1));
            }
            if (type === MENU_LIST_FORMULA.LINE && selectedRow?.length === 1) {
                return !(selectedRow[0].SUBType === BOM_TYPE.PRODUCT || selectedRow[0].SUBType === BOM_TYPE.EXPERIMENT);
            }
            return true;
        }
        return true;
    }

    /**
     * Method to get the list of icon with label for context menu
     *
     * @return {*}  {ContextMenuInterface[]}
     * @memberof ContextMenuHelper
     */
    public getUnapprovedContextMenuItems(): ContextMenuInterface[] {
        return [
            {
                name: UNAPPROVED.EDIT,
                action: () => this.callMenu(UNAPPROVED.EDIT),
                cssClasses: ["ag-edit-header ag-seperator"],
                icon: '<span class="ag-context-icon icon-experiment-Edit-Folder"></span>',
            },
        ];
    }

    /**
     * Method to enable/disable BOM/BOS Comparison from experiment list page
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableBomAndBosReviewComparison(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.BOM_REVIEW_COMPARISON)) {
            const { selectedExperiments, activeExperiment } = _contextMenuDataHelper;
            const expList = activeExperiment ? [activeExperiment] : selectedExperiments;
            return expList?.length !== 1;
        }
        return true;
    }

    /**
     * Method to enable/disable edit multiple bom
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disableEditMultipleBom(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.OPEN_MULTIPLE_BOMS)) {
            const { selectedExperiments } = _contextMenuDataHelper;
            return !!(selectedExperiments?.length === 0 || selectedExperiments?.length > this.maxWSOpenExpLength);
        }
        return true;
    }

    /**
     * Method to get the list of context menu for attribute analysis
     *
     * @return {*}  {ContextMenuInterface[]}
     * @memberof ContextMenuHelper
     */
    public getContextMenuForAttributeAnalysis = () => {
        return [
            {
                name: DEFAULT_MENU.COPY.NAME,
                action: () => this.copyFocusedCell$.next(DEFAULT_MENU.COPY.NAME),
                icon: '<span class="ag-context-icon iconset-content_copy_outline"></span>',
            },
        ];
    };

    /**
     * Method to enable/disable plm nutrition calculator
     * @param {ContextMenuDataHelper} _contextMenuDataHelper
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */
    public disablePLMNutritionCalc(_contextMenuDataHelper: ContextMenuDataHelper): boolean {
        if (this.checkAccessPermission(APPLICATION_PERMISSIONS.NUTRITION_CALCULATOR)) {
            const { activeExperiment, selectedExperiments } = _contextMenuDataHelper;
            return !(activeExperiment?.Type === EXPERIMENT || activeExperiment?.Type === PRODUCT || selectedExperiments?.length === 1);
        }
        return true;
    }

    /**
     * Method to check Access permission
     * @param {string} permissionName
     * @returns {boolean}
     * @memberof ContextMenuHelper
     */

    public checkAccessPermission(permissionName: string): boolean {
        return this.securityHelper.hasPermission(permissionName);
    }
}
