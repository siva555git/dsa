import { findIndex, find } from "lodash";
import { OTHER_USER_MENU_CHANGE, MENU_NAME_CHANGE, PRODUCT_MENU_CHANGE, PRODUCT } from "../constants/context-menu.constant";
import {
    BomDetailsModel,
    ContextMenuDataHelper,
    ContextMenuModel,
    ExperimentFormulaContextMenuModel,
    ExperimentsModel,
} from "../models/experiment-bom.model";
import { TreeViewModel } from "../models/experiment-list.model";
import { SelectedRowDataModel } from "../models/selected-row-data.model";

export class ContextMenuUtil {
    /**
     * Method to modify the context menu if it has other user experiment for Ag grid
     * @param {any} contextmenu
     * @memberof ContextMenuUtil
     */
    public static modifycontextMenu(contextmenu, activeExperiment?: ExperimentsModel): ExperimentFormulaContextMenuModel[] {
        contextmenu.forEach((menu) => {
            const menuCopy = menu;
            if (activeExperiment && activeExperiment.Type === PRODUCT && PRODUCT_MENU_CHANGE.includes(menu.name)) {
                menuCopy.name = MENU_NAME_CHANGE.find((nameToBeChanged) => nameToBeChanged.menuName === menu.name).name;
                return;
            }
            if (OTHER_USER_MENU_CHANGE.includes(menu.name)) {
                menuCopy.name = MENU_NAME_CHANGE.find((nameToBeChanged) => nameToBeChanged.menuName === menu.name).name;
            }
        });
        return contextmenu;
    }

    /**
     * Method to find index of menu
     * @param {any} contextmenu
     * @param {string} findName
     * @memberof ContextMenuUtil
     */
    public static findMenuIndex(contextmenu, findName: string): number {
        const index = findIndex(contextmenu, { name: findName });
        return index;
    }

    /**
     * Method to disable delete variant menu based on condition
     * @param {ContextMenuModel[]} menu
     * @param selectedRow
     * @param rowData
     * @param {SelectedRowDataModel[]} selectedExperiments
     * @param {boolean} isOtherExp
     * @param {ExperimentsModel} activeExperiment
     * @param {BomDetailsModel} bomDetails
     * @memberof ContextMenuUtil
     */
    public static ContextMenuDataHelper(
        menu: ContextMenuModel[],
        selectedRow,
        rowData,
        selectedExperiments?: SelectedRowDataModel[],
        isOtherExp?: boolean,
        activeExperiment?: ExperimentsModel,
        bomDetails?: BomDetailsModel,
        sortState?: string,
        isHideDeletedItems?: boolean,
        columnId?: string,
        canShowBomCompare?: boolean,
    ): ContextMenuDataHelper {
        return {
            menu,
            selectedRow,
            rowData,
            selectedExperiments,
            isOtherExp,
            activeExperiment,
            bomDetails,
            sortState,
            isHideDeletedItems,
            columnId,
            canShowBomCompare,
        };
    }

    /**
     * Method to get the entire grid data
     * @param contextmenu
     * @param toFilter
     * @memberof ContextMenuUtil
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static filterMenu(contextmenu, toFilter: string): any {
        return contextmenu.filter((menu) => menu.context === toFilter || !menu.context);
    }

    /**
     * Method to find rowdata using folder id / parent folder id
     * @static
     * @param {TreeViewModel} newFile
     * @param {Array<TreeViewModel>} fileArray
     * @return {*}  {TreeViewModel}
     * @memberof ContextMenuUtil
     */
    public static findRowData(newFile: TreeViewModel, fileArray: Array<TreeViewModel>): TreeViewModel {
        let fileData = find(fileArray, (file: TreeViewModel) => file.FolderID === newFile.FolderID);
        if (!fileData) {
            fileData = find(fileArray, (file: TreeViewModel) => file.FolderID === newFile.ParentFolderID);
        }
        return fileData;
    }
}
