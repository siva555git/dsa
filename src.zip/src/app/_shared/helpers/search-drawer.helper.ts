import { Injectable } from "@angular/core";
import { PRODUCT } from "@te-shared/constants/context-menu.constant";
import { SUBTypes } from "@te-shared/enums";
import { DisplayGridColumnModel } from "../components/display-grid-data/display.grid.model";
import { MAX_EXPORPRO_OPEN_LENGTH, UNAPPROVED_SEARCH_TABLE } from "../constants";
import { BomDetailExperimentsModel, ExperimentsModel } from "../models/experiment-bom.model";

@Injectable()
export class SearchDrawerHelper {
    /**
     * Method to add experiment to the cart
     * @param {BomDetailExperimentsModel[]} openedExperiments
     * @param {any} cartLists
     * @memberof SearchDrawerHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static isMaxExpExceeds(openedExperiments: BomDetailExperimentsModel[], cartLists: any): boolean {
        const isConditionSatisfied =
            openedExperiments?.length > 0
                ? Number(openedExperiments?.length) + Number(cartLists?.length) >= MAX_EXPORPRO_OPEN_LENGTH
                : cartLists?.length >= MAX_EXPORPRO_OPEN_LENGTH;
        return isConditionSatisfied;
    }

    /**
     * Method to add experiment to the cart
     * @param {BomDetailExperimentsModel[]} openedExperiments
     * @param {ExperimentsModel} experiment
     * @memberof SearchDrawerHelper
     */
    public static isAlreadyOpened(experiment: ExperimentsModel, openedExperiments: BomDetailExperimentsModel[]): boolean {
        if (openedExperiments?.length === 0) return false;
        const isOpenedInBOM =
            experiment.IPC && experiment.Type === PRODUCT
                ? openedExperiments?.find((exp) => exp.IPC === experiment.IPC && exp.BOMType === SUBTypes.PRODUCT)
                : openedExperiments?.find((exp) => exp.ExpCode === experiment.ExpCode && exp.BOMType === SUBTypes.EXPERIMENT);
        return !!isOpenedInBOM;
    }

    /**
     * Method to add experiment to the cart
     * @param {ExperimentsModel} experiment
     * @param {any} cartLists
     * @memberof SearchDrawerHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public static isAddedInCart(experiment: ExperimentsModel, cartLists: any): boolean {
        const addedInCart = experiment.IPC
            ? cartLists.find((cartItem) => cartItem.SUBCode === experiment.IPC)
            : cartLists.find((cartItem) => cartItem.ExpCode === experiment.ExpCode);
        return !!addedInCart;
    }

    /**
     * Method to config the unapproved search table columns and display value
     * @static
     * @returns {DisplayGridColumnModel[]}
     * @memberof SearchDrawerHelper
     */
    public static configUnapprovedHeaderColumns(): DisplayGridColumnModel[] {
        const unApprovedSearchColumns: DisplayGridColumnModel[] = [
            {
                columndID: UNAPPROVED_SEARCH_TABLE.UNAPPROVEDID_COLUMN_ID,
                displayColumnName: UNAPPROVED_SEARCH_TABLE.UNAPPROVEDID_COLUMN_HEADERTEXT,
            },
            {
                columndID: UNAPPROVED_SEARCH_TABLE.DESCRIPTION_NAME_COLUMN_ID,
                displayColumnName: UNAPPROVED_SEARCH_TABLE.DESCRIPTION_NAME_COLUMN_HEADERTEXT,
            },
            {
                columndID: UNAPPROVED_SEARCH_TABLE.COSTKG_COLUMN_ID,
                displayColumnName: UNAPPROVED_SEARCH_TABLE.COSTKG_COLUMN_HEADERTEXT,
            },
            {
                columndID: UNAPPROVED_SEARCH_TABLE.COSTKGCURRENCY_COLUMN_ID,
                displayColumnName: UNAPPROVED_SEARCH_TABLE.COSTKGCURRENCY_COLUMN_HEADERTEXT,
            },
            {
                columndID: UNAPPROVED_SEARCH_TABLE.CATEGORY_COLUMN_ID,
                displayColumnName: UNAPPROVED_SEARCH_TABLE.CATEGORY_COULMN_HEADERTEXT,
            },
            {
                columndID: UNAPPROVED_SEARCH_TABLE.MARKETCODE_COLUMN_ID,
                displayColumnName: UNAPPROVED_SEARCH_TABLE.MARKETCODE_COULMN_HEADERTEXT,
            },
            {
                columndID: UNAPPROVED_SEARCH_TABLE.CREATEDBY_COLUMN_ID,
                displayColumnName: UNAPPROVED_SEARCH_TABLE.CREATEDBY_COULMN_HEADERTEXT,
            },
            {
                columndID: UNAPPROVED_SEARCH_TABLE.CREATEDON_COLUMN_ID,
                displayColumnName: UNAPPROVED_SEARCH_TABLE.CREATEDON_COULMN_HEADERTEXT,
            },
        ];
        return unApprovedSearchColumns;
    }
}
