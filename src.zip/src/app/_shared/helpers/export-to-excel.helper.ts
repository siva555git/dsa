import { Injectable } from "@angular/core";
import { EXCEL_EXTENSION } from "@te-shared/constants";
import * as XLSX from "xlsx";

@Injectable()
export class ExportToExcelHelper {
    exportToExcel(exportData, fileName: string, sheetName: string): void {
        if (exportData && exportData?.length > 0) {
            const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData);
            const workbook: XLSX.WorkBook = { Sheets: { [sheetName]: worksheet }, SheetNames: [sheetName] };
            XLSX.writeFile(workbook, `${fileName} ${EXCEL_EXTENSION}`, { bookSST: true, cellStyles: true });
        }
    }
}
