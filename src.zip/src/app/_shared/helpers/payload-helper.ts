/* eslint-disable max-lines */
import { Injectable } from "@angular/core";
import { ExperimentEditorBomUtil } from "@te-experiment-editor/helpers/experiment-editor-bom.util";
import { ExperimentEditorHelper } from "@te-experiment-editor/helpers/experiment-editor.helper";
import { AppStateService } from "@te-services/app-state/app.state.service";
import { SUBTypes } from "@te-shared/enums";
import { chain, forEach, map, sortBy, filter, find } from "lodash";
import { FacilitiesModel } from "@te-shared/models/facilities-model";
import {
    GRID_DATA_SOURCE_CONSTANTS,
    INACTIVE_BOM_FLAG,
    REFRESH_GRID,
    REMOVE_ALL_FLAG,
} from "../../experiment-editor/constants/experiment-editor.constant";
import { AddBomModel } from "../../experiment-editor/models/add-bom-model";
import {
    CombineIntoNewExperimentModel,
    ExplodeBomItemModel,
    GridDataHelperModel,
    ReplaceBomItemModel,
    UserPreference,
    ValueParameters,
} from "../../experiment-editor/models/experiment-editor.model";
import { ExplodeCombineModel } from "../../experiment-editor/models/explode-combine-model";
import { BOMUpdateModel, RefreshGridModel } from "../../experiment-editor/models/grid-refresh.model";
import {
    DELETE_OPTONS,
    SOMETHING_WRONG,
    ATTRIBUTE_DATA_RESULT_LIMIT,
    COLUMN_ATTRIBUTE_DISPLAY_LIST,
    STOCK_UNIT_DISPLAY,
} from "../constants";
import { COMBINE_SUB_OPTIONS, LINE_SUB_OPTIONS } from "../constants/context-menu.constant";
import { BOM_DETAILS_CONSTANTS, MARK_FOR_HARD_DELETE_FLAG, MARK_FOR_UNDELETE_FLAG } from "../constants/experiment.constant";
import { BomDetailsModel, ExperimentFormulaModel } from "../models/experiment-bom.model";
import { AgGridUtil } from "./ag-grid-util";
import { ExperimentBomUtil } from "./experiment-bom.util";

@Injectable({
    providedIn: "root",
})
export class PayloadHelper {
    constructor(private readonly appState: AppStateService) {}

    /**
     * Method to process response for BOM parts update API
     * @param {AddBomModel} request
     * @param response
     * @param {GridDataHelperModel} gridDataHelper
     * @memberof PayloadHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public processUpdateBOMPartsSuccess(request: AddBomModel, response: any, gridDataHelper: GridDataHelperModel): RefreshGridModel {
        const updateBOMPartsMap = {
            [REFRESH_GRID.FILL_PARTS_UPDATE]: () => {
                const refreshData = this.getRefreshDataPayload([], [response], [], []);
                return this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
            },
            [REFRESH_GRID.APPLY_FACTOR]: () => {
                const refreshData = this.getRefreshDataPayload([], [response], [], []);
                return this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
            },
            [LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE]: () => {
                const responseData = response?.IsDelete === MARK_FOR_HARD_DELETE_FLAG ? [] : [response];
                const deletedData = this.refreshDelete([request], responseData, gridDataHelper.addType);
                const refreshData = this.getRefreshDataPayload([], [], deletedData, responseData);
                return this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
            },
            [DELETE_OPTONS.CONTEXT_MENU]: () => {
                const responseData = response?.IsDelete === MARK_FOR_HARD_DELETE_FLAG ? [] : [response];
                const deletedData = this.refreshDelete([request], responseData, gridDataHelper.addType);
                const refreshData = this.getRefreshDataPayload([], [], deletedData, responseData);
                return this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
            },
            [REFRESH_GRID.TOGGLE_INSTRUCTION]: () => {
                const deletedData = this.refreshDelete([request], [response], gridDataHelper.addType);
                const refreshData = this.getRefreshDataPayload([], [], deletedData, [response]);
                return this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
            },
            [REFRESH_GRID.EDIT_BOM_PARTS]: () => {
                return this.createRefreshGridPayload(gridDataHelper.addType, []);
            },
        };
        const refreshGridPayload = updateBOMPartsMap[gridDataHelper.addType]
            ? updateBOMPartsMap[gridDataHelper.addType]()
            : this.createRefreshGridPayload("", []);
        return refreshGridPayload;
    }

    /**
     * Method to reset BOM parts after failure of update BOM parts API
     * @param {ValueParameters} agGridEvent
     * @memberof PayloadHelper
     */
    public processUpdateBOMPartsFailure = (agGridEvent: ValueParameters): void => {
        if (agGridEvent) {
            const oldData = agGridEvent.data;
            oldData[agGridEvent.column.getColId()] = agGridEvent.oldValue;
            AgGridUtil.updateGridWithTransaction(agGridEvent.api, -1, [], [], [oldData]);
        }
    };

    /**
     * Method to process Add BOM API response
     * @param {AddBomModel} request
     * @param response
     * @param {GridDataHelperModel} gridDataHelper
     * @memberof PayloadHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public processAddBOMSuccess = (request: AddBomModel[], response: any, gridDataHelper: GridDataHelperModel): RefreshGridModel => {
        const refreshGridPayload =
            response?.length > 0 ||
            (response.length === 0 &&
                (gridDataHelper.addType === DELETE_OPTONS.CONTEXT_MENU ||
                    gridDataHelper.addType === LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE ||
                    gridDataHelper.addType === REFRESH_GRID.TOGGLE_INSTRUCTION))
                ? this.getRefreshGridPayload(request, response, gridDataHelper)
                : this.createRefreshGridPayload(SOMETHING_WRONG, []);
        return refreshGridPayload;
    };

    /**
     * method to get refresh grid payload
     *
     * @memberof PayloadHelper
     */
    // eslint-disable-next-line max-lines-per-function, @typescript-eslint/no-explicit-any
    public getRefreshGridPayload = (requestPayload: any, response: any, gridDataHelper: GridDataHelperModel): RefreshGridModel => {
        let refreshGridPayload;
        switch (gridDataHelper.addType) {
            case REFRESH_GRID.ADD_PARTS:
            case REFRESH_GRID.FILL_PARTS_ADD:
            case REFRESH_GRID.INSERT_FROM_QUICK_SEARCH: {
                const newlyAddedExpFormula = this.filtreNewAddBomItems(requestPayload, response);
                const refreshData = this.getRefreshDataPayload(newlyAddedExpFormula.newlyAddedExpFormula, [], [], response);
                refreshGridPayload = this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
                break;
            }
            case REFRESH_GRID.INSERT_FROM_SEARCH: {
                const newlyAddedExpFormula = this.filtreNewAddBomItems(requestPayload, response);
                const deletedItems = requestPayload.filter((bomDetails) => bomDetails.IsDelete === 2);
                const { updatedItems } = gridDataHelper.miniEditorCart;
                const refreshData = this.getRefreshDataPayload(
                    newlyAddedExpFormula.newlyAddedExpFormula,
                    updatedItems,
                    deletedItems,
                    response,
                );
                refreshGridPayload = this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
                break;
            }
            case REFRESH_GRID.TOGGLE_INSTRUCTION:
            case LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE:
            case COMBINE_SUB_OPTIONS.DUPLICATES:
            case DELETE_OPTONS.CONTEXT_MENU: {
                const deletedData = this.refreshDelete(requestPayload, response, gridDataHelper.addType);
                const updatedItems = COMBINE_SUB_OPTIONS.DUPLICATES === gridDataHelper.addType ? response : [];
                const refreshData = this.getRefreshDataPayload([], updatedItems, deletedData, response);
                refreshGridPayload = this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
                break;
            }
            case REFRESH_GRID.DRAG_BOM:
            case REFRESH_GRID.APPLY_FACTOR: {
                const refreshData = this.getRefreshDataPayload([], response, [], []);
                refreshGridPayload = this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
                break;
            }
            case REFRESH_GRID.REPLACE_BOM:
            case REFRESH_GRID.EXPLODE_BOM:
            case LINE_SUB_OPTIONS.COMBINE: {
                const deletedData =
                    gridDataHelper.addType === LINE_SUB_OPTIONS.COMBINE
                        ? []
                        : requestPayload.bomItems.filter((bomDetails) => bomDetails.IsDelete === 2);

                const insertedData = AgGridUtil.getNewlyAddedItemsFromBomDetailsResponse(requestPayload, response);
                const refreshData = this.getRefreshDataPayload(insertedData, [], deletedData, response);
                refreshGridPayload = this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
                refreshGridPayload.openNewExpInWorkspace = requestPayload?.OpenExp;
                break;
            }
            case REFRESH_GRID.SCALE_PARTS: {
                const refreshData = this.getRefreshDataPayload([], response, [], gridDataHelper.bomDetails);
                refreshGridPayload = this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
                break;
            }
            case LINE_SUB_OPTIONS.RESEQUENCE: {
                const refreshData = this.getRefreshDataPayload([], response, [], response);
                refreshGridPayload = this.createRefreshGridPayload(gridDataHelper.addType, refreshData);
                break;
            }
            default: {
                break;
            }
        }
        return refreshGridPayload;
    };

    /**
     * Method to generate the refresh data payload
     * @param addedItems
     * @param updatedItems
     * @param deletedItems
     * @param bomDetails
     * @memberof PayloadHelper
     */
    public getRefreshDataPayload = (addedItems, updatedItems, deletedItems, bomDetails): BOMUpdateModel => {
        return { addedItems, updatedItems, deletedItems, bomDetails };
    };

    /**
     * Method to generate the refresh grid payload for various actions like delete, add, update, scale, fill etc
     * @param {string} refreshType
     * @param {any} refreshData
     * @memberof PayloadHelper
     */
    public createRefreshGridPayload = (refreshType: string, refreshData: BOMUpdateModel | []): RefreshGridModel => {
        return {
            refreshType,
            refreshData,
        };
    };

    /**
     * Method to create refresh payload for delete
     *
     * @private
     * @param {ExperimentFormulaModel[]} bomItemToUpdate
     * @param {ExperimentFormulaModel[]} experimentFormulas
     * @param {string} refreshType
     * @memberof PayloadHelper
     */
    private refreshDelete = (
        bomItemToUpdate: ExperimentFormulaModel[],
        experimentFormulas: ExperimentFormulaModel[],
        refreshType: string,
    ): ExperimentFormulaModel[] => {
        if (!experimentFormulas) return [];
        return refreshType === LINE_SUB_OPTIONS.TOGGLE_DELETE_UNDELETE
            ? filter(bomItemToUpdate, (bomItem) =>
                  experimentFormulas.some(
                      (experimentFormula) =>
                          bomItem.ExpFormulaID === experimentFormula.ExpFormulaID && experimentFormula.IsDelete === INACTIVE_BOM_FLAG,
                  ),
              )
            : filter(bomItemToUpdate, (bomItem) => bomItem.IsDelete === REMOVE_ALL_FLAG);
    };

    /**
     * returns the newly added bom details expformulaids from the payload
     * @param {any} addBOMPayload
     * @param {any} addBomResponse
     * @memberof PayloadHelper
     */
    private filtreNewAddBomItems = (addBOMPayload, addBomResponse) => {
        const formulaSeqKey = GRID_DATA_SOURCE_CONSTANTS.FORMULA_SEQUENCE;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const newlyAddedBomItems = filter(addBOMPayload, (newlyAdded: any) => {
            return newlyAdded.ExpFormulaID === "";
        });
        const newlyAddedData = chain(addBomResponse).keyBy(formulaSeqKey).at(map(newlyAddedBomItems, formulaSeqKey)).value();
        newlyAddedData.forEach((newlyAdded) => {
            newlyAdded.UnapprovedDescription =
                newlyAdded.SUBType === SUBTypes.UNAPPROVED
                    ? addBOMPayload.find((addBOM) => addBOM?.SUBCode === Number(newlyAdded?.SUBCode))?.UnapprovedDescription
                    : // eslint-disable-next-line unicorn/no-null
                      null;
        });
        const newAddedPayload = {
            newlyAddedExpIds: map(newlyAddedData, BOM_DETAILS_CONSTANTS.EXP_FORMULA_ID),
            newlyAddedExpFormula: newlyAddedData,
        };
        return newAddedPayload;
    };

    public static getAttributesPayLoad = (ipcValues: Array<string>) => {
        return {
            filter: {
                flagsmustnot: [],
                ipcs: [...new Set(ipcValues)],
                sortby: {
                    ipc: {
                        order: "asc",
                    },
                },
            },
            from: 0,
            recordcount: ATTRIBUTE_DATA_RESULT_LIMIT,
        };
    };

    public constructExplodeCombinePayload = (
        bomItems: ExperimentFormulaModel[],
        explodedItems: ExperimentFormulaModel[],
        combinedItems: ExperimentFormulaModel[],
        type: string,
        combineIntoNewExperiment?: CombineIntoNewExperimentModel,
        instructionsPreference?: UserPreference[],
    ): ExplodeCombineModel => {
        const isPublic = this.appState.getPrivacyModelInfo();
        return {
            bomItems,
            combinedItems,
            explodedItems,
            type,
            ...combineIntoNewExperiment,
            IsPublic: isPublic,
            instructionsPreference,
        };
    };

    /**
     * Method to construct payload for combine duplicate
     *
     * @param {ExperimentFormulaModel[]} bomItems
     * @param {any} combinedExperiments
     * @return {*}  {AddBomModel[]}
     * @memberof PayloadHelper
     */
    public static constructCombineDuplicatePayload(
        bomItems: ExperimentFormulaModel[],
        combinedExperiments: ExplodeBomItemModel[],
        bomDetails: BomDetailsModel,
    ): AddBomModel[] {
        const activeBomItems = bomItems.filter((bomDetail) => bomDetail.IsDelete === MARK_FOR_UNDELETE_FLAG);
        forEach(combinedExperiments, (selectedData) => {
            let duplicateBomItems = activeBomItems.filter(
                (activeBomItem) =>
                    activeBomItem.SUBCode === selectedData.subCode ||
                    ExperimentBomUtil.getExperimentForumla(bomDetails.Experiments, selectedData.subCode)?.ExpID ===
                        Number(activeBomItem.SUBCode),
            );
            if (duplicateBomItems.length > 0) {
                duplicateBomItems = sortBy(duplicateBomItems, [GRID_DATA_SOURCE_CONSTANTS.FORMULA_SEQUENCE]);
                duplicateBomItems[0].Parts = selectedData.parts;
                duplicateBomItems.forEach((experimentFormula, index) => {
                    if (index !== 0) {
                        const experiment = experimentFormula;
                        experiment.IsDelete = REMOVE_ALL_FLAG;
                    }
                });
            }
        });
        return bomItems;
    }

    /**
     * Method to construct payload for Replacing Bom Item
     *
     * @param {ReplaceBomItemModel} replaceBomItemModel
     * @return {*}  {ExplodeCombineModel}
     * @memberof PayloadHelper
     */
    public getReplaceBomItemPayload(replaceBomItemModel: ReplaceBomItemModel): ExplodeCombineModel {
        const activeExperimentBom = ExperimentBomUtil.getTopLevelExperimentByExpIdAndType(
            replaceBomItemModel.gridDataHelper.activeExperiment.ExpID,
            replaceBomItemModel.gridDataHelper.bomDetails.Experiments,
            replaceBomItemModel.gridDataHelper.activeExperiment?.Type,
        );
        forEach(activeExperimentBom?.ExperimentFormula, (currentBom: ExperimentFormulaModel) => {
            const addBom = currentBom;
            if (currentBom.FormulaSeq === replaceBomItemModel.existingBomFormulaSeq) {
                addBom.IsDelete = replaceBomItemModel.deleteFlagForReplacingBom;
            }
        });
        const replacingBomModel: AddBomModel = {
            CreatedBy: replaceBomItemModel.replacingBom.CreatedBy,
            ExpFormulaID: replaceBomItemModel.replacingBom.ExpFormulaID,
            ExpID: replaceBomItemModel.replacingBom.ExpID,
            FormulaSeq: replaceBomItemModel.replacingBom.FormulaSeq,
            SUBCode: replaceBomItemModel.replacingBom.SUBCode,
            SUBType: replaceBomItemModel.replacingBom?.SUBType,
            Parts: replaceBomItemModel.replacingBom?.Parts,
            Instruction: replaceBomItemModel.replacingBom?.Instruction,
            IsDelete: replaceBomItemModel.replacingBom?.IsDelete,
        };
        const sequenceToInsert = ExperimentEditorHelper.getSequenceToInsert([replacingBomModel]);
        const bomDetailsAddBomPayload = ExperimentEditorHelper.insertMultipleItemsAtIndex(
            activeExperimentBom?.ExperimentFormula,
            sequenceToInsert,
            [replacingBomModel],
        );
        ExperimentEditorBomUtil.reSequncePayload(bomDetailsAddBomPayload);
        return this.constructExplodeCombinePayload(bomDetailsAddBomPayload, [], [], REFRESH_GRID.EXPLODE_BOM);
    }

    /**
     * Method to get stock plant Info
     * @param columnLayout
     * @param {FacilitiesModel[]} facilities
     * @returns {Array<[]>}
     * @memberof PayloadHelper
     */
    public getStockPlantInfo(columnLayout, facilities: FacilitiesModel[]): Array<[]> {
        const plantIDs = [];
        forEach(columnLayout, (layout) => {
            const item = layout;
            if (item?.columns === COLUMN_ATTRIBUTE_DISPLAY_LIST.STOCK) {
                item.ColumnSelectedValue = item.value.replace(` ${STOCK_UNIT_DISPLAY}`, "");
                const plantInfo = find(facilities, (facility) => {
                    return facility.costbookcode === item.ColumnSelectedValue;
                });
                if (plantInfo) plantIDs.push({ plantId: plantInfo.facilitycode, plantName: plantInfo.costbookcode });
            }
        });
        return plantIDs;
    }
}
