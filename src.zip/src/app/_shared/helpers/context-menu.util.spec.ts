/* eslint-disable max-lines-per-function */
import { TestBed } from "@angular/core/testing";
import { BomDetailsModel } from "@te-shared/models/experiment-bom.model";
import { TreeViewModel } from "../models";
import {
    treeViewModel,
    folderRowData,
    menu,
    selectedRowData,
    mockGridDataSource,
    mockActiveExperiment,
    bomDetails,
} from "../../testing/mock-context-menu.helper";
import { MENU_LIST } from "../constants/context-menu.constant";
import { ContextMenuUtil } from "./context-menu.util";

describe("ContextMenuUtil", () => {
    beforeEach(() =>
        TestBed.configureTestingModule({
            providers: [ContextMenuUtil],
        }),
    );

    it("should create", () => {
        const service: ContextMenuUtil = TestBed.inject(ContextMenuUtil);
        expect(service).toBeTruthy();
    });

    it("should call findRowData", () => {
        spyOn(ContextMenuUtil, "findRowData").and.callThrough();
        ContextMenuUtil.findRowData(treeViewModel, folderRowData as unknown as Array<TreeViewModel>);
        expect(ContextMenuUtil.findRowData).toHaveBeenCalled();
    });

    it("should call findRowData", () => {
        spyOn(ContextMenuUtil, "findRowData").and.callThrough();
        treeViewModel.ParentFolderID = 123_455;
        ContextMenuUtil.findRowData(treeViewModel, folderRowData as unknown as Array<TreeViewModel>);
        expect(ContextMenuUtil.findRowData).toHaveBeenCalled();
    });

    it("should call filterMenu", () => {
        spyOn(ContextMenuUtil, "filterMenu").and.callThrough();
        ContextMenuUtil.filterMenu(menu, "Editor");
        expect(ContextMenuUtil.filterMenu).toHaveBeenCalled();
    });

    it("should call filterMenu", () => {
        spyOn(ContextMenuUtil, "filterMenu").and.callThrough();
        ContextMenuUtil.filterMenu(menu, "Landing");
        expect(ContextMenuUtil.filterMenu).toHaveBeenCalled();
    });

    it("should call ContextMenuDataHelper", () => {
        spyOn(ContextMenuUtil, "ContextMenuDataHelper").and.callThrough();
        ContextMenuUtil.ContextMenuDataHelper(
            menu,
            selectedRowData,
            mockGridDataSource,
            selectedRowData,
            false,
            mockActiveExperiment,
            bomDetails as unknown as BomDetailsModel,
        );
        expect(ContextMenuUtil.ContextMenuDataHelper).toHaveBeenCalled();
    });

    it("should call findMenuIndex", () => {
        spyOn(ContextMenuUtil, "findMenuIndex").and.callThrough();
        ContextMenuUtil.findMenuIndex(menu, MENU_LIST.EDIT_EXPERIMENT);
        expect(ContextMenuUtil.findMenuIndex).toHaveBeenCalled();
    });

    it("should call modifycontextMenu", () => {
        spyOn(ContextMenuUtil, "modifycontextMenu").and.callThrough();
        ContextMenuUtil.modifycontextMenu(menu);
        expect(ContextMenuUtil.modifycontextMenu).toHaveBeenCalled();
    });
});
