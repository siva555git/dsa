import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { AppDataService } from "../../_services";
import {
    BatchSheetModel,
    BatchSheetReturn,
    GenerateLabelResponse,
    LabelTemplatePayload,
    LabelTemplateResponse,
    SampleResponse,
} from "../../experiment-editor/models/batch-sheet.model";
import { Experiment } from "../models/experiment.model";

@Injectable()
export class BatchSheetHelper {
    constructor(private readonly appDataService: AppDataService) {}

    /**
     * Method to create the batchSheet
     *
     * @param {BatchSheetModel} batchSheetModel
     * @returns {Observable<BatchSheetReturn>}
     * @memberof BatchSheetHelper
     */
    public createBatchSheet(batchSheetModel: BatchSheetModel): Observable<BatchSheetReturn> {
        return this.appDataService.post(this.appDataService.url.createBatchSheet, [], batchSheetModel);
    }

    /**
     * Method to validate ExpCode or ExpId
     * @returns {Observable<BatchSheetReturn>}
     * @memberof BatchSheetHelper
     */
    public validateExpCode(payload: { expCode?: string; expID?: number }): Observable<Experiment> {
        return this.appDataService.post(this.appDataService.url.validateExpCode, [], payload);
    }

    /**
     * Method to get sample details
     * @returns {Observable<BatchSheetReturn>}
     * @memberof BatchSheetHelper
     */
    public getSample(): Observable<BatchSheetReturn> {
        return this.appDataService.get(this.appDataService.url.getSampleSheet, []);
    }

    /**
     * Method to get Label Template
     *
     * @returns {Observable<BatchSheetReturn>}
     * @memberof BatchSheetHelper
     */
    public getLabelTemplate(): Observable<LabelTemplateResponse[]> {
        return this.appDataService.get(this.appDataService.url.getLabelTemplate, []);
    }

    /**
     * Method to generate label template
     * @param {LabelTemplatePayload} payload
     * @memberof BatchSheetHelper
     */
    public generateLabelTemplate(payload: LabelTemplatePayload): Observable<GenerateLabelResponse> {
        return this.appDataService.post(this.appDataService.url.generateLabelTemplate, [], payload);
    }

    /**
     * Method to validate sample Id
     * @param {string} sampleID
     * @memberof BatchSheetHelper
     */
    public validateSampleId(sampleID: string): Observable<SampleResponse> {
        return this.appDataService.get(this.appDataService.url.getDetailsBySampleID, [sampleID]);
    }

    /**
     * Method to generate SAP PO
     * @param {string} sampleID
     * @memberof BatchSheetHelper
     */
    public generateSAPPO(payload: {
        xmlPayload: string;
        PlantID: string;
        ExpID: number;
        TotalParts: string;
        UOM: string;
    }): Observable<{ result: string }> {
        return this.appDataService.post(this.appDataService.url.generateSapPo, [], payload);
    }
}
