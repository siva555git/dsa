import { TestBed, waitForAsync } from "@angular/core/testing";
import { AppDataService } from "@te-services/index";
import { MockAppDataService } from "@te-testing/mock-app.data.service";
import { BatchSheetHelper } from "./batch-sheet.helper";

describe("BatchSheetHelper", () => {
    let service: BatchSheetHelper;

    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [
                BatchSheetHelper,
                {
                    provide: AppDataService,
                    useClass: MockAppDataService,
                },
            ],
        })));

    beforeEach(() => {
        service = TestBed.inject(BatchSheetHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should call createBatchSheet", () => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const response = service.createBatchSheet({} as any);
        expect(response).toBeDefined();
    });

    it("should call validateExpCode", () => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const response = service.validateExpCode({} as any);
        expect(response).toBeDefined();
    });

    it("should call getSample", () => {
        const response = service.getSample();
        expect(response).toBeDefined();
    });

    it("should call getLabelTemplate", () => {
        const response = service.getLabelTemplate();
        expect(response).toBeDefined();
    });

    it("should call generateLabelTemplate", () => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const response = service.generateLabelTemplate({} as any);
        expect(response).toBeDefined();
    });

    it("should call validateSampleId", () => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const response = service.validateSampleId({} as any);
        expect(response).toBeDefined();
    });
});
