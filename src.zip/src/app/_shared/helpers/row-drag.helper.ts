/* eslint-disable max-lines-per-function */
import { GridApi, RowNode } from "@ag-grid-community/core";
import { Injectable } from "@angular/core";
import { EXPERIMENT_ACCESS, PERMISSION_CATEGORY_CONSTANT } from "@te-shared/constants";
import { filter, forEach, sortBy } from "lodash";
import { EMPTY } from "../../app.constant";
import {
    DRAG_EVENT,
    GRID_DATA_SOURCE_CONSTANTS,
    ROW_DRAG_MESSAGE,
    ROW_DRAG_UP,
} from "../../experiment-editor/constants/experiment-editor.constant";
import { ExperimentEditorBomUtil } from "../../experiment-editor/helpers/experiment-editor-bom.util";
import { ExperimentEditorUtil } from "../../experiment-editor/helpers/experiment-editor.util";
import { AttributeDragManageParameters, AttributeDragValidateParameters } from "../../experiment-editor/models/experiment-editor.model";
import { AppBroadCastService, AppStateService } from "../../_services";
import { ExperimentAccessResponseModel, TreeViewModel } from "../models";
import { AgGridUtil } from "./ag-grid-util";
import { ExperimentAccessHelper } from "./experiment-access.helper";
import { ExperimentBomUtil } from "./experiment-bom.util";

@Injectable()
export class RowDragHelper {
    constructor(
        private readonly appBroadCastService: AppBroadCastService,
        private readonly appState: AppStateService,
        private readonly experimentAccessHelper: ExperimentAccessHelper,
    ) {}

    /**
     * Method to check if Attribute Row Drag Action is valid
     *
     * @param {AttributeDragValidateParameters} validateParameters
     * @memberof RowDragHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public isAttributeRowDragValid = (validateParameters: AttributeDragValidateParameters): any => {
        const currentUserID = Number(this.appState.getCurrentUserSapEmpId());
        const selectedRows = AgGridUtil.getSelectedRows(validateParameters.gridApi);
        let rowDragDirection = validateParameters.attributeDragDirection;
        const agGridRowDragParameters = validateParameters.event;
        const { overNode, vDirection } = agGridRowDragParameters;
        let isValid = { value: true, errorMessage: "" };
        let accessInfo;
        if (validateParameters?.activeExperiment) {
            accessInfo = this.experimentAccessHelper.getExperimentAccessCheck(
                [validateParameters.activeExperiment],
                currentUserID,
                EXPERIMENT_ACCESS.MOVE_LINE,
            );
        }
        if (agGridRowDragParameters.type === DRAG_EVENT.DRAG_END) {
            isValid = this.isAttributeRowDragValidOnDragEnd(validateParameters, isValid, accessInfo, selectedRows);
        } else if (agGridRowDragParameters.type === DRAG_EVENT.DRAG_MOVING && vDirection) {
            rowDragDirection = vDirection;
        }

        return { isValid, rowDragDirection, selectedRows, overNode };
    };

    /**
     * Method to update dragged over row nodes
     *
     * @param {*} gridApi
     * @param {*} draggedOverRowNode
     * @param {*} [newDraggedOverRowNode]
     * @memberof RowDragHelper
     */
    public updateGridRowsWhenDragging = (gridApi, draggedOverRowNode, newDraggedOverRowNode?) => {
        const rowsToRefresh = [];
        if (draggedOverRowNode) {
            rowsToRefresh.push(draggedOverRowNode);
        }
        if (newDraggedOverRowNode) {
            rowsToRefresh.push(newDraggedOverRowNode);
        }
        AgGridUtil.refreshSelectedGridCells(gridApi, rowsToRefresh, undefined, false);
    };

    private isAttributeRowDragValidOnDragEnd(
        validateParameters: AttributeDragValidateParameters,
        isValid: { value: boolean; errorMessage: string },
        accessInfo: ExperimentAccessResponseModel,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        selectedRows: any,
    ) {
        let isValidData = isValid;
        if (!validateParameters.activeExperiment) {
            isValidData = { value: false, errorMessage: ROW_DRAG_MESSAGE.NO_ACTIVE_EXP_SELECTED };
        } else if (!accessInfo.isPermitted) {
            isValidData = RowDragHelper.getInvalidAccessInfo(accessInfo);
        } else if (selectedRows.length === 0) {
            isValidData = { value: false, errorMessage: ROW_DRAG_MESSAGE.NO_CHECKBOX_SELECTED };
        } else {
            const formulaIdKey = ExperimentBomUtil.getFormulaIdKey(validateParameters.activeExperiment.ExpCode);
            let isRowPresentInActiveExp = true;
            forEach(selectedRows, (gridRow) => {
                if (!gridRow[formulaIdKey]) {
                    isRowPresentInActiveExp = false;
                }
            });
            if (!isRowPresentInActiveExp) {
                isValidData = { value: false, errorMessage: ROW_DRAG_MESSAGE.NO_ACTIVE_BOM_SELECTED };
            }
        }
        return isValidData;
    }

    /**
     * Method to handle Attribute Row Drag Action
     *
     * @param {AttributeDragManageParameters} manageDragParameters
     * @memberof RowDragHelper
     */
    public handleAttributeRowDrag(manageDragParameters: AttributeDragManageParameters) {
        const { activeExperiment, bomDetails, selectedRows, baseExpFormulaID, rowDragDirection } = manageDragParameters;
        const activeExperimentBom = ExperimentBomUtil.getTopLevelExperimentByExpIdAndType(
            activeExperiment.ExpID,
            bomDetails?.Experiments,
            activeExperiment?.Type,
        );
        const expFormulaIDKey = AgGridUtil.getTreeGridKeys(activeExperiment.ExpCode, GRID_DATA_SOURCE_CONSTANTS.EXP_FORMULA_ID_KEY);
        activeExperimentBom.ExperimentFormula = sortBy(activeExperimentBom?.ExperimentFormula, GRID_DATA_SOURCE_CONSTANTS.FORMULA_SEQUENCE);
        const addBomPayLoad = activeExperimentBom?.ExperimentFormula?.filter(
            (element) => !selectedRows.some((bomDetail) => bomDetail[expFormulaIDKey] === element.ExpFormulaID),
        );
        const draggedAttributes = activeExperimentBom?.ExperimentFormula?.filter((element) =>
            selectedRows.some((bomDetail) => bomDetail[expFormulaIDKey] === element.ExpFormulaID),
        );
        let insertIndex = addBomPayLoad?.findIndex((element) => element.ExpFormulaID === baseExpFormulaID);

        // If the dragging over BOM Item is not present in the active experiment, we are adding the dragged BOM items in the last position
        insertIndex = insertIndex === -1 ? addBomPayLoad.length : this.getInsertIndex(rowDragDirection, insertIndex);
        addBomPayLoad.splice(insertIndex, 0, ...draggedAttributes);

        const isPayloadReSequnced = ExperimentEditorBomUtil.reSequncePayload(addBomPayLoad);
        return isPayloadReSequnced ? addBomPayLoad : [];
    }

    /**
     * Method to get the index to insert the dragged row
     *
     * @private
     * @param {string} rowDragDirection
     * @param {number} insertIndex
     * @memberof RowDragHelper
     */
    private getInsertIndex = (rowDragDirection: string, insertIndex: number): number => {
        return rowDragDirection === ROW_DRAG_UP ? insertIndex : insertIndex + 1;
    };

    /**
     * Method to handle the grid changes for Attribute Row drag
     *
     * @param {*} gridApi
     * @param {*} selectedRows
     * @param {string} rowDragDirection
     * @param {string} baseExpFormulaID
     * @memberof RowDragHelper
     */
    public handleGridChangesForAttributeRowDrag(
        gridApi: GridApi,
        selectedRows,
        rowDragDirection: string,
        formulaIdKey: string,
        baseExpFormulaID: string,
    ): void {
        const rowNode = ExperimentEditorUtil.getRowsBasedOnProperty(gridApi, formulaIdKey, [baseExpFormulaID]);
        if (rowNode.length === 0) return;

        // remove selected rows from grid
        AgGridUtil.updateGridWithTransaction(gridApi, -1, [], selectedRows, []);

        // add the rows at the desired position
        const insertIndex = this.getInsertIndex(rowDragDirection, rowNode[0].data.index);
        AgGridUtil.updateGridWithTransaction(gridApi, insertIndex, selectedRows, [], []);
        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
    }

    /** Methods for Folder Row Drag start here */

    /**
     * Method to check if Folder drag and drop is valid
     *
     * @param {RowNode} selectedNode
     * @param {RowNode} targetNode
     * @return {*}  {boolean}
     * @memberof RowDragHelper
     */
    public isFolderRowDragValid(selectedNode: RowNode, targetNode: RowNode): boolean {
        // Preventing drag and drop from 1 Default Folder to another
        if (selectedNode.data?.filePath[0] !== targetNode.data?.filePath[0]) return true;

        // Preventing drag and drop of Folder in the same location
        if (selectedNode.data?.FolderID === targetNode.data?.FolderID) return true;

        const children = selectedNode.childrenAfterGroup;
        let isSelectionParentOfTarget = false;
        forEach(children, (child, index, array) => {
            isSelectionParentOfTarget =
                child.data.FolderID === targetNode.data.ParentFolderID ? true : this.isFolderRowDragValid(child, targetNode);

            if (isSelectionParentOfTarget) {
                // Can not use break statement inside forEach loop, hence we are short-circuting
                // the array length till current index and eventually exiting the loop
                const childrenArray = array;
                childrenArray.length = index + 1;
            }
        });
        return isSelectionParentOfTarget;
    }

    /**
     * Method to check if folder with same name is already present in Target folder
     *
     * @param {Array<TreeViewModel>} folders
     * @param {number} targetFolderId
     * @param {string} selectedFolderName
     * @memberof RowDragHelper
     */
    public isFolderWithSameNameAlreadyPresent = (
        folders: Array<TreeViewModel>,
        targetFolderId: number,
        selectedFolderName: string,
    ): boolean => {
        const currentLevelFolders = filter(folders, (folder: TreeViewModel) => folder.ParentFolderID === targetFolderId);
        const sameNameFolders = filter(
            currentLevelFolders,
            (folder: TreeViewModel) => folder.FolderName.toLowerCase() === selectedFolderName.toLowerCase(),
        );
        return sameNameFolders.length > 0;
    };

    /**
     * Method to check if the folder is dragged and dropped under the same folder
     *
     * @param {string} sourceFilePath
     * @param {string} targetFilePath
     * @memberof RowDragHelper
     */
    public areFolderPathsEqual = (sourceFilePath: Array<string>, targetFilePath: Array<string>): boolean => {
        if (sourceFilePath.length !== targetFilePath.length) {
            return false;
        }
        let isEqual = true;
        forEach(sourceFilePath, (item, index) => {
            if (targetFilePath[index] !== item) {
                isEqual = false;
            }
        });
        return isEqual;
    };

    /**
     * Moving draagging folder into new Parent Folder
     *
     * @param {Array<string>} newParentPath
     * @param {RowNode} node
     * @param {Array<TreeViewModel>} allUpdatedNodes
     * @memberof RowDragHelper
     */
    public moveToPath(newParentPath: Array<string>, node: RowNode, allUpdatedNodes: Array<TreeViewModel>): void {
        const rowNode = node;

        const oldPath = rowNode.data.filePath;
        const fileName = oldPath[oldPath.length - 1];
        const newChildPath = [...newParentPath];
        newChildPath.push(fileName);

        rowNode.data.filePath = newChildPath;
        allUpdatedNodes.push(rowNode.data);

        if (rowNode.childrenAfterGroup) {
            forEach(rowNode.childrenAfterGroup, (childNode: RowNode) => {
                this.moveToPath(newChildPath, childNode, allUpdatedNodes);
            });
        }
    }

    /**
     * Method to get invalid access info
     * @param {ExperimentAccessResponseModel} accessInfo
     * @returns { value: boolean; errorMessage: string }
     * @memberof RowDragHelper
     */
    public static getInvalidAccessInfo(accessInfo: ExperimentAccessResponseModel): { value: boolean; errorMessage: string } {
        let isValid;
        if (accessInfo?.AccessDetail[0]?.Ownership !== PERMISSION_CATEGORY_CONSTANT.CREATOR) {
            isValid = { value: false, errorMessage: ROW_DRAG_MESSAGE.OTHER_USER_EXPERIMENT };
        } else if (accessInfo?.AccessDetail[0]?.Lock === PERMISSION_CATEGORY_CONSTANT.LOCKED) {
            isValid = { value: false, errorMessage: ROW_DRAG_MESSAGE.LOCKED_EXPERIMENT };
        }
        return isValid;
    }
}
