import { GridOptions, GetRowIdParams, IRowDragItem, ColDef, RowNode, CellContextMenuEvent } from "@ag-grid-community/core";
import { Injectable } from "@angular/core";
import { GRID_APPLY_COLUMN, RESTRICTED_ACCESS_GRID_APPLY_COLUMN } from "@te-shared/constants/tree-view.constant";

@Injectable()
export class AgGridConfigHelper {
    /**
     * Default configuration fields for the columns in the ag grid
     *
     * @memberof AgGridConfigHelper
     */
    public static getDefaultColumnDefinition(): ColDef {
        return {
            resizable: true,
            editable: true,
            sortable: false,
            enableCellChangeFlash: false,
            lockPinned: true,
            filter: true,
            suppressMenu: true,
        };
    }

    /**
     * Default configuration fields for the columns in the ag grid
     *
     * @memberof AgGridConfigHelper
     */
    public static getDefaultColumnDefinitionSearchIPC(): ColDef {
        return {
            resizable: false,
            editable: false,
            sortable: true,
            enableCellChangeFlash: false,
            lockPinned: true,
            filter: true,
            suppressMenu: true,
        };
    }

    /**
     * Default configuration fields for the columns in the ag grid for bom view report
     *
     * @memberof AgGridConfigHelper
     */
    public static getBomReportColumnDefinition(): ColDef {
        return {
            resizable: true,
            editable: false,
            sortable: false,
            enableCellChangeFlash: false,
            lockPinned: true,
            filter: false,
            suppressMenu: true,
        };
    }

    /**
     *
     *
     * @static
     * @return {*}  {ColDef}
     * @memberof AgGridConfigHelper
     */
    public static getUnapprovedColumnDefinition(): ColDef {
        return {
            editable: false,
            resizable: true,
            sortable: true,
            filter: true,
            flex: 1,
            lockPosition: true,
        };
    }

    /**
     * Default configuration fields for the ag grid experiment list columns
     *
     * @memberof AgGridConfigHelper
     */
    public static getDefaultExperimentListColumnDefinition(): ColDef {
        return { sortable: true, filter: false };
    }

    /**
     * Default configuration fields for the ag grid variant columns
     *
     * @memberof AgGridConfigHelper
     */
    public static getProductVariantColumnDefinition(): ColDef {
        return {
            sortable: false,
            editable: false,
            lockPosition: true,
            filter: true,
            menuTabs: ["filterMenuTab"],
        };
    }

    /**
     * Returns the grid options for the editor and makes provision for aligned grid
     *
     * @memberof AgGridConfigHelper
     */
    public static getEditorGridOptions(defaultColDefinition: ColDef): GridOptions {
        return {
            animateRows: true,
            treeData: true,
            getDataPath: (data) => data.hierarchyExpFormulaID,
            singleClickEdit: true,
            allowContextMenuWithControlKey: true,
            stopEditingWhenCellsLoseFocus: true,
            suppressDragLeaveHidesColumns: true,
            excludeChildrenWhenTreeDataFiltering: true,
            alignedGrids: [],
            defaultColDef: defaultColDefinition,
            isRowSelectable: (rowNode: RowNode) => rowNode.level === 0,
            getRowId: (parameters: GetRowIdParams) => parameters.data.hierarchyExpFormulaID.join("_"),
            groupDefaultExpanded: 0,
            onCellContextMenu: (parameters: CellContextMenuEvent) => {
                if (parameters?.node?.level > 0) {
                    parameters.api.hidePopupMenu();
                    parameters.api.deselectAll();
                }
            },
        };
    }

    /**
     * Returns the grid options for the footer and makes provision for aligned grid
     *
     * @memberof AgGridConfigHelper
     */
    public static getFooterGridOptions(defaultColDefinition: ColDef): GridOptions {
        return {
            alignedGrids: [],
            getRowId: (parameters: GetRowIdParams) => parameters.data.footerType,
            defaultColDef: defaultColDefinition,
        };
    }

    /**
     * Default configuration fields for the columns in the ag grid
     * @param iconComponentToBeRendered
     * @memberof AgGridConfigHelper
     */
    public static getAutoGroupColumnDefinition(iconComponentToBeRendered): ColDef {
        return {
            editable: false,
            cellRendererParams: {
                checkbox: false,
                suppressCount: true,
                innerRenderer: iconComponentToBeRendered,
            },
            rowDragText: (parameter: IRowDragItem) => parameter.rowNode.data.FolderName,
        };
    }

    public static getFoldersDefaultColDef(): ColDef[] {
        return [
            {
                field: GRID_APPLY_COLUMN.state[0].colId,
                hide: true,
                comparator: (folderNameA: string, folderNameB: string) =>
                    folderNameA.toLowerCase().localeCompare(folderNameB.toLowerCase()),
            },
        ];
    }

    public static getRestrictedAccessDefaultColDef(): ColDef[] {
        return [
            {
                field: RESTRICTED_ACCESS_GRID_APPLY_COLUMN.state[0].colId,
                hide: true,
                comparator: (nameA: string, nameB: string) => nameA.toLowerCase().localeCompare(nameB.toLowerCase()),
            },
        ];
    }

    /**
     * Default configuration fields for the columns in the ag grid
     *
     * @memberof AgGridConfigHelper
     */
    public static getDefaultColumnDefinitionForCG(): ColDef {
        return {
            resizable: false,
            editable: false,
            sortable: false,
            enableCellChangeFlash: false,
            lockPinned: false,
            filter: false,
            suppressMenu: false,
        };
    }
}
