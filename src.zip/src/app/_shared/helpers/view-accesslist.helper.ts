import { Injectable } from "@angular/core";
import { RestrictedUsageAccessList, RestrictedUsageListTreeView } from "@te-shared/components/product-data/models/product-data.model";
import { RESTRICTED_USER_GROUP_OR_SINGLE } from "@te-shared/components/product-data/product-data-constant";
import { filter, find, forEach } from "lodash";

@Injectable()
export class ViewAccessListHelper {
    /**
     * Method to get security group names
     *
     * @param {RestrictedUsageAccessList[]} restrictedUseValues
     * @memberof ViewAccessListHelper
     */
    public static getSecurityGroupNames(restrictedUseValues: RestrictedUsageAccessList[]): Array<string> {
        const groupNames = filter(
            restrictedUseValues,
            (list) => list?.restricteduseoverride?.toUpperCase() === RESTRICTED_USER_GROUP_OR_SINGLE.RESTRICTED_USER_ACCESS_LIST_GROUP,
        );
        return groupNames.map((group) => group?.accessgiven);
    }

    /**
     * Method to get view access list users
     *
     * @param {RestrictedUsageAccessList[]} restrictedUseValues
     * @memberof ViewAccessListHelper
     */
    public static getAccessListUsers(restrictedUseValues: RestrictedUsageAccessList[]): Array<string> {
        const userIds = filter(
            restrictedUseValues,
            (list) => list?.restricteduseoverride?.toUpperCase() === RESTRICTED_USER_GROUP_OR_SINGLE.RESTRICTED_USER_ACCESS_LIST_SINGLE,
        );
        return userIds.map((group) => group?.accessgiven);
    }

    /**
     * Method to create filepath for view access list
     *
     * @param {RestrictedUsageListTreeView[]} accessList
     * @memberof ViewAccessListHelper
     */
    public static createTreeStructure(accessList: RestrictedUsageListTreeView[]): void {
        forEach(accessList, (data: RestrictedUsageListTreeView) => {
            if (!data) return;
            const restrictedGroup = data;
            const restrictedGroupCode = [];
            restrictedGroupCode.push(restrictedGroup?.flagGroupCode);
            const parentGroupCode = [];
            if (restrictedGroup?.parentFlagGroupCode) {
                const datas = this.getParentFlagCode(accessList, restrictedGroup, parentGroupCode);
                restrictedGroupCode.push(...datas);
                restrictedGroup.filePath = restrictedGroupCode.reverse();
            } else {
                restrictedGroup.filePath = [restrictedGroup?.flagGroupCode];
            }
        });
    }

    /**
     * Method to find parent flag codes
     * @param { RestrictedUsageListTreeView[] } restrictedGroups
     * @param { RestrictedUsageListTreeView } restrictedGroup
     * @param { Array<string> } parentFlagGroup
     * @returns {Array<string>}
     * @memberof ViewAccessListHelper
     */
    public static getParentFlagCode(
        restrictedGroups: RestrictedUsageListTreeView[],
        restrictedGroup: RestrictedUsageListTreeView,
        parentFlagGroup: Array<string>,
    ): Array<string> {
        const parentFolder = find(restrictedGroups, (folder) => folder?.flagGroupCode === restrictedGroup?.parentFlagGroupCode);
        parentFlagGroup.push(parentFolder ? parentFolder?.flagGroupCode : restrictedGroup?.parentFlagGroupCode.toUpperCase());
        if (!parentFolder?.parentFlagGroupCode) {
            return parentFlagGroup;
        }
        return this.getParentFlagCode(restrictedGroups, parentFolder, parentFlagGroup);
    }
}
