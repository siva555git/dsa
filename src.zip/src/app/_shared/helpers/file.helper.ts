import { Injectable } from "@angular/core";
import { AppBroadCastService } from "@te-services/index";
import { EMPTY } from "src/app/app.constant";
import * as XLSX from "xlsx";

@Injectable()
export class FileHelper {
    constructor(private appBoardCastService: AppBroadCastService) {}

    /**
     * Method to read excel file
     * @param files
     * @returns {void}
     * @memberof FileHelper
     */
    public readExcelFile(files): void {
        const file = files;
        const fileReader = new FileReader();
        fileReader.readAsArrayBuffer(file);
        fileReader.addEventListener("load", () => {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const arrayBuffer: any = fileReader.result;
            const data = new Uint8Array(arrayBuffer);
            const array = [];
            for (let index = 0; index !== data.length; index += 1) {
                // eslint-disable-next-line unicorn/prefer-code-point
                array[index] = String.fromCharCode(data[index]);
            }
            const bstr = array.join(EMPTY);
            const workbook = XLSX.read(bstr, { type: "binary" });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const arraylist = XLSX.utils.sheet_to_json(worksheet, { raw: true });
            this.appBoardCastService.uploadedExcelFileInfo(arraylist);
        });
    }

    /**
     * Method to read text file
     * @param files
     * @returns {void}
     * @memberof FileHelper
     */
    public readTextFile(files): void {
        const file = files;
        // eslint-disable-next-line @typescript-eslint/no-this-alias, unicorn/no-this-assignment
        const self = this;
        const fileReader: FileReader = new FileReader();
        // eslint-disable-next-line id-length, func-names, @typescript-eslint/no-unused-vars
        fileReader.onloadend = function (x) {
            const fileContent = fileReader.result;
            self.appBoardCastService.uploadedTextFileInfo(fileContent);
        };
        fileReader.readAsText(file);
    }
}
