/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-lines-per-function */
import { TestBed, waitForAsync } from "@angular/core/testing";
import { EditionSuggesstionHelper } from "@te-experiment-editor/helpers/edition-suggesstion.helper";
import { EDITION_SUGGESTION_ACTION_IN } from "@te-shared/constants";
import { MockEditionSuggestionHelper } from "@te-testing/mock-edition-suggestion.helper";
import { MiniEditorSuggestionHelper } from "./mini-editor-suggestion.helper";

describe("MiniEditorSuggestionHelper", () => {
    let service: MiniEditorSuggestionHelper;

    beforeEach(waitForAsync(() =>
        TestBed.configureTestingModule({
            providers: [{ provide: EditionSuggesstionHelper, useClass: MockEditionSuggestionHelper }],
        })));

    beforeEach(() => {
        service = TestBed.inject(MiniEditorSuggestionHelper);
    });

    it("should create", () => {
        expect(service).toBeTruthy();
    });

    it("should resolve triggerEditSuggestPopup if experimentFormula ID is there", () => {
        const produtRow = {
            SUBCode: "00011002",
            ExpFormulaID: "103238",
            parentAttribute: [],
            suggestedBom: {
                CreatedBy: 44_991,
                ExpFormulaID: "103238",
                ExpID: 63_353_795,
                FormulaSeq: 20,
                // eslint-disable-next-line unicorn/no-null
                Instruction: null,
                IsDelete: 0,
                Parts: 45,
                SUBCode: "00011002",
            },
            activeExpPlantId: "JAFL",
            isSolution: false,
            isFema: true,
        };
        const gridData = {
            activeExperiment: {
                ExpCode: "RXR00214AA",
                ExpID: 63_353_795,
                ExpName: "Combine #1 from RXR00212AA",
                ExpSource: "C",
                type: "",
                PlantID: "JAFL",
            },
            type: 0,
            bomDetail: {
                Experiments: [
                    {
                        ExpCode: "RXR00214AA",
                        ExpID: 63_353_795,
                        ExpName: "Combine #1 from RXR00212AA",
                    },
                ],
            },
            attributes: [
                {
                    ipc: "10811975",
                },
            ],
        };
        const spy = spyOn(service, "triggerEditSuggestPopup").and.callThrough();
        service.triggerEditSuggestPopup(produtRow as any, gridData, 3, EDITION_SUGGESTION_ACTION_IN.MINI_EDITIOR);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve triggerEditSuggestPopup if experimentFormula ID is empty", () => {
        const produtRow = {
            SUBCode: "00011002",
            ExpFormulaID: "",
            parentAttribute: [],
            suggestedBom: {
                CreatedBy: 44_991,
                ExpFormulaID: "",
                ExpID: 63_353_795,
                FormulaSeq: 20,
                // eslint-disable-next-line unicorn/no-null
                Instruction: null,
                IsDelete: 0,
                Parts: 45,
                SUBCode: "00011002",
            },
            activeExpPlantId: "JAFL",
            isSolution: false,
            isFema: true,
        };
        const gridData = {
            activeExperiment: {
                ExpCode: "RXR00214AA",
                ExpID: 63_353_795,
                ExpName: "Combine ",
                ExpSource: "C",
                type: "",
                PlantID: "JAFL",
            },
            type: 0,
            bomDetail: {
                Experiments: [
                    {
                        ExpCode: "RXR00214AA",
                        ExpID: 63_353_795,
                        ExpName: "Combine",
                    },
                ],
            },
        };
        const spy = spyOn(service, "triggerEditSuggestPopup").and.callThrough();
        service.triggerEditSuggestPopup(produtRow as any, gridData, 4, EDITION_SUGGESTION_ACTION_IN.MINI_EDITIOR);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve doesSolutionAndFemaExist", () => {
        const attribute: any = {
            otherdetails: {
                solutions: [
                    {
                        concentration: 0.0001,
                        ipc: "00159000",
                        materialdescription: "OXYPHENYLON",
                        materialipc: "00159000",
                        materialparts: 0.1,
                        solutionipc: "00150363",
                        solutiontype: "d",
                        solventipc: "00058604",
                    },
                    {
                        concentration: 0.0001,
                        ipc: "00159000",
                        materialdescription: "OXYPHENYLON",
                        materialipc: "00159000",
                        materialparts: 0.1,
                        solutionipc: "00150363",
                        solutiontype: "d",
                        solventipc: "00058604",
                    },
                ],
                specs: [
                    {
                        displayvalue: "774005",
                        locked: true,
                        lockedby: "DSB3117",
                        lockedon: "2001-12-13T22:59:17.030Z",
                        origuomcode: "NONE",
                        origvalue1: undefined,
                        origvalue2: undefined,
                        presentationstyle: 1,
                        speccode: "BBA IPC",
                    },
                    {
                        displayvalue: "CLEAN FINE CRYSTALS",
                        locked: true,
                        lockedby: "RJG0215",
                        lockedon: "1996-01-27T09:05:29.000Z",
                        origuomcode: "NONE",
                        origvalue1: 0,
                        origvalue2: 0,
                        presentationstyle: 1,
                        speccode: "APPEARANCE",
                    },
                ],
            },
        };
        spyOn(MiniEditorSuggestionHelper, "doesSolutionAndFemaExist").and.callThrough();
        MiniEditorSuggestionHelper.doesSolutionAndFemaExist(attribute);
        expect(MiniEditorSuggestionHelper.doesSolutionAndFemaExist).toHaveBeenCalled();
    });
});
