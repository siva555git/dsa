export enum UserStatus {
    ACTIVE = "ACTIVE",
    DISABLED = "DISABLED",
    UNKNOWN = "UNKNOWN",
    NOT_FOUND = "NOT FOUND",
    UN_AUTHORIZED = "UN AUTHORIZED",
}
