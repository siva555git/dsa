export enum SUBTypes {
    EXPERIMENT = "E",
    PRODUCT = "I",
    INSTRUCTION = "N",
    UNAPPROVED = "U",
}

export enum ColumnLayouts {
    COST_PER_KG = "CostPerKg",
    COST_PER_PARTS = "CostPerParts",
    COST_CONTRIBUTION = "CostContribution",
    FLAG = "Flag",
    SPEC = "Spec",
    PRODUCT_TYPE = "prodtypecode",
    STOCK = "Stock",
    CC_INDICATOR = "CC Indicator",
    TRUSTEE = "trustee",
    PARTS = "Parts %",
    PARTS_PERENTAGE = "PartsPercentage",
    TECHNOLOGY = "technology",
    PLANT_ALLOCATION = "Plant Allocation",
    DIVISION = "division",
}
