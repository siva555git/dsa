export enum ExperimentFolderExpanded {
    IS_NOT_EXPANDED = "0",
    IS_EXPANDED = "1",
}

export enum ExperimentFolderShared {
    IS_NOT_SHARED = "0",
    IS_SHARED = "1",
}

export enum ExperimentFolderChild {
    HAS_NO_CHILD = "0",
    HAS_CHILD = "1",
}

export enum ExperimentFolderSelected {
    IS_NOT_SELECTED = "0",
    IS_SELECTED = "1",
}

export enum ExperimentFolderDefault {
    IS_NOT_DEFAULT = "0",
    IS_DEFAULT = "1",
}
