/* eslint-disable max-lines-per-function */
/* eslint-disable @typescript-eslint/no-empty-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { mockCellRenderer } from "../../../testing/mock-bom-view-data";
import { DatetimeCellRendererComponent } from "./datetime-cell-renderer.component";

describe("DatetimeCellRendererComponent", () => {
    let component: DatetimeCellRendererComponent;
    let fixture: ComponentFixture<DatetimeCellRendererComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [DatetimeCellRendererComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DatetimeCellRendererComponent);
        component = fixture.componentInstance;
        component.params = mockCellRenderer;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call agInit", () => {
        const spy = spyOn(component, "agInit").and.callThrough();
        component.agInit(fixture.componentInstance.params);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on refresh", () => {
        const spy = spyOn(component, "refresh").and.callThrough();
        component.refresh();
        expect(spy).toHaveBeenCalled();
    });
});
