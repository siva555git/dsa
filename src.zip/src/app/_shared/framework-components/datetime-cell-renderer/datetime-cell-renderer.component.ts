// eslint-disable-next-line import/no-extraneous-dependencies
import { ICellRendererParams } from "@ag-grid-community/core";
import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "@ag-grid-community/angular";
import { COMPOUND_NAMES_FOR_RENDERER } from "@te-shared/constants";
import * as moment from "moment";

@Component({
    selector: "app-datetime-cell-renderer",
    templateUrl: "./datetime-cell-renderer.component.html",
    host: { class: "datetimeCellGrid" },
})
export class DatetimeCellRendererComponent implements ICellRendererAngularComp {
    public params: ICellRendererParams;

    public date: string;

    public parentComponentName: string;

    public componentNames = COMPOUND_NAMES_FOR_RENDERER;

    public agInit(parameters: ICellRendererParams): void {
        this.params = parameters;
        this.date = this.params.value;
        if (this.date && this.parentComponentName === this.componentNames.UNAPPROVED) {
            this.date = moment(this.date).format();
        }
        this.parentComponentName = this.params?.context?.componentParent?.parentComponentName;
    }

    /**
     * Method to refresh the ag grid cell
     *
     * @returns {boolean}
     * @memberof DatetimeCellRendererComponent
     */
    // eslint-disable-next-line class-methods-use-this
    public refresh(): boolean {
        return false;
    }
}
