import { ICellRendererAngularComp } from "@ag-grid-community/angular";
import { ICellRendererParams } from "@ag-grid-community/core";
import { Component } from "@angular/core";

@Component({
    selector: "app-tooltip-cell-renderer",
    templateUrl: "./tooltip-cell-renderer.component.html",
    styleUrls: ["./tooltip-cell-renderer.component.scss"],
})
export class TooltipCellRendererComponent implements ICellRendererAngularComp {
    public params: ICellRendererParams;

    public agInit(parameters: ICellRendererParams): void {
        this.params = parameters;
    }

    /**
     * Method to refresh the ag grid cell
     *
     * @returns {boolean}
     * @memberof DatetimeCellRendererComponent
     */
    public refresh(): boolean {
        return false;
    }
}
