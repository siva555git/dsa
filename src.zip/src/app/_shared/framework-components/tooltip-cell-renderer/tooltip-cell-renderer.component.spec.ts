import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ICellRendererParams } from "@ag-grid-community/core";
import { TooltipCellRendererComponent } from "./tooltip-cell-renderer.component";
import { MatTooltipModule } from "@angular/material/tooltip";

describe("TooltipCellRendererComponent", () => {
    let component: TooltipCellRendererComponent;
    let fixture: ComponentFixture<TooltipCellRendererComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [TooltipCellRendererComponent],
            imports: [MatTooltipModule]
        }).compileComponents();

        fixture = TestBed.createComponent(TooltipCellRendererComponent);
        component = fixture.componentInstance;
        component.params = {} as ICellRendererParams;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
    
    it("should call agInit", () => {
        const spy = spyOn(component, "agInit").and.callThrough();
        component.agInit(fixture.componentInstance.params);
        expect(spy).toHaveBeenCalled();
    });
    
    it("should call refresh", () => {
        const spy = spyOn(component, "refresh").and.callThrough();
        const result = component.refresh();
        expect(spy).toHaveBeenCalled();
        expect(result).toBe(false)
    });
});
