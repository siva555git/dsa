import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { EventEmitter } from "events";

import { NoRowsOverlayComponent } from "./no-rows-overlay.component";

describe("NoRowsOverlayComponent", () => {
    let component: NoRowsOverlayComponent;
    let fixture: ComponentFixture<NoRowsOverlayComponent>;
    const parameters = {
        componentParent: {
            createExpToggle: new EventEmitter(),
            selectedFolderID: 1,
            getNoResultOverlayDetails: () => {
                return { noData: true };
            },
        },
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [NoRowsOverlayComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NoRowsOverlayComponent);
        component = fixture.componentInstance;
        component.params = {
            componentParent: {
                createExpToggle: new EventEmitter(),
            },
        };
        component.params = parameters;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call agInit", () => {
        const spy = spyOn(component, "agInit").and.callThrough();
        component.agInit(fixture.componentInstance.params);
        expect(spy).toHaveBeenCalled();
    });
});
