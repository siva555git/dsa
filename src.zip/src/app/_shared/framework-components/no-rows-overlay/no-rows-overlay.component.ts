import { Component } from "@angular/core";
import { INoRowsOverlayParams } from "@ag-grid-community/core";
import { INoRowsOverlayAngularComp } from "@ag-grid-community/angular";
import { COMPOUND_NAMES_FOR_RENDERER } from "@te-shared/constants";

@Component({
    selector: "app-no-rows-overlay",
    templateUrl: "./no-rows-overlay.component.html",
})
export class NoRowsOverlayComponent implements INoRowsOverlayAngularComp {
    public params;

    public parentComponentName: string;

    public componentNames = COMPOUND_NAMES_FOR_RENDERER;

    agInit(parameters: INoRowsOverlayParams): void {
        this.params = parameters;
        this.parentComponentName = this.params?.context?.componentParent?.parentComponentName;
    }
}
