/* eslint-disable max-lines-per-function */
/* eslint-disable @typescript-eslint/no-empty-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { AppDataService } from "../../../_services";
import { MockAppDataService } from "../../../testing/mock-app.data.service";

import { UsernameCellRendererComponent } from "./username-cell-renderer.component";

describe("UsernameCellRendererComponent", () => {
    let component: UsernameCellRendererComponent;
    let fixture: ComponentFixture<UsernameCellRendererComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [UsernameCellRendererComponent],
            providers: [{ provide: AppDataService, useClass: MockAppDataService }],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UsernameCellRendererComponent);
        component = fixture.componentInstance;
        component.params = {
            data: {
                UserName: "AAA XXX",
                GlobalUserID: "0111",
            },
            context: {
                componentParent: {},
            },
        };
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call agInit", () => {
        const spy = spyOn(component, "agInit").and.callThrough();
        component.agInit(fixture.componentInstance.params);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on refresh", () => {
        const spy = spyOn(component, "refresh").and.callThrough();
        component.refresh();
        expect(spy).toHaveBeenCalled();
    });
});
