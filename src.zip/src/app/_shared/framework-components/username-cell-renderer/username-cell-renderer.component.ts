// eslint-disable-next-line import/no-extraneous-dependencies
import { ICellRendererParams } from "@ag-grid-community/core";
import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "@ag-grid-community/angular";
import { COMPOUND_NAMES_FOR_RENDERER } from "@te-shared/constants/common.constant";
import { AppDataService } from "../../../_services";
import { UserProfileModel } from "../../master-data/models/profile-picture.model";

@Component({
    selector: "app-username-cell-renderer",
    templateUrl: "./username-cell-renderer.component.html",
})
export class UsernameCellRendererComponent implements ICellRendererAngularComp {
    constructor(public appDataService: AppDataService) {}

    public params;

    public userDetails: UserProfileModel;

    agInit(parameters: ICellRendererParams): void {
        this.params = parameters;
        const parentComponent = parameters.context.componentParent.parentComponentName;
        let userDetails;
        if (parentComponent === COMPOUND_NAMES_FOR_RENDERER.BOM_VIEW_REPORT) {
            userDetails = {
                name: parameters?.data?.UserName,
                globalUserID: parameters?.data?.GlobalUserID,
            };
        } else if (parentComponent === COMPOUND_NAMES_FOR_RENDERER.UNAPPROVED) {
            userDetails = {
                name: `${parameters?.data?.CreatedByUser?.FirstName} ${parameters?.data?.CreatedByUser?.Surname}`,
                globalUserID: parameters?.data?.CreatedByUser?.GlobalUserID,
            };
        }
        this.userDetails = userDetails;
    }

    // eslint-disable-next-line class-methods-use-this
    refresh(): boolean {
        return false;
    }
}
