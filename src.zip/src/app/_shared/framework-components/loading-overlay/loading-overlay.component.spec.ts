import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
// eslint-disable-next-line import/no-extraneous-dependencies
import { ILoadingOverlayParams } from "@ag-grid-community/core";
import { LoadingOverlayComponent } from "./loading-overlay.component";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

describe("LoadingOverlayComponent", () => {
    let component: LoadingOverlayComponent;
    let fixture: ComponentFixture<LoadingOverlayComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [LoadingOverlayComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LoadingOverlayComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call agInit", () => {
        const spy = spyOn(component, "agInit").and.callThrough();
        const parameters = {} as ILoadingOverlayParams;
        component.agInit(parameters);
        expect(spy).toHaveBeenCalled();
    });
});
