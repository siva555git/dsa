import { Component } from "@angular/core";
import { ILoadingOverlayParams } from "@ag-grid-community/core";
import { ILoadingOverlayAngularComp } from "@ag-grid-community/angular";

@Component({
    selector: "app-loading-overlay",
    templateUrl: "./loading-overlay.component.html",
    host: { class: "w-100 d-flex align-items-center" },
})
export class LoadingOverlayComponent implements ILoadingOverlayAngularComp {
    public params;

    agInit(parameters: ILoadingOverlayParams): void {
        this.params = parameters;
    }
}
