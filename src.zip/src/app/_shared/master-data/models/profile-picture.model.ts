export interface UserProfileModel {
    name?: string;
    photoUrl?: string;
    globalUserId?: string;
    width?: number;
    height?: number;
    isUpperCase?: boolean;
    GlobalUserID?: string;
    displayName?: boolean;
    globalUserID?: string;
    department?: string;
    regionName?: string;
    firstName?: string;
    surName?: string;
    isdisplayDetail?: boolean;
    fullname?: string;
    FirstName?: string;
    Surname?: string;
    globaluserid?: string;
    position?: string;
}
