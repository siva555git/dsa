export interface UOMDetailsModel {
    uomid: number;
    uomcode: string;
    uomdisplay: string;
    conversionfactor: number;
    description: string;
    IsCommon: number;
    CreatedBy: string;
    CreatedOn: Date;
    UpdatedBy: string;
    UpdatedOn: Date;
    uomtype: string;
}
