export interface InstructionModel {
    InstructionID?: number;
    CategoryName: string;
    CostBookCode: string;
    CreatedBy: number;
    CreatedOn: Date;
    Description: string;
    IsActive: string;
    SortCode: string;
    UpdatedBy: number;
    UpdatedOn: Date;
}

export interface EditInstructionModel {
    Description: string;
    CategoryName: string;
    SortCode: string;
    InstructionID: number;
}

export interface CreateInstructionModel {
    Description: string;
    CategoryName: string;
    SortCode: string;
}
