/* eslint-disable @typescript-eslint/no-explicit-any */

export interface SpecsModel {
    comment: string;
    description: string;
    sortcode: string;
    speccode: string;
}
