/* eslint-disable @typescript-eslint/no-explicit-any */

export interface FlagsModel {
    flagcode: string;
    description: any;
}
