/* eslint-disable @typescript-eslint/no-explicit-any */

export interface FlavorClassesModel {
    id: number;
    name: string;
}
