export interface MasterDataModel {
    flavorTypes: [];
    productTypes: [];
    facilities: [];
    plantsAndSources: [];
    costs: [];
    specs: [];
    flags: [];
    cbwflags: [];
    flavorClasses: [];
    currencies: [];
    currenciesRate: [];
    uomDetails: [];
    technology: [];
}

export interface DuplicationCheckModel {
    nameKey: string;
    idKey: string;
    idValue: number;
}
