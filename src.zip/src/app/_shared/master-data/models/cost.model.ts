/* eslint-disable @typescript-eslint/no-explicit-any */

export interface CostModel {
    active: boolean;
    costbookcode: string;
    countrycode: string;
    currencycode: string;
    createdby: string;
    createdon: Date;
    updatedon: Date;
    description: string;
    updatedby: string;
}
