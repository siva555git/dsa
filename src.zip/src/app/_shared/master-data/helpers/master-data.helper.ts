/* eslint-disable @typescript-eslint/no-explicit-any */

import { Injectable } from "@angular/core";
import { DEFAULT_MASTER_DATA_COUNT } from "@te-shared/constants";
import { NGXLogger } from "ngx-logger";
import { Observable } from "rxjs";
import { AppCacheHelper } from "../../helpers/app-cache.service";
import { MasterDataModel } from "../models/master-data.model";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";

@Injectable()
export class MasterDataHelper {
    constructor(private readonly appCacheHelper: AppCacheHelper,
         private readonly logger: NGXLogger,
         private readonly securityHelper: SecurityHelper
    ) {}

    /**
     * Method to check the default data are in store or not , if not fetch it from API
     * @memberof MasterDataHelper
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public checkAndFetchDefaultData(requiredtypes: string[]): Observable<any> {
        const requiredMasterData = {};
        let mdrResponse: MasterDataModel;
        return new Observable((observer) => {
            this.appCacheHelper.getDefaultDataStoreCount().subscribe({
                next: (responses) => {
                    this.appCacheHelper.getDefaultData(responses).subscribe({
                        next: (response) => {
                            if (response && response.length === DEFAULT_MASTER_DATA_COUNT) {
                                mdrResponse = {
                                    flavorTypes: response[0],
                                    productTypes: this.securityHelper.hasPermission(APPLICATION_PERMISSIONS.ENCAPSULATION_PERMISSION) === false ?
                                     response[1] : response[1].flat(1).filter((e, i) => response[1].flat(1).findIndex(a => a.prodtypecode === e.prodtypecode) === i),
                                    facilities: response[2],
                                    plantsAndSources: response[3],
                                    costs: response[4],
                                    specs: response[5],
                                    flags: response[6]?.filter((flag) => flag.CBW === "N" || !flag.CBW),
                                    cbwflags: response[6]?.filter((flag) => flag.CBW === "Y"),
                                    flavorClasses: response[7],
                                    currencies: response[8],
                                    currenciesRate: response[9],
                                    uomDetails: response[10],
                                    technology: response[11],
                                };
                                requiredtypes.forEach((key) => {
                                    requiredMasterData[key] = mdrResponse[key];
                                });
                                observer.next(requiredMasterData);
                                observer.complete();
                            }
                        },
                        error: (error) => {
                            this.logger.error(error);
                        },
                    });
                },
                error: (error) => {
                    this.logger.error(error);
                },
            });
        });
    }
      /**
     * Method to get the default data
     * @memberof MasterDataHelper
     */

      public getDefaultData(RequiredTypes): object {
        return this.checkAndFetchDefaultData(RequiredTypes).subscribe({
              next: (response) => {
                  if (!response) {
                      return;
                  }
                  return response;
              },
              error: (error) => {
                  this.logger.error(error);
              },
          });
    }
}
