import { createFeatureSelector, createSelector } from "@ngrx/store";
import { costsAdapter } from "../adapter/cost.adapter";
import { CostBookState } from "../state/cost.state";
import * as fromActions from "../actions/cost.actions";

export const initialState: CostBookState = costsAdapter.getInitialState({
    // eslint-disable-next-line unicorn/no-null
    selectedCostBookCode: null,
});
// eslint-disable-next-line default-param-last
export function reducer(state = initialState, action: fromActions.COST_ACTIONS): CostBookState {
    switch (action.type) {
        case fromActions.CostsActionTypes.LOAD_ALL_COST: {
            return costsAdapter.upsertMany(action.payload.cost, state);
        }
        case fromActions.CostsActionTypes.SELECT_COST: {
            // eslint-disable-next-line prefer-object-spread
            return Object.assign({ ...state });
        }
        default: {
            return state;
        }
    }
}

export const getCostState = createFeatureSelector<CostBookState>("costBookState");

export const selectCostIds = createSelector(getCostState, costsAdapter.getSelectors().selectIds);
export const selectCostEntities = createSelector(getCostState, costsAdapter.getSelectors().selectEntities);
export const selectAllCost = createSelector(getCostState, costsAdapter.getSelectors().selectAll);
export const costCount = createSelector(getCostState, costsAdapter.getSelectors().selectTotal);

export const selectCosts = createSelector(
    selectCostEntities,
    // eslint-disable-next-line unicorn/prevent-abbreviations
    (costEntities) => costEntities,
);
