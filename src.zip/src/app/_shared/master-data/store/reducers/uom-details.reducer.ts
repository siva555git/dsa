import { createFeatureSelector, createSelector } from "@ngrx/store";
import * as fromActions from "../actions/uom-details.actions";
import { uomDetailsAdapter } from "../adapter/uom-details.adapter";

import { UOMDetailsState } from "../state/uom-details.state";

export const initialState: UOMDetailsState = uomDetailsAdapter.getInitialState({
    // eslint-disable-next-line unicorn/no-null
    selectedUomId: null,
});
// eslint-disable-next-line default-param-last
export function reducer(state = initialState, action: fromActions.UOM_DETAILS): UOMDetailsState {
    switch (action.type) {
        case fromActions.UOMActionTypes.LOAD_ALL_UOM: {
            return uomDetailsAdapter.upsertMany(action.payload.uomDetails, state);
        }
        case fromActions.UOMActionTypes.SELECT_UOM: {
            // eslint-disable-next-line prefer-object-spread
            return Object.assign({ ...state });
        }
        default: {
            return state;
        }
    }
}

export const getUomDetails = createFeatureSelector<UOMDetailsState>("uomDetailsState");

export const selectUOMIds = createSelector(getUomDetails, uomDetailsAdapter.getSelectors().selectIds);
export const selectUomEntities = createSelector(getUomDetails, uomDetailsAdapter.getSelectors().selectEntities);
export const selectAllUom = createSelector(getUomDetails, uomDetailsAdapter.getSelectors().selectAll);
export const uomCount = createSelector(getUomDetails, uomDetailsAdapter.getSelectors().selectTotal);

export const selectFacilities = createSelector(
    selectUomEntities,
    // eslint-disable-next-line unicorn/prevent-abbreviations
    (facilitiesEntities) => facilitiesEntities,
);
