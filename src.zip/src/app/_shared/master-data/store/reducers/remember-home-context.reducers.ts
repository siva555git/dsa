import { createFeatureSelector, createSelector } from "@ngrx/store";
import * as fromActions from "../actions/remember-home-context.actions";
import { rememberHomeContextAdapter } from "../adapter/remember-home-context.adapter";
import { RememberHomeContextState } from "../state/remember-home-context.state";

export const initialState: RememberHomeContextState = rememberHomeContextAdapter.getInitialState({
    // eslint-disable-next-line unicorn/no-null
    selectedFolderID: null,
});
// eslint-disable-next-line default-param-last
export function reducer(state = initialState, action: fromActions.REMEMBER_HOME_CONTEXT_ACTIONS): RememberHomeContextState {
    switch (action.type) {
        case fromActions.RememberHomeContextActionTypes.LOAD_ALL_REMEMBER_HOME_CONTEXT: {
            return rememberHomeContextAdapter.upsertMany(action.payload.homeContext, state);
        }
        case fromActions.RememberHomeContextActionTypes.SELECT_REMEMBER_HOME_CONTEXT: {
            // eslint-disable-next-line prefer-object-spread
            return Object.assign({ ...state });
        }
        default: {
            return state;
        }
    }
}

export const getRememberHomeContextState = createFeatureSelector<RememberHomeContextState>("rememberHomeContextState");

export const selectRememberHomeContextIds = createSelector(
    getRememberHomeContextState,
    rememberHomeContextAdapter.getSelectors().selectIds,
);
export const selectRememberHomeContextEntities = createSelector(
    getRememberHomeContextState,
    rememberHomeContextAdapter.getSelectors().selectEntities,
);
export const selectAllRememberHomeContext = createSelector(
    getRememberHomeContextState,
    rememberHomeContextAdapter.getSelectors().selectAll,
);
export const rememberHomeContextCount = createSelector(getRememberHomeContextState, rememberHomeContextAdapter.getSelectors().selectTotal);

export const selectRememberHomeContext = createSelector(
    selectRememberHomeContextEntities,
    // eslint-disable-next-line unicorn/prevent-abbreviations
    (rememberHomeContextEntities) => rememberHomeContextEntities,
);
