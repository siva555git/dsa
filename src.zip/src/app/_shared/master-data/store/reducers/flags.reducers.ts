import { createFeatureSelector, createSelector } from "@ngrx/store";
import * as fromActions from "../actions/flags.action";
import { FlagsState } from "../state/flags.state";
import { flagsAdapter } from "../adapter/flags.adapter";

export const initialState: FlagsState = flagsAdapter.getInitialState({
    // eslint-disable-next-line unicorn/no-null
    selectedFlagcode: null,
});
// eslint-disable-next-line default-param-last
export function reducer(state = initialState, action: fromActions.FLAGS_ACTIONS): FlagsState {
    switch (action.type) {
        case fromActions.FlagsActionTypes.LOAD_ALL_FLAGS: {
            return flagsAdapter.upsertMany(action.payload.flags, state);
        }
        case fromActions.FlagsActionTypes.SELECT_FLAGS: {
            // eslint-disable-next-line prefer-object-spread
            return Object.assign({ ...state });
        }
        default: {
            return state;
        }
    }
}

export const getFlagsState = createFeatureSelector<FlagsState>("flagsState");

export const selectFlagsIds = createSelector(getFlagsState, flagsAdapter.getSelectors().selectIds);
export const selectFlagsEntities = createSelector(getFlagsState, flagsAdapter.getSelectors().selectEntities);
export const selectAllFlags = createSelector(getFlagsState, flagsAdapter.getSelectors().selectAll);
export const flagsCount = createSelector(getFlagsState, flagsAdapter.getSelectors().selectTotal);

export const selectFlags = createSelector(
    selectFlagsEntities,
    // eslint-disable-next-line unicorn/prevent-abbreviations
    (flagsEntities) => flagsEntities,
);
