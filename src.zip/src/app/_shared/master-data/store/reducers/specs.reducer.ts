import { createFeatureSelector, createSelector } from "@ngrx/store";
import { specsAdapter } from "../adapter/specs.adapter";
import { SpecsState } from "../state/specs.state";
import * as fromActions from "../actions/specs.action";

export const initialState: SpecsState = specsAdapter.getInitialState({
    // eslint-disable-next-line unicorn/no-null
    selectedSpeccode: null,
});
// eslint-disable-next-line default-param-last
export function reducer(state = initialState, action: fromActions.SPECS_ACTIONS): SpecsState {
    switch (action.type) {
        case fromActions.SpecsActionTypes.LOAD_ALL_SPECS: {
            return specsAdapter.upsertMany(action.payload.specs, state);
        }
        case fromActions.SpecsActionTypes.SELECT_SPECS: {
            // eslint-disable-next-line prefer-object-spread
            return Object.assign({ ...state });
        }
        default: {
            return state;
        }
    }
}

export const getSpecsState = createFeatureSelector<SpecsState>("specsState");

export const selectSpecsIds = createSelector(getSpecsState, specsAdapter.getSelectors().selectIds);
export const selectSpecsEntities = createSelector(getSpecsState, specsAdapter.getSelectors().selectEntities);
export const selectAllSpecs = createSelector(getSpecsState, specsAdapter.getSelectors().selectAll);
export const specsCount = createSelector(getSpecsState, specsAdapter.getSelectors().selectTotal);

export const selectSpecs = createSelector(
    selectSpecsEntities,
    // eslint-disable-next-line unicorn/prevent-abbreviations
    (specsEntities) => specsEntities,
);
