import { createFeatureSelector, createSelector } from "@ngrx/store";
import * as fromActions from "../actions/flavor-classes.actions";
import { FlavorClassesState } from "../state/flavor-classes.state";
import { flavorClassesAdapter } from "../adapter/flavor-classes.adapter";

export const initialState: FlavorClassesState = flavorClassesAdapter.getInitialState({
    // eslint-disable-next-line unicorn/no-null
    selectedId: null,
});
// eslint-disable-next-line default-param-last
export function reducer(state = initialState, action: fromActions.FLAVORCLASSES_ACTIONS): FlavorClassesState {
    switch (action.type) {
        case fromActions.FlavorClassesActionTypes.LOAD_ALL_FLAVORCLASSES: {
            return flavorClassesAdapter.upsertMany(action.payload.flavorClasses, state);
        }
        case fromActions.FlavorClassesActionTypes.SELECT_FLAVORCLASSES: {
            // eslint-disable-next-line prefer-object-spread
            return Object.assign({ ...state });
        }
        default: {
            return state;
        }
    }
}

export const getFlavorClassesState = createFeatureSelector<FlavorClassesState>("flavorClassesState");

export const selectFlavorClassesIds = createSelector(getFlavorClassesState, flavorClassesAdapter.getSelectors().selectIds);
export const selectFlavorClasseEntities = createSelector(getFlavorClassesState, flavorClassesAdapter.getSelectors().selectEntities);
export const selectAllFlavorClasses = createSelector(getFlavorClassesState, flavorClassesAdapter.getSelectors().selectAll);
export const flavorClassesCount = createSelector(getFlavorClassesState, flavorClassesAdapter.getSelectors().selectTotal);

export const selectFlavorClasses = createSelector(
    selectFlavorClasseEntities,
    // eslint-disable-next-line unicorn/prevent-abbreviations
    (flavorClassesEntities) => flavorClassesEntities,
);
