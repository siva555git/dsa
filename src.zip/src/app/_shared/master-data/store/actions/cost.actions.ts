/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable max-classes-per-file */
import { Action } from "@ngrx/store";
import { CostModel } from "../../models/cost.model";

export enum CostsActionTypes {
    LOAD_ALL_COST = "[COST] Load All COST",
    SELECT_COST = "[COST] GET COST By costbookcode",
}

export class LoadCostSuccess implements Action {
    readonly type = CostsActionTypes.LOAD_ALL_COST;

    constructor(public payload: { cost: CostModel[] }) {}
}
export class SelectCosttypes implements Action {
    readonly type = CostsActionTypes.SELECT_COST;

    constructor() {}
}
// eslint-disable-next-line @typescript-eslint/naming-convention
export type COST_ACTIONS = LoadCostSuccess | SelectCosttypes;
