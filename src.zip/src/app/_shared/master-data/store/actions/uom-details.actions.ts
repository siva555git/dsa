/* eslint-disable max-classes-per-file */
import { Action } from "@ngrx/store";
import { UOMDetailsModel } from "../../models/uom-details.model";

export enum UOMActionTypes {
    LOAD_ALL_UOM = "[UOMDETAILS] Load All UOM",
    SELECT_UOM = "[UOMDETAILS] Facilities By uomid",
}

export class LoadUOMSuccess implements Action {
    readonly type = UOMActionTypes.LOAD_ALL_UOM;

    constructor(public payload: { uomDetails: UOMDetailsModel[] }) {}
}
export class SelectUomDetails implements Action {
    readonly type = UOMActionTypes.SELECT_UOM;

    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() {}
}
// eslint-disable-next-line @typescript-eslint/naming-convention
export type UOM_DETAILS = LoadUOMSuccess | SelectUomDetails;
