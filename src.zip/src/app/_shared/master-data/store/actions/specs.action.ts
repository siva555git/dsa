/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable max-classes-per-file */
import { Action } from "@ngrx/store";
import { SpecsModel } from "../../models/specs.model";

export enum SpecsActionTypes {
    LOAD_ALL_SPECS = "[SPECS] Load All SPECS",
    SELECT_SPECS = "[SPECS] GET SPECS",
}

export class LoadSpecsSuccess implements Action {
    readonly type = SpecsActionTypes.LOAD_ALL_SPECS;

    constructor(public payload: { specs: SpecsModel[] }) {}
}
export class SelectSpecs implements Action {
    readonly type = SpecsActionTypes.SELECT_SPECS;

    constructor() {}
}
// eslint-disable-next-line @typescript-eslint/naming-convention
export type SPECS_ACTIONS = LoadSpecsSuccess | SelectSpecs;
