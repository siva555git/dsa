/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable max-classes-per-file */
import { Action } from "@ngrx/store";
import { HomeActionContextModel } from "../../../models/experiment-list.model";

export enum RememberHomeContextActionTypes {
    LOAD_ALL_REMEMBER_HOME_CONTEXT = "[REMEMBER_HOME_CONTEXT] Load All REMEMBER_HOME_CONTEXT",
    SELECT_REMEMBER_HOME_CONTEXT = "[REMEMBER_HOME_CONTEXT] GET REMEMBER_HOME_CONTEXT ",
}

export class LoadRememberHomeContextSuccess implements Action {
    readonly type = RememberHomeContextActionTypes.LOAD_ALL_REMEMBER_HOME_CONTEXT;

    constructor(public payload: { homeContext: HomeActionContextModel[] }) {}
}
export class SelectRememberHomeContext implements Action {
    readonly type = RememberHomeContextActionTypes.SELECT_REMEMBER_HOME_CONTEXT;

    constructor() {}
}
// eslint-disable-next-line @typescript-eslint/naming-convention
export type REMEMBER_HOME_CONTEXT_ACTIONS = LoadRememberHomeContextSuccess | SelectRememberHomeContext;
