/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable max-classes-per-file */
import { Action } from "@ngrx/store";
import { FlavorClassesModel } from "../../models/flavor-classes.model";

export enum FlavorClassesActionTypes {
    LOAD_ALL_FLAVORCLASSES = "[FLAVORCLASSES] Load All FLAVOR CLASSES",
    SELECT_FLAVORCLASSES = "[FLAVORCLASSES] GET FLAVOR CLASSES",
}

export class LoadFlavorClassesSuccess implements Action {
    readonly type = FlavorClassesActionTypes.LOAD_ALL_FLAVORCLASSES;

    constructor(public payload: { flavorClasses: FlavorClassesModel[] }) {}
}
export class SelectFlavorClasses implements Action {
    readonly type = FlavorClassesActionTypes.SELECT_FLAVORCLASSES;

    constructor() {}
}
// eslint-disable-next-line @typescript-eslint/naming-convention
export type FLAVORCLASSES_ACTIONS = LoadFlavorClassesSuccess | SelectFlavorClasses;
