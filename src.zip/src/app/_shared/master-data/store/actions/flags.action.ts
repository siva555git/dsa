/* eslint-disable max-classes-per-file */
/* eslint-disable @typescript-eslint/no-empty-function */
import { Action } from "@ngrx/store";
import { FlagsModel } from "../../models/flags.model";

export enum FlagsActionTypes {
    LOAD_ALL_FLAGS = "[FLAGS] Load All FLAGS",
    SELECT_FLAGS = "[FLAGS] GET FLAGS",
}

export class LoadFlagsSuccess implements Action {
    readonly type = FlagsActionTypes.LOAD_ALL_FLAGS;

    constructor(public payload: { flags: FlagsModel[] }) {}
}
export class SelecFlags implements Action {
    readonly type = FlagsActionTypes.SELECT_FLAGS;

    constructor() {}
}
// eslint-disable-next-line @typescript-eslint/naming-convention
export type FLAGS_ACTIONS = LoadFlagsSuccess | SelecFlags;
