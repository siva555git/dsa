import { EntityAdapter, createEntityAdapter } from "@ngrx/entity";
import { FlagsModel } from "../../models/flags.model";

export const flagsAdapter: EntityAdapter<FlagsModel> = createEntityAdapter<FlagsModel>({
    selectId: (flags) => flags.flagcode,
    sortComparer: false,
});

export const { selectIds, selectEntities, selectAll, selectTotal } = flagsAdapter.getSelectors();
