import { EntityAdapter, createEntityAdapter } from "@ngrx/entity";
import { CostModel } from "../../models/cost.model";

export const costsAdapter: EntityAdapter<CostModel> = createEntityAdapter<CostModel>({
    selectId: (costBook) => costBook.costbookcode,
    sortComparer: false,
});

export const { selectIds, selectEntities, selectAll, selectTotal } = costsAdapter.getSelectors();
