import { EntityAdapter, createEntityAdapter } from "@ngrx/entity";
import { FlavorClassesModel } from "../../models/flavor-classes.model";

export const flavorClassesAdapter: EntityAdapter<FlavorClassesModel> = createEntityAdapter<FlavorClassesModel>({
    selectId: (flavorClass) => flavorClass.id,
    sortComparer: false,
});

export const { selectIds, selectEntities, selectAll, selectTotal } = flavorClassesAdapter.getSelectors();
