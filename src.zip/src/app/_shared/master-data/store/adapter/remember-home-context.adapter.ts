import { EntityAdapter, createEntityAdapter } from "@ngrx/entity";
import { HomeActionContextModel } from "../../../models/experiment-list.model";

export const rememberHomeContextAdapter: EntityAdapter<HomeActionContextModel> = createEntityAdapter<HomeActionContextModel>({
    selectId: (homeContext) => homeContext.FolderID,
    sortComparer: false,
});

export const { selectIds, selectEntities, selectAll, selectTotal } = rememberHomeContextAdapter.getSelectors();
