import { EntityAdapter, createEntityAdapter } from "@ngrx/entity";
import { UOMDetailsModel } from "../../models/uom-details.model";

export const uomDetailsAdapter: EntityAdapter<UOMDetailsModel> = createEntityAdapter<UOMDetailsModel>({
    selectId: (uom) => uom.uomid,
    sortComparer: false,
});

export const { selectIds, selectEntities, selectAll, selectTotal } = uomDetailsAdapter.getSelectors();
