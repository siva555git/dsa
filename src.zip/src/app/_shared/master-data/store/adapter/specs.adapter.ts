import { EntityAdapter, createEntityAdapter } from "@ngrx/entity";
import { SpecsModel } from "../../models/specs.model";

export const specsAdapter: EntityAdapter<SpecsModel> = createEntityAdapter<SpecsModel>({
    selectId: (specs) => specs.speccode,
    sortComparer: false,
});

export const { selectIds, selectEntities, selectAll, selectTotal } = specsAdapter.getSelectors();
