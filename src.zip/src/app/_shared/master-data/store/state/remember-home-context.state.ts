import { EntityState } from "@ngrx/entity";
import { HomeActionContextModel } from "../../../models/experiment-list.model";

export interface RememberHomeContextState extends EntityState<HomeActionContextModel> {
    selectedFolderID: string | number | null;
}
