import { EntityState } from "@ngrx/entity";
import { UOMDetailsModel } from "../../models/uom-details.model";

export interface UOMDetailsState extends EntityState<UOMDetailsModel> {
    selectedUomId: string | number | null;
}
