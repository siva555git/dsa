import { EntityState } from "@ngrx/entity";
import { FlagsModel } from "../../models/flags.model";

export interface FlagsState extends EntityState<FlagsModel> {
    selectedFlagcode: string | number | null;
}
