import { EntityState } from "@ngrx/entity";
import { SpecsModel } from "../../models/specs.model";

export interface SpecsState extends EntityState<SpecsModel> {
    selectedSpeccode: string | number | null;
}
