import { EntityState } from "@ngrx/entity";
import { CostModel } from "../../models/cost.model";

export interface CostBookState extends EntityState<CostModel> {
    selectedCostBookCode: string | number | null;
}
