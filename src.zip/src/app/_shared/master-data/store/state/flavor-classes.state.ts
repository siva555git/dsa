import { EntityState } from "@ngrx/entity";
import { FlavorClassesModel } from "../../models/flavor-classes.model";

export interface FlavorClassesState extends EntityState<FlavorClassesModel> {
    selectedId: string | number | null;
}
