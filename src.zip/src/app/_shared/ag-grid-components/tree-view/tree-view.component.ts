/* eslint-disable max-lines */
/* eslint-disable lines-between-class-members */
import {
    ColumnApi,
    GridApi,
    RowNode,
    RowSelectedEvent,
    RowGroupOpenedEvent,
    GetRowIdFunc,
    GetRowIdParams,
    ColDef,
    CellClassParams,
    GetContextMenuItemsParams,
} from "@ag-grid-community/core";
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from "@angular/core";
import { find, map, replace, remove, includes, delay } from "lodash";
import { ToastrService } from "ngx-toastr";
import { Subscription } from "rxjs";
import { GRID_APPLY_COLUMN, DEFAULT_SELECTED_FOLDER_INDEX } from "../../constants/tree-view.constant";
import { EMPTY, LOADING, LOAD_EXPERIMENT_DRAG_DROP } from "../../../app.constant";
import { DRAG_EVENT } from "../../../experiment-editor/constants/experiment-editor.constant";
import { RowDragCallbackParameters } from "../../../experiment-editor/models/experiment-editor.model";
import { GRID_FOLDER_ROW_HEIGHT } from "../../../experiment/experiment.constant";
import { FolderIconRendererComponent } from "../../../experiment/framework-components/folder-icon/folder-icon-renderer.component";
import { ExperimentListService } from "../../../experiment/helpers/experiment-list.service";
import { AppDataService, AppStateService, ErrorFormatService } from "../../../_services";
import { AppBroadCastService } from "../../../_services/app-broadcast/app.broadcast.service";
import {
    COLLABORATION_FOLDER_ID,
    COLLABORATION_GROUP_NAME,
    CONTEXT_MENU_FOLDER_VIEW,
    EXP_ID,
    GRID_SELECTION_TYPE,
    KEYBOARD_KEYS,
    SELECTED,
} from "../../constants";
import {
    EXPERIMENT_DRAG_ERROR_TOASTER_MSG,
    EXPERIMENT_DRAG_SAME_PARENT_ERROR_TOASTER_MSG,
    EXPERIMENT_DRAG_SUCCESS_TOASTER_MSG,
    FOLDER_DRAG_ERROR_MSG,
    FOLDER_DRAG_ERROR_TOASTER_MSG,
    FOLDER_DRAG_SAME_LOCATION_ERROR_TOASTER_MSG,
    FOLDER_PRESENT_ERROR_TOASTER_MSG,
} from "../../constants/experiment.constant";
import { ExperimentFolderSelected } from "../../enums/experiment.enum";
import { AgGridConfigHelper } from "../../helpers/ag-grid-config";
import { AgGridUtil } from "../../helpers/ag-grid-util";
import { ContextMenuHelper } from "../../helpers/context-menu-helper";
import { ContextMenuUtil } from "../../helpers/context-menu.util";
import { RowDragHelper } from "../../helpers/row-drag.helper";
import { TasteEditorUtilClass } from "../../helpers/taste-editor-utils";
import { Experiment } from "../../models";
import { ExperimentDetails, GridParameters, HomeActionContextModel, TreeViewModel } from "../../models/experiment-list.model";
import { DISABLE_COLLABORATION_CONTEXT_MENU } from "../../constants/context-menu.constant";
import { AppCacheHelper } from "../../helpers/app-cache.service";
import { FolderViewHelper } from "../../helpers/folder-view.helper";

@Component({
    selector: "app-tree-view",
    templateUrl: "./tree-view.component.html",
})
export class TreeViewComponent implements OnChanges, OnInit {
    /**
     * Get all the folders list
     *
     * @type {*}
     * @memberof TreeViewComponent
     */
    @Input() public treeListData: Array<TreeViewModel>;
    /**
     * Get Selected Folder ID From the outside component
     *
     * @type {number}
     * @memberof TreeViewComponent
     */
    @Input() public selectedFolderID: number;
    /**
     * Emits the Selected item id
     *
     * @memberof TreeViewComponent
     */
    @Output()
    public selectedItemId = new EventEmitter();
    /**
     * Row selection type
     *
     * @type {*}
     * @memberof TreeViewComponent
     */
    public rowSelection = GRID_SELECTION_TYPE.SINGLE_SELECTION;
    /**
     * Get Selected Experiment From outside component
     *
     * @type {Array}
     * @memberof TreeViewComponent
     */
    @Input() public selectedExperiments = [];
    @Input() public routedExperimentData: ExperimentDetails;
    @Input() public isTrustee: boolean;
    @Input() addedFolderData: TreeViewModel;
    @Input() editFolderData: TreeViewModel;
    @Input() deleteFolderData: number;
    @Input() selectedParentFolderID: number;
    @Input() draggedExperiments: Array<Experiment>;
    @Input() deSelectTreeViewFolder: boolean;
    @Input() isDraggedToFolder: boolean;

    @Output()
    public initGridApi = new EventEmitter();
    @Output()
    public removeExperiments = new EventEmitter();
    @Output() public scrollingPosition = new EventEmitter<TreeViewModel>();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Output() public dynamicScrollPosition = new EventEmitter<any>();
    public rowData: Array<TreeViewModel>;
    public gridApi: GridApi;
    public gridColumnApi: ColumnApi;
    public autoGroupColumnDef: ColDef;
    public getDataPath;
    public columnDefs: ColDef[];
    public getRowId: GetRowIdFunc;
    public defaultColDef: ColDef;
    public icons;
    public getSelectedNode: TreeViewModel;
    public selectedRow: TreeViewModel;
    public onRedirectMembershipExperimentData = false;
    public draggedOverRowNode: RowNode;
    public rowHeight = GRID_FOLDER_ROW_HEIGHT.NORMAL_HEIGHT;
    @Output() public onDeleteKeyPressed = new EventEmitter();
    @Output() public collaborationActiveMenu = new EventEmitter<boolean>();
    @Input() public collaborationMenuFocus: boolean;
    @Input() public homeContext: HomeActionContextModel[] = [];
    public expandedFolders: HomeActionContextModel[] = [];
    public selectedFolderData: HomeActionContextModel;
    public canRowBeSelectedOnExpand: boolean;
    public tooltipShowDelay;
    public getRoutedNode: TreeViewModel;
    public isRoutedExperiment = false;
    public treeviewSubscriptions: Subscription[] = [];

    constructor(
        private readonly contextMenuHelper: ContextMenuHelper,
        public readonly appBroadCastService: AppBroadCastService,
        private readonly experimentListService: ExperimentListService,
        private readonly rowDragHelper: RowDragHelper,
        private readonly toasterService: ToastrService,
        private readonly errorFormatService: ErrorFormatService,
        private readonly appCacheHelper: AppCacheHelper,
        private readonly appDataService: AppDataService,
    ) {
        this.canRowBeSelectedOnExpand = true;
    }

    public ngOnInit(): void {
        this.configAgGrid();
        this.hightlightSelectedFolderLocation();
    }

    /**
     * Method to highlight selected folder location
     * @returns {void}
     * @memberof TreeViewComponent
     */
    public hightlightSelectedFolderLocation(): void {
        this.appBroadCastService.selectedFolderLocation.subscribe((response: ExperimentDetails) => {
            const currentTreeData = this.treeListData.find((treeData) => treeData.FolderID === response?.FolderID);
            this.rowNodeSelectionBasedOnRouting(currentTreeData);
            AppStateService.setRedirectedExperimentDetails(response);
        });
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.treeListData && changes.treeListData.currentValue && !changes?.routedExperimentData?.currentValue) {
            this.rowData = this.treeListData;
            // To Select Default Folder
            this.getSelectedNode = find(this.treeListData, [SELECTED, ExperimentFolderSelected.IS_SELECTED]);
            this.isRoutedExperiment = false;
        } else if (changes.addedFolderData?.currentValue) {
            this.formatAddedFolderAndUpdate(changes.addedFolderData.currentValue);
        } else if (changes.editFolderData?.currentValue) {
            this.updateEditedFolderDetails(changes.editFolderData.currentValue);
        } else if (changes.deleteFolderData?.currentValue) {
            this.updateDeletedFolderDetails(changes.deleteFolderData.currentValue);
        } else if (changes.draggedExperiments?.currentValue && this.isDraggedToFolder) {
            this.handleGridChangesForExperimentDrop();
        } else if (changes.deSelectTreeViewFolder && changes.deSelectTreeViewFolder.currentValue) {
            this.getSelectedNode = undefined;
            this.gridApi.deselectAll();
            if (!this.collaborationMenuFocus) {
                const collaborationData: TreeViewModel = {
                    FolderID: COLLABORATION_FOLDER_ID,
                    FolderName: COLLABORATION_GROUP_NAME,
                };
                this.emitSelectedItem(collaborationData);
            }
        } else if (changes.routedExperimentData && changes.routedExperimentData.currentValue) {
            this.rowData = this.treeListData;
            this.getRoutedNode = this.treeListData.find(
                (experimentData) => experimentData.FolderID === changes.routedExperimentData.currentValue.FolderID,
            );
            this.isRoutedExperiment = true;
            this.firstDataRendered();
        }
    }

    /**
     * Method to subscribe the services
     * @param {TreeViewModel} addedValue
     * @memberof TreeViewComponent
     */
    public formatAddedFolderAndUpdate(addedValue: TreeViewModel): void {
        const copyValue = ContextMenuUtil.findRowData(addedValue, AgGridUtil.getGridRowData(this.gridApi));
        const path = [...copyValue.filePath, addedValue.FolderID.toString()];
        Object.assign(addedValue, {
            ParentFolderID: this.selectedRow ? addedValue.ParentFolderID : this.getSelectedNode.FolderID,
            filePath: path,
        });
        this.treeListData.push(addedValue);
        AppStateService.setExpFolderList(this.treeListData);
        this.gridApi.applyTransaction({ add: [addedValue] });
        const currentSelectedNode = this.gridApi.getRowNode(copyValue.filePath[copyValue.filePath.length - 1]);
        currentSelectedNode.setExpanded(true);
        delay(() => {
            const newlyCreatedNode = this.gridApi.getRowNode(addedValue.FolderID.toString());
            newlyCreatedNode.setSelected(true);
        }, 0);
    }

    /**
     * Method to update the treeview grid after editing folder name
     * @param {CreateFolderModel} editedValue
     * @memberof TreeViewComponent
     */
    public updateEditedFolderDetails(editedValue: TreeViewModel): void {
        const folderToUpdate = this.treeListData.find((expFolder) => expFolder.FolderID === editedValue.FolderID);
        Object.assign(folderToUpdate, { FolderName: editedValue.FolderName, Description: editedValue.Description });
        AppStateService.setExpFolderList(this.treeListData);
        this.gridApi.applyTransaction({ update: [folderToUpdate] });
    }

    /**
     * Method to update the treeview grid after deleting folder
     * @param {number} folderID
     * @memberof TreeViewComponent
     */
    public updateDeletedFolderDetails(folderID: number): void {
        let itemToDelete;
        const allRowData = [];
        this.gridApi.forEachNodeAfterFilterAndSort((rowNode) => {
            const { data } = rowNode;
            allRowData.push(data);
            if (data.FolderID === folderID) {
                itemToDelete = data;
            }
        });
        this.gridApi.applyTransaction({ remove: [itemToDelete] });
        this.setThePreviousFolder(itemToDelete, allRowData);
    }

    /**
     * Method to select and set the previous folder
     * @param {TreeViewModel} itemToDelete
     * @param {TreeViewModel[]} allRowData
     * @memberof TreeViewComponent
     */
    public setThePreviousFolder(itemToDelete: TreeViewModel, allRowData: TreeViewModel[]): void {
        let previousFolderID = -1;
        const currentLevelFolders = allRowData?.filter((folder) => {
            return folder.ParentFolderID === itemToDelete?.ParentFolderID;
        });
        /* Find the previous folder */
        if (currentLevelFolders.length >= 2) {
            currentLevelFolders.forEach((folder, index, array) => {
                if (folder.FolderID === itemToDelete?.FolderID) {
                    //  exiting the loop
                    const folderArray = array;
                    folderArray.length = index + 1;
                } else {
                    previousFolderID = folder.FolderID;
                }
            });
        } else {
            previousFolderID = itemToDelete?.ParentFolderID;
        }
        if (previousFolderID === -1) previousFolderID = itemToDelete?.ParentFolderID;

        /* Select and set previous folder */
        this.gridApi.forEachNodeAfterFilterAndSort((rowNode) => {
            const { data } = rowNode;
            if (data.FolderID === previousFolderID) {
                rowNode.setSelected(true);
            }
        });
    }

    /**
     * Method is called when clickin the node
     * @param {RowSelectedEvent} folderSelectedEvent
     * @returns {void}
     * @memberof TreeViewComponent
     */
    public folderClicked(folderSelectedEvent: RowSelectedEvent): void {
        if (folderSelectedEvent?.node?.isSelected()) {
            const folderSelected = folderSelectedEvent?.data ?? folderSelectedEvent?.node?.data;
            this.selectedRow = folderSelected;
            folderSelected.fromTreeView = true;
            this.emitSelectedItem(folderSelected);
            this.collaborationActiveMenu.emit(true);
        }
    }

    /**
     * Method to select previously selected folder
     * @returns {void}
     * @memberof TreeViewComponent
     */
    public selectRowNode(): void {
        delay(() => {
            if (this.homeContext.length === 0 && !this.gridApi && this.rowData.length === 0) return;
            this.selectedFolderData = this.homeContext.find((homeAction) => homeAction.selected);
            this.canRowBeSelectedOnExpand =
                this.homeContext.filter((homeAction) => homeAction.expanded).length === 0 ? true : !this.selectedFolderData;
            this.homeContext.forEach((homeActions) => {
                homeActions.filePath.forEach((filePath) => {
                    const rowNode = AgGridUtil.getSelectedFolderRowData(this.gridApi, filePath);
                    if (rowNode?.id === filePath && !rowNode.selected && !rowNode.expanded) {
                        if (homeActions.selected) {
                            this.canRowBeSelectedOnExpand = false;
                            rowNode.setSelected(homeActions.selected);
                        }
                        if (homeActions.expanded) {
                            rowNode.setExpanded(homeActions.expanded);
                        }
                    }
                });
            });
            delay(() => {
                this.scrollingPosition.emit();
            }, 0);
        }, 500);
    }

    /**
     * Method to select the redirected Folder
     * @returns {void}
     * @memberof TreeViewComponent
     */
    public rowNodeSelectionBasedOnRouting(selectedNode: TreeViewModel): void {
        this.canRowBeSelectedOnExpand = true;
        if (selectedNode && this.gridApi) {
            delay(() => {
                selectedNode.filePath.forEach((filePath, index, selectedNodeArray) => {
                    const rowNode = AgGridUtil.getSelectedFolderRowData(this.gridApi, filePath);
                    if (!rowNode) return;
                    if (index === selectedNodeArray.length - 1 && rowNode?.id === filePath) {
                        this.canRowBeSelectedOnExpand = false;
                        rowNode.setSelected(true);
                        delay(() => {
                            const selectedNodes = this.gridApi.getSelectedNodes();
                            this.dynamicScrollPosition.emit(selectedNodes[0]?.rowTop);
                        }, 600);
                    } else {
                        rowNode.setExpanded(true);
                    }
                });
                delay(() => {
                    this.canRowBeSelectedOnExpand = true;
                }, 0);
            }, 500);
        }
    }

    /**
     * Method to emit selected item
     * @param {TreeViewModel} folderData
     * @returns {void}
     * @memberof TreeViewComponent
     */
    public emitSelectedItem(folderData: TreeViewModel): void {
        this.selectedItemId.emit(folderData);
    }

    /**
     * Configure the ag grid properties to load the grid
     * @param {parameters} GridParameters
     * @returns {void}
     * @memberof TreeViewComponent
     */
    onGridReady(parameters: GridParameters): void {
        this.gridApi = parameters.api;
        this.gridColumnApi = parameters.columnApi;
        this.gridColumnApi.applyColumnState(GRID_APPLY_COLUMN);
        this.initGridApi.emit(this.gridApi);
    }

    /**
     * This method is used to capture the delete key press
     * @param {any} event
     * @memberof TreeViewComponent
     */
    public onCellKeyDown(event): void {
        if (event?.event.key === KEYBOARD_KEYS.DELETE) {
            this.onDeleteKeyPressed.emit();
        }
    }

    /**
     * Select the user's folder by default on load
     * @memberof TreeViewComponent
     */
    public firstDataRendered(): void {
        this.treeviewSubscriptions.push(
            this.appBroadCastService.isHomeUrlIdentifySubject.subscribe((data: boolean) => {
                if (data) {
                    const experimentDetails = AppStateService.getRedirectedExperimentDetails();
                    this.getRoutedNode = this.treeListData.find((experimentData) => experimentData.FolderID === experimentDetails.FolderID);
                    this.rowNodeSelectionBasedOnRouting(this.getRoutedNode);
                }
            }),
        );
        if (this.isRoutedExperiment) this.rowNodeSelectionBasedOnRouting(this.getRoutedNode);
        if (!this.isRoutedExperiment) this.selectRowNode();
        const loggedInUserId = this.appDataService.getUserId();
        if (
            (this.homeContext?.length === 0 && !this.isTrustee) ||
            (this.homeContext?.length === 1 && this.homeContext[0]?.FolderName === loggedInUserId && !this.isTrustee)
        ) {
            this.gridApi.forEachNode((rowNode: RowNode, index: number) => {
                rowNode.setSelected(index === DEFAULT_SELECTED_FOLDER_INDEX);
            });
        }
    }

    /**
     * Configure the ag grid properties to load the grid, set the default values
     * @memberof TreeViewComponent
     */
    public configAgGrid(): void {
        this.icons = {
            groupExpanded: '<i class="ag-icon ag-icon-small-down"/>',
            groupContracted: '<i class="ag-icon ag-icon-small-right"/>',
            dropNotAllowed: '<i style="color: red" class="ag-icon ag-icon-not-allowed"/>',
        };

        this.defaultColDef = AgGridConfigHelper.getDefaultColumnDefinition();

        this.defaultColDef.sortable = true;

        this.columnDefs = AgGridConfigHelper.getFoldersDefaultColDef();

        this.tooltipShowDelay = 0;

        this.autoGroupColumnDef = AgGridConfigHelper.getAutoGroupColumnDefinition(FolderIconRendererComponent);

        this.getDataPath = (data: TreeViewModel) => data.filePath;

        this.autoGroupColumnDef.rowDrag = !this.isTrustee;

        this.getRowId = (parameters: GetRowIdParams) => parameters.data.FolderID.toString();

        this.autoGroupColumnDef.cellClassRules = {
            "folder-hover-over": (parameters: CellClassParams) => parameters.node === this.draggedOverRowNode,
            "hide-row-drag-handle": (parameters: CellClassParams) =>
                TasteEditorUtilClass.isDefaultFolder(parameters.node.data.FolderName) || !parameters.node.data.ParentFolderID,
        };
    }

    /**
     * Method to update expand and collapse event in ngrx
     * @param {RowGroupOpenedEvent} rowGroupevent
     * @returns {void}
     * @memberof TreeViewComponent
     */
    public onRowGroupOpened(rowGroupEvent: RowGroupOpenedEvent): void {
        const rowGroupEventData = rowGroupEvent;
        if (
            (this.selectedRow?.FolderID !== rowGroupEventData.data.FolderID || !rowGroupEvent.data.parentFolderID) &&
            this.canRowBeSelectedOnExpand
        ) {
            rowGroupEventData.node.setSelected(true);
        }
        if (rowGroupEventData.expanded) {
            this.storeHomeContextData(rowGroupEventData.data, true);
        } else {
            // If parent is collapsed, then need to collapse child folders if expanded
            this.expandedFolders.forEach((expandedFolder) => {
                const expandedFolderdata = expandedFolder;
                const isChildFolder = includes(expandedFolder.filePath, String(rowGroupEventData.data.FolderID));
                if (isChildFolder) {
                    expandedFolderdata.expanded = false;
                }
            });
            this.storeHomeContextData(rowGroupEventData.data);
        }
    }

    /**
     * Method to handle Row Drag Events
     *
     * @param {RowDragCallbackParameters} agGridRowDragEvent
     * @return {*}  {void}
     * @memberof TreeViewComponent
     */
    public onRowDrag(agGridRowDragEvent: RowDragCallbackParameters): void {
        agGridRowDragEvent.node.setSelected(true);
        // eslint-disable-next-line default-case
        switch (agGridRowDragEvent.type) {
            case DRAG_EVENT.DRAG_END: {
                // Exitting function if invkoed by dropping experiment into folder
                if (agGridRowDragEvent.node.data?.ExpCode) return;

                if (!this.draggedOverRowNode) {
                    this.toasterService.error(FOLDER_DRAG_ERROR_TOASTER_MSG);
                    return;
                }
                this.handleGridChangesForFolderRowDrag(agGridRowDragEvent);
                this.refreshDraggedOverRowNode();

                break;
            }
            case DRAG_EVENT.DRAG_MOVING: {
                if (TasteEditorUtilClass.isDefaultFolder(agGridRowDragEvent.node.key)) return;
                this.refreshDraggedOverRowNode(agGridRowDragEvent.overNode);

                break;
            }
            case DRAG_EVENT.DRAG_LEAVE: {
                this.refreshDraggedOverRowNode();

                break;
            }
            // No default
        }
    }

    /**
     * Method to handle AG-Grid Changes For Folder Row Drag
     *
     * @param {RowDragCallbackParameters} agGridRowDragEvent
     * @return {*}  {void}
     * @memberof TreeViewComponent
     */
    public handleGridChangesForFolderRowDrag(agGridRowDragEvent: RowDragCallbackParameters): void {
        const movingData: TreeViewModel = agGridRowDragEvent.node.data;
        const newParentPath = this.draggedOverRowNode.data ? this.draggedOverRowNode.data.filePath : [];
        const shouldParentBeChanged = !this.rowDragHelper.areFolderPathsEqual(newParentPath, movingData.filePath.slice(0, -1));
        const isInvalidDragAction = this.rowDragHelper.isFolderRowDragValid(agGridRowDragEvent.node, this.draggedOverRowNode);
        if (
            isInvalidDragAction ||
            !shouldParentBeChanged ||
            this.rowDragHelper.isFolderWithSameNameAlreadyPresent(
                AgGridUtil.getGridRowData(this.gridApi),
                this.draggedOverRowNode.data?.FolderID,
                movingData.FolderName,
            )
        ) {
            let errorMessage = shouldParentBeChanged
                ? replace(FOLDER_PRESENT_ERROR_TOASTER_MSG, "<name>", movingData.FolderName) + this.draggedOverRowNode.data.FolderName
                : FOLDER_DRAG_SAME_LOCATION_ERROR_TOASTER_MSG;
            errorMessage = isInvalidDragAction ? FOLDER_DRAG_ERROR_TOASTER_MSG : errorMessage;
            this.toasterService.error(errorMessage);
            return;
        }

        this.updateParentFolder(movingData, newParentPath, agGridRowDragEvent.node);
    }

    /**
     * Method to update the Parent Folder if Row drag and drop is valid
     *
     * @private
     * @param {TreeViewModel} movingData
     * @param {Array<string>} newParentPath
     * @param {RowNode} newNode
     * @memberof TreeViewComponent
     */
    private updateParentFolder(movingData: TreeViewModel, newParentPath: Array<string>, node: RowNode) {
        const newNode = node;
        newNode.data.ParentFolderID = this.draggedOverRowNode.data.FolderID;
        const targetFolderName = this.draggedOverRowNode.data.FolderName;
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.experimentListService
            .updateParentFolder({
                childExpFolderId: movingData.FolderID,
                parentExpFolderId: this.draggedOverRowNode.data.FolderID,
            })
            .subscribe({
                next: () => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    const updatedRows = [];
                    this.rowDragHelper.moveToPath(newParentPath, newNode, updatedRows);
                    this.gridApi.applyTransaction({ update: updatedRows });
                    this.gridApi.clearFocusedCell();

                    // movingData.filePath will contain the filpath in heirarchial order in array format,where the
                    // last element is the folder that is being draggesamd the 1st element being the default User Folder(Eg: SXS1234)
                    this.toasterService.success(`${movingData.FolderName} successfully moved into ${targetFolderName}`);
                },
                error: this.handleError,
            });
    }

    /**
     * Method to set Parent Node for dragging child node
     *
     * @param {RowNode} [overNode]
     * @return {*}  {void}
     * @memberof TreeViewComponent
     */
    private refreshDraggedOverRowNode(overNode?: RowNode): void {
        let currentDragOverNode = overNode;
        const isAlreadySelected = this.draggedOverRowNode === currentDragOverNode;
        if (isAlreadySelected) return;

        // Setting currentDragOverNode to undefined if any folder is tried
        // to drop into the system generated Default Folders
        const isPotentialParentADefaultFolder = TasteEditorUtilClass.isDefaultFolder(currentDragOverNode?.data?.FolderName);
        if (isPotentialParentADefaultFolder) {
            currentDragOverNode = undefined;
        }
        const previousDragOverNode = { ...this.draggedOverRowNode };
        this.draggedOverRowNode = currentDragOverNode;
        this.rowDragHelper.updateGridRowsWhenDragging(this.gridApi, previousDragOverNode, currentDragOverNode);
    }

    /**
     * Method to handle folder grid changes for Experiment drag and drop
     *
     * @return {*}  {void}
     * @memberof TreeViewComponent
     */
    public handleGridChangesForExperimentDrop(): void {
        const isExperimentDroppedIntoSameParentFolder = this.selectedParentFolderID === this.draggedOverRowNode?.data.FolderID;
        if (!this.draggedOverRowNode || isExperimentDroppedIntoSameParentFolder) {
            const toastMessage = isExperimentDroppedIntoSameParentFolder
                ? EXPERIMENT_DRAG_SAME_PARENT_ERROR_TOASTER_MSG
                : EXPERIMENT_DRAG_ERROR_TOASTER_MSG;
            this.toasterService.error(toastMessage);
            return;
        }

        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOAD_EXPERIMENT_DRAG_DROP);
        this.experimentListService
            .updateParentFolder({
                childExperimentIds: map(this.draggedExperiments, EXP_ID),
                parentExpFolderId: this.draggedOverRowNode.data.FolderID,
            })
            .subscribe({
                next: (result) => {
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                    this.removeExperiments.emit(result);
                    this.toasterService.success(`${EXPERIMENT_DRAG_SUCCESS_TOASTER_MSG} ${this.draggedOverRowNode.data.FolderName}`);
                    this.refreshDraggedOverRowNode();
                },
                error: this.handleError,
            });
    }

    /**
     * Method to handle Error for Api calls
     *
     * @private
     * @param {*} error
     * @memberof TreeViewComponent
     */
    private handleError = (error) => {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
        this.refreshDraggedOverRowNode();
        this.toasterService.error(FOLDER_DRAG_ERROR_MSG);
        this.errorFormatService.logFormattedError(FOLDER_DRAG_ERROR_MSG, error);
    };

    /**
     * Method to return contextmenu
     * @param {GetContextMenuItemsParams} contextMenuItemParameters
     * @returns {void}
     * @memberof TreeViewComponent
     */
    public getContextMenuItems = (contextMenuItemParameters: GetContextMenuItemsParams): void => {
        if (this.isTrustee) return;
        if (contextMenuItemParameters.api?.getSelectedNodes()?.length <= 1) {
            contextMenuItemParameters.api.deselectAll();
            contextMenuItemParameters.node.setSelected(true);
            this.folderClicked(contextMenuItemParameters as unknown as RowSelectedEvent);
        }
        this.appBroadCastService.matomoDetect.next(CONTEXT_MENU_FOLDER_VIEW);
        const menu = this.contextMenuHelper.getContextMenuItemsFolder();
        remove(menu, (menuItems) => includes(DISABLE_COLLABORATION_CONTEXT_MENU, menuItems.name));
        const contextMenuDataHelper = ContextMenuUtil.ContextMenuDataHelper(menu, this.selectedRow, "", this.selectedExperiments);
        const contextmenu = this.contextMenuHelper.contextMenuDisable(contextMenuDataHelper);
        // eslint-disable-next-line consistent-return
        return contextmenu;
    };

    /**
     * Method to store home context data
     * @param {HomeActionContextModel} selectedFolderData
     * @returns {void}
     * @memberof TreeViewComponent
     */
    public storeHomeContextData(selectedFolderData: HomeActionContextModel, isExpanded = false): void {
        const homeContextData = FolderViewHelper.formHomeContextData(selectedFolderData);
        homeContextData.expanded = isExpanded;
        homeContextData.isTrusteeNode = selectedFolderData.isTrusteeNode;
        this.expandedFolders.push(homeContextData);
        this.appCacheHelper.storeHomeContext(this.expandedFolders);
        const filteredArray = this.homeContext.filter((folder) => folder.expanded && folder.isTrusteeNode === this.isTrustee);
        if (!this.canRowBeSelectedOnExpand && this.expandedFolders.length === filteredArray.length) {
            this.canRowBeSelectedOnExpand = true;
        }
    }

    /**
     * Method to destroy subscriptions
     * @returns {void}
     * @memberof TreeViewComponent
     */
    ngOnDestroy(): void {
        TasteEditorUtilClass.removeSubscriptions(this.treeviewSubscriptions);
    }
}
