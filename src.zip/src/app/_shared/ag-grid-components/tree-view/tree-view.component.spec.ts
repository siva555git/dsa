/* eslint-disable max-lines */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-empty-function */
/* eslint-disable max-lines-per-function */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { GridApi, ColumnApi, RowNode, RowSelectedEvent, GetContextMenuItemsParams } from "@ag-grid-community/core";
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChanges } from "@angular/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { cloneDeep } from "lodash";
import { NGXLogger } from "ngx-logger";
import { ToastrService } from "ngx-toastr";
import { of } from "rxjs";
import { MatDialog } from "@angular/material/dialog";
import { RouterTestingModule } from "@angular/router/testing";
import { CreativeReviewHelper } from "src/app/creative-review/helpers/creative-review-helper";
import { ExperimentAccessHelper } from "../../helpers/experiment-access.helper";
import { ExperimentHelper } from "../../helpers/experiment-helper";
import { DialogHelper } from "../../helpers/dialog-helper";
import { DEFAULT_EXPERIMENT_FOLDER } from "../../constants";
import { DRAG_EVENT } from "../../../experiment-editor/constants/experiment-editor.constant";
import { ExperimentListService } from "../../../experiment/helpers/experiment-list.service";
import {
    mockExperiment,
    mockGridApiNew,
    mockGridColumnApiNew,
    mockGroupOpenedMatched,
    mockRowDragCallbackParameters,
} from "../../../testing/mock-ag-grid-data";
import { MockAppDataService } from "../../../testing/mock-app.data.service";
import { MockAppStateService } from "../../../testing/mock-app.state.service";
import { gridParameters, rowSelectedEvent, treeViewModel } from "../../../testing/mock-context-menu.helper";
import { MockExperimentService } from "../../../testing/mock-experiment-service";
import { MockLoggerService } from "../../../testing/mock-logger.service";
import { MockToastrService } from "../../../testing/mock-toastr.service";
import { AppBroadCastService, AppDataService, AppStateService, ErrorFormatService, WindowReferenceService } from "../../../_services";
import { ExperimentFolderChild, ExperimentFolderExpanded, ExperimentFolderSelected } from "../../enums/experiment.enum";
import { ContextMenuHelper } from "../../helpers/context-menu-helper";
import { ContextMenuUtil } from "../../helpers/context-menu.util";
import { RowDragHelper } from "../../helpers/row-drag.helper";
import { ExperimentApiService } from "../../helpers/experiment-api.service";
import { ExperimentDetails, GridParameters, TreeViewModel } from "../../models/experiment-list.model";
import { TreeViewComponent } from "./tree-view.component";
import { SecurityHelper } from "../../security/helpers/security.helper";
import { AppCacheHelper } from "../../helpers/app-cache.service";
import { MockAppcacheHelper } from "../../../testing/mock-app-cache-helper";
import { mockHomeContextData } from "../../../testing/mock-home-context";
import { FolderViewHelper } from "../../helpers/folder-view.helper";
import { AgGridUtil } from "../../helpers/ag-grid-util";

describe("TreeViewComponent", () => {
    let component: TreeViewComponent;
    let fixture: ComponentFixture<TreeViewComponent>;

    const primaryFolder: TreeViewModel = {
        FolderID: 5_000_185,
        FolderName: "Summa Testing",
        ParentFolderID: 5_000_005,
        filePath: ["SXS2761"],
        expanded: ExperimentFolderExpanded.IS_NOT_EXPANDED,
        hasChild: ExperimentFolderChild.HAS_NO_CHILD,
        selected: ExperimentFolderSelected.IS_NOT_SELECTED,
        Description: "",
    };
    const selectedFolder = {
        FolderID: 5_000_454,
        FolderName: "SXS2761",
        ParentFolderID: 5_000_005,
        expanded: "1",
        filePath: ["SXS2761"],
        hasChild: "2",
        selected: "1",
        Description: "SXS2761",
    };

    const experimentDetails: ExperimentDetails = {
        ExperimentCode: "K1S25567AA",
        FolderName: "Test",
        FolderID: 1,
        ParentFolderID: "5000005",
    };
    const dialogReferenceStub = {
        afterClosed() {
            return of("result"); // this can be whatever, esp handy if you actually care about the value returned
        },
    };
    const dialogStub = { open: () => dialogReferenceStub };

    const agGridEvent = {
        api: {
            getSelectedNodes() {
                return [{}];
            },
            deselectAll() {
                return true;
            },
            selectNode() {},
        },
        node: {
            setSelected() {},
            isSelected: () => true,
        },
        value: "",
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            declarations: [TreeViewComponent],
            providers: [
                RowDragHelper,
                ContextMenuHelper,
                ErrorFormatService,
                AppBroadCastService,
                WindowReferenceService,
                ExperimentApiService,
                ExperimentHelper,
                DialogHelper,
                ExperimentAccessHelper,
                { provide: NGXLogger, useClass: MockLoggerService },
                { provide: ToastrService, useClass: MockToastrService },
                { provide: AppDataService, useClass: MockAppDataService },
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: ExperimentListService, useClass: MockExperimentService },
                {
                    provide: MatDialog,
                    useValue: dialogStub,
                },
                SecurityHelper,
                { provide: AppCacheHelper, useClass: MockAppcacheHelper },
                CreativeReviewHelper,
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(TreeViewComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        component.gridApi = mockGridApiNew as unknown as GridApi;
        component.gridColumnApi = mockGridColumnApiNew as unknown as ColumnApi;
    });

    it("should call on getContextMenuItems ", () => {
        spyOn(component, "folderClicked").and.returnValue();
        const spy = spyOn(component, "getContextMenuItems").and.callThrough();
        component.getContextMenuItems(agGridEvent as unknown as GetContextMenuItemsParams);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on configAgGrid ", () => {
        const spy = spyOn(component, "configAgGrid").and.callThrough();
        component.configAgGrid();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on firstDataRendered ", () => {
        const spy = spyOn(component, "firstDataRendered").and.callThrough();
        spyOn(component, "rowNodeSelectionBasedOnRouting").and.returnValue();
        component.firstDataRendered();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on folderClicked ", () => {
        let rowSelectedEventData = cloneDeep(rowSelectedEvent);
        rowSelectedEventData.data = primaryFolder;
        rowSelectedEventData.node = {
            selected: true,
            isSelected: () => true,
            setExpanded: () => true,
        } as unknown as RowNode;
        component.selectedRow = primaryFolder;
        spyOn(component, "folderClicked").and.callThrough();
        rowSelectedEventData = rowSelectedEventData as unknown as RowSelectedEvent;
        component.folderClicked(rowSelectedEventData);
        expect(component.selectedRow).toEqual(primaryFolder);
    });

    it("should call on folderClicked ", () => {
        let rowSelectedEventData = cloneDeep(rowSelectedEvent);
        rowSelectedEventData.node = {
            selected: false,
            isSelected: () => false,
            setExpanded: () => true,
        } as unknown as RowNode;
        spyOn(component, "folderClicked").and.callThrough();
        rowSelectedEventData = rowSelectedEventData as unknown as RowSelectedEvent;
        component.folderClicked(rowSelectedEventData);
        expect(component.selectedRow).toBeUndefined();
    });

    it("should call on emitSelectedItem ", () => {
        const spy = spyOn(component, "emitSelectedItem").and.callThrough();
        component.emitSelectedItem(treeViewModel);
        expect(spy).toHaveBeenCalled();
    });

    xit("onGridReady called", () => {
        const parameters = gridParameters;
        component.onGridReady(parameters as unknown as GridParameters);
        expect(component.gridApi).not.toBeNull();
        expect(component.gridColumnApi).not.toBeNull();
    });

    it("should call on formatAddedFolderAndUpdate ", () => {
        const spy = spyOn(component, "formatAddedFolderAndUpdate").and.callThrough();
        component.getSelectedNode = primaryFolder;
        component.treeListData = [];
        ContextMenuUtil.findRowData = () => primaryFolder;
        component.formatAddedFolderAndUpdate(primaryFolder);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on updateEditedFolderDetails ", () => {
        const spy = spyOn(component, "updateEditedFolderDetails").and.callThrough();
        const updateFolder: TreeViewModel = {
            FolderID: 5_000_185,
            FolderName: "TestFolder2M",
            ParentFolderID: 5_000_005,
        };
        component.treeListData = [updateFolder];
        component.updateEditedFolderDetails(updateFolder);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on updateDeletedFolderDetails ", () => {
        const spy = spyOn(component, "updateDeletedFolderDetails").and.callThrough();
        component.updateDeletedFolderDetails(5_000_185);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on setThePreviousFolder ", () => {
        const spy = spyOn(component, "setThePreviousFolder").and.callThrough();
        component.setThePreviousFolder(primaryFolder, [primaryFolder]);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onCellKeyDown for capturing delete keypress", () => {
        const spy = spyOn(component, "onCellKeyDown").and.callThrough();
        const event = { event: { keyCode: 46 } };
        component.onCellKeyDown(event);
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for ngOnChanges ", () => {
        const spy = spyOn(component, "ngOnChanges").and.callThrough();
        component.getSelectedNode = primaryFolder;
        component.selectedRow = primaryFolder;
        ContextMenuUtil.findRowData = () => primaryFolder;
        component.treeListData = [selectedFolder as unknown as TreeViewModel];
        component.routedExperimentData = experimentDetails as unknown as ExperimentDetails;
        const changes = {
            addedFolderData: {
                currentValue: primaryFolder,
            },
            treeListData: {
                currentValue: [selectedFolder],
            },
            routedExperimentData: {
                currentValue: [experimentDetails],
            },
        } as unknown as SimpleChanges;
        component.ngOnChanges(changes);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onRowDrag and toaster error", () => {
        spyOn(mockRowDragCallbackParameters.node, "setSelected").and.returnValue();
        spyOn(component, "onRowDrag").and.callThrough();
        component.onRowDrag(mockRowDragCallbackParameters);
        expect(component.draggedOverRowNode).toBeUndefined();
    });

    it("should call onRowDrag and DRAG_MOVING", () => {
        const rowDragCallbackParameters = cloneDeep(mockRowDragCallbackParameters);
        spyOn(rowDragCallbackParameters.node, "setSelected").and.returnValue();
        rowDragCallbackParameters.type = DRAG_EVENT.DRAG_MOVING;
        const spy = spyOn(component, "onRowDrag").and.callThrough();
        component.onRowDrag(rowDragCallbackParameters);
        expect(spy).toHaveBeenCalled();
    });

    it("should call onRowDrag and DRAG_LEAVE", () => {
        const rowDragCallbackParameters = cloneDeep(mockRowDragCallbackParameters);
        spyOn(rowDragCallbackParameters.node, "setSelected").and.returnValue();
        rowDragCallbackParameters.type = DRAG_EVENT.DRAG_LEAVE;
        spyOn(component, "onRowDrag").and.callThrough();
        component.onRowDrag(rowDragCallbackParameters);
        expect(component.draggedOverRowNode).toBeUndefined();
    });

    it("should call onRowDrag and DRAG_END", () => {
        const rowDragCallbackParameters = cloneDeep(mockRowDragCallbackParameters);
        rowDragCallbackParameters.node.data = primaryFolder;
        rowDragCallbackParameters.node.childrenAfterGroup = [];
        const node = { data: selectedFolder, setExpanded: () => true };
        component.draggedOverRowNode = node as unknown as RowNode;
        spyOn(rowDragCallbackParameters.node, "setSelected").and.returnValue();
        const spy = spyOn(component, "onRowDrag").and.callThrough();
        component.onRowDrag(rowDragCallbackParameters);
        expect(spy).toHaveBeenCalled();
    });

    it("should call handleGridChangesForFolderRowDrag and toaster error", () => {
        const mockFolder = cloneDeep(selectedFolder);
        mockFolder.FolderName = DEFAULT_EXPERIMENT_FOLDER[0].FolderName;
        const rowDragCallbackParameters = cloneDeep(mockRowDragCallbackParameters);
        rowDragCallbackParameters.node.data = primaryFolder;
        rowDragCallbackParameters.node.childrenAfterGroup = [];
        const node = { data: mockFolder };
        component.draggedOverRowNode = node as unknown as RowNode;
        const spy = spyOn(component, "handleGridChangesForFolderRowDrag").and.callThrough();
        component.handleGridChangesForFolderRowDrag(rowDragCallbackParameters);
        expect(spy).toHaveBeenCalled();
    });

    it("should call handleGridChangesForFolderRowDrag and updateParentFolder error", () => {
        const rowDragCallbackParameters = cloneDeep(mockRowDragCallbackParameters);
        rowDragCallbackParameters.node.data = primaryFolder;
        rowDragCallbackParameters.node.childrenAfterGroup = [];
        const node = { data: selectedFolder };
        component.draggedOverRowNode = node as unknown as RowNode;
        const spy = spyOn(component, "handleGridChangesForFolderRowDrag").and.callThrough();
        component.handleGridChangesForFolderRowDrag(rowDragCallbackParameters);
        expect(spy).toHaveBeenCalled();
    });

    it("should call handleGridChangesForFolderRowDrag and updateParentFolder Success", () => {
        const mockFolder = cloneDeep(primaryFolder);
        mockFolder.FolderID = 5_000_201;
        const rowDragCallbackParameters = cloneDeep(mockRowDragCallbackParameters);
        rowDragCallbackParameters.node.data = mockFolder;
        rowDragCallbackParameters.node.childrenAfterGroup = [];
        const node = { data: selectedFolder };
        component.draggedOverRowNode = node as unknown as RowNode;
        const spy = spyOn(component, "handleGridChangesForFolderRowDrag").and.callThrough();
        component.handleGridChangesForFolderRowDrag(rowDragCallbackParameters);
        expect(spy).toHaveBeenCalled();
    });

    it("should call handleGridChangesForExperimentDrop error 1", () => {
        spyOn(component, "handleGridChangesForExperimentDrop").and.callThrough();
        component.handleGridChangesForExperimentDrop();
        expect(component.draggedOverRowNode).toBeUndefined();
    });

    it("should call handleGridChangesForExperimentDrop error 2", () => {
        spyOn(component, "handleGridChangesForExperimentDrop").and.callThrough();
        const node = { data: selectedFolder };
        component.draggedOverRowNode = node as unknown as RowNode;
        component.selectedParentFolderID = selectedFolder.ParentFolderID;
        component.handleGridChangesForExperimentDrop();
        expect(component.draggedOverRowNode).toBeUndefined();
    });

    it("should call handleGridChangesForExperimentDrop and updateParentFolder error", () => {
        spyOn(component, "handleGridChangesForExperimentDrop").and.callThrough();
        const node = { data: selectedFolder };
        component.draggedOverRowNode = node as unknown as RowNode;
        component.selectedParentFolderID = 12_345_678;
        component.draggedExperiments = [mockExperiment];
        component.handleGridChangesForExperimentDrop();
        expect(component.draggedOverRowNode).toBeUndefined();
    });

    it("should call handleGridChangesForExperimentDrop and updateParentFolder success", () => {
        spyOn(component, "handleGridChangesForExperimentDrop").and.callThrough();
        const node = { data: selectedFolder };
        component.draggedOverRowNode = node as unknown as RowNode;
        component.selectedParentFolderID = 12_345_678;
        component.draggedExperiments = [mockExperiment, mockExperiment];
        component.handleGridChangesForExperimentDrop();
        expect(component.draggedOverRowNode).toBeUndefined();
    });

    it("should call on onRowGroupOpened when same folder is selected", () => {
        const mockGroupOpenedMatchedData = cloneDeep(mockGroupOpenedMatched);
        component.selectedRow = {
            FolderID: 50_011_012,
            FolderName: "Testing",
        };
        spyOn(component, "onRowGroupOpened").and.callThrough();
        mockGroupOpenedMatchedData.node = mockGroupOpenedMatchedData.node as unknown as RowNode;
        mockGroupOpenedMatchedData.node = {
            setSelected() {},
        };
        component.onRowGroupOpened(mockGroupOpenedMatchedData);
        expect(mockGroupOpenedMatchedData.selected).toBeFalsy();
    });
    it("should call on onRowGroupOpened ", () => {
        const mockGroupOpenedMatchedData = cloneDeep(mockGroupOpenedMatched);
        mockGroupOpenedMatchedData.expanded = false;
        component.expandedFolders = [mockHomeContextData];
        component.selectedRow = {
            FolderID: 50_011_012,
            FolderName: "Testing",
        };
        spyOn(component, "onRowGroupOpened").and.callThrough();
        mockGroupOpenedMatchedData.node = mockGroupOpenedMatchedData.node as unknown as RowNode;
        mockGroupOpenedMatchedData.node = {
            setSelected(object1) {
                return object1;
            },
        };
        component.homeContext = [];
        component.onRowGroupOpened(mockGroupOpenedMatchedData);
        expect(mockGroupOpenedMatchedData.selected).toBeFalsy();
    });

    it("should call on storeHomeContextData when isExpanded = false", () => {
        const mockHomeContext = mockHomeContextData;
        mockHomeContext.selectedCollaborationGroup = undefined;
        spyOn(component, "storeHomeContextData").and.callThrough();
        spyOn(FolderViewHelper, "formHomeContextData").and.returnValue(mockHomeContextData);
        component.storeHomeContextData(mockHomeContextData);
        expect(component.expandedFolders).toEqual([mockHomeContext]);
    });

    it("should call on storeHomeContextData when isExpanded = true", () => {
        const mockHomeContext = mockHomeContextData;
        mockHomeContext.expanded = true;
        mockHomeContext.selectedCollaborationGroup = undefined;
        spyOn(component, "storeHomeContextData").and.callThrough();
        spyOn(FolderViewHelper, "formHomeContextData").and.returnValue(mockHomeContextData);
        component.storeHomeContextData(mockHomeContextData, true);
        expect(component.expandedFolders).toEqual([mockHomeContext]);
    });

    it("should call on selectRowNode when homeContext is empty", () => {
        component.homeContext = [];
        component.rowData = [];
        const spy = spyOn(component, "selectRowNode").and.callThrough();
        component.selectRowNode();
        expect(spy).toHaveBeenCalled();
    });

    xit("should call on selectRowNode when homeContext available", () => {
        const mockHomeContext = cloneDeep(mockHomeContextData);
        mockHomeContext.selected = true;
        component.homeContext = [mockHomeContext];
        const selectedNode = {
            // eslint-disable-next-line id-length
            id: 5_000_367,
            selected: false,
            expanded: false,
        };
        spyOn(AgGridUtil, "getSelectedFolderRowData").and.returnValue(selectedNode);
        const spy = spyOn(component, "selectRowNode").and.callThrough();
        component.selectRowNode();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on rowNodeSelectionBasedOnRouting when passing the selected Folder", () => {
        const selectedNode = {
            selected: false,
            expanded: false,
            setExpanded: () => true,
        };
        component.gridApi = mockGridApiNew as unknown as GridApi;
        spyOn(AgGridUtil, "getSelectedFolderRowData").and.returnValue(selectedNode);
        const spy = spyOn(component, "rowNodeSelectionBasedOnRouting").and.callThrough();
        component.rowNodeSelectionBasedOnRouting(primaryFolder);
        expect(spy).toHaveBeenCalled();
    });
});
