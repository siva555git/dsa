/* eslint-disable max-lines-per-function */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { CellClickedEvent, ColumnApi, GridApi, RowGroupOpenedEvent } from "@ag-grid-community/core";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { MockExperimentHelper } from "@te-testing/mock-experiment.helper";
import { cloneDeep } from "lodash";
import { GridParameters } from "@te-shared/models";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { mockGridApiNew, mockGridColumnApiNew } from "../../../testing/mock-ag-grid-data";
import { ExperimentFolderSelectorComponent } from "./experiment-folder-selector.component";

describe("ExperimentFolderSelectorComponent", () => {
    let component: ExperimentFolderSelectorComponent;
    let fixture: ComponentFixture<ExperimentFolderSelectorComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ExperimentFolderSelectorComponent],
            providers: [
                {
                    provide: ExperimentHelper,
                    useClass: MockExperimentHelper,
                },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExperimentFolderSelectorComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        component.gridApi = cloneDeep(mockGridApiNew as unknown as GridApi);
        component.gridColumnApi = cloneDeep(mockGridColumnApiNew as unknown as ColumnApi);
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call on configAgGrid ", () => {
        component.configAgGrid();
        expect(component.rowData).toEqual([]);
    });

    it("should call on refreshGrid ", () => {
        const spy = spyOn(component, "refreshGrid").and.callThrough();
        component.refreshGrid();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getDefaultFolderID ", () => {
        const folderID = component.getDefaultFolderID();
        expect(folderID).toEqual(12_345_678);
    });

    it("should call on verifySelectedFolder ", () => {
        const folderID = component.verifySelectedFolder(0);
        expect(folderID).toBeDefined();
    });

    it("should call on onGridReady ", () => {
        const spy = spyOn(component, "onGridReady").and.callThrough();
        component.onGridReady({
            api: mockGridApiNew,
            columnApi: mockGridColumnApiNew,
        } as unknown as GridParameters);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onFolderClicked ", () => {
        component.onFolderClicked({ data: { FolderID: 12_345_678 } } as unknown as CellClickedEvent);
        expect(component.selectedFolderID).toEqual(12_345_678);
    });

    it("should call on onRowGroupOpened  ", () => {
        const spy = spyOn(component, "onRowGroupOpened").and.callThrough();
        component.onRowGroupOpened({
            node: {
                // eslint-disable-next-line no-empty-function, @typescript-eslint/no-empty-function
                setSelected() {},
            },
            event: new Event("asd"),
        } as unknown as RowGroupOpenedEvent);
        expect(spy).toHaveBeenCalled();
    });
});
