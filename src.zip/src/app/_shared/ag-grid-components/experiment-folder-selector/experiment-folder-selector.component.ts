/* eslint-disable dot-notation */
import {
    CellClickedEvent,
    CellKeyDownEvent,
    ColDef,
    ColumnApi,
    GetDataPath,
    GetRowIdFunc,
    GetRowIdParams,
    GridApi,
    RowNode,
    RowGroupOpenedEvent,
} from "@ag-grid-community/core";
import { Component, EventEmitter, Output } from "@angular/core";
import { NavigationHelper } from "@te-experiment-editor/helpers/navigation-helper";
import { GRID_FOLDER_ROW_HEIGHT } from "@te-experiment/experiment.constant";
import { FolderIconRendererComponent } from "@te-experiment/framework-components/folder-icon/folder-icon-renderer.component";
import { GRID_SELECTION_TYPE, KEYBOARD_KEYS } from "@te-shared/constants";
import { GRID_APPLY_COLUMN } from "@te-shared/constants/tree-view.constant";
import { AgGridConfigHelper } from "@te-shared/helpers/ag-grid-config";
import { ExperimentHelper } from "@te-shared/helpers/experiment-helper";
import { GridParameters, TreeViewModel } from "@te-shared/models";
import { orderBy } from "lodash";
import { BehaviorSubject } from "rxjs";

@Component({
    selector: "app-experiment-folder-selector",
    templateUrl: "./experiment-folder-selector.component.html",
})
export class ExperimentFolderSelectorComponent {
    @Output() selectedFolder = new EventEmitter<TreeViewModel>();

    public gridApi: GridApi;

    public gridColumnApi: ColumnApi;

    public rowData: Array<TreeViewModel>;

    public defaultColDef: ColDef;

    public columnDefs: ColDef[];

    public rowHeight = GRID_FOLDER_ROW_HEIGHT.NORMAL_HEIGHT;

    public rowSelection = GRID_SELECTION_TYPE.SINGLE_SELECTION;

    public autoGroupColumnDef: ColDef;

    public selectedFolderID = 0;

    public isFirstTimeLoad = true;

    public getDataPath: GetDataPath = (data: TreeViewModel) => data.filePath;

    public getRowId: GetRowIdFunc = (parameters: GetRowIdParams) => parameters.data.FolderID.toString();

    public foldersFetchSub$ = new BehaviorSubject(false);

    public icons = {
        groupExpanded: '<i class="ag-icon ag-icon-small-down"/>',
        groupContracted: '<i class="ag-icon ag-icon-small-right"/>',
    };

    constructor(private readonly experimentHelper: ExperimentHelper) {}

    /**
     * Configure the ag grid properties to load the grid, set the default values
     *
     * @memberof ExperimentFolderSelectorComponent
     */
    public configAgGrid(): void {
        this.defaultColDef = AgGridConfigHelper.getDefaultColumnDefinition();
        this.defaultColDef.sortable = true;

        this.columnDefs = AgGridConfigHelper.getFoldersDefaultColDef();

        this.autoGroupColumnDef = AgGridConfigHelper.getAutoGroupColumnDefinition(FolderIconRendererComponent);

        this.experimentHelper.fetchAllExpFolders().subscribe((folderList) => {
            this.foldersFetchSub$.next(true);
            this.rowData = orderBy(folderList, [(list) => list.FolderName.toLowerCase()], ["asc"]);
        });
    }

    /**
     * Method to refresh AG-Grid when opening
     *
     * @return {*}  {void}
     * @memberof ExperimentFolderSelectorComponent
     */
    public refreshGrid(): void {
        if (this.isFirstTimeLoad) {
            this.gridApi.refreshCells({ force: true });
            this.isFirstTimeLoad = false;
        }

        const rowNodes =
            this.selectedFolderID > 0 ? [this.gridApi.getRowNode(this.selectedFolderID.toString())] : this.gridApi.getSelectedNodes();
        if (this.selectedFolderID === 0) {
            this.setFocusOnFolderAt(0, rowNodes);
            return;
        }
        if (!Number.isFinite(rowNodes[0]?.rowIndex)) {
            this.expandAndFocusFolder(rowNodes[0].data);
            return;
        }

        this.setFocusOnFolderAt(rowNodes[0]?.rowIndex, rowNodes);
    }

    /**
     * Method to set focus on folder at given index
     *
     * @private
     * @param {number} rowIndex
     * @param {RowNode[]} rowNodes
     * @memberof ExperimentFolderSelectorComponent
     */
    private setFocusOnFolderAt(rowIndex: number, rowNodes: RowNode[]): void {
        const firstFolder = this.gridColumnApi.getAllDisplayedColumns()[0];
        this.gridApi.ensureColumnVisible(firstFolder);

        if (rowNodes?.length > 0) {
            rowNodes[0]?.setSelected(true);
        }

        // sets focus into the first grid cell
        this.gridApi.setFocusedCell(rowIndex, firstFolder);
    }

    /**
     * Method to expand and focus folder
     *
     * @private
     * @param {TreeViewModel} folderData
     * @memberof ExperimentFolderSelectorComponent
     */
    private expandAndFocusFolder(folderData: TreeViewModel) {
        folderData.filePath.forEach((folderID) => {
            this.gridApi.getRowNode(folderID.toString()).setExpanded(true);
        });
    }

    /**
     * Method to verify and get selected folder
     *
     * @param {number} folderID
     * @return {*}  {TreeViewModel}
     * @memberof ExperimentFolderSelectorComponent
     */
    public verifySelectedFolder(folderID: number): TreeViewModel {
        const rowNode = this.gridApi.getRowNode(folderID.toString());
        this.selectedFolderID = rowNode?.data?.FolderID ?? 0;
        return rowNode?.data;
    }

    /**
     * Method to get the default folderID
     *
     * @return {*}  {number}
     * @memberof ExperimentFolderSelectorComponent
     */
    public getDefaultFolderID(): number {
        const rowNode = this.gridApi?.getDisplayedRowAtIndex(0);
        return rowNode?.data?.FolderID ?? 0;
    }

    /**
     * Configure the ag grid properties to load the grid
     *
     * @param {GridParameters} parameters
     * @memberof ExperimentFolderSelectorComponent
     */
    public onGridReady(parameters: GridParameters): void {
        this.gridApi = parameters.api;
        this.gridColumnApi = parameters.columnApi;
        this.gridColumnApi.applyColumnState(GRID_APPLY_COLUMN);
    }

    /**
     * Method to navigate to next/previous/expand/collapse row on down/up/left/right key pressed
     *
     * @param {CellKeyDownEvent} keyDownEvent
     * @memberof ExperimentFolderSelectorComponent
     */
    public onCellKeyDown = (keyDownEvent: CellKeyDownEvent): void => {
        const keyboardNavigationMap = {
            [KEYBOARD_KEYS.DOWN_ARROW]: () => NavigationHelper.onDownArrowKeyPressed(keyDownEvent),
            [KEYBOARD_KEYS.UP_ARROW]: () => NavigationHelper.onUpArrowKeyPressed(keyDownEvent),
            [KEYBOARD_KEYS.RIGHT_ARROW]: () => {
                if (+keyDownEvent.data.hasChild > 0) {
                    keyDownEvent.node.setExpanded(true);
                }
            },
            [KEYBOARD_KEYS.LEFT_ARROW]: () => {
                if (+keyDownEvent.data.hasChild > 0) {
                    keyDownEvent.node.setExpanded(false);
                }
            },
            [KEYBOARD_KEYS.ENTER]: () => {
                // eslint-disable-next-line no-unused-expressions
                keyDownEvent.event?.preventDefault();
                // eslint-disable-next-line no-unused-expressions
                keyDownEvent.event?.stopPropagation();

                this.onFolderClicked(keyDownEvent);
            },
            [KEYBOARD_KEYS.SPACE]: () => {
                // eslint-disable-next-line no-unused-expressions
                keyDownEvent.event?.preventDefault();
                keyDownEvent.node.setSelected(true);

                if (+keyDownEvent.data.hasChild > 0) {
                    keyDownEvent.node.setExpanded(!keyDownEvent.node.expanded);
                }
            },
        };
        if (keyboardNavigationMap[keyDownEvent.event["key"]]) {
            keyboardNavigationMap[keyDownEvent.event["key"]]();
        }
    };

    /**
     * Method to handle expand and collapse event
     *
     * @param {RowGroupOpenedEvent} rowGroupEvent
     * @memberof ExperimentFolderSelectorComponent
     */
    public onRowGroupOpened = (rowGroupEvent: RowGroupOpenedEvent): void => {
        rowGroupEvent.node.setSelected(true);
        // eslint-disable-next-line no-unused-expressions
        rowGroupEvent.event?.preventDefault();
        // eslint-disable-next-line no-unused-expressions
        rowGroupEvent.event?.stopPropagation();
    };

    /**
     * Method to handle folder clicked event
     *
     * @param {CellClickedEvent} folderSelectedEvent
     * @memberof ExperimentFolderSelectorComponent
     */
    public onFolderClicked(folderSelectedEvent: CellClickedEvent): void {
        this.selectedFolderID = folderSelectedEvent.data.FolderID;
        this.selectedFolder.emit(folderSelectedEvent.data);
    }
}
