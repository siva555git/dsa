/* eslint-disable unicorn/no-abusive-eslint-disable */
/* eslint-disable */

/* Dependencies */
import { Action } from "@ngrx/store";

/* helper and models */
import { TAB } from "../constants/common.constant";
import { TabDataModel } from "../../models/tab-data-model";

export class AddTab implements Action {
    readonly type = TAB.ADD_TAB;

    constructor(public payload: TabDataModel) {}
}

export class UpdateTab implements Action {
    readonly type = TAB.UPDATE_TAB;

    constructor(public payload: TabDataModel) {}
}

export class RemoveTab implements Action {
    readonly type = TAB.REMOVE_TAB;

    constructor(public payload: TabDataModel) {}
}

export class GetTab implements Action {
    readonly type = TAB.GET_TAB;

    constructor(public payload: TabDataModel) {}
}

export type TabActions = AddTab | UpdateTab | RemoveTab | GetTab;
