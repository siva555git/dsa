import { TabDataModel } from "src/app/models/tab-data-model";
import { AddTab, GetTab, RemoveTab, UpdateTab } from "./tab-add-update";
import { TAB } from "../constants/common.constant";

describe("AddTAB Action", () => {
    let action: AddTab;
    beforeEach(() => {
        action = new AddTab({ tabId: "testId1" });
    });
    it("create an instance", () => {
        expect(action).toBeTruthy();
    });
    it("should create a tab ", () => {
        const tabData: TabDataModel = { tabId: "testId1" };
        const addAction = new AddTab(tabData);
        expect(addAction.payload).toBe(tabData);
        expect(addAction.type).toBe(TAB.ADD_TAB);
    });
});
describe("UpdateTab Action", () => {
    it("should update a tab ", () => {
        const tabData: TabDataModel = { tabId: "testId1", tabHeader: "Test header" };
        const updateAction = new UpdateTab(tabData);
        expect(updateAction.payload).toBe(tabData);
        expect(updateAction.type).toBe(TAB.UPDATE_TAB);
    });
});
describe("RemoveTab Action", () => {
    it("should remove a tab ", () => {
        const tabData: TabDataModel = { tabId: "testId1" };
        const removeAction = new RemoveTab(tabData);
        expect(removeAction.payload).toBe(tabData);
        expect(removeAction.type).toBe(TAB.REMOVE_TAB);
    });
});
describe("GetTab Action", () => {
    it("should get a tab ", () => {
        const tabData: TabDataModel = { tabId: "testId1" };
        const getAction = new GetTab(tabData);
        expect(getAction.payload).toBe(tabData);
        expect(getAction.type).toBe(TAB.GET_TAB);
    });
});
