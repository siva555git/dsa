/* eslint-disable   @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars */

import { TestBed, inject } from "@angular/core/testing";
import { HttpClientTestingModule } from "@angular/common/http/testing";

import { OAuthService } from "angular-oauth2-oidc";

import { AuthGuard } from "./auth.guard";
import { AppStateService } from "../../_services";
import { AppSettings } from "../../app.settings";
import { UserStatus } from "../enums";
import { MockOAuthService } from "../../testing/mock-oauth.service";
import { AppBroadCastService } from "../../_services/app-broadcast/app.broadcast.service";

/* eslint-disable-next-line     max-lines-per-function */
xdescribe("AuthGuard", () => {
    const routeMock: any = { snapshot: {}, url: "/home" };
    const routeStateMock: any = { snapshot: {}, url: "/" };
    const routerMock = { navigate: jasmine.createSpy("navigate") };

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                AppStateService,
                AuthGuard,
                AppBroadCastService,
                {
                    provide: OAuthService,
                    useClass: MockOAuthService,
                },
            ],
        });
    });

    it("should create", inject([AuthGuard], (guard) => {
        expect(guard).toBeTruthy();
    }));

    it("should redirect an unauthenticated user to the unauthorized route", inject([AuthGuard], (guard) => {
        AppSettings.isOktaRequired = true;
        const authService = TestBed.inject(OAuthService);

        spyOn(authService, "hasValidIdToken").and.returnValue(false);
        spyOn(authService, "initImplicitFlow");

        expect(guard.canActivate(routeMock, routeStateMock)).toEqual(false);
        expect(authService.initImplicitFlow).toHaveBeenCalled();
    }));

    it("should allow authenticated user to access app [OKTA Disabled]", inject([AuthGuard], (guard) => {
        AppSettings.isOktaRequired = false;
        const authService = TestBed.inject(OAuthService);

        spyOn(authService, "hasValidIdToken").and.returnValue(false);
        spyOn(authService, "hasValidAccessToken").and.returnValue(false);

        expect(guard.canActivate(routeMock, routeStateMock)).toEqual(true);
    }));

    it("should allow authenticated user to access app with Active user status [OKTA Enabled]", inject([AuthGuard], (guard) => {
        AppSettings.isOktaRequired = true;
        const appState: AppStateService = TestBed.inject(AppStateService);
        const authService = TestBed.inject(OAuthService);

        appState.set(appState.stateId.isAccessDenied, false);
        appState.set(appState.stateId.userAppStatus, UserStatus.ACTIVE);

        spyOn(authService, "hasValidIdToken").and.returnValue(true);
        spyOn(authService, "hasValidAccessToken").and.returnValue(true);

        expect(guard.canActivate(routeMock, routeStateMock)).toEqual(true);
    }));

    it("should not allow authenticated user to access app with UNKNOWN user status [OKTA Enabled]", inject([AuthGuard], (guard) => {
        AppSettings.isOktaRequired = true;
        const appState: AppStateService = TestBed.inject(AppStateService);
        const authService = TestBed.inject(OAuthService);

        appState.set(appState.stateId.isAccessDenied, true);
        appState.set(appState.stateId.userAppStatus, UserStatus.UNKNOWN);

        spyOn(authService, "hasValidIdToken").and.returnValue(true);
        spyOn(authService, "hasValidAccessToken").and.returnValue(true);

        expect(guard.canActivate(routeMock, routeStateMock)).toEqual(false);
    }));

    xit("should not allow authenticated user to access child routes with UNKONWN user status [OKTA Enabled]", inject(
        [AuthGuard],
        (guard) => {
            AppSettings.isOktaRequired = true;
            const appState: AppStateService = TestBed.inject(AppStateService);
            const authService = TestBed.inject(OAuthService);

            appState.set(appState.stateId.isAccessDenied, true);
            appState.set(appState.stateId.userAppStatus, UserStatus.UNKNOWN);

            spyOn(authService, "hasValidIdToken").and.returnValue(true);
            spyOn(authService, "hasValidAccessToken").and.returnValue(true);

            expect(guard.AuthGuard(routeMock, routeStateMock)).toEqual(false);
        },
    ));
});
