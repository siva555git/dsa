import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from "rxjs";
import { OAuthService } from "angular-oauth2-oidc";
import { AppSettings } from "../../app.settings";
// eslint-disable-next-line import/no-cycle
import { AppStateService } from "../../_services";
import { UserStatus } from "../enums";

@Injectable({
    providedIn: "root",
})
export class AuthGuard {
    constructor(private oAuthSvc: OAuthService, private appState: AppStateService) {}

    canActivate(
        _next: ActivatedRouteSnapshot, // eslint-disable-line @typescript-eslint/no-unused-vars
        _state: RouterStateSnapshot, // eslint-disable-line @typescript-eslint/no-unused-vars
    ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
        if (!AppSettings.isOktaRequired && !AppSettings.isEntraRequired) {
            return true;
        }
        if (AppSettings.isOktaRequired) {
            if (this.oAuthSvc.hasValidIdToken() && this.oAuthSvc.hasValidAccessToken()) {
                return !(
                    this.appState.get(this.appState.stateId.isAccessDenied) ||
                    this.appState.get(this.appState.stateId.userAppStatus) !== UserStatus.ACTIVE
                );
            }
            this.oAuthSvc.initImplicitFlow();
            return true;
        }
        return !(
            this.appState.get(this.appState.stateId.isAccessDenied) ||
            this.appState.get(this.appState.stateId.userAppStatus) !== UserStatus.ACTIVE
        );
    }

    canActivateChild(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot,
    ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
        return this.canActivate(next, state);
    }
}
