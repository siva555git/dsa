export const HTTP_ERRORS = "HTTP_ERRORS";
