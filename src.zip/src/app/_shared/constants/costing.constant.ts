export const COSTING_KEY_VALUES = {
    EXPERIMENT: "Experiment",
    TECHNOLOGY: "technology",
    TECHNOLOGYID: "technologyid",
    BATCHSIZE_KEY_IN_PRODUCT: "batchsizeinkg",
};

export const PRODUCT_PROCUREMENT_TYPE = {
    TYPE_X: "x",
    TYPE_MAKE: "make",
};
