/* eslint-disable id-length */
export const SAMPLE_CONST = {
    BLOCK: "block",
    NUNITO_SANS: "NunitoSans",
    HTML_P: "html-p",
    HTML_SPAN: "html-span",
    GRAY: "#757575",
    BLACK: "#000000",
    LIGHT_GRAY: "#7C7C7C",
    LIGHT_GRAY_1: "#C7C7C7",
    AUTO: "auto",
    BAR_CODE: "barCode",
    QR_CODE: "qrCode",
    LEFT: "left",
    RIGHT: "right",
    FOOTER: "This document contains confidential information which is a trade secret and the exclusive Property of international flavors & Fragrances Inc. No use may be made of it without written consent of the corporation. You are requested to take such precautions.",
    FOOTER_DESC: "footerDesc",
    FOOTER_COUNT: "footerCount",
    ASCENDING: "asc",
    DARK_GRAY: "#222D35",
    NONE: "none",
    BAR_CODE_TEMPLATE: "BAR_CODE",
    QR_CODE_TEMPLATE: "QR_CODE",
    PIXEL: "pixel",
    HTML: "html",
    PLAIN: "plain",
    UNIT_CM: "cm",
    FORM_SOURCE: "Form-Source",
    LANDSCAPE: "landscape",
    PORTRAIT: "portrait",
    THREE_SAMPLES: `More than 3 samples were requested.  Do you want to proceed ?`,
    PAGE_A4: "A4",
    PAGE_LETTER: "LETTER",
    PAGE_LEGAL: "LEGAL",
    PAGE_FS: "FOOLSCAP",
    PDF: "Microsoft Print to PDF",
    EXCLUDING_RECOVERED_ITEMS: "(Excluding recovered items.)",
};

export const UOM_TYPE = {
    W: "W",
    V: "V",
    U: "U",
    C: "C",
};

export const UOM_FOR_SAP_PO = ["G", "KG", "PARTS"];

export const UOM_VALIDATION_MESSAGE_FOR_SAP_PO = "While selecting the SAP PO , UOM should be any one of (g, kg, parts)";

export const STANDARD_TEMPLATES = [
    { value: "Small", name: "Small (7.5 x 2.5 cm)", width: 213, height: 71 },
    { value: "Medium", name: "Medium (10 x 4 cm)", width: 283, height: 113 },
    { value: "Large", name: "Large (10 x 5 cm)", width: 283, height: 141 },
];

export const SAMPLE_TYPE = {
    MAKE_SAMPLE: "Make Sample",
    REPRINT_LABEL: "Reprint Label",
};

export const LABEL_ORIENTATION = [{ orientationType: "landscape" }, { orientationType: "portrait" }];

export const DEFAULT_PAGE_SIZE = { width: 21, height: 29.7 };

export const PAGE_SIZE_DETAILS = [
    {
        name: "LETTER",
        description: "US LETTER PAPER",
        sizeCm: { width: 21.59, height: 27.94 },
        sizePx: { width: 816, height: 1056 },
    },
    {
        name: "A4",
        description: "A4 PAPER",
        sizeCm: { width: 21, height: 29.7 },
        sizePx: { width: 793, height: 1122 },
    },
    {
        name: "FOOLSCAP",
        description: "FOOLSCAP - FS PAPER",
        sizeCm: { width: 21.5, height: 34.5 },
        sizePx: { width: 812, height: 1303 },
    },
    {
        name: "LEGAL",
        description: "LEGAL PAPER",
        sizeCm: { width: 21.59, height: 35.56 },
        sizePx: { width: 816, height: 1344 },
    },
];

export const ERROR_MESSAGE = {
    SAMPLE_NOT_EXIST: "Sample ID does not exist.",
};

export const TEMPLATE_DETAILS = [
    {
        name: "Standard experiment label - Small (7.5 x 2.5 cm)",
        barcodeWidth: 1,
        barcodeHeight: 20,
        qrCodeWidth: 50,
        size: { width: 2.5, height: 7.5 },
    },
    {
        name: "Standard experiment label - Medium (10 x 4 cm)",
        barcodeWidth: 1.2,
        barcodeHeight: 20,
        qrCodeWidth: 50,
        size: { width: 4.5, height: 12 },
    },
    {
        name: "Standard experiment label - Medium with logo (10 x 4 cm)",
        barcodeWidth: 1.2,
        barcodeHeight: 20,
        qrCodeWidth: 50,
        size: { width: 4.5, height: 12 },
    },
    {
        name: "Standard experiment label - Medium with logo (10.3 x 3.4 cm)",
        barcodeWidth: 1.2,
        barcodeHeight: 20,
        qrCodeWidth: 50,
        size: { width: 4, height: 11 },
    },
    {
        name: "Standard experiment label - Large (10 x 5 cm)",
        barcodeWidth: 1.6,
        barcodeHeight: 30,
        qrCodeWidth: 75,
        size: { width: 5, height: 10 },
    },
    {
        name: "Custom experiment label - (8.0 x 2.8 cm)",
        barcodeWidth: 1.2,
        barcodeHeight: 20,
        qrCodeWidth: 55,
        size: { width: 4.5, height: 12 },
    },
    {
        name: "Custom experiment label - (8.9 x 2.9 cm)",
        barcodeWidth: 1.4,
        barcodeHeight: 22,
        qrCodeWidth: 55,
        size: { width: 4.5, height: 12 },
    },
    {
        name: "Custom experiment label - (8.9 x 3.8 cm)",
        barcodeWidth: 1.4,
        barcodeHeight: 24,
        qrCodeWidth: 65,
        size: { width: 4.5, height: 12 },
    },
    {
        name: "Custom experiment label - With Product Type (10 x 4 cm)",
        barcodeWidth: 1.2,
        barcodeHeight: 20,
        qrCodeWidth: 50,
        size: { width: 4.5, height: 12 },
    },
];
export const LABEL_WITH_PRODUCT_TYPE = "Custom experiment label - With Product Type (10 x 4 cm)";
