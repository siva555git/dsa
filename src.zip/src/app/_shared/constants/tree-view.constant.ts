import { ApplyColumnStateParams } from "@ag-grid-community/core";

export const GRID_APPLY_COLUMN: ApplyColumnStateParams = {
    state: [
        {
            colId: "FolderName",
            sort: "asc",
        },
    ],
};

export const DEFAULT_SELECTED_FOLDER_INDEX = 0;

export const RESTRICTED_ACCESS_GRID_APPLY_COLUMN: ApplyColumnStateParams = {
    state: [
        {
            colId: "name",
            sort: "asc",
        },
    ],
};
