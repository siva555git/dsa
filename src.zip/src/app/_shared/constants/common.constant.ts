/* eslint-disable max-lines */
/* eslint-disable id-length */
import { SearchType } from "../../experiment-editor/models/experiment-editor.model";
import { ColumnLayouts } from "../enums/experiment-formula.enum";
import { WorkSpaces } from "../models/create-tab.model";
import { EXPERIMENT_TYPE_CONTEXT_MENU, MENU_LIST } from "./context-menu.constant";
import { SAMPLE_TYPE } from "./print-sample.constant";

export const PANEL_CLASS = "model-popup";

const RED_FILL_BUTTON = "red-button fill-button";
const BLUE_BTN_CSS = "fill-button";
export const RED_BTN_CSS = RED_FILL_BUTTON;
const SUBMIT_WARNING_MSG = "This action cannot be undone";
const CC_INDICATOR = "CC Indicator";
export const DELETE_MESSAGE = "Are you sure you want to delete?";
const RECENTLY_USED_EXPERIMENT = "Recently Used Experiments";
const ALL_MY_EXPERIMENTS_CONST = "All My Experiments";
const DIALOG_MODEL = "dialog-model";
export const TITLE_CHANGE_URL_LIST = {
    HOME: { TITLE: "Experiments", URL: "home" },
    COLUMN_LAYOUT: { TITLE: "Master Data <span class='icon-chevron_right-black-18dp'></span> Column Layout", URL: "column-layout" },
    EXPERIMENT_ANALYSIS: {
        TITLE: "Master Data <span class='icon-chevron_right-black-18dp'></span> BOM Recommendations",
        URL: "experiment-analysis",
    },
    IPC_SELECTION: { TITLE: "Master Data <span class='icon-chevron_right-black-18dp'></span> IPC Selection", URL: "ipc-selection" },
    BOM_VIEW_EVENT_REPORT: {
        TITLE: "Tools <span class='icon-chevron_right-black-18dp'></span> Bom View Event Report",
        URL: "bom-view-event-report",
    },
    GRA_COMPLIANCE_REPORT: {
        TITLE: "Tools <span class='icon-chevron_right-black-18dp'></span> GRA Compliance Dashboard",
        URL: "gra-compliance-report",
    },
    USER_SETTINGS: { TITLE: "User Settings", URL: "user-settings" },
    INSTRUCTION: { TITLE: "Master Data <span class='icon-chevron_right-black-18dp'></span> Instructions", URL: "instruction" },
    UNAPPROVED: { TITLE: "Master Data <span class='icon-chevron_right-black-18dp'></span> Unapproved", URL: "unapproved" },
    MY_TASKS: { TITLE: "My Tasks", URL: "my-tasks" },
    INTERNAL_SAMPLE_REQUEST: {
        TITLE: "Tools <span class='icon-chevron_right-black-18dp'></span> Internal Sample Request",
        URL: "internal-sample-request",
    },
};

export const SELECTED = "selected";

export const TEST_WARNING_MESSAGE = "Warning: This is a Test Database";

export const TEST_DATABASE = "iff | Taste Editor TEST DATABASE";

export const EMPTY_VALUES_WARNING_MESSAGE = "";

export const INDEX = "index";

export const CREATIVE_REVIEW_FILTER = "Creative review filter";

export const TYPE = "type";

export const CLOSE_TOOLTIP = "Close";

export const HOME_TOOLTIP = "Home";

export const DELETE_CONFIRMATION = {
    panelClass: PANEL_CLASS,
    width: "540px",
    disableClose: true,
    data: {
        title: "Delete Soft Deleted Items",
        message: DELETE_MESSAGE,
        subMesssage: SUBMIT_WARNING_MSG,
        submitText: "Delete",
        cancelText: "Cancel",
        submitBtnClass: RED_FILL_BUTTON,
    },
};

export const SAMPLE_CONFIRMATION = {
    panelClass: PANEL_CLASS,
    width: "540px",
    disableClose: true,
    data: {
        title: "Sample Confirmation",
        message: "You have requested number of samples. Do you want to proceed ?",
        submitText: "Yes",
        cancelText: "No",
        submitBtnClass: RED_FILL_BUTTON,
    },
};

export const DEFAULT_YIELD_VALUE = 100;

export const TASTE_DESCRIPTOR_START_SEQUENCE = 10;

export const PRODUCT_TYPE = "Flav";
export const FRAG_TYPE = "Frag";

export const GRID_VIEW = {
    COMPACT_VIEW: "Compact View",
    EXPAND_VIEW: "Expand View",
};

export const APP_PRIVACY = {
    APP_STATE_PRIVACY_CODE: "PRIVACY-MODEL",
    OPEN_MODEL: "PUBLIC",
    CLOSED_MODEL: "PRIVATE",
};

export const SIDE_BAR_MENU = {
    FOLDER: "Folder",
};

/* Initial Constants */
export const ALPHABET_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
export const AVAILABLE_LIST_COUNT = 2;

/* Pager Constants */
export const PAGE_SIZES = ["All", 25, 50, 100, 500];
export const PAGE_COUNT = 25;
export const ALL_PAGE_COUNT = 500;

/* BUild Default Version */
export const BUILD_DEFAULT = "0.0.0";

export const ROW_SELECTED = "row-selected";

export const MENU_HOVER_TIME = 2000;

export const TO_GET_OPEN_TABS = "/1";

export const OBJ_ID = "id";

export const CLASS = "class";

export const DEFAULT_EXP_CLASS = "experiment-data-lists";

export const DEFAULT_ACTIVE_EXP_CLASS = "experiment-data-lists experiment-data-lists-active";

export const EXP_FORMULA_LOCATION = "/experiment-formula/tab/";

export const EXP_LOCKED_CLASS = { LOCK: "expLocked  icon-lock", UNLOCK: "expunLocked icon-lock" };

export const EXP_SORT_CLASS = { SORTED: "expSort icon-bom-sort", UNSORTED: "expUnSort icon-bom-sort" };

export const YIELD_VALUES = {
    MIN: 0.01,
    MAX: 100,
    DECIMAL_LENGTH: 2,
};

export const BATCH_SIZE_VALUES = {
    MIN: 1,
    MAX: 32_267,
    DECIMAL_LENGTH: 2,
};

export const BATCH_SHEET_VALUES = {
    NO_OF_SAMPLES: "NumberOfSamples",
    REQUIRED_SAMPLE_SIZE: "RequiredSampleSize",
};

export const UOM_VALUES = {
    MIN: 0,
    MAX: 100,
    DECIMAL_LENGTH: 4,
};

// eslint-disable-next-line @typescript-eslint/no-loss-of-precision
export const INT_64_MAX_VALUE = 9_223_372_036_854_775_807;

export const SAMPLES_VALUES = {
    MIN: 1,
    MAX: 20,
};

export const REQUIRED_SAMPLE_SIZE = {
    MIN: 0.001,
    MAX: 100_000,
    DECIMAL_LENGTH: 3,
};

export const TOTAL_REQUIREMENT_SIZE = {
    MIN: 0.001,
    MAX: 2_000_000,
    DECIMAL_LENGTH: 3,
};

export const NO_OF_PAPER_COPIES = {
    MIN: 1,
    MAX: 10,
    DECIMAL_LENGTH: 0,
};

// eslint-disable-next-line no-useless-escape
export const SPECIAL_CHARACTER_FORMAT = /[!"#$%&'()*+,./:;<=>?@[\\\]^_{|}\-]+/;

export const ALPHABETS_FORMAT = /[a-z]/i;

export const PRODUCT_SEARCH_CONSTANTS = {
    DEFAULT_IPC_SELECTION: "All",
    DEFAULT_PRODUCT_CATEGORY: { ProductSearchID: 0, SearchName: "All" },
    ALL_INGREDIENTS_IPC_SELECTION: "ALL INGREDIENTS",
    ALL_TASTE_PRODUCT_IPC_SELECTION: "ALL TASTE PRODUCT",
    DEFAULT_PRODUCT_QUERY: "startswith",
    PRODUCT_GRID_COLUMN_LIST: ["IPC", "Description"],
    PRODUCT_BOM_DETAILS: ["Parts", "Comments", "Sequence No."],
    PRODUCT_SEARCH_CHECKBOX_LIST: [
        { searchCriteria: "Description", checked: true },
        { searchCriteria: "IPC", checked: true },
        { searchCriteria: "FEMA #", checked: true },
        { searchCriteria: "CAS #", checked: true },
        { searchCriteria: "IUPAC", checked: false },
        { searchCriteria: "E NUM", checked: false },
    ],
    PRODUCT_SEARCH_SPECS_CHECKBOX_LIST: ["FEMA #", "CAS #", "IUPAC", "E NUM"],
    PRODUCT_SEARCH_SPECS_IPC_SELECTION: "FEMA #, CAS #, IUPAC, E NUM",
    PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE: {
        "FEMA #": "FEMA #",
        // eslint-disable-next-line sonarjs/no-duplicate-string
        "CAS #": "FEMA RELATED CAS NUMBER",
        IUPAC: "RELATED CAS DESCRIPTION",
        "E NUM": "EU E-NUMBER",
    },
    PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE_DETAILS: ["FEMA #", "FEMA RELATED CAS NUMBER", "RELATED CAS DESCRIPTION"],
    DEFAULT_PRODUCT_SEARCH_SPECS_CHECKBOX_VALUE_DETAILS: ["FEMA #", "FEMA RELATED CAS NUMBER"],
    DEFAULT_CHECKBOX_SELECTION: ["description", "ipc"],
    START_FROM: 0,
    LIMIT: 50,
    PRODUCT_SEARCH_LIMIT: 2000,
    SORT_ORDER: "asc",
    PRODUCT_SEARCH_ONLY_PASS_AUDIT: "If ON, search results will show products in green or blue only.",
    PRODUCT_SEARCH_AUDIT_TOGGLE_TOOLTIP_MSG: "Search result set is too large. Please change search term to narrow down to less than 5k.",
    EMPTY_SEARCH_RESULT_COUNT: 0,
};

export const INSTRUCTION_SEARCH = {
    DEFAULT_CATEGORY: "ALL",
    FAVORITE_CATEGORY: "Favorites",
    DEFAULT_SEARCH_CLAUSE: "startswith",
    INSTRUCTIONS: "Instructions",
    ID: "InstructionID",
    SORT_CODE: "SortCode",
    FAV_INSTRUCTION: "favouriteIns",
    INSTRUCTION_COLUMN_LIST: ["Instructions", "SortCode"],
};

export const UNAPPROVED_SEARCH = {
    DEFAULT_CATEGORY: "ALL",
    DEFAULT_SEARCH_CLAUSE: "contains",
    UNAPPROVEDID: "UnapprovedID",
    DESCRIPTION: "Description",
    COSTKG: "Cost/KG",
    COSTKGCURRENCY: "Cost/KG Currency",
    CreatedBy: "CreatedBy",
    CreatedOn: "CreatedOn",
    Category: "Category",
    MarketCode: "MarketCode",
    MNC: "MNC",
    UNAPPROVED_SEARCH_CHECKBOX_LIST: [
        { searchCriteria: "ID", checked: true },
        { searchCriteria: "Description", checked: true },
    ],
    DEFAULT_CHECKBOX_SELECTION: ["description", "id"],
    CreatedOn_Format: "DD MMM YYYY",
};

export const EXPERIMENTS_SEARCH = {
    START_FROM: 0,
    LIMIT: 200,
    DEFAULT_SEARCH_CLAUSE: "contains",
    EXPERIMENTS_SEARCH_CHECKBOX_LIST: [
        { searchCriteria: "Code", checked: true },
        { searchCriteria: "Name", checked: true },
        { searchCriteria: "Exp ID", checked: true },
    ],
    EXPERIMENT_GRID_COLUMN_LIST: ["ExperimentCode", "ExperimentName", "ProductType", "IPC", "ExpID"],
    EXP_CODE: "code",
};

export const PRODUCTS_SEARCH_CATEGORIES = ["Recently Used"];
export const PRODUCTS_SEARCH_SEARCHBY = {
    description: "description",
    ipc: "code",
};
export const PRODUCTS_SEARCH = {
    LIMIT: 50,
    OFFSET: 0,
};

export const TABS: WorkSpaces[] = [
    {
        UserTabID: -1,
        TabName: "Home",
        location: "/home",
        class: "experiment-home experiment-home-active",
        active: true,
        WorkSpaceDetail: [],
        ProductSearchID: 957,
        SavedLayoutTypeID: 382,
        CustomLayoutTypeID: 386,
        IsSavedSelected: true,
        CreatedBy: undefined,
        CreatedOn: undefined,
        IsCurrent: undefined,
        Sequence: undefined,
        UpdatedBy: undefined,
        UpdatedOn: undefined,
        IsHideDeletedSetting: true,
    },
];

export const BOM_TYPE = {
    PRODUCT: "I",
    INSTRUCTION: "N",
    EXPERIMENT: "E",
    UNAPPROVED: "U",
};

export const INSTRUCTION_VALUE = {
    YES: "Y",
};

export const BASIC_ROUTES_URL = {
    HOME: "/home",
    EXPERIMENT_FORMULA_TAB: "/experiment-formula/tab",
    REPORTS: "/reports/bom-view-event-report",
    UNAPPROVED: "/master-data/unapproved",
    CREATIVE_REVIEW_REPORTS: "/reports/gra-compliance-report",
    MASTER_DATA: "/master-data/ipc-selection",
    BOM_RESTRICTION: "/master-data/experiment-analysis",
    COMMON_LAYOUT: "/master-data/column-layout",
    USER_SETTINGS: "/user-settings",
    INSTRUCTION: "/master-data/instruction",
    MY_TASKS: "/my-tasks",
    INTERNAL_SAMPLE_REQUEST: "/internal-sample-request",
    FEATURE_FEEDBACKS: "/feature-feedback",
};

export const PATH_URL = {
    USER_SETTINGS: "user-settings",
    COMMON_LAYOUT: "master-data/column-layout",
    BOM_RESTRICTIONS: "master-data/experiment-analysis",
    IPC_SELECTION: "master-data/ipc-selection",
    MASTER_DATA: "master-data",
    REPORTS: "reports",
    BOM_VIEW_REPORTS: "reports/bom-view-event-report",
    UNAPPROVED: "master-data/unapproved",
    CREATIVE_REVIEW_REPORTS: "reports/gra-compliance-report",
    HOME: "home",
    MY_TASKS: "my-tasks",
    INTERNAL_SAMPLE_REQUEST: "internal-sample-request",
    FEATURE_FEEDBACKS: "feature-feedback",
};

export const RECENT_CART_ADD_TIME = 2000;

export const COLUMN_LAYOUT_HIGH_LIGHT_TIME = 5000;

export const DATA_TYPE = {
    STRING: "string",
    BOOLEAN: "boolean",
    ARRAY: "array",
};

export const BATCH_SIZE = "Batch Size";

export const MAX_INSTRUCTION_LENGTH = 68;

export const DELAY_TIME_FOR_OTHER_EXP_FOCUS = 50;

/* Tree Grid Constants */
export const EMPTY_VALUES_XXX = "-xxx-";
export const CHILDMAPPING = "subformula"; // change the value once we change to actual data
export const GRID_EDIT_MODE = "Cell";
export const GRID_SELECTION_TYPE = {
    SINGLE_SELECTION: "single",
    MULTIPLE_SELECTION: "multiple",
};
export const FIRST_COLUMN_WIDTH = "60%";
export const SECOND_COLUMN_WIDTH = "40%";
export const ATTRIBUTE_HEADER_ALIGNMENT = "right";
export const ATTRIBUTE_HEADER_WIDTH = 100;
export const EXPERIMENT_HEADER_ALIGNMENT = "right";
export const EXPERIMENT_HEADER_WIDTH = 80;
export const SUB_CODE = "SUBCode";
export const NAME = "name";
export const EXP_ID = "ExpID";
export const HEADER_NAME_EXP_ID = "Exp ID";
export const INGREDIENT = "Ingrediant";
export const INSTRUCTION = "Instruction";
export const SUB_EXPERIMENT = "Sub Experiment";
export const FORMULA_SEQUENCE = "formulaSeq";
export const GRID_FROZEN_COLUMNS = 4;
export const COLUMN_SELECTION = 4;
export const YES = "YES";
export const NO = "NO";
export const NAN = "NaN";
export const WORKING_COST_VALUE = "0.000";
export const PARTS = "Parts";
/* Tree Grid Constants */

export const HOME = "home";

export const TAB = {
    ADD_TAB: "ADD_TAB",
    UPDATE_TAB: "UPDATE_TAB",
    GET_TAB: "GET_TAB",
    REMOVE_TAB: "REMOVE_TAB",
};

export const ITEMLIST_TYPE = {
    ARRAY_OF_ARRAYS: "ARRAY_OF_ARRAYS",
    ARRAY_OF_OBJECTS: "ARRAY_OF_OBJECTS",
};

export const EXPERIMENT_HEADER = {
    UPDATE_EXPERIMENT_HEADER: "UPDATE_EXPERIMENT_HEADER",
    UPDATE_TAB_HEADER: "UPDAATE_TAB_HEADER",
    ACTIVE_EXPERIMENT: "ACTIVE_EXPERIMENT",
    ADD_ATTRIBUTE_HEADER: "ADD_ATTRIBUTE_HEADER",
    REMOVE_TAB_EXPERIMENT_HEADER: "REMOVE_TAB_EXPERIMENT_HEADER",
    EXPANDED_EXPERIMENT: "EXPANDED_EXPERIMENT",
};

export const DATAMODEL = {
    TAB_DATA_MODEL: "tabDataModel",
};
/* debounce time */
export const SEARCH_DEBOUNCE_TIME = 500;

/* Tab configuration fields */
export const EXP_TAB_WIDTH = 138;
export const NON_EXP_TAB_WIDTH = 142;
export const TAB_ACTIVE = "active";
export const TAB_LOCATION = "location";
export const ADD_TAB = "add-tab";
export const REMOVE_TAB = "remove-tab";
export const RENAME_TAB = "rename-tab";
export const UPDATED_TAB = "update-tab";
export const LOAD_TABS = "load-tab";
export const TAB_ACTION = "tab-action";
export const TAB_DATA = "tab-data";
export const USER_TAB_ID = "UserTabID";
export const GET_TABS_FAILURE = "Failed to retrieve the tabs. Please reload the application";
export const TAB_NAME_EMPTY = "Workspace name cannot be blank";
export const WARNING_MESSAGE = "";
export const NOT_IN_NATURAL_ORDER = "Sort experiment by natural order to use this function.";
export const TAB_COUNT_FOR_CLOSE_ALL = 2;

/* Tab configuration fields */

export const COLUMN_ATTRIBUTE_DISPLAY_LIST = {
    SPEC: "Spec",
    COST_PER_KG: "CostPerKg",
    FLAG: "Flag",
    CBWFLAG: "FlagCBW",
    STOCK: "Stock",
    COST_PER_PARTS: "CostPerParts",
    COST_CONTRIBUTION: "CostContribution",
    // eslint-disable-next-line sonarjs/no-duplicate-string
    PLANT_ALLOCATION: "Plant Allocation",
};

export const TOOL_TIP_LENGTH = 25;

export const COST_ATTRIBUTES = ["CostPerKg", "CostPerParts", "CostContribution"];
const PLANT_ALLOCATION = "Plant Allocation";

export const APPEND_COST_ATTRIBUTES = [
    {
        costValue: "CostPerKg",
        displayValue: "/Kg",
    },
    {
        costValue: "CostPerParts",
        displayValue: "/Parts",
    },
    {
        costValue: "CostContribution",
        displayValue: "%",
    },
];

export const COULMN_LAYOUT_WITH_ATTRIBUTES = [
    "Spec",
    "CostPerKg",
    "Flag",
    "FlagCBW",
    "Stock",
    "CostPerParts",
    "CostContribution",
    "Plant Allocation",
];

export const COLUMN_LAYOUT_DELETE_ERROR = 5000;

export const COLUMN_LAYOUT_SORT_ORDER = "Sequence";

export const BOM_MENU = {
    BOM_CART: "bomCart",
    BOM_LAYOUT: "bomLayout",
};

export const CART_WARNING_INFO =
    "WARNING : Ingredient already exists in the grid and can be added using Edit Parts. Adding from cart could result in the grid going out of natural order";

export const COLUMN_LAYOUT_TYPES = {
    EDIT_PROD_SAVED: "MCL",
    EDIT_BOM_CUSTOM: "EXC",
    PRODUCT_SEARCH_CUSTOM: "PSC",
    EDIT_BOM_SAVED: "EXS",
    PRODUCT_SEARCH_SAVED: "PSS",
};

export const NEW_COPY = " - Copy";

export const COLUMN_LAYOUT_CONFIRMATION_MESSAGE = {
    title: "Warning",
    message: "Do you want to save changes?",
    subMesssage: "Unsaved changes will be lost",
    submitText: "Yes",
    cancelText: "No",
    submitBtnClass: BLUE_BTN_CSS,
};

export const OTHER_USER_EXPERIMENT_CLICK_ALERT = {
    title: "Access Denied",
    message: "Experiment is locked or set as private",
    subMesssage: "",
    submitText: "Ok",
    submitBtnClass: BLUE_BTN_CSS,
};

export const COLUMN_LAYOUT_DELETE_MESSAGE = {
    title: "Delete Column Layout",
    message: DELETE_MESSAGE,
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};

export const NOTIFICATION_DELETE_MESSAGE = {
    title: "Delete Notification",
    message: DELETE_MESSAGE,
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};

export const CREATE_EXPERIMENT = "create-experiment";
export const PARTS_PERCENTAGE = "PartsPercentage";

export const GET_TOP_LEVEL_NODES = "getTopLevelNodes";

export const DYNAMIC_PRODUCT_SEARCH_COLUMNS = [
    // eslint-disable-next-line sonarjs/no-duplicate-string
    { value: "prodtypecode", displayValue: "Product Type" },
    { value: "Spec", displayValue: "Spec" },
    { value: "CostPerKg", displayValue: "Cost/Kg" },
    { value: "Flag", displayValue: "Flag" },
    { value: "FlagCBW", displayValue: "CBW Flag" },
    { value: CC_INDICATOR, displayValue: CC_INDICATOR },
    { value: "trustee", displayValue: "Trustee" },
    { value: "Stock", displayValue: "Stock" },
    { value: "CostPerParts", displayValue: "Cost/Parts" },
    { value: "CostContribution", displayValue: "Cost %" },
    { value: "PartsPercentage", displayValue: "Parts %" },
    { value: "technology", displayValue: "Technology" },
    { value: PLANT_ALLOCATION, displayValue: PLANT_ALLOCATION },
    { value: "division", displayValue: "Division" },
];

export const NO_ATTRIBUTE_DISPLAY_VALUE = {
    prodtypecode: "Product Type",
    trustee: "Trustee",
    "CC Indicator": CC_INDICATOR,
    PartsPercentage: "Parts %",
    technology: "Technology",
    PlantAllocation: PLANT_ALLOCATION,
    division: "Division",
};

export const SUM_AGGREGATE = "Sum";
export const CUSTOM_AGGREGATE = "Custom";
export const FOOTER_SUMMARY_CLASS = "footer-summary-heading";
export const INGREDIENT_NAME = "ingredientName";
export const TOTAL_COST = "Total Cost";
export const TOTAL_PARTS = "Total Parts";
export const WORKING_COST = "Working Cost";
export const WORKING_COST_TOOLTIP_INFO = "Single Level WC as intermediates are not considered yet";
export const DEFAULT_CURRENCY = {
    ColumnValue: "USD",
    CreatedBy: 0,
    PrefTypeCode: "DefaultCurrency",
    UpdatedBy: 0,
    UserID: 0,
    UserPrefID: 145,
    UserPrefTypeID: 8,
};
export const FOOTER_FORMAT = "n4";
export const FOOTER_SUMMARY_VALUE_CLASS = "footer-summary-value";
export const SAVE_EVENT = "cellSave";
export const RP_SAVE = "RP_SAVE";
export const RP_CLICK = "RP_CLICK";

export const DISABLE = "disable";
export const EXPERIMENT = "Experiments";
export const CREATE = "Create";
export const FOLDER = "Folder";
export const CREATE_SUBMISSION = "Create Experiment submission";
export const CREATE_FOLDER_SUBMISSION = "Create Folder submission";
export const LESS_THAN = "<";
export const GREATER_THAN = ">";
export const LESS_THAN_CODE = "&lt;";
export const GREATER_THAN_CODE = "&gt;";
export const CREATED_ON = "CreatedOn";
export const DESC_VALUE = "DESC";

export const LOCKED_BY_STATUS = {
    LOCKED: "1",
    NOT_LOCKED: "0",
};

export const ERROR_TOASTER_MESSAGE = "Something went wrong. Please Try Again";

export const FMP_CONST = {
    RANGE: {
        HIGH_PREDICTION_LEVEL_FROM: 100,
        HIGH_PREDICTION_LEVEL_TO: 80,
        UNCERTAIN_PREDICTION_LEVEL: 50,
        LOW_PREDICTION_LEVEL_FROM: 20,
        LOW_PREDICTION_LEVEL_TO: 0,
    },
    FAIL: {
        HEADING: "Failed",
        MESSAGE: "This FMP will not pass Test 1.",
        CLASS: "bummer",
        VALUE: "0",
        TEXT_CLASS: "",
    },
    PASS: {
        HEADING: "Pass!",
        MESSAGE: "This FMP will pass Test 1.",
        CLASS: "good",
        VALUE: "100",
        TEXT_CLASS: "",
    },
    UNCERTAIN: {
        HEADING: "Uncertain",
        MESSAGE: "This FMP is uncertain for Test 1.",
        CLASS: "warning",
        VALUE: "10",
        TEXT_CLASS: "",
    },
    UNAVAILABLE: {
        HEADING: "Unavailable",
        MESSAGE: "FMP not available.",
        CLASS: "",
        VALUE: "",
        TEXT_CLASS: "unavailable",
    },
    PREDICTION: {
        PASS: "PASS",
        FAIL: "FAIL",
        PASS_VALUE: 1,
        FAIL_VALUE: 0,
    },
    ERROR: "Something went wrong. Please try again later.",
    PRODUCT_ERROR: "FMP Review is not applicable for product.",
    VERSION: {
        V1: "V1",
        V2: "V2",
    },
    MESSAGE_TYPE: {
        Failed: "FAILED",
        Unavailable: "UNAVAILABLE",
    },
    MAX_DOSAGE: {
        SUCCESS: "Success",
        FAILURE: "Failure",
    },
    FMP_TYPE: {
        MAX_DOSAGE: "MAX_DOSAGE",
        PREDICTION: "PREDICTION",
    },
};

export const ALL_OTHER_EXP_SEARCH_TEXT_LENGTH = 10;

export const OTHER_EXP_STATUS = {
    YES: true,
    NO: false,
};

export const SEARCH_AUDIT_STATUS = {
    STATUS_PASS: "PASS",
    STATUS_WARNING: "WARNING",
    STATUS_CRITICAL: "CRITICAL",
    STATUS_FAIL: "FAIL",
    STATUS_INFO: "INFO",
    STATUS_SEVERE: "SEVERE",
};

export const SEARCH_AUDIT_STATUS_ICON = {
    ICON_PASS: "icon-filled-pass",
    ICON_WARNING: "icon-filled-warning",
    ICON_CRITICAL: "icon-filled-critical",
    ICON_FAIL: "icon-filled-fail",
    ICON_INFO: "icon-filled-warning info",
    ICON_SEVERE: "severe",
};

export const INSTRUCTION_LENGTH = 47;

export const NUMRIC_LIMITS = {
    NUMBER_LIMIT: 11,
    DECIMAL_LIMIT: 4,
    LIMITATIONS: 9,
};

export const NUMRIC_LIMITS_FOR_SAMPLE = {
    NUMBER_LIMIT: 19,
    DECIMAL_LIMIT: 4,
};

export const DISPLAY_DECIMALS = 4;

export const APPLY_FACTOR_LIMITS = {
    PAGE_FROM: "APPLY_FACTOR",
    NUMBER_LIMIT: 5,
    DECIMAL_LIMIT: 2,
    DEFAULT_VALUE: 100,
    MAX_VALUE: 10_000,
};

export const ONLY_SPECIAL_CHAR_RESTRICT = /^[^\dA-Za-z]+$/;

export const APPLY_FACTOR_INFO =
    "Apply factor is used to increase or reduce the parts of one or more ingredients by a percentage factor provided by the user. The min value of Apply Factor is 1.00 and the max value is 10000.00";
export const EXP_FORMULA_ID = "ExpFormulaId";

export const CONTEXT_MENU_FOLDER_VIEW = "Context menu in Folder view";
export const CONTEXT_MENU_EXPERIMENT_LIST = "Context menu in Experiment list";
export const CREATE_EXPERIMENT_BUTTON = "Create button in landing page";
export const CONTEXT_MENU_CREATE_BUTTON = "Context menu in Create button";
export const CONTEXT_MENU_BOM_PAGE = "Context menu in Experiment BOM";
export const LANDING_PAGE = "Landing page";
export const EDIT_HEADER_CLICK = "Edit Header clicked";
export const VIEW_HEADER_CLICK = "View Header clicked";
export const EDIT_BOM_CLICK = "Edit BOM clicked";
export const CREATE_EXPERIMENT_CLICK = "Create Experiment clicked";
export const CREATE_EXPERIMENT_SCRATCH = "Created experiment from scratch";
export const CREATE_EXPERIMENT_SCRATCH_CLICK = "Create experiment from scratch clicked";
export const CREATE_EXPERIMENT_FROM_EXPERIMENT_CLICK = "Create experiment from Experiment clicked";
export const CREATE_EXPERIMENT_FROM_PRODUCT_CLICK = "Create experiment from Product clicked";
export const CREATE_EXPERIMENT_COPY_TO_USER_CLICK = "Create experiment, Copy to User clicked";
export const CREATE_COLLABORATION_GROUP = "Create Collaboration Group clicked";
export const NEW_FOLDER_CLICK = "New Folder clicked";
export const EDIT_BOM = "Edit Bom";
export const AUDIT = "Audit";
export const CREATIVE_REVIEW = "Creative Review clicked";
export const REVIEW_COMPARISON = "BOM/BOS Review Comparison clicked";
export const REVIEW_HISTORY = "Review History clicked";
export const DELETE_CLICK = "Delete clicked";
export const FILL_PARTS_CLICK = "Fill Parts clicked";
export const SCALE_PARTS_CLICK = "Scale Parts clicked";
export const INSERT_CLICK = "Insert clicked";
export const INSERT_INTO_EXP_BOM = "Insert item into Experiment BOM";
export const SORT_CLICK = "Sort clicked";
export const ADD_TO_COLLABORATION_GROUP_CLICK = "Add To Collaboration Group Clicked";
export const LOCK_CLICK = "Lock clicked";
export const APPLY_FACTOR_CLICK = "Apply factor clicked";
export const MARK_FOR_DELETE_CLICK = "Mark for delete clicked";
export const MARK_FOR_UNDELETE_CLICK = "Undelete clicked";
export const COOPERATORS_CLICK = "Cooperators clicked";
export const LINEAGE_CLICK = "Lineage clicked";
export const RECOST_CLICK = "Recost clicked";
export const NOTES_CLICK = "Notes clicked";
export const VARIANTS_CLICK = "Variants clicked";
export const EXPERIMENT_ACCESS_CLICK = "Experiment access clicked";
export const DELETE_VARIANTS_CLICK = "Delete Variants clicked";
export const MARK_AS_PRIVATE_CLICK = "Mark as private clicked";
export const EXPLODE_CLICK = "Explode clicked";
export const INSERT_BOM_CLICK = "Insert clicked";
export const QUICK_INSERT_CLICK = "Quick insert";
export const VIEW_PRODUCT_DATA_CLICK = "View Product data clicked";
export const RESEQUENCE_CLICK = "Resequence clicked";
export const COMBINE_INTO_NEW_EXPERIMENT_CLICK = "Combine into new experiment clicked";
export const COMBINE_DUPLICATES = "Combine duplicates clicked";
export const SEND_TO_IFFMAN = "Send to IFFMAN clicked";
export const COLUMN_LAYOUT_CLICK = "Column Layout clicked";
export const OPEN_EXPERIMENT_OR_PRODUCT = "Open Experiment/Product clicked";
export const DROP_EXPERIMENT_OR_PRODUCT = "Close Experiment/Product clicked";
export const REVISE_EXPERIMENT_CLICKED = "Revise/Copy Experiment clicked";
export const PLM_NUTRITION_CALCULATOR_CLICKED = "PLM Nutrition Calculator clicked";
export const EXPERIMENT_FOLDER = "ExperimentFolder";
export const DELETE_OPTONS = {
    CONTEXT_MENU: "contextMenu",
    CELL_DELETE: "cellDelete",
};
export const ADD_TO_FAVOURITES_CLICKED = "Add to Favorites click";

export const STOCK_UNIT_DISPLAY = "Stock(kg)";
export const ALLOCATION = "Allocation";
export const COLUMN_LAST_USED = {
    COLUMN_SEATCH: "ColumnLastUsedSearch",
    COLUMN_BOM: "ColumnLastUsedBOM",
};
export const OTHER_USER_EXP_SEARCH_ERRORS = {
    OTHER_USER_SEARCH_ERROR: "Able to search only other users experiment",
    EXPERIMENT_CODE_LENGTH_ERROR: "Enter full experiment code to search",
};

export const COLUMN_LAYOUT_ADDED_PAGE = {
    SEARCH: "Search",
    BOM: "BOM",
};

export const EDITION_SUGGESTION_CONSTANTS = {
    DISABLED_ITEM: "Disabled item",
    REPLACE: "Replace",
    INSERT: "Insert",
};

export const EDITION_SUGGESTION_ACTION_IN = {
    PRODUCT_SEARCH: "Product search",
    EDITION_SUGGESTION: "Edition suggestion",
    MINI_EDITIOR: "Mini editior",
    BOM: "BOM",
};

export const MANAGE_SUGGESTION = "Manage_suggestion";

export const EVENT_KEYS = {
    ENTER: "Enter",
    CLICK: "click",
};

export const MASTER_DATA = {
    FLAVOR_TYPES: "flavorTypes",
    COSTS: "costs",
    SPECS: "specs",
    PRODUCT_TYPES: "productTypes",
    FACILITIES: "facilities",
    PLANT_SOURCE: "plantsAndSources",
    FLAVOR_CLASS: "flavorClasses",
    FLAGS: "flags",
    CBW_FLAGS: "cbwflags",
    CURRENCIES: "currencies",
    CURRENCY_RATE: "currenciesRate",
    TECHNOLOGY: "technology",
    UOM_DETAILS: "uomDetails",
};

export const MASTER_DATAS = [
    "flavorTypes",
    "costs",
    "specs",
    "productTypes",
    "facilities",
    "plantsAndSources",
    "flavorClasses",
    "flags",
    "cbwflags",
    "currencies",
    "currenciesRate",
    "uomDetails",
    "technology",
];

export const CREATE_EXP_DISABLED_FIELDS = [
    "ExpName",
    "ExpID",
    "ExpCode",
    "IPC",
    "WorkingCost",
    "CreatedBy",
    "CreatedOn",
    "LockedBy",
    "LockedOn",
    "ExpSource",
    "ExperimentCost",
    "WorkingCostInOtherCurrency",
    "Trustee",
    "ProjectID",
    "CustomerID",
];

/* IPC SELECTION */
export const IPC_SELECTION_DELETE_MESSAGE = {
    title: "Delete IPC Selection",
    message: DELETE_MESSAGE,
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};

export const IPC_SELECTION_MARK_AS_PUBLIC_MESSAGE = {
    title: "Confirm Change?",
    message: undefined,
    submitText: "Yes",
    cancelText: "No",
    submitBtnClass: BLUE_BTN_CSS,
};

export const COOPERATOR_ACCESS = {
    ACCESSLIST: "AL",
    COOPERATOR: "CO",
    COOPERATOR_STAFF: "Add Cooperator Staff",
    EXPERIMENT_LIST: "Experiment Access",
    COOPERATORS_HEADER: "Cooperators",
    ACCESSLIST_HEADER: "Access List",
    ADD_ACTION: "ADD",
    REMOVE_ACTION: "REMOVE",
};

export const PRIVACY_LISTS = [
    { name: "Public", isChecked: false },
    { name: "Private", isChecked: false },
];
export const PROC_TYPE = {
    NONE: "NONE",
    X: "X",
    BOTH: "BOTH",
    EMPTY: " ",
};

export const PRODUCT_TYPE_CODE = "prodtypecode";
export const FACILITY_CODE = "facilitycode";
export const PLANT_ID = "PlantID";
export const USERPREFERENCE_DEFAULT_PLANT_CODE = "DefaultPlant";
export const USERPREFERENCE_DEFAULT_SOURCE_CODE = "DefaultSource";
export const ATTRIBUTE_DATA_RESULT_LIMIT = 2000;
export const PROD_TYPE_CODE = "Prodtypecode";
export const CURRENCY = "Currency";
export const DECIMALS_PRINTED = 6;
export const DEFAULT_DECIMALS_VALUE = 3;
export const INVALID = "INVALID";
export const STATIC_TEXT_HEIGHT = 19;
export const STATIC_TASK_HEIGHT = 50;
export const STATIC_HEADEAR_HEIGHT = 120;
export const ASSIGNED_PRINT_WIDTH = 654;
export const FONT_STYLE = "16px NunitoSans-Bold";

export const PRODUCT_FLAG_AUDIT = {
    AUDIT: {
        PLANT_ALLOCATION: "PLANT ALLOCATION",
        PLANT_DELETION: "PLANT DELETION",
        DIVISION: "FLAV",
        AUDIT_PRIORITY: "priority",
        // eslint-disable-next-line sonarjs/no-duplicate-string
        RESTRICTED_USE: "RESTRICTED USE",
        // eslint-disable-next-line sonarjs/no-duplicate-string
        INHERITED_RESTRICTED_USE: "INHERITED RESTRICTED USE",
        PRIORITY: {
            PASS: 0,
            INFO: 1,
            WARNING: 2,
            FAIL: 3,
            CRITICAL: 4,
        },
        TYPE: {
            FLAG: "FLAG",
            COST_BOOK: "COSTBOOK",
            DIVISION: "DIVISION",
            MA_FLAG: "MA_FLAG",
        },
        RESULT: {
            INFO: "INFO",
            PASS: "PASS",
            WARNING: "WARNING",
            FAIL: "FAIL",
            CRITICAL: "CRITICAL",
            SEVERE: "SEVERE",
        },
        FLAGS: ["DO NOT USE", "ARCHIVE", "NO NEW USE", "RESTRICTED USE", "INHERITED RESTRICTED USE"],
    },
};

export const DATE_RANGE_DROPDOWN = [
    { Today: "today", value: "today", displayValue: "Today" },
    { Yesterday: "yesterday", value: "yesterday", displayValue: "Yesterday" },
    { OneWeek: "last7Days", value: "last7Days", displayValue: "Last 7 days" },
    { OneMonth: "lastMonth", value: "lastMonth", displayValue: "Last 30 days" },
    { ThreeMonths: "last180Days", value: "last180Days", displayValue: "Last 180 days" },
];

export const DATE_RANGE_DROPDOWN_NOTES = [
    { OneWeek: "last7Days", value: "last7Days", displayValue: "Last 7 days" },
    { OneMonth: "lastMonth", value: "lastMonth", displayValue: "Last 30 days" },
    { allTime: "all", value: "all", displayValue: "All" },
];

export const NOTIFICATION_EVENTS_TYPE = {
    SHARE_EXPERIMENT: "Share Experiment",
    UN_SHARE_EXPERIMENT: "Un Share Experiment",
    SHARE_CO_OP: "Share Co Operator",
    UN_SHARE_CO_OP: "Un Share Co Operator",
    COPY_EXPERIMENT: "Copy Experiment",
    COLLABORATION_GROUP_ADD_USER: "Add user to collaboration group",
    VIEWED_EXPERIMENT: "Viewed Experiment",
};

export const NOTES_CONFIRMATION_MESSAGE_PRIVATE = {
    title: "Notes Privacy Update",
    message: "Set this Note to Private?",
    submitText: "Yes",
    cancelText: "No",
    submitBtnClass: BLUE_BTN_CSS,
};

export const NOTES_CONFIRMATION_MESSAGE_PUBLIC = {
    title: "Notes Privacy Update",
    message: "Set this Note to Public?",
    submitText: "Yes",
    cancelText: "No",
    submitBtnClass: BLUE_BTN_CSS,
};

export const NOTES_DELETE_MESSAGE = {
    title: "Delete Experiment Notes",
    message: DELETE_MESSAGE,
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};

export const NOTES_PRIVACY = {
    private: "1",
    public: "0",
};

export const NOTIFICATION_TYPE_ID = {
    INFORMATION: 1,
    ERROR: 2,
    WARNING: 3,
};

export const NOTIFICATION_EVENT_ID = {
    SHARE_EXPERIMENT: 1,
    UN_SHARE_EXPERIMENT: 2,
    SHARE_CO_OP: 3,
    UN_SHARE_CO_OP: 4,
    COPY_EXPERIMENT: 5,
    CG_ADD_USER: 7,
    LOCK_EXPERIMENT: 8,
    VIEWED_MY_EXPERIMENT: 9,
};

export const IS_PUSH_NOTIFICATION = {
    true: "true",
    false: "false",
};

export const NOTIFICATIONS_TYPE = [
    { name: "All", class: "all", checked: true },
    { name: "Warning", class: "warning", checked: false },
    { name: "Error", class: "error", checked: false },
    { name: "Information", class: "information", checked: false },
];

export const NOTIFICATION_DATE_FORMAT = {
    DATE_FORMAT: "ddd D MMM YYYY",
};

export const NOTES_TYPES = {
    USER: "U",
    SYSTEM: "S",
    SYSTEM_VALUE: "SYSTEM",
};

export const INVALID_USER = {
    name: "DATA",
    value: "Invalid User",
};

export const VARIANT_CONSTANTS = {
    EDIT: "Edit",
    INSERT_HEADER: "Insert",
    SAVE: "SAVE",
    INSERT_BUTTON: "INSERT",
    title: "Delete Variant",
};

export const VARIANT_DELETE_MESSAGE = {
    title: "",
    expCode: "",
    message: DELETE_MESSAGE,
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};

export const COMMON_DIALOG_OLD = {
    panelClass: PANEL_CLASS,
    width: "540px",
    disableClose: true,
    data: {},
};

export const FILL_PARTS_DIALOG = {
    panelClass: PANEL_CLASS,
    width: "560px",
    disableClose: true,
    data: {},
};

export const COMMON_DIALOG_CPY_EXP = {
    panelClass: [PANEL_CLASS, "from-product"],
    width: "540px",
    disableClose: true,
    data: {},
};

export const COMMON_EXPERIMENT_ACCESS_DIALOG = {
    panelClass: PANEL_CLASS,
    width: "440px",
    disableClose: true,
    data: {},
};

export const COMMON_DIALOG = {
    panelClass: DIALOG_MODEL,
    width: "540px",
    disableClose: true,
    data: {},
};

export const COMMON_DIALOG_ADD_FAVORITES = {
    panelClass: DIALOG_MODEL,
    width: "898px",
    disableClose: true,
    data: {},
};

export const COMMON_DIALOG_SALES_PRODUCT = {
    panelClass: PANEL_CLASS,
    width: "878px",
    disableClose: true,
    data: {},
};
export const COMMON_DIALOG_WID = {
    panelClass: [DIALOG_MODEL, "dialog-model-md"],
    width: "95%",
    disableClose: true,
    data: {},
};

export const COMMON_DIALOG_MYTASK = {
    panelClass: [DIALOG_MODEL, "dialog-model-md", "TE-MyTask"],
    width: "95%",
    height: "95vh",
    disableClose: true,
    data: {},
};

export const FULL_SCREEN_POPUP = {
    panelClass: "CreativeReviewPopup",
    width: "95%",
    disableClose: true,
    data: {},
};
export const PICK_IPC_POPUP = {
    panelClass: "pick-ipc-popup",
    width: "95%",
    disableClose: true,
    data: {},
};

export const CR_POPUP = {
    panelClass: ["TE-CR", "CreativeReviewPopup"],
    width: "95%",
    disableClose: true,
    data: {},
};

export const VIEW_ACCESS_POPUP = {
    panelClass: [PANEL_CLASS, "viewAccessList"],
    height: "615px",
    width: "1400px",
    disableClose: true,
    data: {},
};

export const IPC_UPLOAD_REPORT = {
    panelClass: [PANEL_CLASS, "dialog-upload-report"],
    width: "540px",
    disableClose: true,
    data: {},
};

export const REVISE_COPY_DIALOG = {
    panelClass: DIALOG_MODEL,
    width: "460px",
    disableClose: true,
    data: {},
};

export const FLASHPOINT_MESSAGE = {
    Flammable: "This formulation is predicted to be flammable.",
    IsNonFlammable: "This formulation is predicted to be non-flammable.",
    ErrorMessage: "Something went worng. Please try later.",
    unpredictabale: "Flashpoint prediction is not available.",
};
export const FLASHPOINT_SUCCESS = "success";
export const FLASHPOINT_ERROR = "error";
export const HEAT_UNIT = {
    Farenheit: "F",
    Celcius: "C",
};

export const NO_DATA_FOR_TEMPERATURE = "-";
export const KEYBOARD_KEYS = {
    INSERT: "Insert",
    ESCAPE: "Escape",
    ENTER: "Enter",
    DELETE: "Delete",
    DOWN_ARROW: "ArrowDown",
    UP_ARROW: "ArrowUp",
    LEFT_ARROW: "ArrowLeft",
    RIGHT_ARROW: "ArrowRight",
    BACK_SPACE: "Backspace",
    ROW_CLICK: "rowClicked",
    SPACE: " ",
    TAB: "Tab",
    COPY: "c",
    F10: "F10",
};

export const WORKSPACE_ERROR = {
    KEYWORD: "workspace",
    ERROR_MSG: "Keyword Workspace not allowed",
};

export const IS_LANDING_OR_EDITOR_PAGE = {
    Landing: "Landing",
    Editor: "Editor",
};

export const IPC_EXPCODE_LENGTH = {
    IPC_LENGTH: 8,
    EXP_CODE_LENGTH: 10,
    INVALID_EXPCODE_OR_IPC: 9,
    EXP_ID_LENGTH: 8,
};

export const LINEAGE_ERROR_MSGS = {
    INVALID_IPC: "Enter Valid IPC",
    INVALID_EXP_CODE: "Enter Valid Experiment Code",
    INVALID_INGREDIENT: "Ingredient not valid",
};

export const FMP_POPUP = {
    panelClass: PANEL_CLASS,
    width: "490px",
    disableClose: true,
    data: {},
};

export const FLASHPOINT_POPUP = {
    panelClass: PANEL_CLASS,
    width: "510px",
    disableClose: true,
    data: {},
};

export const LINEAGE_POPUP = {
    panelClass: "full-width_popup",
    width: "100%",
    disableClose: true,
    data: {},
};

export const LINEAGE_TOOLTIP_MSG = {
    PRODUCT: "Products",
    EXPERIMENT: "Experiment",
    EXP_NOT_OWNED: "Experiments not owned",
    PROD_NOT_OWNED: "Products not owned",
};

export const LINEAGE_CHILD_TYPEID = {
    PRODUCT: 1,
    EXPERIMENT: 2,
};

export const APPEND_EMPTY_VALUE = "";

export const ATTRIBUTE_CLASS_NAME = {
    ATTRIBUTE_TEXT: "ag-cell-attrib",
    ATTRIBUTE_TEXT_RIGHT: "ag-cell-attrib cell-txtRight",
    ATTRIBUTE_TEXT_CENTER: "ag-cell-attrib cell-txtCenter",
};

export const LINEAGE_CLASS_NAME = {
    HIGHTLIGHT_TEXT: "span.highlight-text",
    HIGHTLIGHT_TEXT_YELLOW: "span.highlight-text.yellow",
    HIGHLIGHT_STYLE: "highlight-text",
};

export const EXPERIMENT_ANALYSIS_DELETE_MESSAGE = {
    title: "Delete Experiment Bom Recommendation",
    message: DELETE_MESSAGE,
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};

export const DELETE_FOLDER_DIALOG_MESSAGE = {
    title: "Delete Folder",
    message: DELETE_MESSAGE,
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};
export const DELETE_COLLABORATION_GROUP = "Delete Collaboration Group clicked";
export const DELETE_COLLABORATION_DIALOG_MESSAGE = {
    title: "Delete Group",
    message: DELETE_MESSAGE,
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};

export const SET_EXPERIMENT_PRIVACY_MESSAGE = {
    title: "Warning!",
    message: "text",
    subMesssage: "text",
    submitText: "OK",
    cancelText: "Cancel",
    submitBtnClass: BLUE_BTN_CSS,
};

export const CANT_DELETE_FOLDER_DIALOG_MESSAGE = {
    title: "Delete Folder",
    message: "Cannot delete",
    subMesssage: "Folder is not empty",
    submitText: "OK",
};

export const ALREADY_OPEN = {
    title: "Warning!",
    message: "Experiment already open in the workspace.",
    subMesssage: undefined,
    submitText: "OK",
};

export const CANT_OPEN_OTHERS_UNACCESS_EXPERIMENTS = {
    title: "Warning!",
    message: "No access to this experiment.",
    subMesssage: "Experiment is not yours, is locked, is private, and you are not a member of the access list.",
    submitText: "OK",
    submitBtnClass: BLUE_BTN_CSS,
};

export const EXPERIMENT_ACCESS_RESPONSE = {
    title: "Warning!",
    message: undefined,
    subMesssage: undefined,
    experimentAccessInfo: undefined,
    cancelText: "OK",
    submitBtnClass: BLUE_BTN_CSS,
};

export const CANT_OPEN_MORE_EXPERIMENTS = {
    title: "Warning!",
    message: "You have exceeded the limit.",
    subMesssage: undefined,
    submitText: "OK",
};

export const CREATIVE_REVIEW_BATCH_PROCESS = {
    title: "Warning!",
    message: "You are requesting more than 20 reviews.",
    subMesssage: undefined,
    submitText: "OK",
    cancelText: "CANCEL",
    submitBtnClass: BLUE_BTN_CSS,
};
export const ALREADY_ADDED_IN_CART = {
    title: "Warning!",
    message: "Experiment already in cart.",
    subMesssage: undefined,
    submitText: "OK",
};

export const DECIMAL_LIMIT = {
    SPECIAL_KEYS: [
        "Backspace",
        "Tab",
        "End",
        "Home",
        "ArrowLeft",
        "ArrowUp",
        "ArrowDown",
        "ArrowRight",
        "Del",
        "Delete",
        "Enter",
        "PageUp",
        "PageDown",
    ],
    DECIMAL_POINT: ".",
    MAX: 10_000,
    MINUS_KEY: "-",
    DECIMAL_KEY: "Decimal",
};
export const CREATE_EXPERIMENT_FROM = {
    FROM_EXPERIMENT: "Create Experiment From Experiment",
    FROM_PRODUCT: "Create Experiment From Product",
    NO_OF_COPIES: "NumberOfCopies",
    IS_VERSION: "IsVersion",
    IS_COPY_ALL_NOTES: "IsCopyAllNotes",
    IS_COPY_CREATIVE_TASK: "IsCopyCreativeTask",
};

export const COLUMN_LAYOUT_FORMCONTROLNAME = {
    ATTRIBUTE: "Attributes",
};
export const PROD_SEARCH_COLUMN_LAYOUT_URL = "productSearch";

export const COLUMN_LAYOUT_DEFAULT = {
    IS_DEFAULT: "1",
    IS_NOT_DEFAULT: "0",
};

export const FILTER_ATTRIBUTES = {
    FILTER_TYPE: "text",
    TYPE: "contains",
};

export const DEFAULT_EXPERIMENT_FOLDER = [
    { FolderID: 0, FolderName: ALL_MY_EXPERIMENTS_CONST, hasAccess: true },
    { FolderID: 1, FolderName: "All Other Experiments", hasAccess: true },
    { FolderID: 2, FolderName: "Shared Experiments", hasAccess: true },
    { FolderID: 3, FolderName: RECENTLY_USED_EXPERIMENT, hasAccess: true },
    { FolderID: 4, FolderName: "All Global Experiments", hasAccess: true },
    { FolderID: 5, FolderName: "Trustee Experiments", hasAccess: true },
];

export enum DefaultExperimentFolderIds {
    ALL_MY_EXPERIMENTS = 0,
    ALL_OTHER_EXPERIMENTS = 1,
    SHARED_EXPERIMENTS = 2,
    RECENTLY_USED_EXPERIMENTS = 3,
    COLLABORATION_FOLDER_ID = 6,
    ALL_GLOBAL_EXPERIMENT = 4,
    SCROLLING_FOLDER_ID = 7, // To store scrolling position in ngrx, we are assuming folderId as 7 (lastDefaultFolderID + 1)
    TRUSTEE_EXPERIMENTS = 5,
}

export const experimentFolderName = {
    ALL_MY_EXPERIMENTS: "All Experiments",
    ALL_OTHER_EXPERIMENTS: "Other Experiments",
    SHARED_EXPERIMENTS: "Shared Experiments",
    RECENTLY_USED_EXPERIMENTS: "Recently Used Experiment",
    COLLABORATION_FOLDER_ID: "Experiments By Collaboration Group",
    EXPERIMENTS_BY_FOLDERID: "Experiments By Folder ID",
    ALL_GLOBAL_EXPERIMENTS: "Global Experiments",
    TRUSTEE_EXPERIMENTS: "All Trustee Experiments",
    TRUSTEE_EXPERIMENTS_BY_FOLDERID: "Trustee Experiments By Folder ID",
};
export const SPECIFIC_EXPERIMENTS_FOLDER = 3;

export const LANDING_PAGE_GRID_COLUMN = {
    STATUS: "Status",
};

export const FOLDER_DESCRIPTION = "FolderName";

export const FORM_VALIDITY = {
    FORM_VALID: "VALID",
    FORM_INVALID: "INVALID",
};

export const EXPERIMENT_COLUMNS = {
    COMMENT: "Comment",
    TASTE_DESCRIPTOR: "TasteDescriptor",
    EXPERIMENT_NAME: "ExpName",
    PRODUCT_TYPE_ID: "ProductTypeID",
    TRUSTEE_NAME: "TrusteeName",
    CREATED_BY_NAME: "CreatedByName",
    EXPERIMENT_ID: "ExpID",
    IPC_CODE: "IPC",
    CREATED_ON: "CreatedOn",
    PLANT_ID: "PlantID",
    FOLDER: "FolderName",
};

export const COMMENT = "Comment";
export const TASTE_DESCRIPTOR = "TasteDescriptor";
export const EXPERIMENT_NAME = "ExpName";
export const PRODUCT_TYPE_ID = "ProductTypeID";
export const TRUSTEE_NAME = "TrusteeName";
export const CREATED_BY_NAME = "CreatedByName";
export const EXPERIMENT_ID = "ExpID";
export const IPC_CODE = "IPC";
export const ADD_TO_CART = "Insert into mini editor";

export const COMPOUND_NAMES_FOR_RENDERER = {
    BOM_VIEW_REPORT: "BomViewEventReportComponent",
    UNAPPROVED: "UnapprovedListComponent",
    PRODUCT_VARIANT: "ProductVariantComponent",
    INSTRUCTION: "ViewInstructionComponent",
};

export const FAV_TOOL_TIP = {
    ADD: "Add to Favorite",
    REMOVE: "Remove from Favorite",
};

export const OTHERUSER_EXP_MSG = "Experiment is unlocked or marked as private or both";
export const ARRAY_INDEX_NOT_FOUND = -1;
export const SEARCH_DRAWER_HEADING = {
    [SearchType.insertItem]: "Insert into experiment BOM",
    [SearchType.ipcView]: "View Results",
    [SearchType.openProductOrExperiment]: "OPEN PRODUCTS / EXPERIMENTS",
    [SearchType.pickIpc]: "Pick IPC",
};
export const OPEN = "OPEN";
export const CLOSE = "CLOSE";
export const APPLY = "APPLY";
export const CANCEL = "CANCEL";
export const WORKSPACE_DETAIL = "WorkSpaceDetail";
export const PRODUCT_SEARCH_ID = "ProductSearchID";
export const USER_TAB_EXP_ID = "UserTabExpID";
export const USER_TAB_DETAILS = "UserTabDetails";
export const USER_COL_LAYOUT = "UserColumnLayoutType";
export const IPC = "ipc";
export const INSTRUCTION_ID = "InstructionID";
export const UNAPPROVED_ID = "UnapprovedID";
export const ZERO_STRING = "0";
export const DESCRIPTION = "Description";

export const COLLABORATION_FOLDER_ID = 6;
export const COLLABORATION_GROUP_NAME = "CollaborationGroup";
export const COLLABORATION_OWN_GROUP = "0";
export const COLUMN_ID = "columndID";
export const DRAGGED_EXP = " Experiments are being dragged...";
export const MAX_EXPORPRO_OPEN_LENGTH = 5;

export const ATTRIBUTES = "Attributes";
export const COLLABORATION_GROUP_COUNT = 0;
export const MAX_USER_LIMIT_COLLABORATION_GROUP = 20;
export const COLLABORATION_GROUP_LIST_SORTBY_NAME = "GroupName";

export const USER_COLLABORATION_GROUP = {
    REMOVE_EXPERIMENT_SUCCESS: "Experiment removed successfully",
    REMOVE_EXPERIMENT_FAILED: "Failed to remove experiment from list",
    IS_OWNED_GROUP: 1,
    REMOVE_EXPERIMENT_SUCCESS_RESPONSE: "Processed Successfully.",
};

export const USER_ATTRIBUTES = {
    USER_ID: "UserID",
};

export const EXPERIMENT_ATTRIBUTES = {
    EXPERIMENT_STAFF: "ExperimentStaff",
    FLAVOUR_TYPE_NAME: "FlavourTypeName",
};

export const EDIT_COLLABORATION_GROUP = "Edit Collaboration Group clicked";

export const COLLABORATION_BUTTON_ACTIONS = {
    CREATE_GROUP: "Create Group",
    EDIT_GROUP: "Edit Group",
    DELETE_GROUP: "Delete Group",
    VIEW_GROUP: "View Group",
    DELETE: "DELETE",
    SAVE: "SAVE",
    UPDATE: "UPDATE",
};

export const COLLABORATION_USER_ID = "UserID";
export const MASTER_DATA_CONFIRMATION_MESSAGE = {
    title: "Field Required",
    message: "You have left one or more mandatory fields empty.",
    subMesssage: "Select 'Continue' to edit or 'Discard' to ignore the changes",
    infoMessage:
        "<p>You have left one or more mandatory fields empty.</br>Select '<b>Continue</b>' to edit or '<b>Discard</b>' to ignore the changes</p>",
    submitText: "Continue",
    cancelText: "Discard",
    submitBtnClass: BLUE_BTN_CSS,
};

export const EXP_SEARCH_CATEGORIES = {
    All_MY_EXPERIMENTS: ALL_MY_EXPERIMENTS_CONST,
    RECENTLY_USED: "Recently Used Experiments",
    MY_FOLDER: "My Folder",
    COLLABORATION_GROUP: "Collaboration Group",
    ALL_SHARED_EXPERIMENTS: "All shared experiments",
    ALL_OTHER_EXPERIMENTS: "All Other Experiments",
    MAX_LENGTH_ALL_OTHER_EXPERIMENTS: 10,
    MAX_LENGTH_EXCEPT_ALL_OTHER_EXPERIMENTS: 255,
    QUICK_INSERT: "Quick Insert",
    GLOBAL_EXPERIMENT: "All Global Experiments",
    TRUSTEE_EXPERIMENT: "Trustee Experiments",
};

// When changing the contents of `EXPERIMENTS_SEARCH_CATEGORIES`, make sure to check/update index of all usages
export const EXPERIMENTS_SEARCH_CATEGORIES = [
    ALL_MY_EXPERIMENTS_CONST,
    "All Shared Experiments",
    RECENTLY_USED_EXPERIMENT,
    "My Folder",
    "Collaboration Group",
    EXP_SEARCH_CATEGORIES.ALL_OTHER_EXPERIMENTS,
];

export const DISABLE_ADD_TO_COLLABORATION = [
    DefaultExperimentFolderIds.ALL_OTHER_EXPERIMENTS,
    DefaultExperimentFolderIds.COLLABORATION_FOLDER_ID,
    DefaultExperimentFolderIds.RECENTLY_USED_EXPERIMENTS,
    DefaultExperimentFolderIds.SHARED_EXPERIMENTS,
];

export const SPECIAL_CHAR = "-.";

export const ACCESS_DENIED_CREATEEXPERIMENT_MENU_LIST = [MENU_LIST.EXPERIMENT];
export const ACCESS_DENIED_EXPERIMENT_MENU_LIST = [
    MENU_LIST.CREATEEXPERIMENT,
    EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH,
    EXPERIMENT_TYPE_CONTEXT_MENU.FROM_PRODUCT,
];

export const CREATIVE_REVIEW_CONFIRMATION_MESSAGE = {
    title: "Warning",
    message: "Some of the item in the review list does not contain dosage",
    subMesssage: "Do you want to continue the reviews without dosage?",
    submitText: "Yes",
    cancelText: "No",
    submitBtnClass: BLUE_BTN_CSS,
};

export const COLUMN_LAYOUT = {
    SPEC_CODE: "speccode",
    COST_BOOK_CODE: "costbookcode",
    FLAG_CODE: "flagcode",
    CBW_FLAG_CODE: "cbwflagcode",
    PLANT_CODE: "plantCode",
};

export const WORKING_COST_RESPONSE = ["Invalid", "", "Not Applicable"];

export const ERROR_STATUS_CODE = [500, 401, 400];

export const REVISE_EXPERIMENT_COPIES = 1;

export const BOM_ITEM_LEVELS = {
    SUB_EXPERIMENTS: 1,
};

export const RECENTLY_USED_ACCESS_LIST = {
    QUICK_SEARCH: "Quick Search",
    QUICK_OPEN: "Quick Open",
    CREATIVE_REVIEW: "Creative Review",
    PRODUCT_DATA: "Product Data",
    OPEN_PRODUCT: "Open Product",
    CREATE_EXPERIMENT_FROM_PRODUCT: "Experiment from Product",
    ATTRIBUTE_ANALYSIS: "Attribute Analysis",
};
export const USER_PLANT_ALLOCATION_ISSUE = {
    title: "Warning!",
    message: undefined,
    subMesssage: undefined,
    submitText: "OK",
};

export const USER_PLANT_ALLOCATION_ISSUE_SCENARIOS = {
    FROM_EXPERIMENT: "from experiment",
    FROM_PRODUCT: "from product",
    REVISE: "Revise",
    COPY_TO_USER: "Copy to user",
};

export const COPY_TO_USER_RESPONSE_STATUS = {
    SUCCESS: "Success",
    ERROR: "ERROR",
    NO_USER_PLANT_EXIST_ERROR_CODE: "0",
    COPY_TO_USER_FAILED_ERROR_CODE: "1",
};

export const DEFAULT_FOLDER_ID = 0;

export const EXPERIMENT_SEARCH_TEXT = 10;

export const DEFAULT_EXPERIMENT_PRIVACY = "Public";

export const PRIVATE_EXPERIMENT_PRIVACY = "Private";

export const SEARCH_EXPERIMENTS_CATEGORY_CHECKBOX = {
    CODE: "Code",
    EXP_ID: "Exp ID",
    NAME: "Name",
};

export const PRODUCT_SEARCH_SALES_TITLE = "Search Product IPC by Sales Number";

export const DEFAULT_COLUMN_LAYOUT = "0";

export const COLUMN_LAYOUT_TAB_INDEX = 1;

export const DIRECT_SORT_COLUMN = ["IPC", "Description", "Product Type"];

export const NESTED_SORT_COLUMNS = { Cost: "Cost", Flag: "Flag", Spec: "Spec" };

export const DIRECT_SORT_COLUMN_WITHKEY = {
    IPC: "ipc",
    Description: "description",
    "Product Type": ColumnLayouts.PRODUCT_TYPE,
};

export const SORT_COLUMNS = {
    Cost: {
        value: "costbooks",
        key: "mnc",
        code: "costbookcode",
    },
    Spec: {
        value: "specs",
        key: "origvalue1",
        code: "speccode",
    },
    Flag: {
        value: "flags",
        key: "flagcode",
        code: "flagcode",
    },
};

export const DEFAULT_PRODUCT_SEARCH_SORT = {
    ipc: {
        order: "asc",
    },
};

export const ZERO_SCALE_PARTS = 0;

export const SCALE_PARTS = "ScaleParts";

export const UNAPPROVED_SEARCH_TABLE = {
    UNAPPROVEDID_COLUMN_ID: "UnapprovedID",
    UNAPPROVEDID_COLUMN_HEADERTEXT: "ID",

    DESCRIPTION_NAME_COLUMN_ID: "Description",
    DESCRIPTION_NAME_COLUMN_HEADERTEXT: "Description",

    COSTKG_COLUMN_ID: "Cost",
    COSTKG_COLUMN_HEADERTEXT: "Cost/KG",

    COSTKGCURRENCY_COLUMN_ID: "CostCurrencyCode",
    COSTKGCURRENCY_COLUMN_HEADERTEXT: "Cost/KG <br> Currency",

    CATEGORY_COLUMN_ID: "Category",
    CATEGORY_COULMN_HEADERTEXT: "Category",

    MARKETCODE_COLUMN_ID: "MarketType",
    MARKETCODE_COULMN_HEADERTEXT: "Market Code",

    CREATEDBY_COLUMN_ID: "CreatedBy",
    CREATEDBY_COULMN_HEADERTEXT: "Created By",

    CREATEDON_COLUMN_ID: "CreatedOn",
    CREATEDON_COULMN_HEADERTEXT: "Created On",
};

export const CATEGORY = "Category";

export const DEFAULT_SPEC_FLASHPOINT = {
    COLUMN_NAME: "FLASHPOINT",
    DEFAULT_VALUE: "C",
    USER_PREFERENCE_TYPEID: 23,
};

export const FLASHPOINT_SPEC_LIST = [
    { value: "F", description: "Fahrenheit" },
    { value: "C", description: "Celsius" },
];
export const SLIDE_PANEL_DIALOG = {
    panelClass: [DIALOG_MODEL, "dialog-wide"],
    width: "95%",
    disableClose: true,
    data: {},
};
export const SLIDE_PDS_DIALOG = {
    panelClass: [DIALOG_MODEL, "TE-PDS"],
    width: "95%",
    disableClose: true,
    data: {},
};
export const DETAILED_COST_PDS_DIALOG = {
    panelClass: [DIALOG_MODEL, "detailed_cost_pds"],
    width: "95%",
    disableClose: true,
    data: {},
};
export const INGREDIANT_DIALOG = {
    panelClass: [DIALOG_MODEL, "model-popup"],
    width: "850px",
    disableClose: true,
    data: {},
};

export const REPRINT_LABEL_DIALOG = {
    panelClass: [PANEL_CLASS, "dialog-model-reprintLabel"],
    width: "760px",
    disableClose: true,
    header: SAMPLE_TYPE.REPRINT_LABEL,
    data: {},
};

export const COMMON_DIALOG_WORKING_COST = {
    panelClass: [PANEL_CLASS, "dialog-model-workingCost"],
    width: "95%",
    disableClose: true,
    data: {},
};

export const IPC_SELECTION_DIALOG = {
    panelClass: [PANEL_CLASS, "dialog-ipcSelection"],
    width: "95%",
    disableClose: true,
    data: {},
};

export const WARNING_CLOSE_ALL_TABS = {
    panelClass: PANEL_CLASS,
    width: "540px",
    disableClose: true,
    data: {},
};

export const CLOSE_ALL_TABS = {
    name: "closeAllTabs",
    title: "Warning!",
    message: "This Action will close all the open workspace at once. <br> Do you want to Proceed?",
    subMesssage: undefined,
    submitText: "YES",
    cancelText: "NO",
    submitBtnClass: BLUE_BTN_CSS,
};

export const EXPERIMENT_PRIVACY = [
    { value: "Public", description: "Public" },
    { value: "Private", description: "Private" },
];

export const TASTE_EDITOR = "Taste Editor";

export const PROJECT_NUMBER_ERROR = "Please provide project number";

export const CAN_SORT_DYNAMIC_COLUMNS = {
    CostPerKg: "CostPerKg",
    Spec: "Spec",
    Flag: "Flag",
    prodtypecode: "prodtypecode",
};

export const EXP_SCREEN_COLUMN_LAYOUT = {
    SORT_BY: "sequence",
    SEQUENCE_INITIAL_VALUE: 0,
    SEQUENCE_INCREMENT: 1,
};

export const DEFAULT_EXP_SCREEN_COLUMN_LAYOUT = [
    { field: "ExpCode", columnValue: "Experiment code", isChecked: true, isDisabled: true, sequence: 1 },
    { field: "ExpName", columnValue: "Experiment name", isChecked: true, isDisabled: true, sequence: 2 },
    { field: "ExpID", columnValue: "Experiment ID", isChecked: true, isDisabled: false, sequence: 3 },
    { field: "IPC", columnValue: "IPC", isChecked: true, isDisabled: false, sequence: 4 },
    { field: "Comment", columnValue: "Comments", isChecked: true, isDisabled: false, sequence: 5 },
    { field: "ProductTypeID", columnValue: "Product type", isChecked: true, isDisabled: false, sequence: 6 },
    { field: "CreatedOn", columnValue: "Created on", isChecked: true, isDisabled: false, sequence: 7 },
    { field: "CreatedByName", columnValue: "Created by", isChecked: true, isDisabled: false, sequence: 8 },
    { field: "PlantID", columnValue: "Plant", isChecked: false, isDisabled: false, sequence: 9 },
    { field: "TrusteeName", columnValue: "Trustee", isChecked: false, isDisabled: false, sequence: 10 },
    { field: "TasteDescriptor", columnValue: "Taste", isChecked: false, isDisabled: false, sequence: 11 },
    { field: "FolderName", columnValue: "Folder", isChecked: false, isDisabled: false, sequence: 12 },
];
export const IPC_COLUMN_LAYOUT_VALIDATION_MSG = {
    PLEASE_SELECT_ATTRIBUTE: "Please select an attribute",
    INVALID_VALUE: "Invalid Value",
};

export const PLANT_MANDATORY_ERROR = "Plant mandatory - cannot be empty";

export const STORE_HEADER_WIDTH_FOR = {
    PRODUCT_SEARCH: "productSearch",
    MINI_EDITOR: "Mini editior",
    PRODUCTSEARCH: "Product search",
    EDIT_HEADER: "",
};
export const CANT_OPEN_EXPERIMENTS = {
    title: "Warning!",
    message: undefined,
    subMesssage: undefined,
    submitText: "OK",
};

export const PANEL_WIDTH = "540px";

export const IPC_VALIDATION = {
    CANNOT_ADD: "Cannot add",
    WORKSPACE_CAPACITY: `BOM items to compare since it exceeds maximum capacity of ${MAX_EXPORPRO_OPEN_LENGTH} BOMs that can be opened in the Experiment BOM. You can open`,
    BOM_COMPARE: "BOMs to compare.",
    ALREADY_OPEN_SUB_MESSAGE: " is already open in the current tab of the Experiment BOM screen.",
    ALREADY_OPEN_MESSAGE: "Product already open ",
    ADDED_IN_CART_SUB: " is already added in the cart",
    ADDED_IN_CART_MESSAGE: "Product already in cart",
};

export const IPC_SELECTION_DELETE_ADMIN_MESSAGE = {
    title: "Delete IPC Selection",
    message:
        "This is a Public IPC Selection. Flavorists would no longer be able to use this IPC Selection. Are you sure you would like to delete?",
    subMesssage: SUBMIT_WARNING_MSG,
    submitText: "Delete",
    cancelText: "Cancel",
    submitBtnClass: RED_BTN_CSS,
};

export enum SelectedTabId {
    SOLUTION = 0,
    FEMA = 1,
    ENUM = 2,
    VARIANT = 3,
    INSTRUCTIONS = 4,
}

export const AUTO_SEARCH_START_COUNT = 3;
export const MIN_SEARCH_VALUE_LENGTH = 3;
export const NOTIFICATION_TYPE_ALL = "All";
export const API = "api";
export const STORE = "store";
export const VIEW_COLLABORATION_GROUP = "View Collaboration Group clicked";
export const SEARCH_FIELD_PLACEHOLDER = {
    GLOBAL_FOLDER_EXPERIMENT_SEARCH_PLACEHOLDER: "Search using Experiment Code/Name",
    EXPERIMENT_SEARCH_PLACEHOLDER: "Search Experiment Code/ID",
    USER_SEARCH_PLACEHOLDER: "Search by User Name",
};

export const LEAVE_COLLABORATION_GROUP = "Leave Collaboration Group clicked";
export const LEAVE_COLLABORATION_DIALOG_MESSAGE = {
    title: "Leave Group",
    message: "",
    subMesssage: "Remove all my experiments from the group",
    submitText: "Yes",
    cancelText: "Cancel",
    submitBtnClass: BLUE_BTN_CSS,
    data: {
        showCheckBox: true,
        removeAllExperiments: true,
    },
};
export const EXPERIMENT_SEARCH_CODE = {
    EXPCODE: "ExpCode",
    EXPNAME: "ExpName",
    EXPID: "ExpID",
};

export const RESIZING_WIDTH = 65;
export const DEFAULT_COLUMN_WIDTH = 150;
export const VARIANT_SCREEN_REQUIRED_FIELDS = ["RootIpc", "VariantChange"];
export const TIME_OUT_ERROR = 408;

export const API_RESPONSE_STATUS = {
    SUCCESS: "Success",
    FAIL: "Fail",
    ERROR: "ERROR",
};

export const COLLABORATION_GROUP_MEMBERS = "Members";
export const INCREDIENT_SEARCH_REPLACE = 'IngredientSearchReplace'
export const CONFIRMATION_CONST = {
    YES: "Yes",
    NO: "No",
};

export const EXPERIMENT_ACCESS_NOT_PERMITTED_MSG = "Not Permitted";
export const ZERO_LENGTH = 0;
export const REMOVE_USER_COLLABORATION_DIALOG_MESSAGE = {
    title: "Remove Member",
    message: "",
    subMesssage: "Remove user's experiments when a user is removed",
    submitText: "Yes",
    cancelText: "No",
    submitBtnClass: BLUE_BTN_CSS,
    data: {
        showCheckBox: true,
        removeAllExperiments: true,
    },
};

export const TOOL_TIP = {
    LOCK: "Lock",
    LOCKED: "Locked",
    SORT_BY_NATURAL_ORDER: "Sort by Natural Order",
    SORT: "Sort",
    ASC: "Ascending",
    DSC: "Decending",
    REVISE: "Revise/Copy",
    MAX_EXP: "Cannot proceed, workspace maximum experiment open limit reached.",
    OTHER_EXP: "Cannot revise, other user experiment or product",
    NOT_EDIT: "Not Editable",
    OTHER_USER: "Not Editable(Other User)",
    SORTED_BY_NATURAL_ORDER: "Sorted by Natural Order",
    NO_EXP_ACCESS: "User is not in the experiment access list",
    FROM_EXPERIMENT: "Create from Experiment",
    CREATE_FROM_PRODUCT: "Create from Product",
    COPY: "Copy",
    CLICK_TO_VIEW_ALL_USERS: "Click to view all users",
    EDIT_EXPERIMENT_NAME: "Edit experiment name",
    LIST_TOOLTIP_LENGTH: {
        EXP_NAME: 25,
        FOLDER_NAME: 20,
    },
};
export const HIGHLIGHT_TYPE = "Notes";
export const HIGHLIGHTED_CLASS = "yellow";
export const AUDIT_FAIL = "Unable to fetch audit result";

export const COLUMN_LAYOUTS_CRITERIA = {
    COST_PER_KG: "CostPerKg",
    COST_PER_PARTS: "CostPerParts",
    COST_CONTRIBUTION: "CostContribution",
    FLAG: "Flag",
    CBWFLAG: "FlagCBW",
    SPEC: "Spec",
    PRODUCT_TYPE: "prodtypecode",
    STOCK: "Stock",
    CC_INDICATOR: "CC Indicator",
    TRUSTEE: "trustee",
    PARTS: "Parts %",
    PARTS_PERENTAGE: "PartsPercentage",
    NO_OPTION: "N",
    Technology: "technology",
    PLANT_ALLOCATION: "Plant Allocation",
    DIVISION: "division",
};

export const CREATE_SAMPLE_POPUP = {
    panelClass: [PANEL_CLASS, "dialog-model-createSample"],
    width: "100%",
    disableClose: true,
    heading: SAMPLE_TYPE.MAKE_SAMPLE,
    data: {},
};
/* Application Brightness Control - Constants */
export const BACKGROUND_PREFERENCE = {
    DEFAULT_BRIGHTNESS_RANGE: 10,
    LOW_BRIGHTNESS_VALUE_UPTO: 4,
    MEDIUM_BRIGHTNESS_VALUE_UPTO: 9,
    HIGH_BRIGHTNESS_VALUE_UPTO: 10,
    PREFERENCE_TYPEID_BRIGHTNESS: 30,
    COLOR_PRIMARY: "--color-primary",
    COLOR_SECONDARY: "--color-secondary",
    COLOR_TERTIARY: "--color-tertiary",
    DEFAULT_BRIGHTNESS: "DefaultBrightness",
    DEFAULT_BRIGHTNESS_VALUE: "10",
};

/* Application Brightness Control - Color Code Constants */
export const STYLE_COLOR_CODE = [
    {
        PRIMARY: "#EFF3F4",
        SECONDARY: "#D1DCDE",
        TERTIARY: "#C0CCCF",
    },
    {
        PRIMARY: "#F2F5F6",
        SECONDARY: "#D9E2E4",
        TERTIARY: "#C3CED1",
    },
    {
        PRIMARY: "#F3F6F7",
        SECONDARY: "#DAE4E6",
        TERTIARY: "#C5D1D3",
    },
    {
        PRIMARY: "#F5F7F8",
        SECONDARY: "#DEE6E8",
        TERTIARY: "#C9D4D7",
    },
    {
        PRIMARY: "#F7F9F9",
        SECONDARY: "#E1E9EB",
        TERTIARY: "#CDD7DA",
    },
    {
        PRIMARY: "#F8FAFA",
        SECONDARY: "#E5ECED",
        TERTIARY: "#D2DBDE",
    },
    {
        PRIMARY: "#FAFBFB",
        SECONDARY: "#E8EEEF",
        TERTIARY: "#D8E1E2",
    },
    {
        PRIMARY: "#FBFCFC",
        SECONDARY: "#EEF2F2",
        TERTIARY: "#E0E6E6",
    },
    {
        PRIMARY: "#FDFDFD",
        SECONDARY: "#F1F4F5",
        TERTIARY: "#E8ECEE",
    },
    {
        PRIMARY: "#FFFFFF",
        SECONDARY: "#F8FAFA",
        TERTIARY: "#F2F5F5",
    },
];

export const VARIANT_SOURCE = {
    EXPERIMENT_FROM_SCRATCH: "ExperimentFromScratch",
    EXP_FROM_EXP: "ExperimentFromExperiment",
    EXP_FROM_PRODUCT: "ExperimentFromProduct",
    COMBINE: "Combine",
    EXP_VARIANT_EDIT: "ExperimentVariantEdit",
    EXP_VARIANT_DELETE: "ExperimentVariantDeleted",
};

export const COMMENTS_AND_NOTES = "Experiment has no comments and notes.";

export const SHOW_ACCESS_LABEL_FOR_FLAGS = ["RESTRICTED USE", "INHERITED RESTRICTED USE"];
export const FLAG_WITH_ACCESS = "[with access]";
export const FLAG_NO_ACCESS = "[no access]";
export const EXPAND_COLLAPSE_EXPERIMENT_LEVEL = 9;
export const ATTRIBUTE_ANALYSIS_EXPAND_COLLAPSE_LEVEL = 31;

export const RESTRICTED_USE_FLAG_CODES = {
    RESTRICTED_USE: "RESTRICTED USE",
    INHERITED_RESTRICTED_USE: "INHERITED RESTRICTED USE",
    INHERITED_RESTRICTED_USE_INHERITED: "INHERITED RESTRICTED USE (INHERITED)",
};

export const FLAG_YOU_HAVE_ACCESS = "You have access.";
export const EXPERIMENT_COPY_VALUES_FOR_FIELD = ["ingredientName", "IPC", "ExpCode", "ExpName", "ExpID"];
export const COPY_MENU_CLICKED = "Copy menu click";
export const INGREDIENT_CONFIRMATION = {
    type: "IngredientSearchReplace",
    title: "Warning",
    message: "Replace",
    subMesssage: "Do you want to proceed?",
    submitText: "YES",
    cancelText: "No",
    data: {},
};
export const PREVIOUS_REQUEST = {
    title: "Warning!",
    submitText: "OK",
    message: "Warning",
    data: {},
};

export const DIVISION_TYPE = {
    FLAV: "FLAV",
    FRAG: "FRAG",
    BOTH: "BOTH",
    INVALID: "INVALID",
    MISSING: "MISSING",
};

export const ARRAY_LENGTH = {
    ONE: 1,
    TWO: 2,
};

export const TOASTR_MSG = {
    EXP_RESEND_UPDATE: "Experiment was updated and successfully resent to IFFMAN.",
    EXP_FORMULA_RESEND: "Experiment formula is Resent to IFFMAN successfully.",
};

export const PASS_AUDIT_RESTRICTED_FLAGS = [{ flagCode: "ARCHIVE" }, { flagCode: "NO NEW USE" }, { flagCode: "DO NOT USE" }];
export const RETAIN_GRID_UPDATE_LEVEL = 1;

export const CREATE_SAMPLE_SORT_OPTIONS = [
    { value: "SORT_BY_NATURAL_ORDER", displayValue: "Sort by Natural Order (includes instructions)" },
    { value: "SORT_BY_NATURAL_ORDER_IN_BOLD", displayValue: "Sort by Natural Order (includes instructions in bold)" },
    { value: "SORT_BY_ID", displayValue: "Sort by IPC (no instructions)" },
    { value: "SORT_BY_DESCRIPTION", displayValue: "Sort by Description (no instructions)" },
    { value: "SORT_BY_PARTS", displayValue: "Sort by Descending parts (no instructions)" },
];

export const DEFAULT_SORT = "SORT_BY_NATURAL_ORDER";
export const SORT_BY_DESCRIPTION = "SORT_BY_DESCRIPTION";
export const SORT_BY_ID = "SORT_BY_ID";
export const SORT_BY_PARTS = "SORT_BY_PARTS";
export const SORT_BY_NATURAL_ORDER_IN_BOLD = "SORT_BY_NATURAL_ORDER_IN_BOLD";

export const DO_NOT_EXPLODE = "DO NOT EXPLODE";

export const DUPLICATE_EXPERIMENT_OPEN_MSG = "Experiment already open in the workspace.";
export const DUPLICATE_PRODUCT_OPEN_MSG = "Product already open in the workspace.";
export const FLEX_PALLET_COLUMN_HEADER = {
    field: "flexPallet",
    headerName: "",
    headerComponent: "customHeader",
    headerComponentParams: {
        type: "FlexPallet",
    },
    pinned: "left",
    width: 30,
    editable: false,
    lockPinned: true,
    lockPosition: true,
    cellRenderer: "flexPalletCellRendererComponent",
    tooltipComponent: "customTooltip",
    tooltipField: "",
    cellRendererParams: "",
    valueFormatter: "",
    headerClass: "flexpallet-header",
    cellClass: "flexpallet-cell",
    cellClassRules: {
        "ag-row-highlight-top": () => false,
        "ag-row-highlight-bottom": () => false,
    },
};
export const IFF_MATERIAL_INFO = {
    IFF_MATERIAL: "Y",
    NOT_AN_IFF_MATERIAL: "N",
};
export const MA_MATERIAL_FLAG = "M&A MATERIAL";
export const SOURCE_FLAG = "SOURCE";
export const MA_MATERIAL_AUDIT = {
    MA_FLAG_SET: "Product has M&A MATERIAL flag.",
    MA_FLAG_NOT_SET: "Product does not have M&A MATERIAL flag.",
};

export const FILL_PARTS_VALUE = 1000;
export const KEYBOARD_EVENT = "keyboard event";
export const FILL_PARTS_SELECTION_LENGTH = 1;
export const FILL_PART_INFO = "You may fill to <b>1000</b> parts automatically while editing parts in a cell and press <b>F10</b>";
export const FLEXPALLET = "flexPallet";
export const NO_PRODUCT_TYPE_MSG = "No Product Type";
export const NO_CREATIVE_TASK = "No creative task in source experiment";
export const NOT_MEMBER_FOR_CREATIVE_TASK = "is not a member of the source experiment's creative task";

export const PAGE_NOT_FOUND = {
    TITLE_TEXT: "Page Doesn't Exist",
    DETAIL_INFO_TEXT: "It looks like this page doesn't exist. Follow the link back home",
    BUTTON_TEXT: "BACK TO HOME",
};
export const DEFAULT_MASTER_DATA_COUNT = 12;

export const SAMPLE_WARNING_DIALOG = {
    NumberOfSamples: "More than 3 samples were requested.  Do you want to proceed ?",
    RequiredSampleSize: "More than 1000 <uom> were requested.  Do you want to proceed ?",
    TotalRequirement: "More than 3000 <uom> were requested.  Do you want to proceed ?",
};

export const SHOW_BOM_BOS_COMPARISON = "Show BOM/BOS Comparison";

export const REVIEW_COMPARISON_POPUP = {
    panelClass: "review_comparison_popup",
    width: "1000px",
    disableClose: true,
    data: {},
};

export const REVIEW_COMPARISON_TABS = {
    tabBOM: "BOM Comparison",
    tabBOS: "BOS Comparison",
};

export const FLEX_PALLET_ACTION = {
    Icon_Header: "Header Clicked",
};
export const NO_USER_EXIST = "N/A";
export const SAMPLE_DEFAULT_VALUE = {
    NO_OF_SAMPLE: 1,
    PAPER_COPIES: 1,
    LABEL_COPIES: 1,
    DECIMAL_PRINTER: 3,
};
export const CUSTOM_EVENT_TYPE = {
    DETAILS_FROM_HOST: "DETAILS_FROM_HOST",
};

export const TOP_LEVEL_ROW_DATA_HIERARCHY_LENGTH = 1;

export const VIEW_DUPLICATE_POURS_COLUMN = {
    IPC_COLUMN_ID: "subipc",
    IPC_COLUMN_HEADERTEXT: "ID",

    DESC_COLUMN_ID: "subipcdescription",
    DESC_COLUMN_HEADERTEXT: "Description",

    SEQUENCE_COLUMN_ID: "bom_path",
    SEQUENCE_COLUMN_HEADERTEXT: "Sequence",
};
export const NO_DUPLICATE_POURS_MSG = "There are no duplicate pours in this formula.";

export const NO_ROW_DISPLAY_MSG = "No Data(s) Available";

export const SAP_WORKING_COST_KEY = "SAPWorkingCost";

export const COST_KEYS_FOR_CURRENCY_CONVERSION = [
    "LaborTime",
    "MachineTime",
    "Packaging",
    "SetupLabor",
    "SetupMachine",
    SAP_WORKING_COST_KEY,
];

export const COST_KEYS = {
    WORKING_COST: "WorkingCost",
    EXPERIMENT_COST: "ExperimentCost",
};

export const ARROW_RIGHT_KEY = "ArrowRight";

export const RECOST_TOOLTIP_NOT_AVAILABLE = "Currency conversion rates are not available for";

export const DETAILED_COSTING_CONST = {
    SUB_IPC_CLICK_EVENT: "ON_SUB_IPC_CLICKED",
    SUB_IPC_CLICK_EVENT_DETAIL: "detail",
};

export const ADD_IPC_TYPE = {
    SINGLE_IPC_UPLOAD: "Single ipc upload",
    BULK_IPC_UPLOAD: "Bulk ipc upload",
};

export const EXCEL_EXTENSION = ".xlsx";

export const IPC_SELECTION = "IPC Selection";

export const FLASHPOINT_PDS_CONSTANT = {
    Farenheit: "0",
    Celcius: "1",
};
