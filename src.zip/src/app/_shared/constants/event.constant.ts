export const EVENT_CLICKED = "BUTTON_EVENT_CLICKED";
export const THEME_CHANGE = "THEME_CHANGE";
export const ROOT_FOLDER_TEXT = "All Experiments";
