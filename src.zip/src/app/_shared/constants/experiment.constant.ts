import { STORE_HEADER_WIDTH_FOR } from ".";

export const BOM_DETAILS_CONSTANTS = {
    ExpID: "ExpID",
    EXP_CODE: "ExpCode",
    EXP_FORMULA_ID: "ExpFormulaID",
    SUB_TYPE: "SUBType",
    LEVEL: "Level",
    INSTRUCTION: "Instruction",
};

export const NODE_LEVEL = {
    ZERO: 0,
    ONE: 1,
    TWO: 2,
};

export const MARK_FOR_HARD_DELETE_FLAG = 2;

export const MARK_FOR_DELETE_FLAG = 1;

export const MARK_FOR_UNDELETE_FLAG = 0;

export const EDIT_SUGGEST_TABS = {
    FEMA: "FEMA",
    SOLUTION: "SOLUTION",
    VARIANT: "VARIANT",
    INSTRUCTION: "INSTRUCTION",
    ENUM: "E NUM",
};

export const EXP_ID_OBJ_KEY = "ExpID";

export const IPC_OBJ_KEY = "IPC";

export const COPY_TO_USER_SUCCESS_MSG = "Experiment(s) copied successfully to";

export const COPY_TO_USER_ERROR_MSG = "Error occured when copying Experiments";

export const USER_FETCH_ERROR_MSG = "Error occured when fetching Users list";

export const USER_FETCH_ERROR_TOASTER_MSG = "No matching user found";

export const FOLDER_DRAG_ERROR_MSG = "Error Moving folder";

export const FOLDER_DRAG_ERROR_TOASTER_MSG = "Folder Move Restricted or Invalid";

export const FOLDER_PRESENT_ERROR_TOASTER_MSG = "Folder with name <name> already present in ";

export const FOLDER_DRAG_SAME_LOCATION_ERROR_TOASTER_MSG = "Source Folder and Target Folder are same";

export const EXPERIMENT_DRAG_ERROR_TOASTER_MSG = "Can not move Experiment to System Reserved Folders";

export const EXPERIMENT_DRAG_SAME_PARENT_ERROR_TOASTER_MSG = "Experiment dropped into source folder";

export const EXPERIMENT_DRAG_NO_EXP_ERROR_TOASTER_MSG = "No Experiments selected to move to folder";

export const EXPERIMENT_DRAG_SUCCESS_TOASTER_MSG = "Selected Experiment(s) successfully moved to";

export const EXPERIMENT_ADD_TO_COLLABORATION_GROUP_SUCCESS = "Experiments successfully added to collaboration group";

export const EXPERIMENT_ADD_TO_COLLABORATION_GROUP_ERROR = "Error on adding experiment to collaboration group";

export const COLUMN_RESIZE_SOURCE = "uiColumnDragged";

export const PRODUCT_PLANT_NOT_ALLOCATE_WARNING = "Warning: This product doesn't have any plant";

export const STORE_HEADER_WIDTH_MAP = {
    [STORE_HEADER_WIDTH_FOR.PRODUCT_SEARCH]: "productSearchHeader",
    [STORE_HEADER_WIDTH_FOR.MINI_EDITOR]: "miniEditorHeader",
    [STORE_HEADER_WIDTH_FOR.EDIT_HEADER]: "editionSuggestionHeader",
    [STORE_HEADER_WIDTH_FOR.PRODUCTSEARCH]: "searchEditionHeader",
};

export const SHOW_TOOLTIP_BELOW_VALUE = 0.0001;

export const ELEMENT_REF_VALUE = "_elementRef";

export const WORKSPACE_DIALOG_BUTTONS = {
    OPEN_IN_NEW_WORKSPACE: "OPEN IN NEW WORKSPACE",
    OPEN_IN_MOST_RECENT_WORKSPACE: "OPEN IN MOST RECENT WORKSPACE",
    EXISTING_WORKSPACE: "EXISTING WORKSPACE",
};

export const EXPERIMENT_OPEN_IN_WORKSPACE_CONST = {
    OPEN_MULTIPLE_EXPERIMENT_BOM: "Open Multiple BOMs",
    SEQUENCE: "Sequence",
    WORKSPACE_PRODUCT_DIALOG_TITLE: "IPC already open in",
};

export const DESC = "desc";

export const WORKSPACE_DIALOG = {
    panelClass: "model-popup",
    width: "730px",
    disableClose: true,
    autoFocus: false,
    data: {
        title: "Experiment already open in",
        message: "",
        cancelText: "CANCEL",
        confirmText: WORKSPACE_DIALOG_BUTTONS.OPEN_IN_NEW_WORKSPACE,
        extraConfirmText: WORKSPACE_DIALOG_BUTTONS.OPEN_IN_MOST_RECENT_WORKSPACE,
        dialogData: [],
    },
};
