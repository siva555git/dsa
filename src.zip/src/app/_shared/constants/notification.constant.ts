export const AUTHENTICATION_SUCCESS = "Authentication Success";
export const AUTHENTICATION_FAILED = "Authentication Failed";
export const SOMETHING_WRONG = "Something went wrong. Please Try Again";
export const AUTHORIZATION_FAILED = "Authorization Failed";

/* Experiment Constants */
export const EXPERIMENT_ERRORS = {
    EXPERIMENT_NOT_FOUND: "No Experiment are available",
    CREATE_EXPERIMENT_ERROR: "Failed to Create New Experiment",
    UPDATE_EXPERIMENT_ERROR: "Failed to Update Experiment",
    ERROR: "Something went wrong.",
};

export const EXPERIMENT_SUCCESS = {
    CREATE_EXPERIMENT_SUCCESS: "New Experiment has been Created",
    UPDATE_EXPERIMENT_SUCCESS: "Experiment has been updated",
};

export const EXPERIMENT_BOM_RESTRICTION_ERRORS = {
    CREATE_ERROR: "Failed to Create New Experiment BOM Recommendation",
    UPDATE_ERROR: "Failed to Update Experiment BOM Recommendation",
    INSERT_ERROR: "Failed to fetch Experiment BOM Recommendation Data",
    DELETE_ERROR: "Failed to delete Experiment Analysis",
};

export const EXPERIMENT_BOM_RESTRICTION_SUCCESS = {
    CREATE_SUCCESS: "New Experiment BOM Recommendation has been Created",
    UPDATE_SUCCESS: "Experiment BOM Recommendation has been updated",
    DELETE_SUCCESS: "Experiment Analysis Deleted Successfully",
};

export const EXPERIMENT_FOLDER_SUCCESS = {
    UPDATE_SUCCESS: "Folder has been Updated Successfully",
    DELETE_SUCCESS: "Folder has been Deleted Successfully",
};

export const EXPERIMENT_FOLDER_ERROR = {
    UPDATE_ERROR: "Failed to update Experiment Folder",
    DELETE_ERROR: "Failed to delete Experiment Folder",
};

export const EXPERIMENT_INFO = {
    YIELD_LIMIT_INFO: "Yield must only be a number between 0.01 and 100",
    USE_LEVEL_INFO: "Use Level must only be a number between 0 and 100",
    BATCH_SIZE_INFO: "Batch size must only be a number between 1 to 32267",
};

/* Experiment Formula Constants */
export const EXPERIMENT_FORMULA_ERRORS = {
    EXPERIMENT_FORMULA_NOT_FOUND: "No data available",
    DELETE_BOM_ERROR: "Failed to delete BOM items",
    LOCK_EXPERIMENT_ERROR: "Failed to Lock Experiment",
    LINEITEMS_NOT_FOUND: "No Line Items available",
    BOMDETAILS_NOT_FOUND: "No BomDetails available",
    ATTRIBUTES_NOT_FOUND: "No Attributes available",
    BOMDETAILS_FETCH_ISSUE: "Failed to fetch experiment BOM detail",
};

/* Folder Constants */
export const FOLDER_SUCCESS = {
    UPDATE_FOLDER_SUCCESS: "Folder has been updated",
    CREATE_FOLDER_SUCCESS: "folder created successfully",
};

export const FOLDER_ERRORS = {
    CREATE_FOLDER_ERROR: "Failed to create New Folder",
    FOLDERNAME_ALREADY_EXISTS: "Folder Name already exists",
    UPDATE_FOLDER_ERROR: "Failed to update folder",
};

/* MDR Constants */
export const MDR_SUCCESS = {
    FLAVOR_TYPE_SUCCESS: "Flavor types has been returned",
    PRODUCT_TYPE_SUCCESS: "Product types has been returned",
};

export const MDR_ERRORS = {
    FLAVOR_TYPE_ERROR: "Failed to fetch the falvor types data",
    PRODUCT_TYPE_ERROR: "Failed to fetch the product types data",
};

/* USER Constants */
export const USER_ERRORS = {
    CREATE_INITIAL_ERROR: "Failed to Create initials",
};

export const USER_SUCCESS = {
    CREATE_INITIAL_SUCCESS: "Initials has been saved",
};

/* Reference Constants */
export const REFERENCE_ERRORS = {
    PRODUCT_SEARCH_ERROR: "Failed to fetch the product search data",
    EXPERIMENT_SEARCH_ERROR: "Failed to fetch the experiment search data",
};

export const PRODUCT_SEARCH_ERROR = {
    CHECKBOX_ERROR: "Atleast one checkbox must be selected",
};

export const COLUMN_LAYOUT_SUCCESS = {
    CREATE_COLUMN_LAYOUT_SUCCESS: "Column Layout has been Created",
    COPY_COLUMN_LAYOUT_SUCCESS: "Column Layout has been Copied",
    UPDATE_COLUMN_LAYOUT_SUCCESS: "Column Layout has been Updated",
    DELETE_COLUMN_LAYOUT_SUCCESS: "Column Layout has been Deleted",
    APPLIED_COLUMN_LAYOUT: "Column Layout has been applied to grid",
};

export const COLUMN_LAYOUT_ERROR = {
    CREATE_COLUMN_LAYOUT_ERROR: "Failed to Create Column Layout",
    COPY_COLUMN_LAYOUT_ERROR: "Failed to copy Column Layout",
    UPDATE_COLUMN_LAYOUT_ERROR: "Failed to update Column Layout",
    DELETE_COLUMN_LAYOUT_ERROR: "Failed to delete Column Layout",
    FORM_NOT_SAVED: "No Changes made, can't save selected Column",
};

export const NOTIFICATION_ERROR = {
    DELETE_NOTIFICATION_ERROR: "Failed to delete Notification(s)",
    DELETE_NOTIFICATION_SUCCESS: "Notification(s) has been Deleted",
};

export const CREATIVE_REVIEW_SUCCESS = {
    SEND_CREATIVE_REVIEW_SUCCESS: "Items sent for review successfully",
    RESEND_CREATIVE_REVIEW_SUCCESS: "Items resent for review successfully",
};

export const CREATIVE_REVIEW_ERROR = {
    SEND_CREATIVE_REVIEW_ERROR: "Failed to perform the review",
    RESEND_CREATIVE_REVIEW_ERROR: "Failed to resend the review item",
};

export const UPDATE_BOM_FAILURE = {
    UPDATE_BOM_ERROR: "Failed to update the parts",
    FILL_PARTS_FAILED: "Fill Parts (to 1000) operation failed",
    FILL_PARTS_SUCCESS: "Fill Parts (to 1000) operation successfull",
};

export const EXPERIMENT_PRIVACY_UPDATE = {
    PRIVACY_UPDATE_SUCCESS: "Experiment Privacy Status Updated",
    PRIVACY_UPDATE_ERROR: "Only update own Experiment Privacy Status",
};

export const IPC_SELECTION_SUCCESS = {
    CREATE_IPC_SELECTION_SUCCESS: "Ipc Selection has been Created",
    COPY_IPC_SELECTION_SUCCESS: "Ipc Selection has been Copied",
    UPDATE_IPC_SELECTION_SUCCESS: "Ipc Selection has been Updated",
    DELETE_IPC_SELECTION_SUCCESS: "Ipc Selection has been Deleted",
};

export const IPC_SELECTION_ERROR = {
    CREATE_IPC_SELECTION_ERROR: "Failed to Create Ipc Selection",
    COPY_IPC_SELECTION_ERROR: "Failed to copy Ipc Selection",
    UPDATE_IPC_SELECTION_ERROR: "Failed to update Ipc Selection",
    DELETE_IPC_SELECTION_ERROR: "Failed to delete Ipc Selection",
    FORM_NOT_SAVED: "No Changes made, can't save selected Ipc",
};

export const NOTES_PRIVACY_UPDATE = {
    PRIVACY_UPDATE_SUCCESS: "Notes Privacy Status Updated",
    PRIVACY_UPDATE_ERROR: "Only update own Experiment Privacy Status",
    DELETE_NOTES: "Notes has been Deleted",
};

export const USER_PREFERENCES = {
    PREFERENCES_UPDATE_SUCCESS: "User Preferences Updated successfully",
    DEFAULT_APPEARENCE: "TOP_RIGHT",
    PREFERENCE_ORDER: "ParameterInString",
    ORDER_BY: "desc",
    FALSE_VALUE: "false",
};

export const USER_PREFERENCES_TYPES = {
    PLANT_CODE: "DefaultPlant",
    SOURCE_CODE: "DefaultSource",
    CURRENCY_CODE: "DefaultCurrency",
    EXP_SCREEN_COLUMN_LAYOUT: "ESCL",
    FLASHPOINT_CODE: "DefaultFlashPoint",
    EDITOR_ODD_LINE_BACKGROUND: "EDITOR_ODD_LINE_BG",
    EXPERIMENT_PRIVACY: "ExperimentPrivacy",
    COMBINE_INTO_OPEN_IN_CURRENT_WORKSPACE: "OPEN_IN_CURRENT_WORKSPACE",
    DEFAULT_PRODUCT_CATEGORY: "DefaultProductCategory",
    EDITOR_AUTO_NATURAL_SORT: "EDITOR_AUTO_NATURAL_SORT",
    DEFAULT_SHOW_INSTRUCTIONS: "isHideInstruction",
    DEFAULT_INCLUDE_INSTRUCTIONS: "isIncludeInstruction",
};

export const POPUP_NOTIFICATION_EVENTS = {
    ADD_EXPERIMENT_ACCESS: "add experiment access",
    REMOVE_EXPERIMENT_ACCESS: "remove experiment access",
    ADD_COOPERATOR: "add cooperator",
    REMOVE_COOPERATOR: "remove cooperator",
    COPY_OTHERS_EXP: "copy others experiment",
    CREATIVE_REVIEW_RESULT: "creative review result",
    USER_JOIN: "join",
    ADD_USER_TO_COLLABORATION_GROUP: "Add user to collaboration group",
    LOCK_EXPERIMENT: "Lock Experiment",
    DELETE_COLLABORATION_GROUP: "Delete collaboration group",
    ASSIGN_TRUSTEE: "Assign Trustee",
    LEAVE_COLLABORATION_GROUP: "Leave collaboration group",
    REMOVE_MEMBER_FROM_COLLABORATION_GROUP: "Remove member from a collaboration group",
    CREATIVE_REVIEW_BATCH_PROCESS: "Batch process",
    VIEWED_MY_EXP: "viewed my experiment",
};

export const DEFAULT_TOASTER_OPTIONS = {
    enableHtml: true,
    positionClass: "toast-bottom-left",
    closeButton: true,
    tapToDismiss: false,
};

export const NOTIF_EVENT_TYPE = {
    INFO: 1,
    ERROR: 2,
    WARNING: 3,
};

/* Folder Constants */
export const FORM_VALIDATION = {
    FIELDS_REQUIRED: "Please fill all the required fields!",
};
export const ALERT_APPEARANCE = {
    None: false,
    BOTTOM_LEFT: "toast-bottom-left",
    TOP_RIGHT: "toast-top-right",
};

export const NOTIFICATION_EVENTS = ["SHARED_MY_EXP", "PROJECT_ASSIGNED", "FAVOURITED_MY_EXP"];

export const NOTIFICATION_SETTING_CODE = {
    SHARED_ME_EXP: "SHARED_ME_EXP",
    COPIED_MY_EXP: "COPIED_MY_EXP",
    CG_ADD_USER: "CG_ADD_USER",
    LOCK_EXPERIMENT: "LOCK_EXPERIMENT",
    VIEWED_MY_EXP:"VIEWED_MY_EXPERIMENT"
};

export const MUTE_OPTIONS = {
    "1 Day": "Day",
    "1 Week": "Week",
    "1 Month": "Month",
};

export const ES_RESPONSE = {
    ES_RESPONSE_ERROR: "Data will reflect in another few mins!",
    ADD_STAFF_LIST: "User added successfully, Data will reflect in another few mins",
    EXPNAME_MSG: "EXP Name updated successfully, Data will reflect in another few mins",
    NOTES_MSG: "Note added successfully, Data will reflect in another few mins",
    ES_FAIL_INFO: "Data will be reflected in the system in another few mins.",
};

export const SOUND_PREFERENCE = {
    SOUND_NOTFICICATION: "SOUND_NOTFICICATION",
    DESKTOP_NOTFICICATION: "DESKTOP_NOTFICICATION",
};

export const DEFAULT_MUTE_OPTION = "1 Day";

export const COLLABORATION_GROUP = {
    CREATE_SUCCESS: "New Collaboration Group Created",
    CREATE_ERROR: "Failed to create Collaboration Group",
    USER_FETCH_ERROR: "Error while fetching user",
    NO_USER_FOUND: "No user found for your search value",
    COLLABORATION_GROUP_NAME_ERROR: "Group Name Already Exist",
    UPDATE_SUCCESS: "Collaboration group has been updated",
    UPDATE_ERROR: "Failed to update collaboration group",
    DELETE_SUCCESS: "Collaboration Group deleted successfully",
    DELETE_ERROR: "Failed to delete Collaboration Group",
    LEAVE_SUCCESS: "Collaboration Group left successfully",
    LEAVE_ERROR: "Failed to leave Collaboration Group",
};

export const EXPERIMENT_REVISE = {
    EXPERIMENT_REVISE_ERROR: "Failed to Revise/Copy Experiment",
};

export const INSTRUCTION_INFO = {
    ADD_TO_FAVORITE_SUCCESS: "Instruction successfully added to Favorites list",
    ADD_TO_FAVORITE_FAILED: "Failed to add Instruction in Favorites list",
};

export const WORKSPACE_SETTINGS_FIELDS = {
    showOddLines: "isShowOddLines",
    showSequence: "isShowSequence",
    sortByNaturalOrder: "isSortByNaturalOrder",
    allowSequence: "isAllowSequence",
    openInCurrentWorkspace: "isOpenInCurrentWorkspace",
};

export const WORKSPACE_SETTINGS = [
    {
        field: WORKSPACE_SETTINGS_FIELDS.showOddLines,
        label: "Show editor odd line background color as grey",
        isChecked: false,
        isDisabled: false,
    },
    {
        field: WORKSPACE_SETTINGS_FIELDS.showSequence,
        label: "Show sequence no. of selected column in editor",
        isChecked: false,
        isDisabled: true,
    },
    {
        field: WORKSPACE_SETTINGS_FIELDS.sortByNaturalOrder,
        label: "Sort selected column automatically by natural order",
        isChecked: false,
        isDisabled: false,
    },
    {
        field: WORKSPACE_SETTINGS_FIELDS.allowSequence,
        label: "Allow sequence change functions only if experiment is sorted by natural order",
        isChecked: false,
        isDisabled: true,
    },
    {
        field: WORKSPACE_SETTINGS_FIELDS.openInCurrentWorkspace,
        label: "Combine into new experiment must open new experiment in current workspace",
        isChecked: false,
        isDisabled: false,
    },
];
export const WORKING_COST_TOASTER_MSG = {
    ERROR: "Error Occurred On Fetching Working Cost Info",
};
