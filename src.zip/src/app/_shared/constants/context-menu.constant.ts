/* eslint-disable max-lines */
/* RIGHT CLICK MENU HEADER */
const VIEW_HEADER = "View Header";
const VARIANT_ICON = "icon-Variant";
const EXPERIMENT_ACCESS = "Access";
const ADD_TO_COLLABORATION_GROUP = "Add to Collaboration Group";
const CREATIVE_REVIEW = "Creative Review";
const REVIEW_HISTORY = "Creative Review History";
const EDIT_EXPERIMENT = "Open Header";
const REVIEW_COMPARISON = "BOM/BOS Review comparison";

export const INSTRUCTION_LIST = {
    EDIT: "Edit",
    DELETE: "Delete",
};

export const AUDIT_EYE_ICON = "ag-audit-eye-icon";

export const INSTRUCTION_EDIT = "Instruction Edit";

export const MENU_LIST = {
    CREATE_EXPERIMENT: "CREATE EXPERIMENT",
    CREATE_FOLDER: "FOLDER",
    EDIT_EXPERIMENT,
    VIEW_EXPERIMENT: VIEW_HEADER,
    EDIT_EXPERIMENT_BOM: "Open BOM",
    COPY_TO_USER: "Copy to User",
    COLLABORATION_GROUP: "COLLABORATION GROUP",
    NEW_COLLABORATION_GROUP: "New Collaboration Group",
    REVISE: "Revise",
    EXPERIMENT: "Experiment",
    LOCK: "Lock",
    CREATEEXPERIMENT: "Create",
    REVIEW: "Review",
    MAINTAIN: "Maintain",
    NEW_SAMPLE: "New Sample",
    NEW_PRODUCT: "New Product",
    MOVE: "Move",
    ADD_TO_FAVOURITES: "Add to Favourites",
    MARK_AS_PRIVATE: "Mark as Private/Public",
    EXPERIMENT_ACCESS,
    ADD_TO_COLLABORATION_GROUP,
    EDIT_COLLABORATION_GROUP: "Edit Collaboration Group",
    DELETE_COLLABORATION_GROUP: "Delete Collaboration Group",
    VIEW_COLLABORATION_GROUP: "View Collaboration Group",
    LEAVE_COLLABORATION_GROUP: "Leave Collaboration Group",
    EDIT_MULTIPLE_EXPERIMENT_BOM: "Open Multiple BOMs",
};

/* RIGHT CLICK SUBMENU ITEMS */
export const SUB_MENU_LIST = {
    EXPERIMENT: {
        AUDIT: "Audit",
        EXPERIMENT_ACCESS,
        ADD_TO_COLLABORATION_GROUP,
        CREATIVE_REVIEW,
        REVIEW_COMPARISON,
        REVIEW_HISTORY,
        COOPERATORS: "Cooperators",
        LINEAGE: "Lineage",
        NOTES: "Notes",
        VARIANT: "Variant",
        DELETE_VARINT: "Delete Variant",
        SEND_TO_IFFMAN: "Resend Formula to IFFMAN",
    },
};

/* Experiment Context Menu */
export const EXPERIMENT_TYPE_CONTEXT_MENU = {
    FROM_SCRATCH: "From Scratch",
    FROM_EXPERIMENT: "From Experiment",
    FROM_PRODUCT: "From Product",
};

/* Experiment Folder Context Menu */
export const EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU = {
    CREATE_FOLDER: "Create Folder",
    EDIT_FOLDER: "Edit Folder",
    DELETE_FOLDER: "Delete Folder",
    NEW_FOLDER: "New Folder",
    NEW_COLLABORATION_GROUP: "Create Collaboration Group",
    EDIT_COLLABORATION_GROUP: "Edit Collaboration Group",
    LEAVE_COLLABORATION_GROUP: "Leave Collaboration Group",
    DELETE_COLLABORATION_GROUP: "Delete Collaboration Group",
    SHARE_FOLDER: "Share Folder",
    RENAME_FOLDER: "Rename Folder",
    VIEW_COLLABORATION_GROUP: "View Collaboration Group",
};

/* Grid Context Menu */
export const GRID_CONTEXT_MENU = [
    {
        name: MENU_LIST.EDIT_EXPERIMENT_BOM,
        cssClasses: ["icon-bom-edits"],
    },
    {
        name: MENU_LIST.EDIT_EXPERIMENT,
        cssClasses: ["icon-edit-header"],
    },
    {
        name: MENU_LIST.REVISE,
        disabled: true,
        cssClasses: ["icon-revise-check"],
    },
    {
        name: MENU_LIST.EXPERIMENT,
        cssClasses: ["icon-create-exp"],
        subMenu: [
            {
                name: SUB_MENU_LIST.EXPERIMENT.AUDIT,
                cssClasses: [AUDIT_EYE_ICON],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.EXPERIMENT_ACCESS,
                cssClasses: ["icon-add-to-fav"],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.ADD_TO_COLLABORATION_GROUP,
                cssClasses: ["icon-Creative-Review"],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW,
                cssClasses: ["icon-Creative-Review"],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.REVIEW_COMPARISON,
                cssClasses: ["icon-review-compare"],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY,
                cssClasses: ["icon-review-history"],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.COOPERATORS,
                cssClasses: ["icon-Cooperators"],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.LINEAGE,
                disabled: true,
                cssClasses: ["icon-lineage"],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.NOTES,
                cssClasses: ["icon-Notes"],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.VARIANT,
                disabled: true,
                cssClasses: [VARIANT_ICON],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.DELETE_VARINT,
                disabled: true,
                cssClasses: [VARIANT_ICON],
            },
            {
                name: SUB_MENU_LIST.EXPERIMENT.SEND_TO_IFFMAN,
                disabled: true,
                cssClasses: [VARIANT_ICON],
            },
        ],
    },
    {
        name: MENU_LIST.CREATE_EXPERIMENT,
        cssClasses: ["icon-create-exp"],
        subMenu: [
            {
                name: EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH,
                cssClasses: ["icon-from-scratch"],
            },
            {
                name: EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT,
                cssClasses: ["icon-From-Experiment"],
            },
            {
                name: EXPERIMENT_TYPE_CONTEXT_MENU.FROM_PRODUCT,
                disabled: true,
                cssClasses: ["icon-From-Product"],
            },
            {
                name: MENU_LIST.COPY_TO_USER,
                cssClasses: ["icon-copy-to-user"],
            },
        ],
    },
    {
        name: MENU_LIST.LOCK,
        disabled: true,
        cssClasses: ["ag-bom-lock ag-seperator"],
    },
];

export const UNAPPROVED = {
    EDIT: "Edit",
};

/* Experiment formula header start */
/* RIGHT CLICK MENU HEADER */
export const MENU_LIST_FORMULA = {
    EXPERIMENT: "Experiment",
    OPEN_HEADER: "Open Header",
    EDIT_EXPERIMENT,
    VIEW_EXPERIMENT: VIEW_HEADER,
    LINE: "Line",
    PRODUCT: "Product",
    WORKSPACE: "Workspace",
    REVISE: "Revise/Copy",
    LOCK: "Lock",
    SOFT_LOCK: "Soft Lock",
    HARD_LOCK: "Hard Lock",
    NEW_SAMPLE: "New Sample",
    NEW_PRODUCT: "New Product",
    EXPERIMENT_ACCESS,
    REMOVE_EXPERIMENT: "Remove Experiment",
    DETAILED_COST: "Detailed Costing",
};

export const LINE_SUB_OPTIONS = {
    INSERT: "Insert",
    QUICK_INSERT: "Quick Insert",
    EDIT_HEADER: VIEW_HEADER,
    APPLY_FACTOR: "Apply Factor",
    COMBINE: "Combine",
    TOGGLE_DELETE_UNDELETE: "Delete / Undelete",
    DELETE_ALL: "Delete Permanently",
    EXPLODE: "Explode",
    VIEW_PRODUCT_DATA: "View Product Data",
    FILL_PARTS: "Fill Parts",
    RESEQUENCE: "Resequence",
    VIEW_FORMULATION: "View Formulation",
    VIEW_NATURAL_ORDER: "View Natural Order",
    REPLACE: "Replace",
    OPEN_IN_WORKSPACE: "Open in Workspace",
    OPEN_IN_NEW_WORKSPACE: "Open in New Workspace",
    SET_INSTRUCTION_ON: "Set Instructions ON",
    SET_INSTRUCTION_OFF: "Set Instructions OFF",
    SORT: "Sort By Natural Order",
    VIEW_MEMBERSHIP: "View Membership ",
    ADD_TO_FAVOURITES: "Add to Favorites",
    // eslint-disable-next-line sonarjs/no-duplicate-string
    ATTRIBUTE_ANALYSIS: "Attribute Analysis ",
};

export const EXPERIMENT_SUB_OPTIONS = {
    AUDIT: "Audit",
    EXPERIMENT_ACCESS,
    ADD_TO_COLLABORATION_GROUP,
    CREATIVE_REVIEW,
    REVIEW_HISTORY,
    COOPERATORS: "Cooperators",
    LINEAGE: "Lineage",
    SCALE_PARTS: "Scale Parts",
    NOTES: "Notes",
    VARIANTS: "Variant",
    DELETE_VARINT: "Delete Variant",
    SEND_TO_IFFMAN: "Resend Formula to IFFMAN",
    RECOST: "Batch MNC",
    DROP_EXPERIMENT_OR_PRODUCT: "Close Experiment / Product",
    VIEW_MEMBERSHIP: "View Membership",
    PRINT_SAMPLE_SHEET: "Make Sample",
    ATTRIBUTE_ANALYSIS: "Attribute Analysis  ",
    PLM_NUTRITION_CALCULATOR: "Nutrition Calculator",
};
export const PRODUCT_SUB_OPTIONS = {
    CREATIVE_REVIEW,
    REVIEW_COMPARISON,
    REVIEW_HISTORY,
    LINEAGE: "Lineage",
    VIEW_PRODUCT_DATA: "View Product Data",
    VARIANT: "Variant ",
    ATTRIBUTE_ANALYSIS: "Attribute Analysis",
    PLM_NUTRITION_CALCULATOR: "Nutrition Calculator ", // white space is needed for context menu differentiation between Experiment and Product sub options in ContextMenuHelper -  callMenu functionality
};
export const WORKSPACE_SUB_OPTIONS = {
    COLUMN_LAYOUT: "Column Layout",
    OPEN_EXPERIMENT_OR_PRODUCT: "Open Experiment/Product",
    DROP_EXPERIMENT_OR_PRODUCT: "Close Experiment/Product",
    SHOW_INSTRUCTIONS: "Show Instructions",
    HIDE_INSTRUCTIONS: "Hide Instructions",
    SHOW_MINI_HEADER: "Show Mini Header",
    HIDE_MINI_HEADER: "Hide Mini Header",
    SHOW_DELETED_ITEMS: "Show Deleted Items",
    HIDE_DELETED_ITEMS: "Hide Deleted Items",
    SHOW_BOM_COMPARISON: "Show BOM Comparison",
    HIDE_BOM_COMPARISON: "Hide BOM Comparison",
};

export const BOM_COMPARE_ICON = {
    [WORKSPACE_SUB_OPTIONS.SHOW_BOM_COMPARISON]: '<span class="ag-context-icon iconset-show-bom-compare"></span>',
    [WORKSPACE_SUB_OPTIONS.HIDE_BOM_COMPARISON]: '<span class="ag-context-icon iconset-hide-bom-compare"></span>',
};

export const COMBINE_SUB_OPTIONS = {
    COMBINE_SUBIPC: "Combine SubIPC",
    INTO_NEW_EXPERIMENT: "Into New Experiment",
    DUPLICATES: "Duplicates",
    COMBINE_DUPLICATES: "Combine Duplicates",
};

export const COMBINE_INTO_NEW_EXP_TITLE = "Combine into New Experiment";

export const DISABLE_MENU_OTHER_EXPERIMENTS = [
    MENU_LIST.CREATE_EXPERIMENT,
    MENU_LIST.EDIT_EXPERIMENT,
    MENU_LIST.EDIT_EXPERIMENT_BOM,
    EXPERIMENT_TYPE_CONTEXT_MENU.FROM_EXPERIMENT,
    EXPERIMENT_TYPE_CONTEXT_MENU.FROM_SCRATCH,
];

export const OTHER_USER_EXP_MENU_CHANGE = {
    VIEW_HEADER,
    VIEW_BOM: "View BOM",
};

export const PRODUCT = "Product";
export const EXPERIMENT = "Experiment";
export const CR_CSS = "ag-Creative-Review";
export const BOM_LINE_CSS = "ag-bom-line";
export const NOTES_CSS = "ag-bom-notes";
export const CREATE_OPTION_CSS = "ag-menu-option_title";
export const VARIANT_CSS = "ag-Variant";
export const EXP_ACCESS_CSS = "ag-exp-access";
export const NOTES_ICON_HTML = `<span class="ag-context-icon icon-bom-notes"></span>`;
export const LINEAGE_ICON_HTML = `<span class="ag-context-icon icon-lineage"></span>`;
export const CR_HISTORY_ICON_HTML = `<span class="ag-context-icon icon-cr-review-history"></span>`;
export const CR_REVIEW_ICON_HTML = `<span class="ag-context-icon icon-Creative-Review"></span>`;
export const CR_CAMPARISION_ICON_HTML = `<span class="ag-context-icon icon-review-compare"></span>`;
export const ADD_FAV_ICON_HTML = `<span class="ag-context-icon icon-add-to-fav"></span>`;
export const PRODUCT_ICON_HTML = `<span class="ag-context-icon icon-varient-view"></span>`;
export const FROM_EXP_ICON_HTML = `<span class="ag-context-icon icon-From-Experiment"></span>`;
export const HIDE_INSTRUCTIONS_ICON_HTML =
    '<span class="ag-context-icon iconset-instructions-inactive"><span class="path1"></span><span class="path2"></span>' +
    '<span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span>' +
    '<span class="path7"></span><span class="path8"></span><span class="path9"></span></span>';
export const EDIT_EXPERIMENT_CSS = "ag-edit-header ag-seperator";
export const PLM_NUTRITION_CALULATOR_ICON_HTML = `<span class="ag-context-icon icon-bom-nutrition-calender"></span>`;
export const VIEW_MEMBERSHIP_ICON = `<span class="ag-context-icon icon-view-membership"></span>`;
export const ATTRIBUTE_ANALYSIS_ICON = `<span class="ag-context-icon icon-attribute-analysis"></span>`;
export const MENU_NAME_CHANGE = [
    {
        menuName: MENU_LIST.EDIT_EXPERIMENT_BOM,
        name: OTHER_USER_EXP_MENU_CHANGE.VIEW_BOM,
    },
    {
        menuName: MENU_LIST.EDIT_EXPERIMENT,
        name: MENU_LIST_FORMULA.VIEW_EXPERIMENT,
    },
    {
        menuName: MENU_LIST_FORMULA.EXPERIMENT,
        name: PRODUCT,
    },
];

export const OTHER_USER_MENU_CHANGE = [MENU_LIST.EDIT_EXPERIMENT, MENU_LIST.EDIT_EXPERIMENT_BOM];

export const PRODUCT_MENU_CHANGE = [MENU_LIST_FORMULA.EXPERIMENT];

export const DISABLE_FORMULA_CONTEXT_MENU = [MENU_LIST_FORMULA.REVISE, LINE_SUB_OPTIONS.RESEQUENCE, EXPERIMENT_SUB_OPTIONS.NOTES];

/* Disable Item to Grid Context Menu */
export const DISABLE_CONTEXT_MENU = [
    MENU_LIST.REVISE,
    EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_FOLDER,
    EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_FOLDER,
];

export const DISABLE_COLLABORATION_CONTEXT_MENU = [
    MENU_LIST.NEW_COLLABORATION_GROUP,
    EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.EDIT_COLLABORATION_GROUP,
    EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.DELETE_COLLABORATION_GROUP,
    EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.VIEW_COLLABORATION_GROUP,
    EXPERIMENT_FOLDER_TYPE_CONTEXT_MENU.LEAVE_COLLABORATION_GROUP,
];

export const INSTRUCTION_ON_ICON_HTML = `<span class="ag-context-icon icon-instruction-on"></span>`;
export const DEFAULT_MENU = {
    COPY: {
        NAME: "Copy Text",
    },
};
export const BOM_REPLACE_CSS_CLASS = "ag-bom-replace";
export const BATCHMNC_ZERO_PARTS_WARINING =
    "Some materials in the experiment have 0 parts, therefore the estimated batch MNC is not accurate.";
