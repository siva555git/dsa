import { ColDef } from "@ag-grid-community/core";

export interface UserTabExperiments {
    ExpID: number;
    Sequence: number;
    IsCurrent: number;
    UserTabExpID?: number;
    IPC?: number;
}

export interface CreateOrUpdateTab {
    UserTabID?: number;
    TabName: string;
    Sequence: number;
    IsCurrent: number;
    CreatedBy: number;
    UpdatedBy: number;
    CreatedOn: string;
    UpdatedOn: string;
    WorkSpaceDetail: UserTabExperiments[];
}

export interface CacheSortModel {
    ExpID: number;
    order: string;
    columnName: string;
    sortType: string;
    ExpCode?: string;
}

export interface InsertSearchFilterModel {
    category: string;
    usingOption: string;
    searchText: string;
    checkBox?: Array<string>;
    ProjectNumber?: number;
    advanceSearch?: boolean;
    showCompatible?: boolean;
    compliance?: boolean;
    folder?: number;
    collaboration?: number;
}

export interface SearchTabModel {
    activeTab: number;
    Product?: InsertSearchFilterModel;
    Experiment?: InsertSearchFilterModel;
    UnApproved?: InsertSearchFilterModel;
    Instruction?: InsertSearchFilterModel;
}
export interface LastSelectedTabModel {
    selectedLastTab: number;
}

export interface ColumnHeaderModel {
    headerName: string;
    columnWidth: number;
}

export interface WorkSpaces {
    SavedLayoutTypeID?: number;
    CustomLayoutTypeID?: number;
    IsSavedSelected?: boolean;
    ProductSearchID: number;
    class?: string;
    CreatedBy: number;
    CreatedOn: string;
    IsCurrent: string;
    Sequence: number;
    TabName: string;
    UpdatedBy: number;
    UpdatedOn: string;
    WorkSpaceDetail?: UserTabExperiments[];
    UserTabID: number;
    location?: string;
    active?: boolean;
    editBomColumnHeader?: ColDef[];
    productSearchHeader?: ColumnHeaderModel[];
    editionSuggestionHeader?: ColumnHeaderModel[];
    miniEditorHeader?: ColumnHeaderModel[];
    searchEditionHeader?: ColumnHeaderModel[];
    SearchFilters?: SearchTabModel;
    sortDetails?: CacheSortModel;
    IsHideDeletedSetting: boolean;
}

export interface TabsCrudDataModel {
    action: string;
    tabData: WorkSpaces[];
    tabIdToActive?: number;
    activeTab?: WorkSpaces;
}

export interface TabSequenceUpdateModel {
    draggedUserTabID: number;
    droppedUserTabID: number;
}

export interface TabDetailModel {
    UserTabID: number;
    TabName: string;
    Sequence: number;
    SavedLayoutTypeID: number;
    CustomLayoutTypeID: number;
    ProductSearchID: number;
    IsSavedSelected: boolean;
    IsCurrent: number;
    CreatedBy: number;
    CreatedOn: Date;
    UpdatedBy: number;
    UpdatedOn: Date;
}
