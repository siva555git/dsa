/* eslint-disable @typescript-eslint/no-explicit-any */
import { RowNode } from "@ag-grid-community/core";
import { SearchType } from "../../experiment-editor/models/experiment-editor.model";
import { TreeViewModel } from ".";
import { BomRawDataModel, ReviewHistoryList, ReviewSelectedRowDataModel } from "../../creative-review/models/creative-review.model";
import { WorkSpaces } from "./create-tab.model";

export interface CreativeReviewDialogDataModel {
    selectedExperiments: ReviewSelectedRowDataModel[];
    submitText?: string;
    cancelText?: string;
    reviews?: ReviewHistoryList[];
    submitBtnClass?: string;
}

export interface CreateFolderDialogDataModel {
    selectedFolderID: number;
    parentFolderID: number;
    folders: Array<TreeViewModel>;
    title: string;
}

export interface BomSearchDialogDataModel {
    activeExperiment?: any;
    gridSelectedExpCodes?: any;
    filteredGridDataSource?: any;
    bomDetails?: any;
    facility?: any;
    type: SearchType;
    criteria?: any;
    openedExperimentOrProduct?: any;
    attributes?: any;
    bomDetail?: any;
    workSpace?: WorkSpaces;
    fromLandingPage?: boolean;
    ProductSearchID?: number;
    lastSelectedExperiment?: RowNode[];
    criteriaName?: string;
}
export interface ReviewComparisonDialogDataModel {
    selectedReviews: ReviewHistoryList[];
    rawData: BomRawDataModel[];
    activeFormula: string;
    selectedExperiments: ReviewSelectedRowDataModel[];
    cancelText?: string;
}

export interface ReviewComparisonDialogRequestDataModel {
    review: ReviewHistoryList[];
    rawData: BomRawDataModel[];
    activeFormula: string;
    selectedExperiments: ReviewSelectedRowDataModel[];
}
export interface CreativeReviewMFEDialogDataModel {
    selectedExperiments: ReviewSelectedRowDataModel[];
    selectedTab?: string;
}
