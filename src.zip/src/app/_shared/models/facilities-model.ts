/* eslint-disable @typescript-eslint/no-explicit-any */

export interface FacilitiesModel {
    active: boolean;
    companycode: number;
    costbookcode: string;
    createdby: string;
    createdon: Date;
    displayValue: string;
    divisioncode: string;
    facilitycode: string;
    facilitytypecode: string;
    name: string;
    profitcenter: number;
    updatedby: string;
}
