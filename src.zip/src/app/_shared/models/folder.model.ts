import { TreeViewModel } from "./experiment-list.model";
import { CollaborationGroupListModel } from "./user-collaboration-group.model";

export interface SelectedFolderDetails {
    FolderID: number;
    folderName?: string;
    parentFolderID?: number;
    addedFolderData?: TreeViewModel;
    editFolderData?: TreeViewModel;
    deleteFolderData?: number;
    deSelectTreeViewFolder?: boolean;
    emptyCollaborationFolder?: boolean;
    collaborationActiveMenu?: boolean;
    selectedCollaborationGroup?: CollaborationGroupListModel;
    isTrusteeFolder?: boolean;
}
