/**
 * ExperimentLineage Model
 *
 * @export
 * @interface ExperimentLineage
 */
export interface ExperimentLineage {
    /**
     * ExpLineageID
     *
     * @type {number}
     * @memberof ExperimentLineage
     */
    ExpLineageID?: number;

    /**
     * ExpID
     *
     * @type {number}
     * @memberof ExperimentLineage
     */
    ExpID?: number;

    /**
     * ParentExpID
     *
     * @type {number}
     * @memberof ExperimentLineage
     */
    ParentExpID?: number;

    /**
     * RootExpID
     *
     * @type {number}
     * @memberof ExperimentLineage
     */
    RootExpID?: number;

    /**
     * RootVersion
     *
     * @type {number}
     * @memberof ExperimentLineage
     */
    RootVersion?: number;

    /**
     * RootVersionLabel
     *
     * @type {string}
     * @memberof ExperimentLineage
     */
    RootVersionLabel?: string;
}
