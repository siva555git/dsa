/* eslint-disable @typescript-eslint/no-explicit-any */

import { FlagsESModel } from "@te-shared/components/product-data/models/product-data.model";
// eslint-disable-next-line import/no-cycle
import { FlagAuditModel } from "./audit.model";

export interface BasicBomAttributes {
    audit: FlagAuditModel;
    ipc: string;
    prodtypecode: string;
    description: string;
    otherdetails?: any;
}

export type ProductVariantModel = {
    variantipc: string;
    variantchange: string;
    description: string;
    changeconditionid: number;
    createdby: string;
    comment: string;
    changeconditiondesc: string;
    ipc: string;
    createdon: string;
    variantDescription: string;
    ipcDescription: string;
    rootipc: string;
};
export interface ProductAllocationModel {
    active: string;
    batchsizeinkg: number;
    facilitycostbookcode: string;
    facilitytypecode: string;
    facilitytypename: string;
    ipc: string;
    phantom: string;
    plant: string;
    procurementtype: string;
    specialprocurement: string;
}
export interface AttributeDetailsPayload {
    facilities: any;
    payload?: any;
}

export interface AttributePayload {
    plantInfo: any;
    payload: any;
}
export interface RestrictedUseModel {
    flagcode?: string;
    accessgiven: string;
    restricteduseoverride: string;
}

export interface ProductTechnologyData {
    comment: string;
    createdby: string;
    technologydescription?: string;
    ipc: string;
    isactive: boolean;
    technologyid: number;
}

export type ProductKeywordModel = {
    UseLevel: string;
    Rating: string;
    EvaluatorCode: string;
    EndUseCode: string;
    Description: string;
    EnteredOn: string;
};

export interface BomAttributes extends BasicBomAttributes {
    alias: any;
    analysis: any;
    costbooks: any;
    createdby: string;
    createdon: string;
    CCIndicator?: string;
    division?: any;
    flags: FlagsESModel[];
    isbom: boolean;
    bomRight?: boolean;
    ischemical: boolean;
    isdilutable: boolean;
    ishalal: boolean;
    iskosher: boolean;
    issolution: boolean;
    lmr: string;
    productallocation: ProductAllocationModel[];
    specs: any;
    trustee: string;
    trusteeInfo?: any;
    typeofipc: any;
    updatedon: string;
    yield: any;
    restricteduse: RestrictedUseModel[];
    solutions: any;
    ro?: any;
    productvariant?: ProductVariantModel[];
    technology?: ProductTechnologyData[];
    bomright?: boolean;
    materialStocks?: any;
}
