// eslint-disable-next-line import/no-extraneous-dependencies
import { ColumnApi, GridApi } from "@ag-grid-community/core";
import { MatAutocomplete } from "@angular/material/autocomplete";
// eslint-disable-next-line import/no-unresolved
import { UserTabExperimentModel } from "@te-experiment-editor/models/experiment-editor.model";
import { ExperimentFolderChild, ExperimentFolderExpanded, ExperimentFolderSelected } from "../enums/experiment.enum";
import { WorkSpaces } from "./create-tab.model";
import { SearchCriteria } from "./search-criteria.model";
// eslint-disable-next-line import/no-cycle
import { CollaborationGroupListModel } from "./user-collaboration-group.model";

export interface CreateFolderModel {
    ExpFolderID?: number;
    Description: string;
    FolderName: string;
    IsDefault: string;
    IsShared: string;
    ParentFolderID: number;
}

export interface OtherUserExpAlert {
    title: string;
    message: string;
    subMesssage: string;
    submitText?: string;
    submitBtnClass: string;
    cancelText?: string;
}

export interface PrivacyUpdateResponse {
    status: boolean;
    isESResponseFlag?: boolean;
}

export interface NoResultDisplayModel {
    noData: boolean;
    selectedFolderID?: number;
    selectedCollaborationGroup?: CollaborationGroupListModel;
    isIPCValid?: boolean;
    isSearchIPCHasValue?: boolean;
}

export interface AllOtherSearchResponse {
    rowData: Array<UserTabExperimentModel>;
    isLoading?: boolean;
    havePermForOtherExp?: boolean;
    searchCriteria?: SearchCriteria;
}

export interface TreeViewModel {
    filePath?: Array<string>;
    FolderID: number;
    ParentFolderID?: number;
    FolderName: string;
    Description?: string;
    hasChild?: ExperimentFolderChild;
    selected?: ExperimentFolderSelected;
    tooltip?: string;
    expanded?: ExperimentFolderExpanded;
    ExperimentFolders?: TreeViewModel[];
}

export interface GridParameters {
    type: string;
    api: GridApi;
    columnApi: ColumnApi;
}
export interface AdditionalTreeViewData {
    hasChild?: "0";
    selected?: "0";
    tooltip?: "";
    expanded?: "0";
}

export interface UpdateParentModel {
    childExperimentIds?: Array<number>;
    childExpFolderId?: number;
    parentExpFolderId: number;
}

export interface IAutoCompleteScrollEvent {
    autoComplete: MatAutocomplete;
    scrollEvent: Event;
}

export interface GlobalExperimentExternalFilter {
    SearchText: string;
    SearchFields: Array<string>;
    UserSelected: number;
}
export interface SharedExperimentExternalFilter {
    SharedType: string;
    SearchText?: string;
    SearchFields?: Array<string>;
}
export interface FilterModel {
    filter: string;
    filterType: string;
    type: string;
}

export interface FilterModelType {
    ExpCode: FilterModel;
}

export interface ExperimentListFilterPayload {
    from: number;
    size: number;
    category: string;
    folderId: number;
    sortType?: string;
    filter?: FilterModelType;
    searchText?: string;
    searchBy?: string[];
    // eslint-disable-next-line @typescript-eslint/ban-types
    sort?: {};
    collaborationGroupId?: number;
    sharedExperimentExternalFilter?: SharedExperimentExternalFilter;
    globalExperimentExternalFilter?: GlobalExperimentExternalFilter;
}

export interface AllOtherExperimentSearchPayload {
    searchText: string;
    limit: number;
    offset: string;
    searchBy: Array<string>;
    searchType: string;
    searchCategory?: string;
    folderId?: number;
    UserSelected?: number;
}

export interface ExperimentList {
    IPC: null;
    Task: null;
    ExpID: number;
    UOMID: number;
    Yield: number;
    Comment: string;
    ExpCode: string;
    isESResponseFlag: boolean;
    ExpName: string;
    PlantID: string;
    Trustee: number;
    IsLocked: boolean;
    IsPublic: boolean;
    LockedBy: number;
    LockedOn: number;
    UseLevel: number;
    BatchSize: number;
    CreatedBy: number;
    CreatedOn: Date;
    ExpSource: string;
    IsDeleted: boolean;
    UpdatedBy: number;
    UpdatedOn: Date;
    ArchivedOn: number;
    FolderName: string;
    IsArchived: boolean;
    CountryCode: string;
    IsFavourite: boolean;
    ProductTypeID: string;
    ExperimentLineage: [
        {
            ExpLineageID: number;
            CreatedBy: number;
            UpdatedBy: number;
            ExpID: number;
        },
    ];
    SourceFlagCodeID: string;
    ExperimentVariant: string;
    UserCollaborationGroupMapped: string;
}

export interface AuditDrawerModel {
    isLock: boolean;
    selectedRows: ExperimentList;
}

export interface WorkSpaceDialogResponse {
    type: string;
    workSpaceDetail: WorkSpaces;
}

export interface AccessCooperatorDrawer {
    currentPage: string;
    expCode: string;
    expId: number;
}

export interface SortModel {
    colId: string;
    sort: string;
}

export interface RemoveExperimentModel {
    CreatedBy: number;
    CreatedOn: string;
    ExpFolderID: number;
    ExpFolderMappedID: number;
    ExpID: number;
    UpdatedBy: number;
    UpdatedOn: string;
}
export interface RemoveExperiment {
    model: RemoveExperimentModel;
}

export interface AgGridParameters {
    startRow: number;
    endRow: number;
    sortModel: Array<SortModel>;
    filterModel: FilterModel;
    searchType: string;
}

export interface ExperimentDetails {
    ExperimentCode: string;
    FolderName: string;
    FolderID: number;
    ParentFolderID?: string;
    SelectedCollaborationGroup?: CollaborationGroupListModel;
}

export interface HomeActionContextModel {
    filePath?: Array<string>;
    FolderID: number;
    ParentFolderID?: number;
    FolderName: string;
    fromTreeView?: boolean;
    selectedCollaborationGroup?: CollaborationGroupListModel;
    scrollingPosition?: number;
    selected?: boolean;
    expanded?: boolean;
    slideBarPosition?: number;
    isTrusteeNode?: boolean;
}

export interface ColumnValues {
    columnValue: string;
    field: string;
    isChecked: boolean;
    isDisabled: boolean;
    sequence: number;
}
export interface DynamicFieldModel {
    folderID: number;
    columnsValue: ColumnValues[];
    isTrusteeFolder?: boolean;
}

export type CreateExpInterimData = {
    userCollaborationGroupList: CollaborationGroupListModel[];
    selectedFolderID: number;
    selectedCollabGrpID: number;
};

export interface CreateSampleRememberData {
    SampleCount: number;
    SampleSize: number;
    UOM: string;
    YieldToggle: boolean;
    Decimals?: number;
    BomSortOrder?: string;
    PaperPrinter?: string;
    PaperSize?: string;
    LabelTemplate?: string;
    LabelPrinter?: string;
    LabelOrientation?: string;
    SampleOrientation?: string;
    IsPrintSampleChecked?: boolean;
    IsLabelChecked?: boolean;
    IsDoubleSidePrint?: boolean;
}
