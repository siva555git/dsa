export interface NotificationPreference {
    AppModuleID: number;
    AppSettingID: number;
    Description: string;
    NotificationUserPreferenceID: string;
    ParameterCode: string;
    ParameterInString: string;
    SelectValue: string;
    UserID?: number;
    CreatedBy?: number;
    UpdatedBy?: number;
    IsActive: boolean;
}

export interface PreferenceResponse {
    muteNotification: NotificationPreference[];
    notificationAppearance: NotificationPreference[];
    notifyMeList: NotificationPreference[];
    soundPrefences: NotificationPreference[];
}

export interface GeneralPreference {
    ColumnValue: string;
    PrefTypeCode: string;
    UserID: number;
    UserPrefID: number;
    UserPrefTypeID: number;
    CreatedBy?: number;
    UpdatedBy?: number;
    CreatedOn?: Date;
    UpdatedOn?: Date;
}

export interface ColumnLayoutList {
    columnValue: string;
    checked: boolean;
}

export interface WorkspaceSettings {
    field: string;
    label: string;
    isChecked: boolean;
}
