/* eslint-disable @typescript-eslint/no-explicit-any */

export interface FlavorTypesModel {
    id: number;
    name: string;
    parentid: number;
    parentname: string;
    checked?: boolean;
}
