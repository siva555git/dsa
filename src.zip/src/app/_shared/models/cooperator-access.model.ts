import { AddNotes } from "./notes.model";
import { NotificationPayload } from "./notification.model";

export interface CooperatorsAccessPayload {
    expId: number;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    userId: any;
    staffType: string;
}
export interface CooperatorUserModel {
    countryCode: string;
    department: string;
    email: string;
    firstName: string;
    globalUserID: string;
    initials: string;
    isActive: string;
    isLocked: string;
    profilePicURL: string;
    regionName: string;
    surName: string;
    userId: number;
    ApplicationUser?: CooperatorUserModel;
    user?: string;
}

export interface MultipleNotificationExpDetail {
    expCode: string;
    expId: number;
}

export interface CreateNotesPayload {
    staffs: CooperatorsAccessPayload;
    notes: AddNotes[];
    notifications: NotificationPayload[];
}

export interface UsersListSearchPayload {
    searchText: string;
}

export interface CopyToUserPayload {
    expIds: Array<number>;
    copyToGlobalUserId: string;
    copyToUserInitial: string;
    userNotes: string;
    IsPublic: boolean;
    IsCopyAllNotes?: boolean;
    ExpFolderID: number;
    CollaborationGroupID: number;
    AddVariant?: boolean;
    IscopyCreativeTask?: boolean;
}
