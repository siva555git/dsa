export interface LineageResponseModel {
    topExp: string;
    level: number;
    parentTypeID: number;
    parentExpID: string;
    parentExpCode: string;
    parentExpName: string;
    childTypeID: number;
    childExpID: string;
    childExpCode: string;
    childExpName: string;
    isChild: null;
    isParent: boolean;
    IPC: string;
    IPCDescription: string;
    trustee: string;
    plant: null;
    region: null;
    childCreatedBy: string;
    parentCreatedBy: null;
    childID: string;
    ParentID: string;
    isOtherUserFormula: boolean;
    lineageHierarchyPath?: Array<string>;
    creatorName?: string;
    creatorPlant?: string;
    creatorRegion?: string;
    lineageDescription?: string;
}

export interface LineagePayload {
    formulaIds: Array<string>;
    showRelative: boolean;
}
