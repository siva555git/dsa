import { RefreshGridModel } from "../../experiment-editor/models/grid-refresh.model";
import { RetainGridModel } from "../../experiment-editor/models/retain-grid-model";
import { ExperimentFromExperimentPayload } from "./create-experiment.model";
import { Experiment } from "./experiment.model";
import { SendExpToIFFMANResponse } from "./notes.model";
import { SelectedRowDataModel } from "./selected-row-data.model";

export interface ChangeConditionResponse {
    Description: string;
    IsActive: boolean;
    changeConditionID: number;
}

export interface VariantPayload {
    ChangeConditionID: number;
    ChangeDesc: string;
    ExpID?: number;
    RootIPC?: string;
    Remark: string;
    ExpVariantID?: number;
    changeConditionDesc?: string;
    IPCDescription?: string;
    VariantSource?: string;
}

export interface ExperimentVariant {
    ChangeConditionID: number;
    ChangeDesc: string;
    CreatedBy: number;
    CreatedOn: Date;
    ExpID: number;
    ExpVariantID: number;
    RootIPC: string;
    UpdatedBy: number;
    UpdatedOn: Date;
    Remark: string;
    Change?: {
        Description: string;
    };
}

export interface UpdatedVariantData {
    variantData?: VariantPayload;
    variantUpdatedExperiment?: ExperimentVariant;
    retainedUpdateInfo?: { retainGridModel: RetainGridModel; refreshGridData: RefreshGridModel };
    variantSource: string;
    isVariantUpdateCancelled: boolean;
    iffManResponse?: SendExpToIFFMANResponse[];
}
export interface EditModeValue {
    ChangeConditionID: number;
    ChangeDesc: string;
    CreatedBy: number;
    CreatedOn: Date;
    ExpID: number;
    ExpVariantID: number;
    RootIPC: string;
    UpdatedBy: number;
    UpdatedOn: Date;
    Remark: string;
    Change?: {
        Description: string;
    };
    User?: {
        CountryCode: string;
        CreatedBy: number;
        CreatedOn: string;
        Department: string;
        Email: string;
        FirstName: string;
        GlobalUserID: string;
        Initials: string;
        IsActive: string;
        IsAutoCreated: string;
        IsLocked: string;
        LockedBy: number;
        RegionName: string;
        Surname: string;
        UpdatedBy: number;
        UpdatedOn: string;
        UserID: string;
    };
}

export interface FormDataCheck {
    ChangeConditionID: number;
    ChangeDesc: string;
    Remark: string;
}

export interface VariantFormData {
    Comments: string;
    CreatedBy?: number;
    CreatedOn?: Date;
    RootIpc: string;
    VariantChange: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ChangeConditionId?: any;
}

export interface GridRetainedUpdateInfo {
    retainGridModel: RetainGridModel;
    refreshGridData: RefreshGridModel;
}

export interface OpenVariantPayload {
    experiment: SelectedRowDataModel;
    shouldOpenExpInTab: boolean;
    newExperimentResponse?: Experiment[];
    ipcDetails?: ExperimentFromExperimentPayload;
    source?: string;
    retainedUpdateInfo?: GridRetainedUpdateInfo;
}
