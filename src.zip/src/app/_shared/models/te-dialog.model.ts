export interface TasteEditorDialogData {
    title: string;
    message?: string;
    confirmText: string;
    extraConfirmText?: string;
    cancelText: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    dialogData: any;
}

export interface TasteEditorDialogModel {
    panelClass: string;
    width: string;
    disableClose?: boolean;
    data: TasteEditorDialogData;
    autoFocus?: boolean;
}
