/* eslint-disable @typescript-eslint/no-explicit-any */

export interface CurrencyRateModel {
    CurrencyFrom: string;
    CurrencyTo: string;
    Rate: string;
    StartOn: Date;
    RateType: string;
    IsActive: boolean;
}
