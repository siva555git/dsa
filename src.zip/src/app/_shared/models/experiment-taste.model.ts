/**
 * ExperimentTaste Model
 *
 * @export
 * @interface ExperimentTaste
 */
export interface ExperimentTaste {
    /**
     * ExpTasteID
     *
     * @type {number}
     * @memberof ExperimentTaste
     */
    ExpTasteID?: number;

    /**
     * ExpID
     *
     * @type {number}
     * @memberof ExperimentTaste
     */
    ExpID?: number;

    /**
     * FlavourSeq
     *
     * @type {number}
     * @memberof ExperimentTaste
     */
    FlavourSeq?: number;

    /**
     * FlavourTypeID
     *
     * @type {number}
     * @memberof ExperimentTaste
     */
    FlavourTypeID: number;
}
