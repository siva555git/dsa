/**
 * GridRowModel Model
 *
 * @export
 * @interface GridRowModel
 */
export interface GridRowModel {
    /**
     * rowIndex
     *
     * @type {number}
     * @memberof GridRowModel
     */
    rowIndex: number;

    /**
     * selectedColumn
     *
     * @type {string}
     * @memberof GridRowModel
     */
    selectedColumn: string;

    /**
     * currentValue
     *
     * @type {number}
     * @memberof GridRowModel
     */
    currentValue?: number;

    /**
     * previousValue
     *
     * @type {number}
     * @memberof GridRowModel
     */
    previousValue?: number;

    /**
     * SUBCode
     *
     * @type {string}
     * @memberof GridRowModel
     */
    SUBCode?: string;

    /**
     * SUBType
     *
     * @type {string}
     * @memberof GridRowModel
     */
    SUBType?: string;

    /**
     * Instruction
     *
     * @type {string}
     * @memberof GridRowModel
     */
    Instruction?: string;

    /**
     * IsPublic
     *
     * @type {boolean}
     * @memberof GridRowModel
     */
    IsPublic?: boolean;

    /**
     * IsOtherUserExp
     *
     * @type {boolean}
     * @memberof GridRowModel
     */
    IsOtherUserExp?: boolean;
}
