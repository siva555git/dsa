/* eslint-disable unicorn/prevent-abbreviations */
export interface CreateExperiment {
    action: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    experiments: any;
}

export interface AllOtherExperiment {
    experiments: boolean;
    isLoading: boolean;
}

export interface BatchSizePayload {
    plant: string;
    technologyid: number;
}

export interface BatchSizeResponse {
    batch: number;
    facilitycode: string;
    isdefault: boolean;
    isminimum: boolean;
    technologyid: number;
}

export interface WorkingCostPayload {
    batchsize: number;
    yield: number;
    subcount: number;
    costbookcode: string;
    saptechnologyid: number;
    usemin: string;
    productTypeID?: string;
    isFlagCheckNeeded?: boolean;
}

export interface WorkingCostResponse {
    SetupMachine: number;
    MachineTime: number;
    Packaging: number;
    SetupLabor: number;
    LaborTime: number;
    BatchUpperSize: number;
    SAPWorkingCost: string;
    MinUsed: string;
    error?: string;
    status?: number;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    message?: string;
}

export interface PrivacyStatusResponse {
    status: boolean;
}

export interface PrivacyUpdateColumns {
    ExpCode: string;
    IsPublic: boolean;
    ExpID?: number;
}
export interface ExperimentPrivacyPayload {
    updateColumns: PrivacyUpdateColumns[];
}

export interface ExperimentFromExperimentPayload {
    ExpID?: number;
    ExpFolderID: number;
    NumberOfCopies: number;
    IsVersion?: boolean;
    AddVariant?: boolean;
    ExpCode?: string;
    ExpSource?: string;
    IsPublic?: boolean;
    ipc?: string;
    ipcDescription?: string;
    IsCopyAllNotes?: boolean;
    isOtherUserExp?: boolean;
    CollaborationGroupID?: number;
    variantSource?: string;
    IsRevise?: boolean;
    TaskID?: string;
    isChainSeries?: boolean;
}
export interface CreateExpFromExpProdPayload {
    NumberOfCopies: number;
    IsVersion?: boolean;
    AddVariant: boolean;
    IsCopyAllNotes?: boolean;
    ipc?: string;
    ipcDescription?: string;
    expFolderId?: number;
    collaborationGrpId?: number;
    IsCopyCreativeTask?: boolean;
    selectedPlant?: string;
}
export interface ReviseExperimentPayload {
    sourceExpID: number;
    sourceExpCode: string;
    selectedFolderID?: number;
    isOwnExp?: boolean;
    activeExpType?: string;
    CollaborationGroupID?: number;
    IsRevise?: boolean;
    TaskID?: string;
    isChainSeries?: boolean;
}

export interface UomModel {
    id: number;
    value: string;
    key: string;
}

export interface AddWorkingCostPayload {
    ExpID: number;
    CostBookCode: string;
    WorkingCost: number;
    isCreateOrUpdate: boolean;
}

export interface WorkSpaceUpdateModel {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    updatedData: any;
    refreshType: string;
}

export interface MyTaskColumns {
    CustomerId?: string;
    CustomerName?: string;
    DisplayCustomer?: string;
    DisplayProject?: string;
    DisplayTask: string;
    EndUse?: string;
    EndUseName?: string;
    ProjectId?: string;
    ProjectName?: string;
    TaskId: string;
    TaskName: string;
    UseLevel: string;
}

export interface CreativeTaskModel {
    value: MyTaskColumns;
}
