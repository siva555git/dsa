import { PlantAndSourceModel } from "./plant-and-source.model";
import { ProductTypesModel } from "./product-types.model";
import { FacilitiesModel } from "./facilities-model";
// eslint-disable-next-line import/no-cycle
import { ExperimentsModel } from "./experiment-bom.model";
// eslint-disable-next-line import/no-cycle
import { RestrictedUsageAccessList } from "../components/product-data/models/product-data.model";

export interface Audit {
    createdBy: string;
    createdOn: Date;
    updatedBy?: string;
    updatedOn?: Date;
    isActive: boolean;
}

export interface ExperimentValidation {
    status: string;
    message: string;
    type: string;
    ipc?: string;
    name?: string;
    showIcon?: boolean;
    flagCode?: string;
    description?: string;
    restrictedUse?: RestrictedUsageAccessList[];
}

export interface ExperimentHeaderModel {
    productTypes?: ProductTypesModel[];
    plantsAndSources?: PlantAndSourceModel[];
    facilities?: FacilitiesModel[];
    experimentToAudit?: ExperimentsModel;
    checkForSevereAudit?: boolean;
}

export interface BomAuditModel {
    showIcon?: boolean;
    result: string;
    priority: number;
    type: string;
    description: string;
}

export interface SecurityGroupCodeModel {
    securitygroupcode: string;
    globaluserid: string;
    createdby: string;
    createdon: Date;
    updatedby: string;
    updatedon: Date;
}

export interface UserSecurityGroupModel {
    securitygroupmembers: SecurityGroupCodeModel[];
}

export interface FlagAuditModel {
    results: BomAuditModel[];
    status: string;
}
export interface ExpAnalysisAuditModel {
    data?: string;
    length?: number;
    status?: string;
    type?: string;
    calculatedValue: number;
    displayLabel: string;
    restrictedvalue: number;
    errorMessage?: string;
}

// eslint-disable-next-line @typescript-eslint/naming-convention
export interface explodedBOMModel {
    TopIPC: number | string;
    subipcdescription?: string;
    description?: string;
    bomlevel: number;
    ipc: string;
    ipcpt?: string;
    subipc: string;
    subipcpt?: string;
    parts: number;
    actualparts?: number;
    isbom: boolean;
    ispbonsubipc: boolean;
    isProcessBase?: string;
    subtype?: string;
    producttypeid?: string;
    bom_path?: string;
    sequence?: number;
    topipc?: string | number;
}

// eslint-disable-next-line @typescript-eslint/naming-convention
export interface bomAnalysisResponse {
    pourCounts: ExpAnalysisAuditModel[];
    duplicateBOM: explodedBOMModel[];
    status?: number;
    data?: string;
}

export interface ProductDetailsForViewFlag {
    ipc: string;
    description: string;
}

export interface MASourceDataMDRResponse {
    // eslint-disable-next-line no-use-before-define
    masource: MASourceDataModel[];
}
export interface MASourceDataModel {
    CostBookCode: string;
    CreatedBy: string;
    CreatedOn: Date;
    FlagCode: string;
    ID: string;
    IFFMaterial: string;
    IsActive: boolean;
    ProcessedOn: Date;
    SourceSystemID: number;
    UpdatedBy: string;
    UpdatedOn: Date;
}

// eslint-disable-next-line @typescript-eslint/naming-convention
export interface auditResponseModel {
    auditResponse: Array<[]>;
    duplicatePoursBOM?: explodedBOMModel[];
}
