// eslint-disable-next-line import/no-cycle
import { CreateFolderModel } from "./experiment-list.model";
import { NotificationPayload } from "./notification.model";

export interface CollaborationGroupCreatedUser {
    FirstName: string;
    Surname: string;
    UserID?: number;
    GlobalUserID?: string;
}

export interface CollaborationGroupMappedUser {
    IsOwnedGroup: number;
}

export interface CollaborationGroupListModel {
    CollaborationGroupID: number;
    CreatedByUser: CollaborationGroupCreatedUser;
    GroupDescription: string;
    GroupName: string;
    UserCollaborationGroupMapped: CollaborationGroupMappedUser[];
    CreatedOn?: string;
}
export interface UserCollaborationExpPayload {
    CollaborationGroupID: number;
    selectedExpIDList: Array<number>;
}
export interface UserCollaborationMappedModel {
    CollaborationGroupMappedID: number;
    CollaborationGroupID: number;
    ExpID: number;
    CreatedBy: number;
    CreatedOn: Date;
    UpdatedBy: number;
    UpdatedOn: Date;
    UserID: number;
}
export interface AddedExpTableData {
    newlyAddedExpID: string;
    newlyAddedExpName: string;
    existingExpID: string;
    existingExpName: string;
}

export interface SelectedExpModel {
    BatchSize: number;
    CountryCode: number;
    CreatedBy: number;
    CreatedOn: string;
    ExpCode: string;
    ExpID: number;
    ExpName: string;
    ExperimentNote?: Array<[]>;
    ExperimentTaste?: Array<[]>;
    ExperimentVariant?: undefined;
    IPC: number;
    IsArchived: string;
    IsDeleted: string;
    IsLocked: string;
    IsPublic: boolean;
    LockedBy: number;
    ProductTypeID: string;
    index?: number;
    isAlreadyExist?: boolean;
}
export interface MatDialogDataModel {
    selectedExperiment: SelectedExpModel[];
    selectedGroup: CollaborationGroupListModel;
    displayGridDataSource: [
        {
            columndID: string;
            displayColumnName: string;
        },
    ];
}
export interface UserAccessList {
    UserID: number;
    firstName: string;
    surName: string;
    department: string;
    regionName: string;
}

export interface CreateCollaboration {
    GroupName: string;
    GroupDescription?: string;
    MemberIds: Array<number>;
    Notification?: NotificationPayload[];
}

export interface RemoveExpForUser {
    UserID: number;
    RemoveExperiments: boolean;
}

export interface EditCollaboration {
    GroupName: string;
    GroupDescription?: string;
    GroupID: string;
    RemovedUser?: Array<RemoveExpForUser>;
    AddedUser?: Array<number>;
    Notification?: NotificationPayload[];
}

export interface ApplicationSettings {
    appSettingID: number;
    parameterCode: string;
    parameterInString: string;
}

export interface NotificationPreference {
    ApplicationSettings: ApplicationSettings;
    notificationUserPreferenceID: number;
    selectValue: string;
}

export interface CurrentUser {
    Isadactive: boolean;
    active: boolean;
    costcenter: string;
    costcentername: string;
    countrycode: string;
    countryname: string;
    createdby: string;
    createdon: Date;
    deptcode: string;
    deptname: string;
    displayname?: string;
    divisioncode?: string;
    divisionname?: string;
    email: string;
    employeecatcode?: string;
    employeecatname?: string;
    employeetype?: string;
    facilitycode?: string;
    fax?: string;
    firstname: string;
    fullname: string;
    globaluserid: string;
    initials: string;
    ismanager: boolean;
    jobfamily?: string;
    lastname: string;
    mobile?: number;
    nickname?: string;
    notificationPreference: NotificationPreference;
    orgunitcode: string;
    orgunitname: string;
    personnelarea: string;
    phone?: number;
    position: string;
    positioncode?: string;
    regioncode: string;
    regionname: string;
    reportsto: string;
    reporttoname: string;
    sapempid: string;
    subareacode: string;
    subareaname: string;
    title?: string;
    type: string;
    updatedby?: string;
    updatedon?: Date;
}

export interface CollaborationAndFolderModel {
    CreatedBy: number;
    CreatedOn: Date;
    ExpFolderID: number;
    ExpFolderMappedID: number;
    ExpID: number;
    ExperimentFolder: CreateFolderModel;
    UpdatedBy: number;
    UpdatedOn: Date;
    CollaborationGroupID: number;
    UserCollaborationGroup: CollaborationGroupListModel;
}
export interface ViewCollaborationFolderModel {
    CollaborationGroupMappedID: number;
    CollaborationGroupID: number;
    ExpID: number;
    CreatedBy: number;
    CreatedOn: Date;
    UpdatedBy: number;
    UpdatedOn: Date;
    UserID: number;
    ExpFolderID: number;
    ExpFolderMappedID: number;
    ExperimentFolder: CreateFolderModel;
    UserCollaborationGroup: CollaborationGroupListModel;
}
export interface CollaborationGroupCreatorInfo {
    createdDate: string;
    createdById: number;
}

export interface AddExpToCollaborationGroupPayload {
    selectedcollaborationGroup: CollaborationGroupListModel;
    selectedExperiments: SelectedExpModel[];
    isDialogOpened: boolean;
    isdragged: boolean;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    userCollaborationGroupToggle?: any;
}
