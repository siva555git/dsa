import { SortModelItem } from "@ag-grid-community/core";

export interface FilterDto {
    field: string;
    text: string;
    type: string;
}
export interface SortDto {
    field: string;
    order: "DESC" | "ASC";
}
export interface IngredientSearchPayload {
    Sort?: SortModelItem[];
    Filter?: FilterDto[];
    From: number;
    Limit: number;
}

export interface IngredientReplaceResponseModel {
    ExpID: number;
    OldIPC: string;
    NewIPC: string;
    GlobalUserID: string;
    ActionDateTime: Date;
    ProcessIndicator: string;
    ProcessDateTime: Date;
}

export interface IngredientResponsePayload {
    ExpFormulaID: number;
    IPC: string;
    ExpID: number;
    ExpCode: string;
    ExpName: string;
    ProductTypeID: string;
}
export interface IngredientResponseModel {
    totalCount: number;
    currentCount: number;
    rows: IngredientResponsePayload[];
}
export interface IngredientReplacePayload {
    ExpID?: string;
    OldIPC: string;
    NewIPC: string;
    PartFactor: number;
    GlobalUserID?: string;
}
