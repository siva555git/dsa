import { FlagsESModel } from "@te-shared/components/product-data/models/product-data.model";

export interface ExperimentAccessModel {
    Ownership: string;
    Lock: string;
    Privacy: string;
    CategoryName: string;
    isActive?: boolean;
    IsPermitted?: boolean;
    AccessList: string;
    ExpID: number;
    Trustee: boolean;
    AccessFunction?: string;
    CreatedByUserName?: string;
}

export interface FunctionCategoryModel {
    AccessFunction: string;
    CategoryName: string;
    Description: string;
    IsActive: boolean;
}

export interface PermissionCategoryModel {
    AccessList: string;
    CategoryName: string;
    IsActive: boolean;
    IsPermitted: boolean;
    Lock: string;
    Ownership: string;
    Privacy: string;
}
export interface ExperimentAccessPermissionModel {
    ExperimentAccess: {
        FunctionCategory: FunctionCategoryModel[];
        PermissionCategory: PermissionCategoryModel[];
    };
}

export interface ExperimentAccessResponseModel {
    isPermitted: boolean;
    AccessDetail: ExperimentAccessModel[];
}

export interface SecurityGroupcodeModel {
    securitygroupcode: string;
    globaluserid?: string;
}
export interface SecurityGroupMembersResposeModel {
    securitygroupmembers: SecurityGroupcodeModel[];
}
export interface RestictedUseModel {
    flagcode: string;
    accessgiven: string;
}

export interface OtherdetailsModel {
    restricteduse?: RestictedUseModel[];
}

export interface ProductDataModel {
    otherdetails?: OtherdetailsModel;
    restricteduse?: RestictedUseModel[];
    flags?: FlagsESModel[];
}

export interface FlagCodeModel {
    flagCode?: string;
    value?: string;
}

export interface MiniEditorPermissionModel {
    isMiniHeaderAccessible: boolean;
    isQuickInsertAccessible: boolean;
    isEditHeaderAccessible: boolean;
    isAuditAccessible: boolean;
    isDeleteUnDeleteAccessible: boolean;
    isInstructionAccessible: boolean;
    isOpenAccessible: boolean;
    isNoteAccessible: boolean;
    isLayoutAccessible: boolean;
    isVariantAccessible: boolean;
    isInsertAccessible: boolean;
    isExperimentPrivacyAccessible: boolean;
}
