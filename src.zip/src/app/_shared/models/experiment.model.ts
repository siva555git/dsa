/* eslint-disable @typescript-eslint/no-explicit-any */
import { ExperimentTaste } from "./experiment-taste.model";
import { ExperimentMappedFolder } from "./experiment-mapped-folder.model";
import { ExperimentLineage } from "./experiment-lineage.model";
// eslint-disable-next-line import/no-cycle
import { ExperimentCost } from "./experiment-bom.model";
import { NotesResponse } from "./notes.model";
import { CreateOrUpdateTab } from "./create-tab.model";

/**
 *
 *
 * @export
 * @interface Experiment
 * @extends {ExperimentTaste, ExperimentLineage, ExperimentMappedFolder}
 */
export interface Experiment {
    /**
     * ExpID
     *
     * @type {number}
     * @memberof Experiment
     */
    ExpID?: number;

    /**
     * ExpCode
     *
     * @type {string}
     * @memberof Experiment
     */
    ExpCode?: string;

    /**
     * ExpName
     *
     * @type {string}
     * @memberof Experiment
     */
    ExpName: string;

    /**
     * ProductTypeID
     *
     * @type {any}
     * @memberof Experiment
     */
    ProductTypeID: any;

    /**
     * CountryCode
     *
     * @type {string}
     * @memberof Experiment
     */
    CountryCode?: string;

    /**
     * TaskID
     *
     * @type {string}
     * @memberof Experiment
     */
    TaskID: string;

    /**
     * SourceFlagCodeID
     *
     * @type {number}
     * @memberof Experiment
     */
    SourceFlagCodeID: number;

    /**
     * PlantID
     *
     * @type {number}
     * @memberof Experiment
     */
    PlantID: string;

    /**
     * Yield
     *
     * @type {}
     * @memberof Experiment
     */
    Yield: number;

    /**
     * BatchSize
     *
     * @type {number}
     * @memberof Experiment
     */
    BatchSize: number;

    /**
     * WorkingCost
     *
     * @type {number}
     * @memberof Experiment
     */
    WorkingCost: number;

    /**
     * Unit Of Measurement ID
     *
     * @type {number}
     * @memberof Experiment
     */
    UoMID: number;

    /**
     * Use Level
     *
     * @type {number}
     * @memberof Experiment
     */
    UseLevel: number;

    /**
     * ExpType
     *
     * @type {string}
     * @memberof Experiment
     */
    ExpSource?: string;

    /**
     * IPC
     *
     * @type {number}
     * @memberof Experiment
     */
    IPC: number;

    /**
     * IsLocked
     *
     * @type {boolean}
     * @memberof Experiment
     */
    IsLocked?: boolean | string;

    /**
     * LockedBy
     *
     * @type {number}
     * @memberof Experiment
     */
    LockedBy?: number;

    /**
     * LockedOn
     *
     * @type {Date}
     * @memberof Experiment
     */
    LockedOn?: Date;

    /**
     * IsArchived
     *
     * @type {boolean}
     * @memberof Experiment
     */
    IsArchived?: boolean;

    /**
     * ArchivedOn
     *
     * @type {Date}
     * @memberof Experiment
     */
    ArchivedOn?: Date;

    /**
     * IsDeleted
     *
     * @type {boolean}
     * @memberof Experiment
     */
    IsDeleted?: boolean;

    /**
     * DeletedOn
     *
     * @type {Date}
     * @memberof Experiment
     */
    DeletedOn?: Date;

    /**
     * CreatedBy
     *
     * @type {number}
     * @memberof Experiment
     */
    CreatedBy?: number;

    /**
     * CreatedOn
     *
     * @type {Date}
     * @memberof Experiment
     */
    CreatedOn?: string;

    /**
     * IsTasteUpdated
     *
     * @type {boolean}
     * @memberof Experiment
     */
    IsTasteUpdated?: boolean;

    /**
     * IsCostUpdated
     *
     * @type {boolean}
     * @memberof Experiment
     */
    IsCostUpdated?: boolean;

    /**
     * CreatedBy User
     *
     * @type {any}
     * @memberof Experiment
     */
    CreatedByUser?: any;

    /**
     * LockedBy21 User
     *
     * @type {any}
     * @memberof Experiment
     */
    LockedByUser?: any;

    /**
     * IsPublic
     *
     * @type {boolean}
     * @memberof Experiment
     */
    IsPublic?: boolean;

    /**
     * ExperimentTaste
     *
     * @type {[ExperimentTaste]}
     * @memberof Experiment
     */
    ExperimentTaste: Array<ExperimentTaste>;

    /**
     * ExperimentLineage
     *
     * @type {ExperimentLineage}
     * @memberof Experiment
     */
    ExperimentLineage: ExperimentLineage;

    /**
     * ExperimentMappedFolder
     *
     * @type {ExperimentMappedFolder}
     * @memberof Experiment
     */
    ExperimentMappedFolder: ExperimentMappedFolder;

    /**
     * ExperimentCost
     *
     * @type {ExperimentCost}
     * @memberof Experiment
     */
    ExperimentCost?: ExperimentCost;

    /**
     * Comment
     *
     * @type {string}
     * @memberof Experiment
     */
    Comment?: string;

    /**
     * CollaborationGroupID
     *
     * @type {number}
     * @memberof Experiment
     */
    CollaborationGroupID?: number;

    /**
     * ExperimentNote
     *
     * @type {string}
     * @memberof Experiment
     */
    ExperimentNote?: NotesResponse[];

    /**
     *
     *
     * @type {CreateOrUpdateTab}
     * @memberof Experiment
     */
    PreferredWorkspaceToOpen?: CreateOrUpdateTab;
}

export interface WorkspaceUserSettings {
    isOddLineBackground?: boolean;
    isOpenInCurrentExp?: boolean;
    defaultProductCategory?: number;
    isAutoNaturalSort?: boolean;
}
