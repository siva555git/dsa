/* eslint-disable @typescript-eslint/no-explicit-any */
// eslint-disable-next-line import/no-cycle
import { GridDataHelperModel, WorkSpaceModel } from "../../experiment-editor/models/experiment-editor.model";
import { ExperimentTaste } from "./experiment-taste.model";
import { NotesResponse } from "./notes.model";
import { SelectedRowDataModel } from "./selected-row-data.model";
import { CollaborationGroupListModel } from "./user-collaboration-group.model";
import { ExperimentMappedFolder } from "./experiment-mapped-folder.model";
// eslint-disable-next-line import/no-cycle
import { ProductVariantModel } from "./attributes-model";

export interface ExperimentCost {
    WorkingCost: number | string;
    MNC?: number;
    MNCUpdatedOn?: Date;
    UpdatedOn?: Date;
    BosonMNC?: number;
    BosonMNCUpdatedOn?: Date;
}

export interface ComplianceDetailsModel {
    applic_lvl_fr: string;
    compliance: string;
    compliance_order: string;
    ipc: string;
    message: string;
    regul_id: string;
    review_lvl_fr: string;
    rul_id: string;
}

export interface ExperimentVariant {
    ChangeConditionID: number;
    ChangeDesc: string;
    CreatedBy: number;
    CreatedOn: Date;
    ExpID: number;
    ExpVariantID: number;
    RootIPC: string;
    UpdatedBy: number;
    UpdatedOn: Date;
    Remark: string;
    User?: any;
    Change?: {
        Description: string;
    };
}

export interface ExperimentFormulaModel {
    CreatedBy?: number;
    ExpFormulaID: string;
    ExpID: number;
    FormulaSeq: number;
    Instruction?: string;
    IsDelete: number;
    Parts: number;
    SUBCode: string;
    SUBType: string;
    UpdatedBy?: number;
    UpdatedOn?: Date;
    CreatedOn?: Date;
    ipc?: string;
    ingredientName?: string;
    parentExpCode?: string;
    ExperimentMappedFolder?: ExperimentMappedFolder[];
    CreatedByUser?: {
        FirstName: string;
        GlobalUserID: string;
        Surname: string;
    };
    complianceDetails?: ComplianceDetailsModel;
    UnapprovedDescription?: string;
}

export interface FlashPointPrediction {
    formula: string;
    confidenceScore: string;
    predictedFlashpoint: string;
    heatmapImage?: string;
}
export interface FlashPointResponse {
    status: string;
    ipcWithNoChemical?: Array<{ ipc: string; isbom: boolean; description: string }>;
    ipcs: Array<string>;
    flashpointData?: FlashPointPrediction[];
}

export interface ExperimentsModel {
    ExpID: number;
    ExpCode: string;
    ExpName: string;
    ProductTypeID?: string;
    CountryCode: string;
    Task?: string;
    SourceFlagCodeID?: string;
    PlantID?: string;
    Yield: number;
    BatchSize: number;
    ExpSource?: string;
    IsLocked: string;
    LockedBy: number;
    IsArchived: string;
    IsDeleted: string;
    CreatedBy: number;
    Trustee?: number;
    UpdatedBy: number;
    CreatedOn: Date;
    UpdatedOn: Date;
    IsOtherExp?: boolean;
    IsPublic: boolean;
    UoMID: number;
    ExperimentFormula?: ExperimentFormulaModel[];
    ExperimentStaff?: Array<number>;
    ExperimentStaffDetails?: Array<{
        CreatedBy?: number;
        CreatedOn?: Date;
        ExpID?: number;
        ExpStaffID?: number;
        StaffType?: string;
        UpdatedBy?: number;
        UpdatedOn?: Date;
        UserID?: number;
    }>;
    WorkingCostValue?: number | string;
    ExperimentNote?: NotesResponse[];
    IPC?: any;
    Level?: number;
    ExperimentVariant?: ExperimentVariant;
    ExpAccessStatus?: boolean;
    ExperimentCost?: ExperimentCost;
    SharedTo?;
    SharedFrom?;
    code?;
    IsViewindicator?: boolean;
    ipc?: string;
    ingredientName?: string;
    Type?: string;
    ProductNote?: NotesResponse[];
    IsCostUpdated?: boolean;
    MappedFolderID: number;
    IsAppliedNaturalOrder?: boolean;
    Comment?: string;
    TaskID?: string;
    UseLevel?: number;
    CreatedByUser?: {
        FirstName: string;
        GlobalUserID: string;
        Surname: string;
    };
    productvariant?: ProductVariantModel[];
    IsCompliance?: boolean;
    BOMType?: string; // just temporarily added for validateIpcOrExpID in ExperimentEditorHelper file
    SUBType?: string; // just temporarily added for validateIpcOrExpID in ExperimentEditorHelper file
    SubType?: string; // just temporarily added for validateIpcOrExpID in ExperimentEditorHelper file
    isChainSeries?: boolean;
}

export interface ExperimentStaffModel {
    UserID?: number;
}

export interface BomDetailExperimentsModel {
    ExpID: number;
    ExpCode: string;
    ExperimentFormula?: ExperimentFormulaModel[];
    IPC?: any;
    Yield?: number;
    Level?: number;
    IsLocked?: string;
    ExpName?: string;
    ExperimentTaste?: ExperimentTaste[];
    CreatedOn: string | Date;
    ExpAccessStatus?: boolean;
    ExperimentStaffDetails?: ExperimentStaffModel[];
    ExperimentCost?: ExperimentCost;
    ExperimentMappedFolder?: ExperimentMappedFolder[];
    ExperimentNote?: Array<NotesResponse>;
    Comment?: string;
    CreatedBy?: number;
    BOMType?: string;
    Type?: string; // just temporarily added for validateIpcOrExpID in ExperimentEditorHelper file
    SubType?: string; // just temporarily added for validateIpcOrExpID in ExperimentEditorHelper file
    SUBType?: string; // just temporarily added for validateIpcOrExpID in ExperimentEditorHelper file
    SUBCode?: string;
}
export interface BomDetailsModel {
    [Experiments: string]: BomDetailExperimentsModel[];
}

export interface ContextMenuDataHelper {
    menu: any;
    selectedRow: any;
    rowData: any;
    activeExperiment: ExperimentsModel;
    selectedExperiments: SelectedRowDataModel[];
    isOtherExp: boolean;
    bomDetails: BomDetailsModel;
    sortState?: string;
    isSharedExperiment?;
    screenName?: string;
    collaborationGroupList?: CollaborationGroupListModel;
    selectedFolderID?: number;
    collaborationGroupCount?: number;
    userTabInfo?: WorkSpaceModel;
    shouldHideInstructions?: boolean;
    shouldHideMiniHeader?: boolean;
    isHideDeletedItems?: boolean;
    columnId?: string;
    canShowBomCompare?: boolean;
    attributes?: any[];
}

export interface ContextMenuModel {
    name: string;
    cssClasses?: Array<string>;
    icon?: string;
    action?: any;
    disabled?: boolean;
}

export interface ExperimentFormulaContextMenuModel {
    name: string;
    action?: any;
    cssClasses: string[];
    icon: string;
    disabled?: boolean;
    subMenu?: undefined;
    context?: string;
}

export interface ExperimentFormulaIndexModel {
    expFormula: ExperimentFormulaModel;
    index: number;
}

export interface NewAndUpdatedExperimentModel {
    updatedActiveExperiment: BomDetailExperimentsModel[];
    newlyAddedExperiments: BomDetailExperimentsModel[];
}

export interface CombineExpModel {
    selectedRows: ExperimentFormulaModel[];
    experimentBOMDetails: ExperimentFormulaModel[];
    gridDataHelper: GridDataHelperModel;
    isCombineDuplicates: boolean;
    userTabDetails: WorkSpaceModel[];
    userCollaborationGroupList: CollaborationGroupListModel[];
    expFolderID: number;
}

export interface FlexPalletModel {
    expID: string;
    taskID: string;
    ipcList: Array<string>;
}
