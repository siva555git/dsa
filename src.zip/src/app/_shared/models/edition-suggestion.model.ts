/**
 * EditionSuggesstion Model
 *
 * @export
 * @interface EditionSuggesstion
 */
export interface EditionSuggesstionModel {
    /**
     * femaIpcCode
     *
     * @type { Array<string>}
     * @memberof EditionSuggesstionModel
     */
    femaIpcCode?: Array<string>;

    /**
     * enumIpcCode
     *
     * @type { Array<string>}
     * @memberof EditionSuggesstionModel
     */
    enumIpcCode?: Array<string>;

    /**
     * solutionData
     *
     * @type { Array<string>}
     * @memberof EditionSuggesstionModel
     */
    solutionData?: Array<string>;

    /**
     * varientData
     *
     * @type { Array<string>}
     * @memberof EditionSuggesstionModel
     */
    variantData?: Array<string>;
}
