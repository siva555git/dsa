export interface SocketNotificationModel {
    Subject: string;
    Body: string;
    NotificationTypeID: number;
    NotificationEventID: number;
    CreatedTo: number;
    IsPushMessage: string;
    UserName: string;
    alertAppearance: string;
    isValidPush?: boolean;
    ExpCode?: string;
    shouldPlaySound?: boolean;
}
