import { MatomoProperties } from "./matomo-properties.model";

/**
 * Matomo Event Model
 *
 * @export
 * @interface MatomoEvent
 */
export interface MatomoEvent {
    /**
     * action
     *
     * @type {string}
     * @memberof MatomoEvent
     */
    action: string;

    /**
     * properties
     *
     * @type {MatomoProperties}
     * @memberof MatomoEvent
     */
    properties: MatomoProperties;
}
