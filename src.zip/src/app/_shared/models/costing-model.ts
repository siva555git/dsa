// eslint-disable-next-line import/no-cycle
import { BomAttributes } from "./attributes-model";
// eslint-disable-next-line import/no-cycle
import { ExperimentsModel } from "./experiment-bom.model";
import { FacilitiesModel } from "./facilities-model";
import { PlantAndSourceModel } from "./plant-and-source.model";
import { ProductTypesModel } from "./product-types.model";

export interface WorkingCostResponse {
    BatchUpperSize: number;
    LaborTime: number;
    MachineTime: number;
    MinUsed: number;
    Packaging: number;
    SAPWorkingCost: string;
    SetupLabor: number;
    SetupMachine: number;
}

export interface WorkingCostDialogData {
    costingHeader: string;
    costingCalculation: string;
    isStatic: boolean;
    costingCalculationValue?: string;
    costingValue?: number | string;
}
export interface DetailedCostingPreparePayloadModel {
    plantAndSourceInfo: PlantAndSourceModel[];
    facilityInfo: FacilitiesModel[];
    selectedItem: ExperimentsModel;
    productType: ProductTypesModel[];
    isLandingPage: boolean;
    isZeroPartsExist: boolean;
    attributesInfo?: BomAttributes[];
}

export interface DetailedCostingPayload {
    expID: string;
    ipc: string;
    plant: string;
    facilitycode: string;
    currencycode: string;
    userID: string;
    description: string;
    userAllocatedPlant: FacilitiesModel[];
    technologyID: string;
    batchSize: number;
    isZeroPartsExist: boolean;
}
