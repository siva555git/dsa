/* eslint-disable @typescript-eslint/no-explicit-any */
export interface ModifiedDetails {
    selectedCheckList: Array<any>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    masterCheckBox: boolean;
}
