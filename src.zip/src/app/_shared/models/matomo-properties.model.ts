/**
 * Matomo Properties Model
 *
 * @export
 * @interface MatomoProperties
 */
export interface MatomoProperties {
    /**
     * category
     *
     * @type {string}
     * @memberof MatomoProperties
     */
    category: string;

    /**
     * label
     *
     * @type {string}
     * @memberof MatomoProperties
     */
    label: string;

    /**
     * value
     *
     * @type {number}
     * @memberof MatomoProperties
     */
    value?: number;
}
