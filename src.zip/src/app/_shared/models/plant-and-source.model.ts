/* eslint-disable @typescript-eslint/no-explicit-any */

export interface PlantAndSourceModel {
    IsActive: string;
    PlantID: string;
    Source: string;
    SourceFlag: string;
    UserID: number;
    plantCode?: string;
    displayValue?: string;
    columnLayoutdisplayText?: string;
    UserAllocationID: number;
}
