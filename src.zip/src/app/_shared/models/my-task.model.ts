export interface TaskAssigneeModel {
    Name: string;
    UserId: string;
}

export interface MyTaskModel {
    CreatedDate?: Date;
    CustomerId?: string;
    CustomerName?: string;
    DueDate?: Date;
    EndUseCode?: string;
    EndUseDescription?: string;
    LogId?: string;
    Potential?: string;
    Priority?: string;
    ProjectDescription?: string;
    ProjectId?: string;
    QueueName: string;
    SourceSystem?: string;
    TaskAssignee?: TaskAssigneeModel[];
    TaskId: string;
    TaskStatus?: string;
    TaskType?: string;
    UseLevel?: string;
}
