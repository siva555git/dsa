export interface AddNotes {
    ExpID: number;
    Description: string;
    NoteType: string;
    IsPrivate: string;
    ExpNoteID?: string;
    userIds?: number[];
}

export interface SendExpToIFFMANResponse {
    ErrorNumber: string;
    Procedure: string;
    ErrorLine: string;
    ErrorMsg: string;
    Comment: string;
    CreatedBy: string;
    CreateDate: string;
    case: string;
    displayMessage: string;
}

export interface NotesResponse {
    ExpID: number;
    Description: string;
    NoteType: string;
    IsPrivate: string;
    CreatedBy: number;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    User: any;
    CreatedOn: Date;
    UpdateOn: Date;
    UpdatedBy: number;
    ExpNoteID: string;
    isESResponseFlag?: boolean;
    iffManResponse?: SendExpToIFFMANResponse[];
}

export interface DeletePayload {
    ExpNoteId: number;
    ExpID: number;
}
export interface NotesObject {
    noteDesc: string;
    noteId: string;
}

export interface GetExperimentNotesByIdPayload {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    limit: any;
    ExpId: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    offset: any;
    filter?: string;
}

export interface ClearSearchModel {
    searchText: string;
    defaultFilterValue: string;
}
