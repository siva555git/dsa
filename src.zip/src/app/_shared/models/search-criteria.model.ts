/* eslint-disable @typescript-eslint/no-explicit-any */
export interface SearchCriteria {
    searchText: string;
    limit: number;
    offset: number;
    searchBy: Array<string>;
    searchType: string;
    activeExpID?: number;
    searchCategory?: string;
    folderId?: number;
    UserSelected?: number;
}

export interface ExpDetailsModel {
    from: number;
    recordcount: number;
    query?: any;
    filter: any;
    plantId?: string;
    checkrestricted?: boolean;
    activeExpSource?: string;
    activeExpCode?: string;
}
export interface IpcSearchCriteria {
    esDetails: ExpDetailsModel;
    isAllCategorySelected?: boolean;
    layoutDetails?: [];
    isEncapsulationUser?: boolean;
    plantInfo?: Array<[]>;
}

export interface IPCProductDetails {
    ipc: string;
    mode: string;
    isEncapsulationUser?: boolean;
}

export type RemoveItemModel = {
    cartItem: any;
    cartItemIndex: number;
};
