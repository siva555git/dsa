/* eslint-disable @typescript-eslint/no-explicit-any */

export interface ProductTypesModel {
    PTtechnologyID: number;
    active: boolean;
    description: string;
    divisioncode: string;
    facilitycode: string;
    prodtypecode: string;
    yield: number;
    isRecentlyUsed?: boolean;
    ID?: number;
}

export interface RecentlyUsedProductTypesModel {
    ColumnValue: string;
    UserPrefID: number;
}
