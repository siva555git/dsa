import { NotesResponse } from "./notes.model";

export interface SelectedRowDataModel {
    ExpID: number;
    ExpCode: string;
    checked: boolean;
    CreatedBy: number;
    IPC: number;
    productType?: number | string;
    ExpName: string;
    UseLevel?: number;
    Yield?: number;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ExperimentVariant?: any;
    IsPublic?: boolean;
    IsLocked?: string;
    ExpAccessStatus?: boolean;
    index?: number;
    IsOtherExp?: boolean;
    SharedTo?;
    SharedFrom?;
    MappedFolderID?: number;
    FolderName?: string;
    Trustee?: number;
    ExperimentStaffDetails?: Array<{
        CreatedBy?: number;
        CreatedOn?: Date;
        ExpID?: number;
        ExpStaffID?: number;
        StaffType?: string;
        UpdatedBy?: number;
        UpdatedOn?: Date;
        UserID?: number;
    }>;
    ExperimentNote?: Array<NotesResponse>;
    Comment?: string;
    TaskID?: string;
}
export interface InstructionNewItem {
    CreatedBy?: number;
    CreatedOn?: Date;
    ExpFormulaID?: string | number;
    ExpID?: number;
    FormulaSeq?: number;
    Instruction?: string;
    IsDelete?: number;
    Parts?: number;
    SUBCode?: string;
    SUBType?: string;
    UpdatedBy?: number;
    UpdatedOn?: Date;
}
