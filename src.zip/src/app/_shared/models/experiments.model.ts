import { UntypedFormArray, UntypedFormGroup } from "@angular/forms";
import { IServerSideGetRowsRequest } from "@ag-grid-community/core";
import { ColumnLayoutDetails, EditionSuggesstionItemModel } from "@te-experiment-editor/models/experiment-editor.model";
import { RefreshGridModel } from "../../experiment-editor/models/grid-refresh.model";
import { WorkSpaces } from "./create-tab.model";
import { ExperimentsModel } from "./experiment-bom.model";
import { Experiment } from "./experiment.model";
import { FacilitiesModel } from "./facilities-model";
import { FlavorTypesModel } from "./flavor-types-model";
import { PlantAndSourceModel } from "./plant-and-source.model";
import { ProductTypesModel } from "./product-types.model";
import { CollaborationGroupListModel } from "./user-collaboration-group.model";
import { ProductVariantModel } from "./attributes-model";
import { AllOtherExperimentSearchPayload, ExperimentDetails } from "./experiment-list.model";

export interface AuditSideNavMessage {
    status: string;
    primaryMessage: string;
    secondaryMessage: string;
    isActionButtonVisible: boolean;
}

export interface RecentlyViewExperiment {
    Experiments: {
        Experiments: [Experiment];
    };
}

export interface RecentlyUsedExpInSearch {
    count: number;
    rows: Experiment[];
}

export interface ProductSearchList {
    total: number;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    searchresults: any[];
}

export interface ExperimentReturnFromAPI {
    Experiments: any; // eslint-disable-line @typescript-eslint/no-explicit-any
    expDetail: any; // eslint-disable-line @typescript-eslint/no-explicit-any
    rows: any; // eslint-disable-line @typescript-eslint/no-explicit-any
}

export interface RecentlyViewedPayload {
    limit: number;
    offset: number;
    searchType: string;
    description?: string;
    searchText: string;
    searchBy: Array<string>;
    activeExpID?: number;
    plantId?: string;
    isOpenproduct?: boolean;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    esPayload?: any;
    isEncapsulationUser?: boolean;
}
export interface FMPDialogData {
    experiment: ExperimentsModel;
}

export interface MaxDosageResponse {
    expid?: string;
    maxpassdosage?: number;
    message?:
        | Array<{
              type: string;
              message: string;
              bomlevel: number;
          }>
        | string;
    errormessage?: string;
    errors?: Array<string>;
}

export interface FMPResponseData {
    expid: string;
    failscore: number;
    passscore: number;
    prediction: number;
    message: Array<{ type: string; message: string }> | string;
    failed?: Array<string>;
    unavailable?: Array<string>;
}

export interface ReferenceUserPreferenceTypeModel {
    CreatedBy: number;
    CreatedOn: Date;
    IsActive: string;
    PrefDesc: string;
    PrefTypeCode: string;
    UpdatedBy: number;
    UpdatedOn: Date;
    UserPrefTypeID: number;
}

export interface UserPreferenceModel {
    ColumnValue: string;
    CreatedBy: number;
    UpdatedBy: number;
    UserID: number;
    UserPrefID: number;
    UserPrefTypeID: number;
    ReferenceUserPreferenceType: ReferenceUserPreferenceTypeModel;
}

export interface CooperatorAccessData {
    expId: number;
    currentPage: string;
    expCode: string;
    isViewMode?: boolean;
    selectedExpRows?: ExperimentsModel[];
}
export interface UserCollaborationGroup {
    expId: number;
    currentPage: string;
    expCode: string;
}

export interface ExperimentHeaderModel {
    productTypes?: ProductTypesModel[];
    plantsAndSources?: PlantAndSourceModel[];
    facilities?: FacilitiesModel[];
    experimentToAudit?: ExperimentsModel;
    checkForSevereAudit?: boolean;
}

export interface VariantDetailModel {
    userName: string;
    globalUserId: string;
    ipcDescription: string;
}

export interface RefreshExperimentHeaderModel extends RefreshGridModel {
    expCodes?: string[];
}

export interface ValidateExperimentHeaders {
    value: boolean;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    errorMessage: any;
    formControlName: string;
}

export interface ValidateUserInputModel {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    dropDownValues: any;
    validateKey: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    form: any;
    toasterMessage: string;
    formControlName: string;
}

export interface DefaultExperimentFolderModel {
    FolderID: number;
    FolderName: string;
}
export interface SortEventModel {
    active: string;
    direction: string;
}

export interface WorkSpaceValidation {
    isWorkSpaceDetailRequired?: boolean;
    workspace?: WorkSpaces[];
}

export interface ExperimentTasteHelperModel {
    selectedTaste: FlavorTypesModel;
    experimentForm: UntypedFormGroup;
    experimentTaste: UntypedFormArray;
    selectedFlavors: FlavorTypesModel[];
    filteredSelectedFlavors?: FlavorTypesModel[];
    expTasteForm?: UntypedFormGroup;
}

export interface GridPayloadModel {
    folderId: number;
    request: IServerSideGetRowsRequest;
    allotherExperimentsValue: AllOtherExperimentSearchPayload;
    selectedCollaborationGroup: CollaborationGroupListModel;
    cacheBlockSize: number;
    searchValueInput: string;
    sharedTypeInput: string;
    columnsFilterArray: string[];
    isTrusteeFolder?: boolean;
    redirectedExperimentDetails?: ExperimentDetails;
}
export interface ProductList {
    femaIpcCode: string;
    solutionData: EditionSuggesstionItemModel[];
    variantData: ProductVariantModel[];
    activeExpPlantId?: string;
    columnDetails?: ColumnLayoutDetails;
    enumIpcCode?: string;
    activeExpSource?: string;
    activeExpCode?: string;
    facilities: FacilitiesModel[];
}
export interface InstructionSearchModel {
    CategoryName: string;
    ColumnValue: string;
    CostBookCode: string;
    Description: string;
    InstructionID: number;
    IsFavourite: boolean;
    SortCode: string;
    UserPrefID: string;
}
