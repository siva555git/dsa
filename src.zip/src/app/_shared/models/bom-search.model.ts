/* eslint-disable @typescript-eslint/no-explicit-any */
import { SearchType } from "../../experiment-editor/models/experiment-editor.model";
import { BomSearchDialogDataModel } from "./dialog.model";
import { ExperimentsModel } from "./experiment-bom.model";

export interface BomSearchModel {
    searchType: SearchType;
    softDeletedItems: ExperimentsModel[];
    deletedItems: ExperimentsModel[];
    data: BomSearchDialogDataModel;
    cartListCopy: any[];
}

export interface CartItemsModel {
    addedItems: any[];
    updatedItems: any[];
    softDeletedItems: ExperimentsModel[];
    deletedItems: ExperimentsModel[];
    cartLists: any[];
    cartListCopy: any[];
}

export interface NestedColumnModel {
    [sortyKey: string]: {
        order: string;
        nested: {
            path: string;
            filter: {
                match: {
                    [matchKey: string]: string;
                };
            };
        };
    };
}

export interface DirectColumnModel {
    [sortyKey: string]: {
        order: string;
    };
}
