import { QuickSearchItem } from "@te-experiment-editor/models/experiment-editor.model";
import { FlagAuditModel } from "./audit.model";
import { ExperimentStaffModel } from "./experiment-bom.model";
import { NotesResponse } from "./notes.model";
import { CollaborationGroupCreatedUser } from "./user-collaboration-group.model";

export interface ExperimentOrProduct extends QuickSearchItem {
    ipc?: string;
    audit?: FlagAuditModel;
    complianceDetails?: string;
    TaskID?: string;
    UseLevel?: number;
    CreatedOn?: Date;
    Comment?: string;
    CreatedByUser?: CollaborationGroupCreatedUser;
    ExperimentStaffDetails?: ExperimentStaffModel[];
    ExperimentNote?: NotesResponse[];
}
