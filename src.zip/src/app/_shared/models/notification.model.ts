export interface NotificationPayload {
    Subject: string;
    ExpCode: string;
    UserName: string;
    CreatedTo: number;
    NotificationTypeID: number;
    NotificationEventID: number;
    IsPushMessage: string;
    UserSettingCode: string;
    Body?: string;
}

export interface GetNotificationPayload {
    dateRange: string;
}

export interface NotificationFilterModel {
    name: string;
    checked: boolean;
    class: string;
}
export interface NotificationEventModel {
    NotificationEventID: number;
    Description: string;
    IsActive: boolean;
}

export interface NotificationTypeModel {
    NotificationTypeID: number;
    Description: string;
    IsActive: boolean;
}

export interface NotificationResultModel {
    Subject: string;
    Body: string;
    CreatedBy: string;
    CreatedOn: Date;
    CreatedTo: string;
    IsPushMessage: boolean;
    IsRead: boolean;
    NotificationEventID: number;
    NotificationID: string;
    NotificationTypeID: number;
    ReferenceNotificationEvent: NotificationEventModel;
    ReferenceNotificationType: NotificationTypeModel;
}

export interface DeleteNotificationPayload {
    notifIds: number[];
}

export interface NotificationResponse {
    unReadCount: number;
    notifications: NotificationResultModel[];
}
