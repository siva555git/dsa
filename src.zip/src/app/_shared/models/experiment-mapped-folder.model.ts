/**
 * ExperimentMappedFolder Model
 *
 * @export
 * @interface ExperimentMappedFolder
 */
export interface ExperimentMappedFolder {
    /**
     * ExperimentMappedFolder
     *
     * @type {number}
     * @memberof ExperimentMappedFolder
     */
    ExpFolderID: number;
}
