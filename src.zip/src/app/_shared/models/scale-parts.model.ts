import { BomDetailsModel } from "./experiment-bom.model";

export interface ScalePartsInput {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    Experiments: any;
    TotalPartsToScale?: number;
    RoundingValue?: number;
}
export interface ScalePartsDialogData {
    title: string;
    message: string;
    cancelText: string;
    confirmText: string;
    dialogData: [];
}

export interface ScalePartsRefreshGrid {
    selectedExperiments: any;
    bomDetails: BomDetailsModel;
}
