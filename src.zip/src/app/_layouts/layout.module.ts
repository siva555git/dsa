/** Angular Modules */
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";

/** Custom Modules */
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { NgMaterialModule } from "../material.module";
import { SharedModule } from "../_shared/shared.module";

/** Components */
import { HeaderComponent } from "./header/header.component";
import { SidenavListComponent } from "./sidenav-list/sidenav-list.component";
import { ContainerComponent } from "./container/container.component";
import { SideBarComponent } from "./side-bar/side-bar.component";
import { CreativeReviewModule } from "../creative-review/creative-review.module";

const components = [HeaderComponent, SidenavListComponent, ContainerComponent, SideBarComponent];

@NgModule({
    declarations: [...components],
    imports: [CommonModule, NgMaterialModule, RouterModule, SharedModule, ReactiveFormsModule, FormsModule, CreativeReviewModule],
    exports: [...components],
    providers: [GridApiService],
})
export class LayoutModule {}
