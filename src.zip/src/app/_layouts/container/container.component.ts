/** Angular */
import { Component, OnInit, ChangeDetectorRef } from "@angular/core";

/** Services */
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { EMPTY, ERROR, INSERT_OR_REPLACE_LOADER_START, INSERT_OR_REPLACE_LOADER_STOP, PLEASE_WAIT } from "src/app/app.constant";
import { AppBroadCastService, AppEventManager } from "../../_services";

/** Enums and Contants */
import { THEME_CHANGE } from "../../_shared/constants/event.constant";

@Component({
    selector: "app-container",
    templateUrl: "./container.component.html",
})
export class ContainerComponent implements OnInit {
    /** private members */
    private ngUnsubscribe: Subject<any> = new Subject<void>(); /* eslint-disable-line @typescript-eslint/no-explicit-any */

    /** public members */
    public isThemeDark: false;

    public showAppLoader = false;

    public appLoaderMsg = "";

    public insertReplaceLoaderExist = false;

    constructor(
        private readonly appBroadcast: AppBroadCastService,
        private readonly eventManager: AppEventManager,
        private readonly cdr: ChangeDetectorRef,
    ) {
        this.eventManager.subscribe(THEME_CHANGE, (event) => {
            this.isThemeDark = event.isThemeDark;
        });
    }

    ngOnInit(): void {
        this.cdr.detectChanges();
        this.appBroadcast.appSpinnerPrompt.pipe(takeUntil(this.ngUnsubscribe)).subscribe((value) => {
            if (value === INSERT_OR_REPLACE_LOADER_START) {
                this.insertReplaceLoaderExist = true;
                this.appLoaderMsg = PLEASE_WAIT;
                this.showAppLoader = this.appLoaderMsg.length > 0;
            } else if (value === ERROR || value === INSERT_OR_REPLACE_LOADER_STOP) {
                this.insertReplaceLoaderExist = false;
                // eslint-disable-next-line no-param-reassign
                value = EMPTY;
            }
            if (!this.insertReplaceLoaderExist) {
                this.appLoaderMsg = value;
                this.showAppLoader = value.length > 0;
            }
        });
    }
}
