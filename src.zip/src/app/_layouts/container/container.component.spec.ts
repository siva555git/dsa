import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { By } from "@angular/platform-browser";
import { ContainerComponent } from "./container.component";
import { AppBroadCastService, AppEventManager } from "../../_services";
import { THEME_CHANGE } from "../../_shared/constants/event.constant";
import { SpyService, callback } from "../../testing/spy.service";

describe("ContainerComponent", () => {
    let component: ContainerComponent;
    let fixture: ComponentFixture<ContainerComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ContainerComponent],
            providers: [AppBroadCastService, AppEventManager],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ContainerComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should subscribe on theme change", () => {
        const eventService = TestBed.inject(AppEventManager);
        const spyService = TestBed.inject(SpyService);

        expect(spyService.called).toBeFalsy();

        eventService.subscribe(THEME_CHANGE, () => callback(spyService));
        eventService.broadcast({ name: THEME_CHANGE, isThemeDark: true });

        expect(spyService.called).toBeTruthy();
    });

    it("should resolve for ngOnInit when appSpinnerPrompt responds with loader start", () => {
        const appBroadcast = TestBed.inject(AppBroadCastService);
        appBroadcast.appSpinnerPrompt.next("Insert or Replace Loader Start");
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
        expect(component.insertReplaceLoaderExist).toBeTrue();
    });
    
    it("should resolve for ngOnInit when appSpinnerPrompt responds with Loader Stop", () => {
        const appBroadcast = TestBed.inject(AppBroadCastService);
        appBroadcast.appSpinnerPrompt.next("Insert or Replace Loader Stop");
        component.ngOnInit();
        expect(component.insertReplaceLoaderExist).toBeFalse();
    });
});
