/* eslint-disable max-lines-per-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { OAuthLogger, OAuthService, UrlHelperService } from "angular-oauth2-oidc";
import { RouterTestingModule } from "@angular/router/testing";
import { MatDialog } from "@angular/material/dialog";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { Router } from "@angular/router";
import { of } from "rxjs";
import { MockGridapiService } from "@te-testing/mock-gridapi.service";
import { DialogHelper } from "@te-shared/helpers/dialog-helper";
import { NGXLogger } from "ngx-logger";
import { MockAppDataService } from "@te-testing/mock-app.data.service";
import { MockLoggerService } from "@te-testing/mock-logger.service";
import { ToastrService } from "ngx-toastr";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { MockToastrService } from "@te-testing/mock-toastr.service";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { AuthorizationDirective } from "@te-shared/security/directives/authorization.directive";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { SideBarComponent } from "./side-bar.component";
import { MockExperimentHelper } from "../../testing/mock-experiment.helper";
import { MockCreativereview } from "../../testing/mock-creativereview-helper";
import { AppBroadCastService, AppDataService, AppStateService } from "../../_services";
import { CreativeReviewHelper } from "../../creative-review/helpers/creative-review-helper";
import { ExperimentHelper } from "../../_shared/helpers/experiment-helper";
import { PATH_URL } from "../../_shared/constants/common.constant";
import { SUB_MENU_LIST } from "../../_shared/constants/context-menu.constant";
import { TabHelper } from "../../_shared/helpers/tab-helper";
import { MockTabHelperService } from "../../testing/mock-tabhelper.service";

describe("SideBarComponent", () => {
    let component: SideBarComponent;
    let fixture: ComponentFixture<SideBarComponent>;
    const dialogReferenceStub = {
        afterClosed() {
            return of(); // this can be whatever, esp handy if you actually care about the value returned
        },
    };

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [SideBarComponent, AuthorizationDirective],
            imports: [RouterTestingModule, HttpClientTestingModule],
            providers: [
                AppDataService,
                AppBroadCastService,
                AppStateService,
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                { provide: GridApiService, useClass: MockGridapiService },
                { provide: AppDataService, useClass: MockAppDataService },
                {
                    provide: ExperimentHelper,
                    useClass: MockExperimentHelper,
                },
                {
                    provide: CreativeReviewHelper,
                    useClass: MockCreativereview,
                },
                { provide: TabHelper, useClass: MockTabHelperService },
                {
                    provide: MatDialog,
                    // eslint-disable-next-line @typescript-eslint/no-empty-function
                    useValue: { open: () => dialogReferenceStub },
                },
                DialogHelper,
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                SecurityHelper,
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SideBarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should open the folder view on landing page", () => {
        const appBroadcast = TestBed.inject(AppBroadCastService);
        const mockData = { menuName: "Folder", status: true };
        appBroadcast.onUpdateActiveClassSideBar(mockData);
        expect(appBroadcast).toBeTruthy();
    });

    it("should check the parsed route dosen't exist in route config", () => {
        const router = TestBed.inject(Router);
        router.navigate(["/"]);
        const result = component.hasRoute(PATH_URL.HOME);
        expect(result).toBeFalsy();
    });

    it("should call on onViewProductClicked", () => {
        const spy = spyOn(component, "onViewProductClicked").and.callThrough();
        component.onViewProductClicked();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onCreativeReviewCheck", () => {
        const spy = spyOn(component, "onCreativeReviewCheck").and.callThrough();
        component.onCreativeReviewCheck(false);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on creativeReviewPublish", () => {
        const spy = spyOn(component, "creativeReviewPublish").and.callThrough();
        component.creativeReviewPublish();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onShowCreativeReviewPopUp with experiments creative review", () => {
        const spy = spyOn(component, "onShowCreativeReviewPopUp").and.callThrough();
        component.onShowCreativeReviewPopUp(SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onShowCreativeReviewPopUp with experiments review history", () => {
        const spy = spyOn(component, "onShowCreativeReviewPopUp").and.callThrough();
        component.onShowCreativeReviewPopUp(SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnInit", () => {
        const spy = spyOn(component, "ngOnInit").and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on ngOnDestroy", () => {
        const spy = spyOn(component, "ngOnDestroy").and.callThrough();
        component.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for onOpenProductClicked()", () => {
        const spy = spyOn(component, "onOpenProductClicked").and.callThrough();
        component.onOpenProductClicked();
        expect(spy).toHaveBeenCalled();
    });

    it("should resolve for openReviewComparisonPopup", () => {
        const spy = spyOn(component, "openReviewComparisonPopup").and.callThrough();
        component.openReviewComparisonPopup();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onViewAttributeAnalysisClicked", () => {
        const spy = spyOn(component, "onViewAttributeAnalysisClicked").and.callThrough();
        component.onViewAttributeAnalysisClicked();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onOpenSampleDialog", () => {
        const spy = spyOn(component, "onOpenSampleDialog").and.callThrough();
        component.onOpenSampleDialog();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onReprintLabelClicked", () => {
        const spy = spyOn(component, "onReprintLabelClicked").and.callThrough();
        component.onReprintLabelClicked();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on checkAndAlertPendingProcess", () => {
        const parameters = {
            isLastRequestPending: true,
            oldIPC: "1RR04333",
            newIpc: "1RR04332",
        };
        const spy = spyOn(component, "checkAndAlertPendingProcess").and.callThrough();
        component.checkAndAlertPendingProcess(parameters);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on onIngrediantSearch", () => {
        spyOn(component, "checkAndAlertPendingProcess");
        const spy = spyOn(component, "onIngrediantSearch").and.callThrough();
        component.onIngrediantSearch();
        expect(spy).toHaveBeenCalled();
    });
});
