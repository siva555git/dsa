/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, OnInit, OnDestroy } from "@angular/core";
import { Router } from "@angular/router";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { Subscription } from "rxjs";
import { MatDialog } from "@angular/material/dialog";
import { CreateSampleComponent } from "@te-shared/components/create-sample/create-sample.component";
import { GridApiService } from "@te-experiment-editor/helpers/grid-api-service";
import { DialogHelper } from "@te-shared/helpers/dialog-helper";
import { SAMPLE_TYPE } from "@te-shared/constants/print-sample.constant";
import { IngrediantSearchReplaceComponent } from "../../reports/ingrediant-search-replace/ingrediant-search-replace.component";
import { AppBroadCastService } from "../../_services/app-broadcast/app.broadcast.service";
import {
    BASIC_ROUTES_URL,
    FULL_SCREEN_POPUP,
    INGREDIANT_DIALOG,
    PANEL_CLASS,
    PATH_URL,
    PREVIOUS_REQUEST,
    REPRINT_LABEL_DIALOG,
    SIDE_BAR_MENU,
    SLIDE_PANEL_DIALOG,
    CREATE_SAMPLE_POPUP,
    YIELD_VALUES,
} from "../../_shared/constants/common.constant";
import { SelectedRowDataModel } from "../../_shared/models/selected-row-data.model";
import { SUB_MENU_LIST } from "../../_shared/constants/context-menu.constant";
import { CreativeReviewHelper } from "../../creative-review/helpers/creative-review-helper";
import { ExperimentHelper } from "../../_shared/helpers/experiment-helper";
import { BomSearchDialogDataModel } from "../../_shared/models/dialog.model";
import { SearchType } from "../../experiment-editor/models/experiment-editor.model";
import { BomSearchComponent } from "../../_shared/components/bom-search/bom-search.component";
import { TabHelper } from "../../_shared/helpers/tab-helper";
import { ExperimentsModel } from "../../_shared/models/experiment-bom.model";
import { AttributeAnalysisComponent } from "../../reports/attribute-analysis/attribute-analysis.component";
import { ConfirmationDialogComponent } from "../../_shared/components/confirmation-dialog/confirmation-dialog.component";
import { EMPTY, LOADING } from "../../app.constant";

@Component({
    selector: "app-side-bar",
    templateUrl: "./side-bar.component.html",
})
export class SideBarComponent implements OnInit, OnDestroy {
    public sideBarMenus: any;

    public menuActiveState: any;

    public updateActiveSideMenuSubscription: Subscription;

    public sideBarExpSubscription: Subscription;

    public applicationPermissions = APPLICATION_PERMISSIONS;

    public selectedExperiments: SelectedRowDataModel[] = [];

    public basicRoutes = BASIC_ROUTES_URL;

    public pathSettings = PATH_URL;

    public previousReplaceRequestPending = { isLastRequestPending: true, oldIPC: EMPTY, newIpc: EMPTY };

    constructor(
        private readonly appBroadCastService: AppBroadCastService,
        private readonly dialog: MatDialog,
        private readonly gridApiService: GridApiService,
        private readonly creativeReviewHelper: CreativeReviewHelper,
        private readonly experimentHelper: ExperimentHelper,
        private readonly router: Router,
        private readonly tabHelper: TabHelper,
        private readonly dialogHelper: DialogHelper,
    ) {}

    public ngOnInit(): void {
        this.sideBarMenus = SIDE_BAR_MENU;
        this.updateActiveSideMenuSubscription = this.appBroadCastService.updateActiveSideMenu.subscribe((state) => {
            this.menuActiveState = state;
        });
        this.sideBarExpSubscription = this.appBroadCastService.selectedExp.subscribe((result) => {
            this.selectedExperiments = result;
        });
        this.creativeReviewPublish();
        this.openReviewComparisonPopup();
    }

    public ngOnDestroy(): void {
        if (this.updateActiveSideMenuSubscription !== undefined) {
            this.updateActiveSideMenuSubscription.unsubscribe();
        }
        if (this.sideBarExpSubscription !== undefined) {
            this.sideBarExpSubscription.unsubscribe();
        }
    }

    /**
     * Method to show and hide master data menu based on route
     *
     * @memberof SideBarComponent
     */
    public hasRoute(route: string): any {
        return this.router.url.includes(route);
    }

    /**
     * Method to open View Products from dashboard icon
     * @memberof SideBarComponent
     */
    public onViewProductClicked(): void {
        this.dialogHelper.onOpenViewProductDialog(EMPTY);
    }

    /**
     * Method to open View Analysis Attribute from dashboard icon
     * @memberof SideBarComponent
     */
    public onViewAttributeAnalysisClicked(): void {
        const slidePanel = SLIDE_PANEL_DIALOG;
        this.dialog.open(AttributeAnalysisComponent, slidePanel);
    }

    /*
     * Method to call when ingrediant search menu clicked
     * @memberof SideBarComponent
     */
    public onIngrediantSearch(): void {
        this.appBroadCastService.onUpdateAppSpinnerPrompt(LOADING);
        this.sideBarExpSubscription.add(
            this.gridApiService.getIngredientRequestStatus().subscribe({
                next: (status) => {
                    this.previousReplaceRequestPending = status;
                    if (this.previousReplaceRequestPending.isLastRequestPending) {
                        this.checkAndAlertPendingProcess(this.previousReplaceRequestPending);
                    } else {
                        const slidePanel = INGREDIANT_DIALOG;
                        this.dialog.open(IngrediantSearchReplaceComponent, slidePanel);
                    }
                    this.appBroadCastService.onUpdateAppSpinnerPrompt(EMPTY);
                },
            }),
        );
    }

    /**
     * Method to show popup when previous request is pending.
     *
     * @param {{ isLastRequestPending: boolean; oldIPC: string; newIpc: string }} previousRequestPending
     * @return {void} void
     * @memberof onIngrediantSearch
     */
    public checkAndAlertPendingProcess(previousRequestPending: { isLastRequestPending: boolean; oldIPC: string; newIpc: string }): void {
        if (previousRequestPending.isLastRequestPending) {
            const dialogMessage = PREVIOUS_REQUEST;
            dialogMessage.message = `Please wait until your previous request gets processed. <br> <b> '${previousRequestPending.oldIPC}' </b> replacing by <b>'${previousRequestPending.newIpc}' </b>
      <span class="replace-alert"><i class="icon-est-time"></i> Estimated wait time <span class="bold-text"> 24 hours</span></span>`;
            const dialogOptions = PREVIOUS_REQUEST;
            dialogOptions.data = dialogMessage;
            this.dialog.open(ConfirmationDialogComponent, {
                panelClass: PANEL_CLASS,
                width: "540px",
                disableClose: true,
                data: PREVIOUS_REQUEST,
            });
        }
    }

    /**
     * Method to Check and Open the Creative Review
     *
     * @memberof SideBarComponent
     */
    public onCreativeReviewCheck(value: boolean): void {
        let tabName: string;
        if (!value) {
            tabName =
                this.selectedExperiments?.length > 0 ? SUB_MENU_LIST.EXPERIMENT.CREATIVE_REVIEW : SUB_MENU_LIST.EXPERIMENT.REVIEW_HISTORY;
        }
        this.onShowCreativeReviewPopUp(tabName);
    }

    /**
     * Method to publish creative review
     *
     * @memberof SideBarComponent
     */
    public creativeReviewPublish(): void {
        this.appBroadCastService.creativeReview.subscribe((value: boolean) => {
            this.onCreativeReviewCheck(value);
        });
    }

    /**
     * Method to open the creative review drawer
     * @param {string} tabName
     * @memberof SideBarComponent
     */
    public onShowCreativeReviewPopUp(tabName: string): void {
        if (tabName) {
            this.appBroadCastService.onReviewTabChange(tabName);
        }
        const reviewSelectedData = this.creativeReviewHelper.formatReviewSelectedData(this.selectedExperiments);
        this.experimentHelper.openCreativeReviewDialog(reviewSelectedData);
    }

    /**
     * Method to open Open Product / Experiment popup
     * @returns {void}
     * @memberof SideBarComponent
     */
    public onOpenProductClicked(): void {
        const dialogData: BomSearchDialogDataModel = {
            type: SearchType.openProductOrExperiment,
            openedExperimentOrProduct: [],
            fromLandingPage: true,
        };
        const dialogOptions = FULL_SCREEN_POPUP;
        dialogOptions.data = dialogData;
        const dialogReference = this.dialog.open(BomSearchComponent, dialogOptions);
        dialogReference.afterClosed().subscribe((newExperiments: ExperimentsModel[]) => {
            if (newExperiments) {
                this.tabHelper.openExpInNewTab(newExperiments);
            }
        });
    }

    /**
     * Method to open make sample dialog
     * @returns {void}
     * @memberof SideBarComponent
     */
    public onOpenSampleDialog(): void {
        const dialogOptions = CREATE_SAMPLE_POPUP;
        dialogOptions.data = {
            yield: YIELD_VALUES.MAX,
            type: SAMPLE_TYPE.MAKE_SAMPLE,
        };
        this.dialog.open(CreateSampleComponent, CREATE_SAMPLE_POPUP);
    }

    /**
     * Method to open reprint label dialog
     * @returns {void}
     * @memberof SideBarComponent
     */
    public onReprintLabelClicked(): void {
        const slidePanel = REPRINT_LABEL_DIALOG;
        slidePanel.data = {
            type: SAMPLE_TYPE.REPRINT_LABEL,
        };
        this.dialog.open(CreateSampleComponent, slidePanel);
    }

    /**
     * Method to open review comparison popup
     *
     * @returns {void}
     * @memberof SideBarComponent
     */
    public openReviewComparisonPopup(): void {
        this.appBroadCastService.reviewComparison.subscribe((value: boolean) => {
            if (!value) return;
            const reviewSelectedData = this.creativeReviewHelper.formatReviewSelectedData(this.selectedExperiments);
            this.experimentHelper.openReviewListDialog(reviewSelectedData);
        });
    }
}
