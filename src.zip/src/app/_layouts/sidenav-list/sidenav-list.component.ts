/** Angular */
import { Component, Input, EventEmitter, Output } from "@angular/core";

@Component({
    selector: "app-sidenav-list",
    templateUrl: "./sidenav-list.component.html",
})
export class SidenavListComponent {
    /** public members */
    @Input()
    public userProfileInfo: any; /* eslint-disable-line @typescript-eslint/no-explicit-any */

    @Output()
    sidenavClose = new EventEmitter();

    onSidenavClose(): void {
        this.sidenavClose.emit();
    }
}
