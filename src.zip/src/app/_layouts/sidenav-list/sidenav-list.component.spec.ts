import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";

import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { SidenavListComponent } from "./sidenav-list.component";

describe("SidenavListComponent", () => {
    let component: SidenavListComponent;
    let fixture: ComponentFixture<SidenavListComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [SidenavListComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SidenavListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should emit on side navigation close", () => {
        spyOn(component.sidenavClose, "emit");

        component.onSidenavClose();

        expect(component.sidenavClose.emit).toHaveBeenCalled();
    });
});
