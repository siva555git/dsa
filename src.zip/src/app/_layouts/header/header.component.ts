/* eslint-disable max-lines */
/* eslint-disable angular/document-service */
/** Angular */
import { Component, OnInit, Input, EventEmitter, Output, ViewChild, SimpleChanges, Renderer2 } from "@angular/core";
import { NavigationStart, Router } from "@angular/router";

/** Dependencies */
import { NGXLogger } from "ngx-logger";

/** Services */
import { ToastrService } from "ngx-toastr";
import { MatSidenav } from "@angular/material/sidenav";
import { delay } from "lodash";
import { APPLICATION_PERMISSIONS } from "@te-shared/security/security.constant";
import { MatomoAction, MatomoCategory, MatomoLabel } from "../../_shared/enums";
import { AppSettings } from "../../app.settings";
import { AppEnvironment } from "../../../config/app.environment";
import { NotificationHelper } from "../../_shared/components/notification-drawer/helper/notification-helper";
import { TabHelper } from "../../_shared/helpers/tab-helper";
import { AppBroadCastService, AppEventManager, AppStateService, MatomoService, AppDataService } from "../../_services";

/** Enums & Constants */
import { EVENT_CLICKED, THEME_CHANGE } from "../../_shared/constants/event.constant";
import {
    GET_TABS_FAILURE,
    DATE_RANGE_DROPDOWN,
    COLUMN_LAYOUT_HIGH_LIGHT_TIME,
    TITLE_CHANGE_URL_LIST,
    DEFAULT_CURRENCY,
    USER_PREFERENCES_TYPES,
    ADD_TAB,
    REMOVE_TAB,
    TEST_WARNING_MESSAGE,
    EMPTY_VALUES_WARNING_MESSAGE,
    WARNING_MESSAGE,
    STYLE_COLOR_CODE,
    BACKGROUND_PREFERENCE,
} from "../../_shared/constants";
import { NotificationResponse } from "../../_shared/models/notification.model";
import { NotificationDrawerComponent } from "../../_shared/components/notification-drawer/notification-drawer.component";
import { CurrenciesModel } from "../../experiment-editor/models/experiment-editor.model";
import { UserPreferencesHelper } from "../../user-settings/user-settings-components/helper/user-perferences-helper";
import { GeneralPreference } from "../../_shared/models/notification-preferences.model";
import { CurrencyRateModel } from "../../_shared/models/currencies-rate-model";
import { TabsCrudDataModel, WorkSpaces } from "../../_shared/models/create-tab.model";

@Component({
    selector: "app-header",
    templateUrl: "./header.component.html",
})
export class HeaderComponent implements OnInit {
    /** public members */

    public Testdatabase = WARNING_MESSAGE;

    public isThemeDark = false;

    public environment = AppSettings.Env;

    public showBuildTag = AppSettings.config().ShowBuildTag;

    public isFontShift = false;

    public notificationCount = 0; // init value

    public notificationCountValue: number; // init value

    public notificationList: NotificationResponse;

    public highlightCount = false;

    public WarningMessage: string;

    public currentPageTitle = TITLE_CHANGE_URL_LIST.HOME.TITLE;

    public defaultCurrency: string;

    public currencies: CurrenciesModel[];

    public currenciesRate: CurrencyRateModel[];

    public recentTabs: WorkSpaces[] = [];

    public showNotification: boolean;

    public appBrightnessUserPref: GeneralPreference;

    public appBrightnessPayload: GeneralPreference[];

    public appBrightnessControl = BACKGROUND_PREFERENCE;

    public appBrightnessRange = BACKGROUND_PREFERENCE.DEFAULT_BRIGHTNESS_RANGE;

    public applicationPermissions = APPLICATION_PERMISSIONS;

    @Input() public currencyDetails;

    @Input() public currencyRateDetails;

    @Input()
    public userProfileInfo: any; /* eslint-disable-line @typescript-eslint/no-explicit-any */

    @Output()
    public emitNotification = new EventEmitter();

    @ViewChild("notificationDrawer") notificationDrawer: MatSidenav;

    @ViewChild("notificationComponent") notificationComponent: NotificationDrawerComponent;

    constructor(
        private renderer: Renderer2,
        private eventManager: AppEventManager,
        private logger: NGXLogger,
        private matomoService: MatomoService,
        private tabHelperService: TabHelper,
        private readonly toastrService: ToastrService,
        private readonly appBroadCastService: AppBroadCastService,
        private readonly notificationHelper: NotificationHelper,
        public readonly router: Router,
        private readonly userPreferencesHelper: UserPreferencesHelper,
        private readonly appDataService: AppDataService,
    ) {
        this.getDefaultPreferenceValues();
        this.router.events.subscribe((event) => {
            if (event instanceof NavigationStart) {
                this.getCurrentPageTitle(event.url);
            }
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.currencyDetails && changes.currencyDetails.currentValue) {
            this.currencies = changes.currencyDetails.currentValue;
        }
        if (changes.currencyRateDetails && changes.currencyRateDetails.currentValue) {
            this.currenciesRate = changes.currencyRateDetails.currentValue;
        }
    }

    public ngOnInit(): void {
        this.eventManager.subscribe(EVENT_CLICKED, (event) => {
            this.logger.debug(event.args);
            if (event.args.operation.toLowerCase() === "increment") {
                this.notificationCount += 1;
            } else if (event.args.operation.toLowerCase() === "decrement" && this.notificationCount > 0) {
                this.notificationCount -= 1;
            }
        });
        this.notificationHelper.viewAllNotifications(DATE_RANGE_DROPDOWN[2].OneWeek);
        this.viewNotifications();
        this.highlightNotificationCount();
        this.getRecentWorkspace();
        this.appBroadCastService.tabsCrudOperationSubject.subscribe((tabAction: TabsCrudDataModel) => {
            if (tabAction.action === REMOVE_TAB || tabAction.action === ADD_TAB) {
                this.getRecentWorkspace();
            }
        });
        this.setWarningMessage();
    }

    /**
     * Method to ret the recent tabs
     * @returns {void}
     * @memberof HeaderComponent
     */
    public getRecentWorkspace(): void {
        this.tabHelperService.getRecentTabs().subscribe({
            next: (response) => {
                if (response) {
                    this.recentTabs = response;
                }
            },
            error: (error) => {
                this.logger.error(error);
            },
        });
    }

    public setWarningMessage(): void {
        this.WarningMessage =
            this.environment === AppEnvironment.DEV || this.environment === AppEnvironment.QAS
                ? TEST_WARNING_MESSAGE
                : EMPTY_VALUES_WARNING_MESSAGE;
    }

    public loadSelectedTab(userTabID: number): void {
        this.tabHelperService.openRecentTab(userTabID);
    }

    /**
     * Method to setProperty in root for app brightness level inter link with fontShift
     * @returns {void}
     * @memberof HeaderComponent
     */
    public setStyleProperty(rangeLevel: number): void {
        const rangeIndex = (rangeLevel === 0 ? 1 : rangeLevel) - 1;
        const setBackgroundProperty = `${BACKGROUND_PREFERENCE.COLOR_PRIMARY}:${STYLE_COLOR_CODE[rangeIndex].PRIMARY}; ${BACKGROUND_PREFERENCE.COLOR_SECONDARY}:${STYLE_COLOR_CODE[rangeIndex].SECONDARY}; ${BACKGROUND_PREFERENCE.COLOR_TERTIARY}:${STYLE_COLOR_CODE[rangeIndex].TERTIARY};`;
        if (this.isFontShift) {
            this.renderer.setProperty(
                document.body,
                "style",
                `${setBackgroundProperty} --font-xs:12px; --font-sm:14px; --font-md:16px; --font-lg:18px; --font-xl:20px; --font-grid:13px;`,
            );
        } else {
            this.renderer.setProperty(document.body, "style", `${setBackgroundProperty}`);
        }
    }

    /**
     * Method to get the default data are in store
     * @returns {void}
     * @memberof HeaderComponent
     */
    public getDefaultPreferenceValues(): void {
        const userPreference = AppStateService.getUserDefaultPreferenceType();
        userPreference?.forEach((element) => {
            if (element.PrefTypeCode === USER_PREFERENCES_TYPES.CURRENCY_CODE) {
                this.defaultCurrency = element.ColumnValue || DEFAULT_CURRENCY.ColumnValue;
            }
            if (element.PrefTypeCode === BACKGROUND_PREFERENCE.DEFAULT_BRIGHTNESS) {
                this.appBrightnessRange = Number.parseInt(element.ColumnValue ?? BACKGROUND_PREFERENCE.DEFAULT_BRIGHTNESS_VALUE, 10);
                this.appBrightnessUserPref = this.userPreferencesHelper.setUserId(element);
                this.appBrightnessUserPref.UserPrefID = element.UserPrefID ?? undefined;
                this.setStyleProperty(this.appBrightnessRange);
            }
        });
    }

    /**
     * Method to clear the notification count
     *
     * @returns {void}
     * @memberof HeaderComponent
     */
    public clearCount(): void {
        this.notificationCount = 0;
    }

    public toggleDarkTheme(checked: boolean): void {
        this.isThemeDark = checked;
        this.eventManager.broadcast({
            name: THEME_CHANGE,
            isThemeDark: checked,
        });
        this.matomoService.trackEvent(
            MatomoCategory.APP_THEME,
            MatomoAction.THEME_CHANGE,
            this.isThemeDark ? MatomoLabel.DARK_THEME : MatomoLabel.DEFAULT_THEME,
        );
    }

    /**
     * Method to get the opened tabs of the user and update in the tabs list
     * @memberof HeaderComponent
     */
    public loadTabs(): void {
        this.tabHelperService.getOpenedTabs().subscribe({
            next: (response) => {
                if (response) {
                    this.tabHelperService.loadTabs(response.WorkSpace);
                }
            },
            error: (error) => {
                this.logger.error(error);
                this.toastrService.error(GET_TABS_FAILURE);
            },
        });
    }

    /**
     * Method to open notification drawer
     * @memberof HeaderComponent
     */
    public openNotificationCenterDrawer(): void {
        this.showNotification = true;
        delay(() => {
            this.notificationComponent.showLoading = true;
            this.notificationComponent.notificationResult = [];
            this.notificationHelper.viewAllNotifications(DATE_RANGE_DROPDOWN[2].OneWeek);
            this.notificationDrawer.toggle();
            this.notificationComponent.highlightUnreadNotification();
            this.notificationHelper.updateNotifications();
        }, 0);
        this.matomoService.trackEvent(MatomoCategory.PROFILE_SECTION, MatomoAction.CLICK, MatomoLabel.VIEW_ALL_NOTIFICATIONS);
    }

    /**
     * Method to open notification drawer
     * @memberof HeaderComponent
     */
    public closeNotificationDrawer(): void {
        this.notificationDrawer.close();
        this.showNotification = false;
        this.notificationCountValue = 0;
    }

    /**
     * Method to get notifications from broadcast service and send result to notification drawer comp
     * @memberof HeaderComponent
     */
    public viewNotifications(): void {
        this.appBroadCastService.notificationsSubject.subscribe((response) => {
            this.notificationCountValue = response.unReadCount;
            this.notificationList = response.notifications;
            this.highlightNotificationCount();
            if (this.notificationComponent) this.notificationComponent.showLoading = false;
        });
    }

    /**
     * Method to hightlight unread notification
     * @returns {void}
     * @memberof HeaderComponent
     */
    public highlightNotificationCount(): void {
        this.highlightCount = true;
        delay(() => {
            this.highlightCount = false;
        }, COLUMN_LAYOUT_HIGH_LIGHT_TIME);
    }

    /**
     * Method to add class to DOM Font Size Toggle inter link with app Brightness controll
     * @memberof HeaderComponent
     */
    public fontToggle(): void {
        const rangeIndex = (this.appBrightnessRange === 0 ? 1 : this.appBrightnessRange) - 1;
        if (this.isFontShift) {
            this.isFontShift = false;
            this.setStyleProperty(this.appBrightnessRange);
        } else {
            this.renderer.setProperty(
                document.body,
                "style",
                `${BACKGROUND_PREFERENCE.COLOR_PRIMARY}:${STYLE_COLOR_CODE[rangeIndex].PRIMARY};
                ${BACKGROUND_PREFERENCE.COLOR_SECONDARY}:${STYLE_COLOR_CODE[rangeIndex].SECONDARY};
                ${BACKGROUND_PREFERENCE.COLOR_TERTIARY}:${STYLE_COLOR_CODE[rangeIndex].TERTIARY}; --font-xs:12px; --font-sm:14px; --font-md:16px; --font-lg:18px; --font-xl:20px; --font-grid:13px;`,
            );
            this.isFontShift = true;
        }
    }

    /**
     * Method to get the current page title
     *
     * @memberof HeaderComponent
     */
    public getCurrentPageTitle(url: string): void {
        this.currentPageTitle = TITLE_CHANGE_URL_LIST.HOME.TITLE;
        switch (true) {
            case url.includes(TITLE_CHANGE_URL_LIST.COLUMN_LAYOUT.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.COLUMN_LAYOUT.TITLE;
                break;
            }
            case url.includes(TITLE_CHANGE_URL_LIST.EXPERIMENT_ANALYSIS.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.EXPERIMENT_ANALYSIS.TITLE;
                break;
            }
            case url.includes(TITLE_CHANGE_URL_LIST.IPC_SELECTION.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.IPC_SELECTION.TITLE;
                break;
            }
            case url.includes(TITLE_CHANGE_URL_LIST.BOM_VIEW_EVENT_REPORT.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.BOM_VIEW_EVENT_REPORT.TITLE;
                break;
            }
            case url.includes(TITLE_CHANGE_URL_LIST.USER_SETTINGS.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.USER_SETTINGS.TITLE;
                break;
            }
            case url.includes(TITLE_CHANGE_URL_LIST.GRA_COMPLIANCE_REPORT.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.GRA_COMPLIANCE_REPORT.TITLE;
                break;
            }
            case url.includes(TITLE_CHANGE_URL_LIST.INSTRUCTION.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.INSTRUCTION.TITLE;
                break;
            }
            case url.includes(TITLE_CHANGE_URL_LIST.UNAPPROVED.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.UNAPPROVED.TITLE;
                break;
            }
            case url.includes(TITLE_CHANGE_URL_LIST.MY_TASKS.URL): {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.MY_TASKS.TITLE;
                break;
            }
            default: {
                this.currentPageTitle = TITLE_CHANGE_URL_LIST.HOME.TITLE;
                break;
            }
        }
    }

    /**
     * Method to update the app brightness level
     * @returns {void}
     * @memberof HeaderComponent
     */
    public updateAppBrightness(rangeLevel: number): void {
        this.appBrightnessPayload = [];
        this.setStyleProperty(rangeLevel);
        this.appBrightnessUserPref.ColumnValue = `${rangeLevel}`;
        this.appBrightnessPayload.push(this.appBrightnessUserPref);
        this.userPreferencesHelper
            .updateGeneralUserPreferences(this.appDataService.url.defaultuserpreference, this.appBrightnessPayload)
            .subscribe({
                next: (result) => {
                    this.appBrightnessUserPref.UserPrefID = result
                        ? result?.find((userPref) => {
                              return userPref.UserPrefTypeID === BACKGROUND_PREFERENCE.PREFERENCE_TYPEID_BRIGHTNESS;
                          })?.UserPrefID
                        : undefined;
                },
                error: (error) => {
                    this.logger.error(error);
                },
            });
    }
}
