/* eslint-disable @typescript-eslint/no-empty-function */
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";

import { NGXLogger, CustomNGXLoggerService, NGXLoggerConfigEngine } from "ngx-logger";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { RouterTestingModule } from "@angular/router/testing";
import { MatSidenav } from "@angular/material/sidenav";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { cloneDeep } from "lodash";
import { of } from "rxjs";
import { MockAppDataService } from "../../testing/mock-app.data.service";
import { AppEnvironment } from "../../../config/app.environment";
import { TEST_WARNING_MESSAGE, TITLE_CHANGE_URL_LIST } from "../../_shared/constants";
import { UserPreferencesHelper } from "../../user-settings/user-settings-components/helper/user-perferences-helper";
import { MockUserPreferenceHelper } from "../../testing/mock-user-preference-helper.spec";
import { MockMasterDataHelper } from "../../testing/mock-master-data-helper";
import { HeaderComponent } from "./header.component";
import { MatomoService, AppEventManager, AppBroadCastService, AppStateService, AppDataService } from "../../_services";
import { THEME_CHANGE, EVENT_CLICKED } from "../../_shared/constants/event.constant";
import { MatomoCategory } from "../../_shared/enums/matomo-category.enum";
import { MatomoAction } from "../../_shared/enums/matomo-action.enum";
import { MatomoLabel } from "../../_shared/enums/matomo-label.enum";
import { SpyService, callback } from "../../testing/spy.service";
import { MockLoggerService, MockNGXLoggerHttpService, MockLoggerConfig } from "../../testing/mock-logger.service";
import { MockMatomoService } from "../../testing/mock-matomo.service";
import { MockTabHelperService } from "../../testing/mock-tabhelper.service";
import { TabHelper } from "../../_shared/helpers/tab-helper";
import { MockToastrService } from "../../testing/mock-toastr.service";
import { NotificationHelper } from "../../_shared/components/notification-drawer/helper/notification-helper";
import { MockNotificationHelper } from "../../testing/mock-notification.helper";
import { MasterDataHelper } from "../../_shared/master-data/helpers/master-data.helper";
import { NotificationDrawerComponent } from "../../_shared/components/notification-drawer/notification-drawer.component";
import { NgMaterialModule } from "../../material.module";
import { mockAppBrightnessControl } from "../../testing/mock-user-setting-data";
import { MockAppStateService } from "../../testing/mock-app.state.service";
import { AuthorizationDirective } from "@te-shared/security/directives/authorization.directive";
import { SecurityHelper } from "@te-shared/security/helpers/security.helper";
import { FormsModule } from "@angular/forms";

/* eslint-disable-next-line max-lines-per-function */
describe("HeaderComponent", () => {
    let component: HeaderComponent;
    let fixture: ComponentFixture<HeaderComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, NgMaterialModule, BrowserAnimationsModule, FormsModule],
            declarations: [HeaderComponent, AuthorizationDirective],
            providers: [
                {
                    provide: NGXLogger,
                    useClass: MockLoggerService,
                },
                {
                    provide: CustomNGXLoggerService,
                    useClass: MockNGXLoggerHttpService,
                },
                {
                    provide: MatomoService,
                    useClass: MockMatomoService,
                },
                {
                    provide: NGXLoggerConfigEngine,
                    useClass: MockLoggerConfig,
                },
                {
                    provide: TabHelper,
                    useClass: MockTabHelperService,
                },
                {
                    provide: ToastrService,
                    useClass: MockToastrService,
                },
                AppBroadCastService,
                {
                    provide: MasterDataHelper,
                    useClass: MockMasterDataHelper,
                },
                { provide: UserPreferencesHelper, useClass: MockUserPreferenceHelper },
                { provide: NotificationHelper, useClass: MockNotificationHelper },
                { provide: AppStateService, useClass: MockAppStateService },
                { provide: AppDataService, useClass: MockAppDataService },
                SecurityHelper
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HeaderComponent);
        component = fixture.componentInstance;
        const mockNotificationComponent = {
            showLoading: false,
            notificationResult: [],
            // eslint-disable-next-line no-empty-function
            highlightUnreadNotification: () => {},
        } as NotificationDrawerComponent;
        component.notificationComponent = mockNotificationComponent;
        fixture.detectChanges();
    });

    it("should create", () => {
        spyOn(component, "getDefaultPreferenceValues").and.returnValue();
        expect(component).toBeTruthy();
    });

    it("should set warning message when environment is DEV", () => {
        component.environment = AppEnvironment.DEV;
        component.setWarningMessage();
        expect(component.WarningMessage).toBe(TEST_WARNING_MESSAGE);
    });

    it("should set warning message when environment is QAS", () => {
        component.environment = AppEnvironment.QAS;
        component.setWarningMessage();
        expect(component.WarningMessage).toBe(TEST_WARNING_MESSAGE);
    });

    it("should set warning message when environment is OTHERS", () => {
        component.environment = 2;
        component.setWarningMessage();
        expect(component.WarningMessage).toBe("");
    });

    it("should broadcast a notification on item add", () => {
        const initialCount = component.notificationCount;
        const eventService = TestBed.inject(AppEventManager);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();

        eventService.subscribe(EVENT_CLICKED, () => callback(spyService));
        eventService.broadcast({ name: EVENT_CLICKED, args: { operation: "increment" } });

        expect(spyService.called).toBeTruthy();
        expect(component.notificationCount).toBeGreaterThan(initialCount);
    });

    it("should broadcast a notification on item remove", () => {
        const initialCount = component.notificationCount;
        component.notificationCount = -1;
        const eventService = TestBed.inject(AppEventManager);
        const spyService = TestBed.inject(SpyService);
        expect(spyService.called).toBeFalsy();

        eventService.subscribe(EVENT_CLICKED, () => callback(spyService));
        eventService.broadcast({ name: EVENT_CLICKED, args: { operation: "decrement" } });

        expect(spyService.called).toBeTruthy();
        expect(component.notificationCount).toBeLessThan(initialCount);
    });

    it("should clear notification count", () => {
        const initialCount = component.notificationCount;

        component.clearCount();

        expect(initialCount).toEqual(0);
    });

    it("should call closeNotificationDrawer", () => {
        const spy = spyOn(component, "closeNotificationDrawer").and.callThrough();
        const mockDrawer = {
            // eslint-disable-next-line no-empty-function
            close: () => {},
        } as MatSidenav;
        component.notificationDrawer = mockDrawer;
        component.closeNotificationDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should call openNotificationCenterDrawer", () => {
        const spy = spyOn(component, "openNotificationCenterDrawer").and.callThrough();
        const mockDrawer = {
            // eslint-disable-next-line no-empty-function
            toggle: () => {},
        } as MatSidenav;
        const mockNotificationComponent = {
            showLoading: false,
            notificationResult: [],
            // eslint-disable-next-line no-empty-function
            highlightUnreadNotification: () => {},
        } as NotificationDrawerComponent;
        component.notificationDrawer = mockDrawer;
        component.notificationComponent = mockNotificationComponent;
        component.openNotificationCenterDrawer();
        expect(spy).toHaveBeenCalled();
    });

    it("should call loadtabs", () => {
        const spy = spyOn(component, "loadTabs").and.callThrough();
        component.loadTabs();
        expect(spy).toHaveBeenCalled();
    });

    it("should emit on dark theme toggle", () => {
        const matomoService: MatomoService = TestBed.inject(MatomoService);
        const eventManager: AppEventManager = TestBed.inject(AppEventManager);

        spyOn(eventManager, "broadcast");
        spyOn(matomoService, "trackEvent");

        component.toggleDarkTheme(true);

        expect(eventManager.broadcast).toHaveBeenCalledWith({
            name: THEME_CHANGE,
            isThemeDark: true,
        });
        expect(matomoService.trackEvent).toHaveBeenCalledWith(MatomoCategory.APP_THEME, MatomoAction.THEME_CHANGE, MatomoLabel.DARK_THEME);
    });

    it("should emit on get current title", () => {
        const spy = spyOn(component, "getCurrentPageTitle").and.callThrough();
        component.getCurrentPageTitle("home");
        expect(spy).toHaveBeenCalled();
        expect(component.currentPageTitle).toEqual(TITLE_CHANGE_URL_LIST.HOME.TITLE);
    });

    it("should emit on get current title on experiment-analysis url", () => {
        const spy = spyOn(component, "getCurrentPageTitle").and.callThrough();
        component.getCurrentPageTitle("experiment-analysis");
        expect(spy).toHaveBeenCalled();
        expect(component.currentPageTitle).toEqual(TITLE_CHANGE_URL_LIST.EXPERIMENT_ANALYSIS.TITLE);
    });

    it("should emit on get current title on column-layout url", () => {
        const spy = spyOn(component, "getCurrentPageTitle").and.callThrough();
        component.getCurrentPageTitle("column-layout");
        expect(spy).toHaveBeenCalled();
        expect(component.currentPageTitle).toEqual(TITLE_CHANGE_URL_LIST.COLUMN_LAYOUT.TITLE);
    });

    it("should emit on get current title on ipc-selection url", () => {
        const spy = spyOn(component, "getCurrentPageTitle").and.callThrough();
        component.getCurrentPageTitle("ipc-selection");
        expect(spy).toHaveBeenCalled();
        expect(component.currentPageTitle).toEqual(TITLE_CHANGE_URL_LIST.IPC_SELECTION.TITLE);
    });

    it("should emit on get current title on user-settings url", () => {
        const spy = spyOn(component, "getCurrentPageTitle").and.callThrough();
        component.getCurrentPageTitle("user-settings");
        expect(spy).toHaveBeenCalled();
        expect(component.currentPageTitle).toEqual(TITLE_CHANGE_URL_LIST.USER_SETTINGS.TITLE);
    });

    it("should emit on get current title on bom-view-event-report url", () => {
        const spy = spyOn(component, "getCurrentPageTitle").and.callThrough();
        component.getCurrentPageTitle("bom-view-event-report");
        expect(spy).toHaveBeenCalled();
        expect(component.currentPageTitle).toEqual(TITLE_CHANGE_URL_LIST.BOM_VIEW_EVENT_REPORT.TITLE);
    });

    it("should emit on get current title on gra-compliance-report url", () => {
        const spy = spyOn(component, "getCurrentPageTitle").and.callThrough();
        component.getCurrentPageTitle("gra-compliance-report");
        expect(spy).toHaveBeenCalled();
        expect(component.currentPageTitle).toEqual(TITLE_CHANGE_URL_LIST.GRA_COMPLIANCE_REPORT.TITLE);
    });

    it("should call fontToggle if isFontShift is true", () => {
        const spy = spyOn(component, "fontToggle").and.callThrough();
        component.appBrightnessRange = 5;
        component.isFontShift = false;
        component.fontToggle();
        expect(spy).toHaveBeenCalled();
    });

    it("should call fontToggle if isFontShift is false", () => {
        const spy = spyOn(component, "fontToggle").and.callThrough();
        component.appBrightnessRange = 5;
        component.isFontShift = true;
        component.fontToggle();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on getRecentWorkspace", () => {
        const spy = spyOn(component, "getRecentWorkspace").and.callThrough();
        component.getRecentWorkspace();
        expect(spy).toHaveBeenCalled();
    });

    it("should call on setStyleProperty", () => {
        const spy = spyOn(component, "setStyleProperty").and.callThrough();
        component.setStyleProperty(0);
        expect(spy).toHaveBeenCalled();
    });

    it("should call on updateAppBrightness", () => {
        const appBrightnessControlData = cloneDeep(mockAppBrightnessControl);
        const service = TestBed.inject(AppDataService);
        component.appBrightnessUserPref = appBrightnessControlData;
        spyOn(service, "post").and.returnValue(of([appBrightnessControlData]));
        const spy = spyOn(component, "updateAppBrightness").and.callThrough();
        component.updateAppBrightness(5);
        expect(spy).toHaveBeenCalled();
    });
});
